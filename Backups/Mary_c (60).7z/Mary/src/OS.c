#include <stdlib.h>
#include <stdio.h>
#include <Mary/Utils.h>
#include <Mary/Hashmap.h>
#include <Mary/OS.h>
#include <Mary/OpenGL.h>
#include <Mary/Window.h>

MARY_PRIMITIVES;

static void Mary_OpenGL_Start();
static void Mary_OpenGL_Finish();

#if defined(_WIN32)
#pragma comment (lib, "opengl32.lib")
//#pragma comment (lib, "glu32.lib")

#define WGL_DRAW_TO_WINDOW_ARB 0x2001
#define WGL_SUPPORT_OPENGL_ARB 0x2010
#define WGL_DOUBLE_BUFFER_ARB 0x2011
#define WGL_PIXEL_TYPE_ARB 0x2013
#define WGL_COLOR_BITS_ARB 0x2014
#define WGL_DEPTH_BITS_ARB 0x2022
#define WGL_STENCIL_BITS_ARB 0x2023
#define WGL_TYPE_RGBA_ARB 0x202B
#define WGL_SAMPLE_BUFFERS_ARB 0x2041
#define WGL_SAMPLES_ARB 0x2042
#define WGL_CONTEXT_MAJOR_VERSION_ARB 0x2091
#define WGL_CONTEXT_MINOR_VERSION_ARB 0x2092
#define WGL_CONTEXT_PROFILE_MASK_ARB 0x9126
#define WGL_CONTEXT_CORE_PROFILE_BIT_ARB 0x0001
#define WGL_CONTEXT_COMPATIBILITY_PROFILE_BIT_ARB 0x0002

HWND g_hwnd = 0;
HDC g_hdc = 0;
HGLRC g_hglrc = 0;
int g_pixel_format = 0;
const uint16_t win32_class_name[] = u"Mary_Win32";
Mary_Hashmap_t windows;
HDC dib_context;
BITMAPINFO dib_bmi;

BOOL(WINAPI *wglChoosePixelFormatARB)(HDC hdc, const int *attribs_i, const FLOAT *attribs_f, UINT max_count, int *out_format, UINT *out_count);
HGLRC(WINAPI *wglCreateContextAttribsARB)(HDC hdc, HGLRC share_context, const int *attribs_i);
static int64_t WINAPI Win32_Wnd_Proc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp);

static void Mary_OS_Start_OpenGL()
{
  WNDCLASSEX wndclass;
  memset(&wndclass, 0, sizeof(wndclass));
  wndclass.cbSize = sizeof(wndclass);
  wndclass.lpfnWndProc = DefWindowProc;
  wndclass.lpszClassName = u"Mary_OpenGL";
  wndclass.style = CS_OWNDC;
  RegisterClassEx(&wndclass);

  g_hwnd = CreateWindowEx(0,
                          u"Mary_OpenGL",
                          0,
                          0, 0,
                          0, 0,
                          0, 0, 0, 0, 0);
  g_hdc = GetDC(g_hwnd);

  PIXELFORMATDESCRIPTOR pfd;
  memset(&pfd, 0, sizeof(pfd));
  SetPixelFormat(g_hdc, ChoosePixelFormat(g_hdc, &pfd), &pfd);

  g_hglrc = wglCreateContext(g_hdc);
  wglMakeCurrent(g_hdc, g_hglrc);

  HMODULE opengl_dll = LoadLibrary(u"opengl32.dll");

  // Buffer Objects
  glBindBuffer = (void *)wglGetProcAddress("glBindBuffer");
  glBufferData = (void *)wglGetProcAddress("glBufferData");
  glDeleteBuffers = (void *)wglGetProcAddress("glDeleteBuffers");
  glDisableVertexAttribArray = (void *)wglGetProcAddress("glDisableVertexAttribArray");
  glDrawArrays = (void *)GetProcAddress(opengl_dll, "glDrawArrays");
  glDrawElements = (void *)GetProcAddress(opengl_dll, "glDrawElements");
  glEnableVertexAttribArray = (void *)wglGetProcAddress("glEnableVertexAttribArray");
  glGenBuffers = (void *)wglGetProcAddress("glGenBuffers");
  glVertexAttribIPointer = (void *)wglGetProcAddress("glVertexAttribIPointer");
  glVertexAttribPointer = (void *)wglGetProcAddress("glVertexAttribPointer");

  // Rendering
  glClear = (void *)GetProcAddress(opengl_dll, "glClear");
  glClearColor = (void *)GetProcAddress(opengl_dll, "glClearColor");

  // Shaders
  glAttachShader = (void *)wglGetProcAddress("glAttachShader");
  glCompileShader = (void *)wglGetProcAddress("glCompileShader");
  glCreateProgram = (void *)wglGetProcAddress("glCreateProgram");
  glCreateShader = (void *)wglGetProcAddress("glCreateShader");
  glDeleteProgram = (void *)wglGetProcAddress("glDeleteProgram");
  glDeleteShader = (void *)wglGetProcAddress("glDeleteShader");
  glDetachShader = (void *)wglGetProcAddress("glDetachShader");
  glGetShaderiv = (void *)wglGetProcAddress("glGetShaderiv");
  glGetShaderInfoLog = (void *)wglGetProcAddress("glGetShaderInfoLog");
  glGetUniformLocation = (void *)wglGetProcAddress("glGetUniformLocation");
  glLinkProgram = (void *)wglGetProcAddress("glLinkProgram");
  glShaderSource = (void *)wglGetProcAddress("glShaderSource");
  glUniform1i = (void *)wglGetProcAddress("glUniform1i");
  glUniform4f = (void *)wglGetProcAddress("glUniform4f");
  glUniformMatrix4fv = (void *)wglGetProcAddress("glUniformMatrix4fv");
  glUseProgram = (void *)wglGetProcAddress("glUseProgram");
  glValidateProgram = (void *)wglGetProcAddress("glValidateProgram");

  // State Management
  glBlendFunc = (void *)GetProcAddress(opengl_dll, "glBlendFunc");
  glEnable = (void *)GetProcAddress(opengl_dll, "glEnable");
  glGetIntegerv = (void *)GetProcAddress(opengl_dll, "glGetIntegerv");
  glGetError = (void *)GetProcAddress(opengl_dll, "glGetError");
  glPixelStorei = (void *)GetProcAddress(opengl_dll, "glPixelStorei");
  glPolygonMode = (void *)GetProcAddress(opengl_dll, "glPolygonMode");
  glScissor = (void *)GetProcAddress(opengl_dll, "glScissor");
  glViewport = (void *)GetProcAddress(opengl_dll, "glViewport");

  // Textures
  glActiveTexture = (void *)wglGetProcAddress("glActiveTexture");
  glBindTexture = (void *)GetProcAddress(opengl_dll, "glBindTexture");
  glDeleteTextures = (void *)GetProcAddress(opengl_dll, "glDeleteTextures");
  glGenTextures = (void *)GetProcAddress(opengl_dll, "glGenTextures");
  glTexImage2D = (void *)GetProcAddress(opengl_dll, "glTexImage2D");
  glTexParameteri = (void *)GetProcAddress(opengl_dll, "glTexParameteri");

  // Utility
  glGetString = (void *)GetProcAddress(opengl_dll, "glGetString");

  // Vertex Array Objects
  glBindVertexArray = (void *)wglGetProcAddress("glBindVertexArray");
  glDeleteVertexArrays = (void *)wglGetProcAddress("glDeleteVertexArrays");
  glGenVertexArrays = (void *)wglGetProcAddress("glGenVertexArrays");

  // Windows Extensions
  wglChoosePixelFormatARB = (void *)wglGetProcAddress("wglChoosePixelFormatARB");
  wglCreateContextAttribsARB = (void *)wglGetProcAddress("wglCreateContextAttribsARB");

  FreeLibrary(opengl_dll);

  const int pf_attribs[] =
  {
    WGL_DRAW_TO_WINDOW_ARB, GL_TRUE,
    WGL_SUPPORT_OPENGL_ARB, GL_TRUE,
    WGL_DOUBLE_BUFFER_ARB, GL_TRUE,
    WGL_PIXEL_TYPE_ARB, WGL_TYPE_RGBA_ARB,
    WGL_COLOR_BITS_ARB, 32,
    WGL_DEPTH_BITS_ARB, 24,
    WGL_STENCIL_BITS_ARB, 8,
    WGL_SAMPLE_BUFFERS_ARB, 1,
    WGL_SAMPLES_ARB, 4,
    0
  };
  unsigned int num_formats = 0;
  wglChoosePixelFormatARB(g_hdc, pf_attribs, 0, 1, &g_pixel_format, &num_formats);

  wglMakeCurrent(g_hdc, 0);
  wglDeleteContext(g_hglrc);
  ReleaseDC(g_hwnd, g_hdc);
  DestroyWindow(g_hwnd);

  g_hwnd = CreateWindowEx(0,
                          u"Mary_OpenGL",
                          0,
                          0, 0,
                          0, 0,
                          0, 0, 0, 0, 0);
  g_hdc = GetDC(g_hwnd);

  memset(&pfd, 0, sizeof(pfd));
  SetPixelFormat(g_hdc, g_pixel_format, &pfd);

  const int context_attribs[] =
  {
    WGL_CONTEXT_MAJOR_VERSION_ARB, 3,
    WGL_CONTEXT_MINOR_VERSION_ARB, 3,
    WGL_CONTEXT_PROFILE_MASK_ARB, WGL_CONTEXT_CORE_PROFILE_BIT_ARB,
    0
  };
  g_hglrc = wglCreateContextAttribsARB(g_hdc, 0, context_attribs);
  wglMakeCurrent(g_hdc, g_hglrc);

  puts((char *)glGetString(GL_VERSION)); // temp
}

static void Mary_OS_Start_Window()
{
  WNDCLASSEX win32_class;
  memset(&win32_class, 0, sizeof(win32_class));
  win32_class.cbSize = sizeof(win32_class);
  win32_class.lpfnWndProc = Win32_Wnd_Proc;
  win32_class.hCursor = LoadCursor(0, IDC_ARROW);
  win32_class.hbrBackground = CreateSolidBrush(RGB(255, 255, 255));
  win32_class.lpszClassName = win32_class_name;
  win32_class.style = CS_OWNDC;
  RegisterClassEx(&win32_class);
  Mary_Hashmap_Create(&windows, sizeof(HWND), sizeof(Mary_Window_t *));
}

static void Mary_OS_Start_Text()
{
  dib_context = CreateCompatibleDC(g_hdc);
  SetBkColor(dib_context, RGB(0, 0, 0));
  SetTextColor(dib_context, RGB(255, 255, 255));
  memset(&dib_bmi, 0, sizeof(dib_bmi));
  dib_bmi.bmiHeader.biSize = sizeof(dib_bmi.bmiHeader);
  dib_bmi.bmiHeader.biWidth = 0;
  dib_bmi.bmiHeader.biHeight = 0;
  dib_bmi.bmiHeader.biPlanes = 1;
  dib_bmi.bmiHeader.biBitCount = 32;
  dib_bmi.bmiHeader.biCompression = BI_RGB;
  dib_bmi.bmiHeader.biSizeImage = 0;
}

void Mary_OS_Start()
{
  Mary_OS_Start_OpenGL();
  Mary_OS_Start_Window();
  Mary_OS_Start_Text();
}

void Mary_OS_Finish()
{
  ////// Text //////
  DeleteDC(dib_context);

  ////// Window //////
  Mary_Hashmap_Destroy(&windows);

  ////// OpenGL //////
  wglMakeCurrent(g_hdc, 0);
  wglDeleteContext(g_hglrc);
  ReleaseDC(g_hwnd, g_hdc);
  DestroyWindow(g_hwnd);
}

void Mary_OS_Window_Create(Mary_Window_t *window)
{
  HWND hwnd = CreateWindowEx(WS_EX_CLIENTEDGE,
                             win32_class_name,
                             L"Praise Yahweh!",
                             WS_OVERLAPPEDWINDOW,
                             100, 100,
                             800, 600,
                             0, 0, 0, 0);
  window->os.handle = hwnd;
  window->os.context = GetDC(hwnd);
  PIXELFORMATDESCRIPTOR pfd; memset(&pfd, 0, sizeof(pfd));
  SetPixelFormat(window->os.context, g_pixel_format, &pfd);
  Mary_Hashmap_Assign(&windows, &hwnd, &window);
}

void Mary_OS_Window_Destroy(Mary_Window_t *window)
{
  Mary_Hashmap_Erase(&windows, &window->os.handle);
  DeleteObject(window->os.brush);
  ReleaseDC(window->os.handle, window->os.context);
  DestroyWindow(window->os.handle);
}

static int64_t WINAPI Win32_Wnd_Proc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
{
  Mary_Window_t *window = 0; Mary_Hashmap_At(&windows, &hwnd, &window);
  if (!window)
  {
    return DefWindowProc(hwnd, msg, wp, lp);
  }
  else if (msg == WM_CLOSE)
  {
    Mary_Window_Destroy(window);
    return 0;
  }
  else if (msg == WM_SIZE)
  {
    Mary_OS_Window_Measure(window);
    window->is_dirty = 1;
    Mary_Window_Update_Size(window);
    Mary_Window_Update_Positions(window);
    Mary_Window_Render(window);
    return 0;
  }
  else if (msg == WM_MOVE)
  {
    window->is_dirty = 1;
    Mary_Window_Update_Size(window);
    Mary_Window_Update_Positions(window);
    Mary_Window_Render(window);
    return 0;
  }
  else if (msg == WM_ERASEBKGND)
  {
    PAINTSTRUCT ps;
    BeginPaint(hwnd, &ps);
    FillRect(window->os.context, &ps.rcPaint, window->os.brush); // I think instead of brush, we could give it a RGB macro. but this is faster.
    EndPaint(hwnd, &ps);
    return 1;
  }
  else
  {
    return DefWindowProc(hwnd, msg, wp, lp);
  }
}

void Mary_OS_Window_Show(Mary_Window_t *window)
{
  ShowWindow(window->os.handle, SW_NORMAL);
  UpdateWindow(window->os.handle);
}

void Mary_OS_Window_Hide(Mary_Window_t *window)
{
  ShowWindow(window->os.handle, SW_HIDE);
}

void Mary_OS_Window_Measure(Mary_Window_t *window)
{
  RECT rect; GetClientRect(window->os.handle, &rect);

  window->w_margin = (float)rect.right;
  window->h_margin = (float)rect.bottom;
  window->w = window->w_margin - window->margin_l - window->margin_r;
  window->h = window->h_margin - window->margin_t - window->margin_b;
  window->w_pad = window->w - window->pad_l - window->pad_r;
  window->h_pad = window->h - window->pad_t - window->pad_b;

  window->x1 = (float)rect.left + window->margin_l;
  window->x2 = (float)rect.right - window->margin_r;
  window->y1 = (float)rect.top + window->margin_t;
  window->y2 = (float)rect.bottom - window->margin_b;
  window->clip_x1 = window->x1;
  window->clip_x2 = window->x2;
  window->clip_y1 = window->y1;
  window->clip_y2 = window->y2;

  // put the following in its own function, for when we need to actually handle the
  // real size of the os window, to make them fit on screen properly.
  // we don't need to have an outer width on every element, because I think we
  // will only ever need it for the Window_t.
  /*GetWindowRect(window->os.handle, &rect);
  window->outer_w = (uint16_t)(rect.right);
  window->outer_h = (uint16_t)(rect.bottom);*/
}

void Mary_OS_Window_Handle_Messages(Mary_Window_t *window)
{
  MSG msg;
  while (PeekMessage(&msg, window->os.handle, 0, 0, PM_REMOVE))
  {
    TranslateMessage(&msg);
    DispatchMessage(&msg);
  }
}

void Mary_OS_Window_Make_Current(Mary_Window_t *window)
{
  wglMakeCurrent(window->os.context, g_hglrc);
}

void Mary_OS_Window_Swap_Buffers(Mary_Window_t *window)
{
  SwapBuffers(window->os.context);
}

void Mary_OS_Window_Back_Color(Mary_Window_t *window)
{
  DeleteObject(window->os.brush);
  window->os.brush = CreateSolidBrush(RGB(window->back_r * 255, window->back_g * 255, window->back_b * 255));
}

void Mary_OS_Sleep(size_t milliseconds)
{
  Sleep((int)milliseconds);
}

float Mary_OS_Milliseconds()
{
  LARGE_INTEGER freq, count;
  QueryPerformanceFrequency(&freq);
  QueryPerformanceCounter(&count);
  u64 us = count.QuadPart * 1000000 / freq.QuadPart;
  return us / 1000.0f;
}

// need a change font func

void Mary_OS_Textmap_Create(Mary_OS_Textmap_t *textmap, uint16_t *text_data, int text_units)
{
  Mary_Vector_t text; Mary_Vector_Create(&text, sizeof(u16), text_units);
  Mary_Vector_t lines; Mary_Vector_Create(&lines, sizeof(Mary_OS_Textmap_Line_t), 32);

  // we strip \n from text, and measure how many lines, words, and words per line there are
  Mary_OS_Textmap_Line_t line; u64 total_words = 0;
  line.words.units = 0, line.w = 0, line.h = 0, line.user_w = 0, line.user_h = 0;
  MARY_Range(text_data, u16, 0, text_units)
  {
    if (range.val == '\0')
    {
      ++line.words.units, ++total_words;
      Mary_Vector_Push_Back(&lines, &line);
      Mary_Vector_Push_Back(&text, range.ptr);
    }
    else if (range.val == '\n')
    {
      ++line.words.units, ++total_words;
      Mary_Vector_Push_Back(&lines, &line);
      line.words.units = 0, line.w = 0, line.h = 0, line.user_w = 0, line.user_h = 0;
    }
    else if (range.val == ' ')
    {
      ++line.words.units, ++total_words;
      Mary_Vector_Push_Back(&text, range.ptr);
    }
    else
    {
      Mary_Vector_Push_Back(&text, range.ptr);
    }
  }

  // we create the bitmap from the \n-less text to conserve texture space
  int max_line_width = MARY_GL_MAX_TEXTURE_SIZE;
  RECT rect = { 0, 0, max_line_width, 0 }; unsigned int flags = DT_LEFT | DT_NOCLIP | DT_WORDBREAK;
  DrawTextEx(dib_context, text.data, (int)text.units, &rect, flags | DT_CALCRECT, 0);
  HBITMAP dib_bitmap; void *dib_data; int dib_bytes = rect.right * rect.bottom * 4;
  dib_bmi.bmiHeader.biWidth = rect.right;
  dib_bmi.bmiHeader.biHeight = -rect.bottom;
  dib_bmi.bmiHeader.biSizeImage = dib_bytes;
  dib_bitmap = CreateDIBSection(dib_context, &dib_bmi, DIB_RGB_COLORS, &dib_data, 0, 0);
  SelectObject(dib_context, dib_bitmap);
  DrawTextEx(dib_context, text.data, (int)text.units, &rect, flags, 0);

  // we now know how big to create our cache
  Mary_Pool_Create(&textmap->cache, dib_bytes +
                   MARY_Pool_Round(sizeof(Mary_OS_Textmap_Line_t)) * lines.units +
                   MARY_Pool_Round(sizeof(Mary_OS_Textmap_Word_t)) * total_words);

  // set bitmap
  textmap->bitmap = (Mary_Bitmap_t) { 0, dib_bytes, (short)rect.right, (short)rect.bottom, 32 };
  textmap->bitmap.data = Mary_Pool_Allocate(&textmap->cache, dib_bytes);
  memcpy(textmap->bitmap.data, dib_data, dib_bytes);

  // init our first line
  u64 line_idx = 0;
  Mary_OS_Textmap_Line_t *line_ptr = Mary_Vector_Point(&lines, line_idx);
  line_ptr->words.unit = sizeof(Mary_OS_Textmap_Word_t);
  line_ptr->words.bytes = line_ptr->words.units * line_ptr->words.unit;
  line_ptr->words.data = Mary_Pool_Allocate(&textmap->cache, line_ptr->words.bytes);
  line_ptr->words.units = 0;
  float line_y_max = 0;

  // init our first word
  Mary_OS_Textmap_Word_t word; Mary_Slice_t word_slice = { 0, 0 }; u16 *word_data; int word_units;
  float bitmap_x = 0, bitmap_y = 0, bitmap_y_max = 0, norm_w, norm_h;
  MARY_Range(text_data, u16, 0, text_units)
  {
    if (range.val == ' ' || range.val == '\n' || range.val == '\0')
    {
      word_slice.to_exclusive = range.val != '\n' ? range.idx + 1 : range.idx;
      word_data = (u16 *)(text_data) + word_slice.from;
      word_units = (int)(word_slice.to_exclusive - word_slice.from);
      word_slice.from = range.idx + 1;
      rect = (RECT) { 0, 0, max_line_width, 0 };
      DrawTextEx(dib_context, word_data, word_units, &rect, flags | DT_CALCRECT, 0);
      word.w = (float)rect.right;
      word.h = (float)rect.bottom;
      line_ptr->w += word.w;
      norm_w = word.w / textmap->bitmap.width;
      norm_h = word.h / textmap->bitmap.height;
      if (norm_h > bitmap_y_max) bitmap_y_max = norm_h;
      if (word.h > line_y_max) line_y_max = word.h;
      word.x1 = bitmap_x;
      bitmap_x += norm_w;
      if (bitmap_x > 1.0f)
      {
        word.x1 = 0.0f;
        bitmap_x = norm_w;
        bitmap_y += bitmap_y_max;
        bitmap_y_max = 0;
      }
      word.x2 = bitmap_x;
      word.y1 = bitmap_y;
      word.y2 = bitmap_y + norm_h;
      Mary_Vector_Push_Back(&line_ptr->words, &word);
    }

    if (range.val == '\n')
    {
      line_ptr->h = line_y_max;
      ++line_idx;
      line_ptr = Mary_Vector_Point(&lines, line_idx);
      line_ptr->words.unit = sizeof(Mary_OS_Textmap_Word_t);
      line_ptr->words.bytes = line_ptr->words.units * line_ptr->words.unit;
      line_ptr->words.data = Mary_Pool_Allocate(&textmap->cache, line_ptr->words.bytes);
      line_ptr->words.units = 0;
      line_y_max = 0;
    }
  }

  // set lines
  textmap->lines.bytes = lines.units * lines.unit;
  textmap->lines.data = Mary_Pool_Allocate(&textmap->cache, textmap->lines.bytes);
  textmap->lines.unit = lines.unit;
  textmap->lines.units = lines.units;
  memcpy(textmap->lines.data, lines.data, textmap->lines.bytes);

  // cleanup
  DeleteObject(dib_bitmap);
  Mary_Vector_Destroy(&lines);
  Mary_Vector_Destroy(&text);
}

void Mary_OS_Textmap_Destroy(Mary_OS_Textmap_t *textmap)
{
  Mary_Pool_Destroy(&textmap->cache);
}

#elif defined(__linux__)

#define to_be_done

#endif

#pragma once

#include <Mary/Utils.h>

typedef uint64_t Mary_UTF_t;
typedef struct Mary_UTF_8_t Mary_UTF_8_t;
typedef struct Mary_UTF_16_t Mary_UTF_16_t;
typedef uint32_t Mary_UTF_32_t;

struct Mary_UTF_8_t {
    uint8_t a, b, c, d;
    Mary_UTF_32_t code;
    Mary_Size_t units;
};

struct Mary_UTF_16_t {
    uint16_t a, b;
    Mary_UTF_32_t code;
    Mary_Size_t units;
};

void Mary_UTF_Encode_8(Mary_UTF_8_t *utf_8, Mary_UTF_32_t code);
void Mary_UTF_Decode_8(Mary_UTF_8_t *utf_8, uint8_t *ptr);
void Mary_UTF_Decode_8_Reverse(Mary_UTF_8_t *utf_8, uint8_t *ptr);
void Mary_UTF_Encode_16(Mary_UTF_16_t *utf_16, Mary_UTF_32_t code);
void Mary_UTF_Decode_16(Mary_UTF_16_t *utf_16, uint16_t *ptr);
void Mary_UTF_Decode_16_Reverse(Mary_UTF_16_t *utf_16, uint16_t *ptr);

#define MARY_UTF_Code_32_To_Units_8(CODE)
#define MARY_UTF_Code_32_To_Units_16(CODE)
#define MARY_UTF_Ptr_8_To_Units_8(PTR)
#define MARY_UTF_Ptr_16_To_Units_16(PTR)
#define MARY_UTF_Encode_8(UTF_8, CODE, CASE_1, CASE_2, CASE_3, CASE_4)
#define MARY_UTF_Decode_8(UTF_8, PTR)
#define MARY_UTF_Decode_8_Reverse(UTF_8, PTR)
#define MARY_UTF_Encode_16(UTF_16, CODE, CASE_1, CASE_2)
#define MARY_UTF_Decode_16(UTF_16, PTR)
#define MARY_UTF_Decode_16_Reverse(UTF_16, PTR)
#define MARY_UTF_Encode_32(UTF_32, CODE, CASE_1)
#define MARY_UTF_Decode_32(UTF_32, PTR)
#define MARY_UTF_Decode_32_Reverse(UTF_32, PTR)

#include <Mary/Macros/UTF_m.h>

#define MARY_UTF_To_Unit(UTF)\
    ( (UTF) >> 3 )

#define MARY_Unit_To_UTF(UNIT)\
    ( (UNIT) << 3 )

#define MARY_UTF_To_Max_Units(UTF)\
    ( (UTF) == 8 ? 4 : (UTF) == 16 ? 2 : 1 )

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <Mary/Utils.h>
#include <Mary/Vector.h>
#include <Mary/Font.h>

#define intern static

#define SWAP_U16 MARY_SWAP_U16
#define SWAP_U32 MARY_SWAP_U32
#define U16(P) (*(uint16_t *)(P))
#define U32(P) (*(uint32_t *)(P))
#define GET_U16(SWAP, P) ((SWAP) ? SWAP_U16(U16(P)) : U16(P))
#define GET_U32(SWAP, P) ((SWAP) ? SWAP_U32(U32(P)) : U32(P))

#define UNICODE_PLATFORM 0
#define UNICODE_SPEC_DEF 0
#define UNICODE_SPEC_1 1
#define UNICODE_SPEC_BMP 3
#define UNICODE_SPEC_2 4
#define UNICODE_SPEC_VAR 5
#define UNICODE_SPEC_FULL 6
#define UNICODE_LANG_DEF 0

#define MICROSOFT_PLATFORM 3
#define MICROSOFT_SPEC_BMP 1
#define MICROSOFT_LANG_EN_US 0x0409

#define NAME_ID_COPYRIGHT 0
#define NAME_ID_FAMILY 1
#define NAME_ID_SUB 3
#define NAME_ID_UNIQUE 3
#define NAME_ID_FULL 4

void Mary_Font_Create(Mary_Font_t *mary_font, char *file_path);
void Mary_Font_Destroy(Mary_Font_t *mary_font);
intern uint32_t Glyph_Index_Format_12(void *cmap, uint32_t unicode, char swap);

void Mary_Font_Create(Mary_Font_t *mary_font, char *file_path)
{
  Mary_File_t mary_file = Mary_File_Read(file_path);
  uint8_t *p = mary_file.data;
  mary_font->data = p;

  ////// Scalar Type and Endianness
  uint8_t *beginning = p;
  uint32_t scalar_type = U32(p); p += 4;
  char swap =
    scalar_type != 0x74727565 &&
    scalar_type != 0x00010000 &&
    scalar_type != 0x74797031 &&
    scalar_type != 0x4F54544F;
  if (swap)
  {
    scalar_type = SWAP_U32(scalar_type);
  }
  char should_stop =
    scalar_type != 0x74727565 &&
    scalar_type != 0x00010000 &&
    scalar_type != 0x74797031 &&
    scalar_type != 0x4F54544F;
  if (should_stop)
  {
    Mary_Exit_Failure("Mary_Font_Create: I don't think this is a ttf or otf file.");
  }

  ////// All Table Locations
  uint16_t num_tables = GET_U16(swap, p); p += 8;
  Mary_Hashmap_t *tables = &mary_font->tables;
  Mary_Hashmap_Create(tables, 5, sizeof(p));
  char tag[5]; memset(tag, 0, 5);
  for (int i = 0; i < num_tables; ++i)
  {
    memcpy(tag, p, 4); p += 8;
    uint32_t offset = GET_U32(swap, p); p += 8;
    uint8_t *table_start = beginning + offset;
    Mary_Hashmap_Insert(tables, tag, &table_start);
    //printf("%s: %p\n", tag, table_start); // temp
  }

  ////// 'name' Table
  {
    uint8_t *p; Mary_Hashmap_At(tables, "name", &p);
    uint8_t *beginning = p; p += 2;
    uint16_t strings_count = GET_U16(swap, p); p += 2;
    uint16_t strings_offset = GET_U16(swap, p); p += 2;
    char has_name = 0; char has_copyright = 0;
    for (int i = 0; i < strings_count; ++i)
    {
      uint16_t platform_id = GET_U16(swap, p); p += 2;
      uint16_t specific_id = GET_U16(swap, p); p += 2;
      uint16_t language_id = GET_U16(swap, p); p += 2;
      uint16_t name_id = GET_U16(swap, p); p += 2;
      uint16_t length = GET_U16(swap, p); p += 2;
      uint16_t offset = GET_U16(swap, p); p += 2;
      //printf("platform:%i specific:%i language:%i name:%i length:%i offset:%i\n", platform_id, specific_id, language_id, name_id, length, offset); // temp
      char is_target =
        (platform_id == UNICODE_PLATFORM &&
        specific_id == UNICODE_SPEC_DEF &&
        language_id == UNICODE_LANG_DEF) ||
        (platform_id == MICROSOFT_PLATFORM &&
        specific_id == MICROSOFT_SPEC_BMP &&
        language_id == MICROSOFT_LANG_EN_US);
      if (is_target)
      {
        if (!has_name && name_id == NAME_ID_FULL || !has_copyright && name_id == NAME_ID_COPYRIGHT)
        {
          Mary_Vector_t v_string;
          Mary_Vector_Create(&v_string, 2, 32);
          uint8_t *p2 = beginning + strings_offset + offset;
          uint16_t codepoint;
          for (int j = 0; j < length; j +=2)
          {
            codepoint = GET_U16(swap, p2); p2 += 2;
            Mary_Vector_Push_Back(&v_string, &codepoint);
          }
          codepoint = 0; Mary_Vector_Push_Back(&v_string, &codepoint);
          Mary_Vector_Fit(&v_string);
          if (name_id == NAME_ID_FULL)
          {
            has_name = 1;
            mary_font->name = v_string.data;
          }
          else
          {
            has_copyright = 1;
            mary_font->copyright = v_string.data;
          }
        }
      }
    }
  }

  ////// 'cmap' table
  {
    uint8_t *p; Mary_Hashmap_At(&mary_font->tables, "cmap", &p);
    uint8_t *beginning = p;
    uint16_t version = GET_U16(swap, p); p += 2;
    uint16_t num_tables = GET_U16(swap, p); p += 2;
    uint8_t *cmap = 0;
    for (int i = 0; i < num_tables; ++i)
    {
      uint16_t platform = GET_U16(swap, p); p += 2;
      uint16_t encoding = GET_U16(swap, p); p += 2;
      uint32_t offset = GET_U32(swap, p); p += 4;
      //printf("platform:%i, encoding:%i, offset:%i\n", platform, encoding, offset);
      if (platform == UNICODE_PLATFORM && encoding == UNICODE_SPEC_2)
      {
        cmap = beginning + offset;
        uint16_t format = GET_U16(swap, cmap);
        printf("format: %i\n", format);
        printf("'a' is index: %i (I think.)\n", Glyph_Index_Format_12(cmap, 'a', swap));
        break;//
      }
      // add more types. can use a hash map for cmaps. key would be format
    }
    if (!cmap)
    {
      Mary_Exit_Failure("Mary_Font_Create: couldn't find a good cmap.");
    }
  }
}

void Mary_Font_Destroy(Mary_Font_t *mary_font)
{
  free(mary_font->data);
  Mary_Hashmap_Destroy(&mary_font->tables);
  free((void *)mary_font->name);
  free((void *)mary_font->copyright);
}

intern uint32_t Glyph_Index_Format_12(uint8_t *cmap, uint32_t unicode, char swap)
{
  uint8_t *p = cmap; p += 4;
  uint32_t length = GET_U32(swap, p); p += 8;
  uint32_t num_groups = GET_U32(swap, p); p += 4;
  uint32_t glyph_code = 0;
  for (size_t i = 0; i < num_groups; ++i)
  {
    uint32_t char_start_code = GET_U32(swap, p); p += 4;
    uint32_t char_end_code = GET_U32(swap, p); p += 4;
    uint32_t glyph_start_code = GET_U32(swap, p); p += 4;
    //printf("start:%i...end:%i\n", char_start_code, char_end_code);
    if (unicode < char_start_code)
    {
      break;
    }
    else if (unicode > char_end_code)
    {
      continue;
    }
    else if (unicode == char_start_code)
    {
      glyph_code = glyph_start_code;
      break;
    }
    else if (unicode == char_end_code)
    {
      glyph_code = char_end_code - char_start_code + glyph_start_code;
      break;
    }
    else
    {
      uint32_t char_mid_code = char_start_code + 1;
      while (unicode != char_mid_code) ++char_mid_code;
      glyph_code = char_mid_code - char_start_code + glyph_start_code;
      break;
    }
  }
  return glyph_code;
}

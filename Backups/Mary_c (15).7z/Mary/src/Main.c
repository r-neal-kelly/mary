#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <Mary/Mary.h>

int main()
{
  //Mary_Start();

#if 0
  Mary_Window_t window;
  Mary_Window_Create(&window);
  while (Mary_Window_Can_Render())
  {
    Mary_Window_Render();
  }
  Mary_Window_Destroy(&window);
#endif

  Mary_Font_t quivira;
  Mary_Font_Create(&quivira, "Quivira.otf");
  wprintf(L"%s\n", quivira.name);
  wprintf(L"%s\n", quivira.copyright);
  Mary_Font_Destroy(&quivira);

  puts("");

  /*Mary_Font_t ezra_sr;
  Mary_Font_Create(&ezra_sr, "SILEOTSR.ttf");
  wprintf(L"%s\n", ezra_sr.name);
  wprintf(L"%s\n", ezra_sr.copyright);
  Mary_Font_Destroy(&ezra_sr);*/

  Mary_Exit_Success();

  //Mary_Finish();
}

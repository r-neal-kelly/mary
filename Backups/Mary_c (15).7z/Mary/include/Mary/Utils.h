#pragma once

#include <stdint.h>

#define MARY_SWAP_U16(I)   \
(                          \
  (I) >> 8 & 0x00FF |      \
  (I) << 8 & 0xFF00        \
)

#define MARY_SWAP_U32(I)   \
(                          \
  (I) >> 24 & 0x000000FF | \
  (I) >> 8  & 0x0000FF00 | \
  (I) << 8  & 0x00FF0000 | \
  (I) << 24 & 0xFF000000   \
)

void Mary_Exit_Success();
void Mary_Exit_Failure(const char *error_string);

typedef struct
{
  void *data;
  size_t size;
}
Mary_File_t;
Mary_File_t Mary_File_Read(const char *file_path);
void Mary_File_Destroy(Mary_File_t *mary_file);

uint8_t *Mary_UTF8_Encode(uint32_t *text);
uint32_t *Mary_UTF8_Decode(uint8_t *text);
uint16_t *Mary_UTF16_Encode(uint32_t *text);
uint32_t *Mary_UTF16_Decode(uint16_t *text);
uint16_t *Mary_UTF8_To_UTF16(uint8_t *text);

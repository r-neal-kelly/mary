#pragma once

#include <stddef.h>

void Mary_Bitbool_Assign(void *bitbool, size_t bitbool_size, size_t bit_index, char boolean);
char Mary_Bitbool_At(void *bitbool, size_t bitbool_size, size_t bit_index);
void Mary_Bitbool_Fill(void *bitbool, size_t bitbool_size, char boolean);
void Mary_Bitbool_Print(void *bitbool, size_t bitbool_size);

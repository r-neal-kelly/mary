#pragma once

#include <stdint.h>
#include <Mary/Hashmap.h>

typedef struct
{
  void *data;
  Mary_Hashmap_t tables;
  const uint16_t *name;
  const uint16_t *copyright;
}
Mary_Font_t;

void Mary_Font_Create(Mary_Font_t *mary_font, char *file_path);
void Mary_Font_Destroy(Mary_Font_t *mary_font);

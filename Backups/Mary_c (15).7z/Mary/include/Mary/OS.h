#pragma once

#if defined(_WIN32)
  #define WIN32_LEAN_AND_MEAN
  #define UNICODE
  #include <Windows.h>
  #pragma comment (lib, "opengl32.lib")
  //#pragma comment (lib, "glu32.lib")
#elif defined(__linux__)
  #define tbd
#endif

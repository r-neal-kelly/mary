#include <stdio.h>
#include <string.h>
#include <Mary/OpenGL.h>
#include <Mary/Element.h>
#include <Mary/Window.h>
#include <Mary/Div.h>
#include <Mary/Text.h>

MARY_PRIMITIVES;

typedef void (*Render_f)(void *);

Mary_Hashmap_t type_sizes; // these can just be a vector of structs!!! our type can be the index.
Mary_Hashmap_t render_funcs;
// instead of having multiple hashmaps, better make a generic object.
// it should have the size of the type, the render func, and other funcs too.
// I want to call Mary_Element_Back_Color on a window and have it just do this extra stuff.
// if an element doesn't have that extra feature, then it should be set to zero.
// there could be problems though, since they will have to be public pointers. Recursive probs.
// this might be getting too close to object oriented.

void Mary_Element_Start()
{
  #define ASSIGN_TYPE_SIZE(TYPE, TYPE_NAME)\
    type = TYPE, size = sizeof(TYPE_NAME), Mary_Hashmap_Assign(&type_sizes, &type, &size)

  #define ASSIGN_RENDER_FUNC(TYPE, RENDER_FUNC)\
    type = TYPE, Render = RENDER_FUNC, Mary_Hashmap_Assign(&render_funcs, &type, &Render)

  size_t type, size;
  Mary_Hashmap_Create(&type_sizes, sizeof(size_t), sizeof(size_t));
  ASSIGN_TYPE_SIZE(MARY_ELEMENT_WINDOW, Mary_Window_t);
  ASSIGN_TYPE_SIZE(MARY_ELEMENT_DIV, Mary_Div_t);
  ASSIGN_TYPE_SIZE(MARY_ELEMENT_TEXT, Mary_Text_t);

  Render_f Render;
  Mary_Hashmap_Create(&render_funcs, sizeof(size_t), sizeof(Render_f));
  ASSIGN_RENDER_FUNC(MARY_ELEMENT_WINDOW, Mary_Window_Render);
  ASSIGN_RENDER_FUNC(MARY_ELEMENT_DIV, Mary_Div_Render);
  ASSIGN_RENDER_FUNC(MARY_ELEMENT_TEXT, Mary_Text_Render);

  #undef ASSIGN_TYPE_SIZE
  #undef ASSIGN_RENDER_FUNC
}

void Mary_Element_Finish()
{
  Mary_Hashmap_Destroy(&type_sizes);
  Mary_Hashmap_Destroy(&render_funcs);
}

void Mary_Element_Create(void *mary_element, size_t type)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  size_t type_size; Mary_Hashmap_At(&type_sizes, &type, &type_size);
  memset(element, 0, type_size);
  element->type = type;
  if (type == MARY_ELEMENT_WINDOW) element->window = MARY_Window(element);
  Mary_Vector_Create(&element->children_s, sizeof(Mary_Element_t *), 0);
  Mary_Vector_Create(&element->children_z, sizeof(Mary_Element_t *), 0);
  Mary_Vector_Create(&element->events, sizeof(Mary_Event_t *), 0);
  Mary_Hashmap_Create(&element->listeners, sizeof(Mary_Element_t *), sizeof(u64));
  element->display = MARY_ELEMENT_DISPLAY_LINE;
  element->unit_w = MARY_ELEMENT_UNIT_FIT_PARENT;
  element->unit_h = MARY_ELEMENT_UNIT_FIT_CHILDREN;
  element->back_a = 1, element->fore_a = 1, element->border_a = 1;
  element->overflow = MARY_ELEMENT_OVERFLOW_Y;
}

void Mary_Element_Destroy(void *mary_element)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  size_t type_size; Mary_Hashmap_At(&type_sizes, &element->type, &type_size);
  Mary_Vector_Destroy(&element->children_s);
  Mary_Vector_Destroy(&element->children_z);
  Mary_Vector_Destroy(&element->events);
  Mary_Hashmap_Destroy(&element->listeners);
  memset(element, 0, type_size); // may just want to memset the element size here?
}

typedef struct { float w, h; } Size; // I think we have this in utils. but it's not official yet.

static Size Compute_Children(Mary_Element_t *parent)
{
  // should probable rename 'left' to x1, and 'top' to y1
  float last_x1 = parent->x1 + parent->pad_l, first_x1 = last_x1, max_x1 = last_x1;
  float right = parent->x2 - parent->pad_r;
  float last_y1 = parent->y1 + parent->pad_t, first_y1 = last_y1;
  float bottom = parent->y2 - parent->pad_b;

  if (parent->overflow == MARY_ELEMENT_OVERFLOW_Y)
  {
    last_y1 -= parent->scroll_y, first_y1 = last_y1;
    bottom -= parent->scroll_y;
  }
  else if (parent->overflow == MARY_ELEMENT_OVERFLOW_X)
  {
    last_x1 -= parent->scroll_x, first_x1 = last_x1, max_x1 = last_x1;
    right -= parent->scroll_x;
  }
  else if (parent->overflow == MARY_ELEMENT_OVERFLOW_XY)
  {
    last_x1 -= parent->scroll_x, first_x1 = last_x1, max_x1 = last_x1;
    right -= parent->scroll_x;
    last_y1 -= parent->scroll_y, first_y1 = last_y1;
    bottom -= parent->scroll_y;
  }

  MARY_Vector_Each(&parent->children_s, Mary_Element_t *)
  {
    Mary_Element_t *child = range.val;

    if (child->display == MARY_ELEMENT_DISPLAY_NONE)
    {
      child->x1 = 0, child->x2 = 0, child->y1 = 0, child->y2 = 0; continue;
    }

    Size children; b64 have_children = 0;

    if (child->unit_w == MARY_ELEMENT_UNIT_FIT_PARENT)
    {
      child->x1 = last_x1 + child->margin_l;
      child->x2 = right - child->margin_r;
      child->w = child->x2 - child->x1;
      last_x1 = right;
    }
    else if (child->unit_w == MARY_ELEMENT_UNIT_FIT_CHILDREN)
    {
      if (!have_children)
      {
        child->x1 = last_x1 + child->margin_l;
        child->x2 = right - child->margin_r;
        child->y1 = last_y1 + child->margin_t;
        child->y2 = bottom - child->margin_b;
        children = Compute_Children(child); have_children = 1;
      }
      child->w = child->pad_l + children.w + child->pad_r;
      child->x2 = child->x1 + child->w;
      last_x1 += child->x2 + child->margin_r;
    }
    else if (child->unit_w == MARY_ELEMENT_UNIT_PIXEL)
    {
      child->x1 = last_x1 + child->margin_l;
      child->x2 = child->x1 + child->w;
      last_x1 += child->x2 + child->margin_r;
    }
    else if (child->unit_w == MARY_ELEMENT_UNIT_PERCENT)
    {

    }

    if (child->unit_h == MARY_ELEMENT_UNIT_FIT_PARENT)
    {
      child->y1 = last_y1 + child->margin_t;
      child->y2 = bottom - child->margin_b;
      child->h = child->y2 - child->y1;
    }
    else if (child->unit_h == MARY_ELEMENT_UNIT_FIT_CHILDREN)
    {
      if (!have_children)
      {
        child->y1 = last_y1 + child->margin_t;
        child->y2 = bottom - child->margin_b;
        children = Compute_Children(child); have_children = 1;
      }
      child->h = child->pad_t + children.h + child->pad_b;
      child->y2 = child->y1  + child->h;
    }
    else if (child->unit_h == MARY_ELEMENT_UNIT_PIXEL)
    {
      child->y1 = last_y1 + child->margin_t;
      child->y2 = child->y1 + child->h;
    }
    else if (child->unit_h == MARY_ELEMENT_UNIT_PERCENT)
    {

    }

    float inner_height = child->h - child->pad_t - child->pad_b;
    if (!have_children)
    {
      children = Compute_Children(child), have_children = 1;
    }
    child->scroll_y_max = (children.h <= inner_height) ? 0 : children.h - inner_height;

    if (child->display == MARY_ELEMENT_DISPLAY_LINE)
    {
      if (last_x1 > max_x1)
      {
        max_x1 = last_x1;
      }
      last_x1 = parent->x1 + parent->pad_l;
      last_y1 = child->y2 + child->margin_b;
    }
    else if (child->display == MARY_ELEMENT_DISPLAY_INLINE_LOOSE)
    {
      if (child->overflow == MARY_ELEMENT_OVERFLOW_NONE || child->overflow == MARY_ELEMENT_OVERFLOW_Y)
      {
        if (last_x1 >= right)
        {
          last_x1 = parent->x1 + parent->pad_l;
          last_y1 += 0; // this needs to increase by the largest child's height? not sure...
          MARY_Range_Regress(1);
        }
      }
    }
  }

  return (Size) { max_x1, last_y1 - first_y1 };
}

static u64 Clip(Mary_Element_t *elem)
{
  float top = elem->parent->dyna_y1 + elem->parent->dyna_pad_t;
  float bottom = elem->parent->dyna_y2 - elem->parent->dyna_pad_b;

  if (bottom <= top || elem->y1 >= bottom || elem->y2 <= top) return 1; // full clip
  
  elem->dyna_y1 = (elem->y1 < top) ? top : elem->y1;
  elem->dyna_y2 = (elem->y2 > bottom) ? bottom : elem->y2;
  float dyna_pad_t = elem->pad_t - (elem->dyna_y1 - elem->y1);
  float dyna_pad_b = elem->pad_b - (elem->y2 - elem->dyna_y2);
  elem->dyna_pad_t = (dyna_pad_t < 0) ? 0 : dyna_pad_t;
  elem->dyna_pad_b = (dyna_pad_b < 0) ? 0 : dyna_pad_b;

  //float parent_w = elem->parent->dyna_x2 - elem->parent->dyna_x1;
  float parent_h = elem->parent->dyna_y2 - elem->parent->dyna_y1;

  glScissor((GLint)(elem->parent->x1 + elem->parent->pad_l),
            (GLint)(elem->window->h - elem->parent->dyna_y2 + elem->parent->dyna_pad_b),
            (GLuint)(elem->parent->w - elem->parent->pad_l - elem->parent->pad_r),
            (GLuint)(parent_h - elem->parent->dyna_pad_t - elem->parent->dyna_pad_b));
  return 0;
}

static void Render_Children(Mary_Element_t *parent)
{
  Render_f Render;
  MARY_Vector_Each(&parent->children_z, Mary_Element_t *)
  {
    // we do need to do a check if we are to even deal with overflow, somewhere.
    if (!Clip(range.val))
    {
      Mary_Hashmap_At(&render_funcs, &range.val->type, &Render);
      Render(range.val);
      Render_Children(range.val);
    }
  }
}

void Mary_Element_Compute_Children(Mary_Window_t *window)
{
  // this allows for the Window_t contraint and also
  // for quicker recursion, it doesn't have to cast each time.
  Compute_Children(MARY_Element(window));
}

void Mary_Element_Render_Children(Mary_Window_t *window)
{
  Render_Children(MARY_Element(window));
}

static void Mary_Element_Window(Mary_Element_t *element, Mary_Window_t *window)
{
  element->window = window;
  MARY_Vector_Each(&element->children_s, Mary_Element_t *)
  {
    Mary_Element_Window(range.val, window);
  }
}

void Mary_Element_Append_To(void *mary_element, void *mary_element_parent)
{
  #define LAST_CHILD_Z(PARENT_PTR)\
    (*(Mary_Element_t **)Mary_Vector_Point(&PARENT_PTR->children_z, PARENT_PTR->children_z.units - 1))

  Mary_Element_t *element = MARY_Element(mary_element);
  Mary_Element_t *parent = MARY_Element(mary_element_parent);

  ////// remove from old parent
  if (element->parent != 0)
  {
    MARY_Vector_Each(&element->parent->children_s, Mary_Element_t *)
    {
      if (range.val == element)
      {
        Mary_Vector_Erase_At(&element->parent->children_s, range.idx); break;
      }
    }
    MARY_Vector_Each(&element->parent->children_z, Mary_Element_t *)
    {
      if (range.val == element)
      {
        Mary_Vector_Erase_At(&element->parent->children_z, range.idx); break;
      }
    }
    Mary_Window_Flag_Dirty(element->window);
  }

  ////// add to new parent
  Mary_Vector_Push_Back(&parent->children_s, &element);
  if (parent->children_z.units == 0)
  {
    Mary_Vector_Push_Back(&parent->children_z, &element);
  }
  else if (LAST_CHILD_Z(parent)->z <= element->z)
  {
    Mary_Vector_Push_Back(&parent->children_z, &element);
  }
  else
  {
    MARY_Vector_Each(&parent->children_z, Mary_Element_t *)
    {
      if (range.val->z > element->z)
      {
        Mary_Vector_Push_At(&parent->children_z, range.idx, &element);
      }
    }
  }
  Mary_Element_Window(element, parent->window);
  Mary_Window_Flag_Dirty(element->window);
  element->parent = parent;

  #undef LAST_CHILD_Z
}

void Mary_Element_Remove(void *mary_element)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  if (element->parent != 0)
  {
    MARY_Vector_Each(&element->parent->children_s, Mary_Element_t *)
    {
      if (range.val == element)
      {
        Mary_Vector_Erase_At(&element->parent->children_s, range.idx); break;
      }
    }
    MARY_Vector_Each(&element->parent->children_z, Mary_Element_t *)
    {
      if (range.val == element)
      {
        Mary_Vector_Erase_At(&element->parent->children_z, range.idx); break;
      }
    }
    Mary_Window_Flag_Dirty(element->window);
    Mary_Element_Window(element, 0);
    element->parent = 0;
  }
}

void Mary_Element_Size(void *mary_element, float w, float h)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  element->w = w, element->h = h;
}

void Mary_Element_Unit_Size(void *mary_element, int unit_w, int unit_h)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  element->unit_w = unit_w, element->unit_h = unit_h;
  // we shouldn't allow this to change window_t...
  // makes me think we should have these funcs in each of their own types...
}

void Mary_Element_Back_Color(void *mary_element, float r, float g, float b, float a)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  element->back_r = r, element->back_g = g, element->back_b = b, element->back_a = a;
}

void Mary_Element_Fore_Color(void *mary_element, float r, float g, float b, float a)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  element->fore_r = r, element->fore_g = g, element->fore_b = b, element->fore_a = a;
}

void Mary_Element_Border_Color(void *mary_element, float r, float g, float b, float a)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  element->border_r = r, element->border_g = g, element->border_b = b, element->border_a = a;
}

void Mary_Element_Margin(void *mary_element, float l, float t, float r, float b)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  element->margin_l = l, element->margin_t = t, element->margin_r = r, element->margin_b = b;
}

void Mary_Element_Padding(void *mary_element, float l, float t, float r, float b)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  element->pad_l = l, element->pad_t = t, element->pad_r = r, element->pad_b = b;
}

void Mary_Element_Scroll_By(void *mary_element, float scroll_y_by)
{
  Mary_Element_t *elem = MARY_Element(mary_element);
  float scroll_y = elem->scroll_y + scroll_y_by;

  if (scroll_y < 0)
  {
    scroll_y = 0;
  }
  else if (scroll_y > elem->scroll_y_max)
  {
    scroll_y = elem->scroll_y_max;
  }

  if (elem->scroll_y != scroll_y)
  {
    elem->scroll_y = scroll_y;
    Mary_Window_Flag_Dirty(elem->window);
  }
}

void Mary_Element_Scroll_To(void *mary_element, float scroll_y_to)
{
  Mary_Element_t *elem = MARY_Element(mary_element);

  if (scroll_y_to < 0)
  {
    scroll_y_to = 0;
  }
  else if (scroll_y_to > elem->scroll_y_max)
  {
    scroll_y_to = elem->scroll_y_max;
  }

  if (elem->scroll_y != scroll_y_to)
  {
    elem->scroll_y = scroll_y_to;
    Mary_Window_Flag_Dirty(elem->window);
  }
}

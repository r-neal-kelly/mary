#include <Mary/Mary.h>

void Mary_Start()
{
  Mary_OS_Start();
  Mary_OpenGL_Start();
  Mary_GL_Texture_Start();
  Mary_Element_Start();
  Mary_Window_Start();
  Mary_Div_Start();
  Mary_Text_Start();
}

void Mary_Finish()
{
  Mary_Text_Finish();
  Mary_Div_Finish();
  Mary_Window_Finish();
  Mary_Element_Finish();
  Mary_GL_Texture_Finish();
  Mary_OpenGL_Finish();
  Mary_OS_Finish();
}

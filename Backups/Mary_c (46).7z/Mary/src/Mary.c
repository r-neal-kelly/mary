#include <Mary/Mary.h>

void Mary_Start()
{
  Mary_OpenGL_Start();
  Mary_OS_Start();
  Mary_Window_Start();
  Mary_Text_Start();
}

void Mary_Finish()
{
  Mary_Text_Finish();
  Mary_Window_Finish();
  Mary_OS_Start();
  Mary_OpenGL_Finish();
}

﻿#include <stdio.h>
#include <stdlib.h>
#include <Mary/Mary.h>

MARY_PRIMITIVES;

void List(units)
{
  Mary_List_t list; Mary_List_Create(&list, sizeof(int), 8);
  for (int i = 0; i < units; ++i) Mary_List_Push_Back(&list, &i);
  //MARY_List_Each(list, int) printf("%llu %i\n", range.idx, range.val);
  MARY_List_Each(list, int) 0;
  Mary_List_Destroy(&list);
}

void List2(units)
{
  Mary_List_t list; Mary_List_Create(&list, sizeof(int), 8);
  for (int i = 0; i < units; ++i) Mary_List_Push_Back(&list, &i);
  //MARY_List_Each(list, int) printf("%llu %i\n", range.idx, range.val);
  for (Mary_Link_t *link = list.front; link != 0; link = link->next) 0;
  Mary_List_Destroy(&list);
}

void Vector(units)
{
  Mary_Vector_t vector; Mary_Vector_Create(&vector, sizeof(int), 8);
  for (int i = 0; i < units; ++i) Mary_Vector_Push_Back(&vector, &i);
  MARY_Vector_Each(vector, int) 0;
  Mary_Vector_Destroy(&vector);
}

int main()
{
#if 0
  Mary_Start();

  Mary_Window_t window;
  Mary_Window_Create(&window);
  while (Mary_Window_Can_Render())
  {
    Mary_Window_Render();
  }
  Mary_Window_Destroy(&window);

  Mary_Finish();
  Mary_Exit_Success();
#endif

#if 1
  MARY_Benchmark(List(1000000), 6);
  MARY_Benchmark(List2(1000000), 6);
  MARY_Benchmark(Vector(1000000), 6);
#endif

#if 0
  Mary_Regex_Start();

  #define PRINT_MATCHES(MATCHES)                                                         \
    MARY_Range(MATCHES.data, Mary_Slice_t, 0, MATCHES.units)                             \
      printf("from: %llu to_exclusive: %llu\n", range.val.from, range.val.to_exclusive);

  if (1)
  {
    Mary_Regex_t regex; Mary_Vector_t matches;

    //MARY_Benchmark(Mary_Regex_Create(&regex, 32, U"(?<[1-9]+z+)a", "g"), 1);
    //MARY_Benchmark(matches = Mary_Regex_Execute(&regex, 32, U"a12zzzza 5zza a"), 12);

    //MARY_Benchmark(Mary_Regex_Create(&regex, 32, U"b(?>12+3?)", "g"), 1);
    //MARY_Benchmark(matches = Mary_Regex_Execute(&regex, 32, U"b122222bdb123ba"), 12);

    //MARY_Benchmark(Mary_Regex_Create(&regex, 32, U"~:Hebrew Char:", "g"), 1);
    //MARY_Benchmark(matches = Mary_Regex_Execute(&regex, 32, U"Ἄνθρωπος בְּרֵאשִׁ֖ית בָּרָ֣א πρὸς πάντα"), 12);

    //MARY_Benchmark(Mary_Regex_Create(&regex, 32, U"^a$", "gm"), 1);
    //MARY_Benchmark(matches = Mary_Regex_Execute(&regex, 32, U"a\na"), 12);

    //MARY_Benchmark(Mary_Regex_Create(&regex, 32, U"a{3,2}", "g"), 1);
    //MARY_Benchmark(matches = Mary_Regex_Execute(&regex, 32, U"aaaaa"), 12);

    MARY_Benchmark(Mary_Regex_Create(&regex, 32, U"~:Latin:+", "g"), 1);
    MARY_Benchmark(matches = Mary_Regex_Execute(&regex, 32, U"abc"), 12);

    PRINT_MATCHES(matches);

    Mary_Vector_Destroy(&matches); Mary_Regex_Destroy(&regex);
  }

  if (0)
  {
    Mary_Regex_t _1, _2, _3, _4; Mary_Vector_t v_1, v_2, v_3, v_4;
    u32 *bound_test = U"This is a misty island.";
                       "01234567891111111111222";
                       "          0123456789012";
    MARY_Benchmark(Mary_Regex_Create(&_1, 32, U"~bis~b", "g"), 1);
    MARY_Benchmark(Mary_Regex_Create(&_2, 32, U"~bis~B", "g"), 1);
    MARY_Benchmark(Mary_Regex_Create(&_3, 32, U"~Bis~b", "g"), 1);
    MARY_Benchmark(Mary_Regex_Create(&_4, 32, U"~Bis~B", "g"), 1); printf("\n");
    MARY_Benchmark(v_1 = Mary_Regex_Execute(&_1, 32, bound_test), 12);
    MARY_Benchmark(v_2 = Mary_Regex_Execute(&_2, 32, bound_test), 12);
    MARY_Benchmark(v_3 = Mary_Regex_Execute(&_3, 32, bound_test), 12);
    MARY_Benchmark(v_4 = Mary_Regex_Execute(&_4, 32, bound_test), 12); printf("\n");
    PRINT_MATCHES(v_1); PRINT_MATCHES(v_2); PRINT_MATCHES(v_3); PRINT_MATCHES(v_4);
    MARY_Vector_Destroy(v_1); MARY_Vector_Destroy(v_2); MARY_Vector_Destroy(v_3); MARY_Vector_Destroy(v_4);
    Mary_Regex_Destroy(&_1); Mary_Regex_Destroy(&_2); Mary_Regex_Destroy(&_3); Mary_Regex_Destroy(&_4);
  }

  #undef PRINT_MATCHES

  Mary_Regex_Finish();
#endif

  Mary_Exit_Success();
}

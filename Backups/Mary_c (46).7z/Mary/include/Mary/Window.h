#pragma once

#include <stdint.h>
#include <Mary/OS.h>
#include <Mary/Hashmap.h>
#include <Mary/List.h>
#include <Mary/Element.h>

typedef struct
{
  Mary_Element_t element;
  Mary_List_t z_indices; // renders will this list in order from lowest to highest z coord.
  HWND win32_hwnd; // might want to make this more cross platform.
  HDC win32_hdc;
  char flags;
  uint16_t inner_width, inner_height;
  uint16_t outer_width, outer_height;
}
Mary_Window_t;

void Mary_Window_Start();
void Mary_Window_Finish();
char Mary_Window_Can_Render();
void Mary_Window_Render();
void Mary_Window_Create(Mary_Window_t *window);
void Mary_Window_Destroy(Mary_Window_t *window);
void Mary_Window_Close(Mary_Window_t *window);
void Mary_Window_Show(Mary_Window_t *window);
void Mary_Window_Hide(Mary_Window_t *window);

void Mary_Window_Append(Mary_Window_t *window, Mary_Element_t *element);
void Mary_Window_Append_To(Mary_Window_t *window, Mary_Element_t *element);
void Mary_Window_Listen(Mary_Window_t *window, Mary_Element_t *element, uint64_t event_flags);

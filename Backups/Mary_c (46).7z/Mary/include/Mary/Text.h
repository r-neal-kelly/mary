#pragma once

#include <stdint.h>
#include <Mary/OS.h>
#include <Mary/String.h>
#include <Mary/Element.h>

typedef struct
{
  Mary_Element_t element;
  Mary_String_t string;
  Mary_Wordmap_v lines;
  float x, y;
  float w, h; // maybe should be int? at least for this type? not sure.
  float r, g, b, a;
  unsigned int texture;
  // will prob need a height to know how far to move vertically.
  // maybe want to attach font details here. we could let fonts be inlined instead, like html.
}
Mary_Text_t;

void Mary_Text_Start();
void Mary_Text_Finish();
void Mary_Text_Create(Mary_Text_t *mary_text, char bit_format, void *string, size_t opt_size, float width, float height);
void Mary_Text_Create_With(Mary_Text_t *mary_text, Mary_String_t *mary_string);
void Mary_Text_Destroy(Mary_Text_t *mary_text);
//void Mary_Text_Change(Mary_Text_t *mary_text, uint16_t *text);
void Mary_Text_Render(Mary_Text_t *mary_text, Mary_Matrix_4x4f *projection);
void Mary_Text_Position(Mary_Text_t *mary_text, float x, float y);
void Mary_Text_Size(Mary_Text_t *mary_text, float w, float h);
void Mary_Text_Color(Mary_Text_t *mary_text, float r, float g, float b, float a);

#pragma once

#include <stdint.h>
#include <Mary/Vector.h>
#include <Mary/Hashmap.h>

enum
{
  MARY_ELEMENT_WINDOW,
  MARY_ELEMENT_TEXT
};

enum
{
  MARY_EVENT_KEYBOARD,
  MARY_EVENT_MOUSE
};

typedef struct
{
  char type;
  void *window;
  void *parent;
  Mary_Vector_t children;
  Mary_Vector_t events;
  Mary_Hashmap_t listeners; // this would be better as a map that I can go through...is not a map type simply a hash with a vector? maybe that would be enough...
  // maybe will want a ptr back to the main struct?
}
Mary_Element_t;

typedef Mary_Vector_t Mary_Element_v;

typedef struct
{
  const int type; // once we know the type, we convert to one of the below.
}
Mary_Event_t;

typedef struct
{
  const int type;
  const float x, y;
  const float w_out, h_out;
  const float w_in, h_in;
}
Mary_Event_Change;

typedef struct
{
  const int type;
  const uint32_t key;
}
Mary_Event_Keyboard;

typedef struct
{
  const int type;
  const uint8_t button;
}
Mary_Event_Mouse;

// when we have events, we make these global objects and put them on a pool.
// then we send out Mary_Event_t's in each elem's event queue, but then point
// to the real events in the pool. this way everyone is getting the same information.
// it may be a little slower this way though. but once the pool is in the cache, every other
// even it easy to access locally.

void Mary_Element_Create(Mary_Element_t *element, char type);
void Mary_Element_Destroy(Mary_Element_t *element);
void Mary_Element_Window(Mary_Element_t *element, void *mary_window);
void Mary_Element_Parent(Mary_Element_t *element, Mary_Element_t *parent);

#define MARY_Element_Each(ELEMENT)\
  MARY_Vector_Each(ELEMENT.children, Mary_Element_t)

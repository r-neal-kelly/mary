#pragma once

#include <Mary/Utils.h>
#include <Mary/Allocator.h>
#include <Mary/Vector.h>
#include <Mary/Pool.h>

#define MARY_Arena_Thread_Bytes 0x300000
#define MARY_Arena_Reserve_Frames 8
#define MARY_Arena_Reserve_Allocs_Per_Frame 8

enum Mary_Arena_Zone_e
{
  MARY_ARENA_FRAME = MARY_FRAME,
  MARY_ARENA_CHAIN = MARY_CHAIN,
  MARY_ARENA_ERROR = MARY_ERROR
};

typedef struct Mary_Arena_t Mary_Arena_t;
typedef void *Mary_Arena_Frame_id; // consider casting to u64

struct Mary_Arena_t
{
  Mary_Pool_t *pool;
  Mary_Vector_t frames;
};

void Mary_Arena_Start();
void Mary_Arena_Stop();
void Mary_Arena_Create();
void Mary_Arena_Destroy();
Mary_Arena_Frame_id Mary_Arena_Push();
void Mary_Arena_Pop(Mary_Arena_Frame_id frame_id);
void *Mary_Arena_Alloc_Frame(Mary_Arena_Frame_id frame_id, Mary_Size_t bytes);
void *Mary_Arena_Alloc_Chain(Mary_Arena_Frame_id frame_id, Mary_Size_t bytes);
void *Mary_Arena_Alloc_Error(Mary_Arena_Frame_id frame_id, Mary_Size_t bytes);
void Mary_Arena_Dealloc_Frame(Mary_Arena_Frame_id frame_id, void *data);
void Mary_Arena_Dealloc_Chain(Mary_Arena_Frame_id frame_id, void *data);
void *Mary_Arena_Alloc(Mary_Enum_t zone, Mary_Arena_Frame_id frame_id, Mary_Size_t bytes);
void Mary_Arena_Dealloc(Mary_Enum_t zone, Mary_Arena_Frame_id frame_id, void *data);
void Mary_Arena_Chain(Mary_Arena_Frame_id frame_id, void *data);
void Mary_Arena_Save(); // I think it would be useful to have a way to get data out of pool to user's location. eg if a lib function returns a chain, but the user wants to keep it.
void Mary_Arena_Empty(); // clears the entire allocation both in pool and in heap.

#define MARY_Arena_In\
  MARY_Allocator_Enum;\
  const Mary_Arena_Frame_id MARY_ARENA_FRAME_ID = Mary_Arena_Push()

#define MARY_Arena_Out\
  Mary_Arena_Pop(MARY_ARENA_FRAME_ID)

#define MARY_Arena_Return\
  MARY_Arena_Out; return

#define MARY_Arena_Chain(DATA)\
  Mary_Arena_Chain(MARY_ARENA_FRAME_ID, DATA)

#define MARY_Arena_Chain_Return(DATA)\
  MARY_Arena_Chain(DATA); MARY_Arena_Return DATA

#define MARY_Arena_Alloc(ENUM, BYTES)\
(\
  ENUM == FRAME ? Mary_Arena_Alloc_Frame(MARY_ARENA_FRAME_ID, BYTES) :\
  ENUM == CHAIN ? Mary_Arena_Alloc_Chain(MARY_ARENA_FRAME_ID, BYTES) :\
  ENUM == ERROR ? Mary_Arena_Alloc_Error(MARY_ARENA_FRAME_ID, BYTES) :\
  ENUM == HEAP ? Mary_Alloc(BYTES) :\
  (MARY_Assert(0, "Invalid allocator"), 0)\
)

#define MARY_Arena_Dealloc(ENUM, BYTES)\
(\
  ENUM == HEAP ? Mary_Dealloc(BYTES) :\
  ENUM == CHAIN ? Mary_Arena_Dealloc_Chain(MARY_ARENA_FRAME_ID, BYTES) :\
  ENUM == FRAME ? Mary_Arena_Dealloc_Frame(MARY_ARENA_FRAME_ID, BYTES) :\
  (MARY_Assert(0, "Invalid allocator"), 0)\
)

// just an idea
#define MARY_Arena_Remember MARY_Arena_In
#define MARY_Arena_Forget MARY_Arena_Out

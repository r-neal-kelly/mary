#pragma once

#include <Mary/Utils.h>
#include <Mary/Allocator.h>

#define MARY_Vector_t\
  MARY_Pointer_t;\
  Mary_Size_t unit;\
  Mary_Size_t units

typedef struct
{
  MARY_Vector_t;
}
Mary_Vector_t;

void Mary_Vector_Create(Mary_Vector_t *this, Mary_Allocator_t allocator, Mary_Size_t unit, Mary_Size_t opt_reserve_units);
void Mary_Vector_Create_At(Mary_Vector_t *this, Mary_p *at_ptr, Mary_Size_t at_unit);
void Mary_Vector_Create_With(Mary_Vector_t *this, Mary_p *with_ptr, Mary_Size_t with_unit, Mary_Size_t opt_with_units);
void Mary_Vector_Destroy(Mary_Vector_t *this);
void Mary_Vector_Reserve(Mary_Vector_t *this, Mary_Size_t units);
void Mary_Vector_Fit(Mary_Vector_t *this);
void Mary_Vector_Push(Mary_Vector_t *this, void *in_elem);
void Mary_Vector_Pop(Mary_Vector_t *this, void *out_elem);
void Mary_Vector_Push_At(Mary_Vector_t *this, Mary_Index_t idx, void *in_elem);
void Mary_Vector_Pop_At(Mary_Vector_t *this, Mary_Index_t idx, void *out_elem);

#define MARY_Vector(NAME, ALLOCATOR, TYPE, OPT_RESERVE_UNITS)
#define MARY_Vector_Stack(NAME, TYPE, UNITS)
#define MARY_Vector_Create(NAME, ALLOCATOR, TYPE, OPT_RESERVE_UNITS)
#define MARY_Vector_Create_At(NAME, AT_DATA, AT_BYTES, AT_ALLOCATOR, AT_TYPE)
#define MARY_Vector_Create_With(NAME, WITH_DATA, WITH_BYTES, WITH_ALLOCATOR, WITH_TYPE, WITH_UNITS)
#define MARY_Vector_Create_Stack(NAME, TYPE, UNITS)
#define MARY_Vector_Cast(THIS)
#define MARY_Vector_Has_At(THIS, IDX)
#define MARY_Vector_Is_Empty(THIS)
#define MARY_Vector_Point(THIS, IDX)
#define MARY_Vector_Point_Front(THIS)
#define MARY_Vector_Point_Back(THIS)
#define MARY_Vector_At(THIS, TYPE, IDX)
#define MARY_Vector_At_Front(THIS, TYPE)
#define MARY_Vector_At_Back(THIS, TYPE)
#define MARY_Vector_Push(THIS, TYPE, ITEM)
#define MARY_Vector_Pop(THIS, TYPE)
#define MARY_Vector_Empty(THIS)
#define MARY_Vector_Each(THIS, TYPE)
#define MARY_Vector_Each_Reverse(THIS, TYPE)

#include <Mary/Macros/Vector_m.h>

// I think we should separate what we use from ones we don't and reorganize. above this line, we have reviewed each function.

void Mary_Vector_Repurpose(Mary_Vector_t *this, size_t unit, size_t opt_units);
void Mary_Vector_Repurpose_With(Mary_Vector_t *this, Mary_p *ptr, size_t ptr_unit, size_t ptr_units);
void Mary_Vector_Copy(Mary_Vector_t *this, Mary_Vector_t *out_copy);
void Mary_Vector_Add_Slice(Mary_Vector_t *this, size_t from, size_t to_exclusive, void *opt_in_elems);
void Mary_Vector_Delete_Slice(Mary_Vector_t *this, size_t from, size_t to_exclusive);
void Mary_Vector_Copy_Slice(Mary_Vector_t *this, size_t from, size_t to_exclusive, void *out_elems);
void Mary_Vector_Take_Slice(Mary_Vector_t *this, size_t from, size_t to_exclusive, void *out_elems);
void Mary_Vector_Put_Slice(Mary_Vector_t *this, size_t from, size_t to_exclusive, void *in_elems);
void Mary_Vector_At(Mary_Vector_t *this, size_t index, void *out_elem);
void Mary_Vector_At_Front(Mary_Vector_t *this, void *out_elem);
void Mary_Vector_At_Back(Mary_Vector_t *this, void *out_elem);
void *Mary_Vector_Point_Push_Back(Mary_Vector_t *this);
void *Mary_Vector_Point_Pop_Back(Mary_Vector_t *this);
void Mary_Vector_Fill(Mary_Vector_t *this, void *in_elem);
Mary_Index_t Mary_Vector_Index_Of(Mary_Vector_t *this, void *elem, char *out_was_found);
Mary_Index_t Mary_Vector_Index_Of_Reverse(Mary_Vector_t *this, void *elem, Mary_Bool_t *out_was_found);
void Mary_Vector_Erase_At(Mary_Vector_t *this, size_t index);
void Mary_Vector_Erase(Mary_Vector_t *this, void *elem);
//void Mary_Vector_Sort(Mary_Vector_t *this);

#undef Vector_t

#undef Vector_Create
#undef Vector_Destroy
#undef Vector_Push

#undef VECTOR_Cast
#undef VECTOR_Point
#undef VECTOR_Point_Back
#undef VECTOR_At
#undef VECTOR_At_Back
#undef VECTOR_Each
#undef VECTOR_Empty

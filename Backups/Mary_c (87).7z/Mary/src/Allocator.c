#include <stdlib.h>
#include <Mary/Allocator.h>
#include <Mary/Pool.h>
#include <Mary/Arena.h>

MARY_Primitives;
MARY_Allocator_Enum;

const Mary_Pool_t *MARY_ALLOCATOR_POOLS;

void *Mary_Allocator_Alloc(Mary_Allocator_t allocator, Mary_Size_t bytes)
{
  if (allocator == FRAME || allocator == CHAIN || allocator == ERROR)
  {
    return Mary_Arena_Alloc(allocator, 0, bytes);
  }
  else if (allocator < STACK)
  {
    return Mary_Pool_Alloc(&((Mary_Pool_t *)MARY_ALLOCATOR_POOLS)[allocator], bytes);
  }
  else if (allocator == MARY_HEAP)
  {
    return Mary_Alloc(bytes);
  }
  else if (allocator == MARY_STACK)
  {
    MARY_Assert(0, "Cannot alloc on the stack."); return 0;
  }
  else
  {
    MARY_Assert(0, "Invalid alloc."); return 0;
  }
}

void *Mary_Allocator_Calloc(Mary_Allocator_t allocator, Mary_Size_t unit, Mary_Size_t units)
{
  if (allocator == FRAME || allocator == CHAIN || allocator == ERROR)
  {
    //return Mary_Arena_Calloc(allocator, 0, unit, units);
    return 0;
  }
  else if (allocator < STACK)
  {
    //return Mary_Pool_Calloc(&((Mary_Pool_t *)MARY_ALLOCATOR_POOLS)[allocator], unit, units);
    return 0;
  }
  else if (allocator == MARY_HEAP)
  {
    return Mary_Calloc(unit, units);
  }
  else if (allocator == MARY_STACK)
  {
    MARY_Assert(0, "Cannot calloc on the stack."); return 0;
  }
  else
  {
    MARY_Assert(0, "Invalid calloc."); return 0;
  }
}

void *Mary_Allocator_Realloc(Mary_Allocator_t allocator, void *data, Mary_Size_t bytes)
{
  if (allocator == FRAME || allocator == CHAIN || allocator == ERROR)
  {
    //return Mary_Arena_Realloc(allocator, 0, data, bytes);
    return 0;
  }
  else if (allocator < STACK)
  {
    return Mary_Pool_Realloc(&((Mary_Pool_t *)MARY_ALLOCATOR_POOLS)[allocator], data, bytes);
  }
  else if (allocator == MARY_HEAP)
  {
    return Mary_Realloc(data, bytes);
  }
  else if (allocator == MARY_STACK)
  {
    MARY_Assert(0, "Cannot realloc on the stack."); return 0;
  }
  else
  {
    MARY_Assert(0, "Invalid realloc."); return 0;
  }
}

void Mary_Allocator_Dealloc(Mary_Allocator_t allocator, void *data)
{
  if (allocator == FRAME || allocator == CHAIN || allocator == ERROR)
  {
    Mary_Arena_Dealloc(allocator, 0, data);
  }
  else if (allocator < STACK)
  {
    Mary_Pool_Dealloc(&((Mary_Pool_t *)MARY_ALLOCATOR_POOLS)[allocator], data);
  }
  else if (allocator == MARY_HEAP)
  {
    Mary_Dealloc(data);
  }
  else if (allocator == MARY_STACK)
  {
    MARY_Assert(0, "Cannot dealloc on the stack.");
  }
  else
  {
    MARY_Assert(0, "Invalid dealloc.");
  }
}

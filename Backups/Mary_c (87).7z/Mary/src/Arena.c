#include <Mary/OS.h>
#include <Mary/Hashmap.h>
#include <Mary/Arena.h>

MARY_Primitives;

#define TRY_AVAILABLE_FRAME(FRAME)\
  MARY_Assert(FRAME != 0, "No frame available.")

#define TRY_AVAILABLE_CHAIN(CHAIN)\
  MARY_Assert(CHAIN != 0, "No chain available.")

#define TRY_INVALID_FRAME(FRAME, FRAME_ID)\
  FRAME_ID ? MARY_Assert(FRAME == FRAME_ID, "Invalid frame_id. Check for an unpopped frame.") : 0

typedef struct
{
  Mary_Vector_t allocs;
  Mary_Vector_t errors;
}
Mary_Arena_Frame_t;

static Mary_Hashmap_t global_arenas;

void Mary_Arena_Start()
{
  Mary_Hashmap_Create(&global_arenas, sizeof(u64), sizeof(Mary_Arena_t));
  Mary_Arena_Create(MARY_Arena_Thread_Bytes);
}

void Mary_Arena_Stop()
{
  Mary_Arena_Destroy();
  Mary_Hashmap_Destroy(&global_arenas);
}

void Mary_Arena_Create(Mary_Size_t bytes)
{
  u64 arena_id = Mary_OS_Thread_Current_ID();
  MARY_Assert(!Mary_Hashmap_Contains_Key(&global_arenas, &arena_id),
              "Thread's arena already created.");
  Mary_Arena_t arena;
  arena.pool = Mary_Pool_Create(bytes);
  Mary_Vector_Create(&arena.frames, arena.pool->id, sizeof(Mary_Arena_Frame_t), MARY_Arena_Reserve_Frames);
  Mary_Hashmap_Assign(&global_arenas, &arena_id, &arena);
}

void Mary_Arena_Destroy()
{
  u64 arena_id = Mary_OS_Thread_Current_ID();
  MARY_Assert(Mary_Hashmap_Contains_Key(&global_arenas, &arena_id),
              "Thread's arena never created.");
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

  MARY_Assert(arena->frames.units == 0, "There are still unpopped frames.");
  Mary_Vector_Destroy(&arena->frames);
  Mary_Pool_Destroy(arena->pool);

  Mary_Hashmap_Erase(&global_arenas, &arena_id);
}

Mary_Arena_Frame_id Mary_Arena_Push()
{
  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

  Mary_Arena_Frame_t *frame = Mary_Vector_Point_Push_Back(&arena->frames);
  Mary_Vector_Create(&frame->allocs, arena->pool->id, sizeof(void *), MARY_Arena_Reserve_Allocs_Per_Frame);
  Mary_Vector_Create(&frame->errors, arena->pool->id, sizeof(Mary_Error_t *), 1);
  return MARY_Vector_Point_Back(&arena->frames);
}

void Mary_Arena_Pop(Mary_Arena_Frame_id frame_id)
{
  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

  Mary_Arena_Frame_t *frame = Mary_Vector_Point_Pop_Back(&arena->frames);

  TRY_AVAILABLE_FRAME(frame);
  TRY_INVALID_FRAME(frame, frame_id);
  MARY_Assert(frame->errors.units == 0, "Unhandled error in arena!");

  MARY_Vector_Each(&frame->allocs, void *)
  {
    if (Mary_Pool_Has_Data(arena->pool, it.val))
    {
      Mary_Pool_Dealloc(arena->pool, it.val);
    }
    else
    {
      Mary_Dealloc(it.val);
    }
  }
  Mary_Vector_Destroy(&frame->allocs);

  MARY_Vector_Each(&frame->errors, void *)
  {
    if (Mary_Pool_Has_Data(arena->pool, it.val))
    {
      Mary_Pool_Dealloc(arena->pool, it.val);
    }
    else
    {
      Mary_Dealloc(it.val);
    }
  }
  Mary_Vector_Destroy(&frame->errors);
}

// should we assert in these when the data ptr is null?
void *Mary_Arena_Alloc_Frame(Mary_Arena_Frame_id frame_id, Mary_Size_t bytes)
{
  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

  Mary_Arena_Frame_t *frame = MARY_Vector_Point_Back(&arena->frames);

  TRY_AVAILABLE_FRAME(frame);
  TRY_INVALID_FRAME(frame, frame_id);

  void *data;

  if (Mary_Pool_Has_Free(arena->pool, bytes))
  {
    data = Mary_Pool_Alloc(arena->pool, bytes);
  }
  else
  {
    data = Mary_Alloc(bytes);
  }

  MARY_Assert(data != 0, "Out of memory.");

  Mary_Vector_Push(&frame->allocs, &data);

  return data;
}

void *Mary_Arena_Alloc_Chain(Mary_Arena_Frame_id frame_id, Mary_Size_t bytes)
{
  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

  Mary_Arena_Frame_t *frame = MARY_Vector_Point_Back(&arena->frames);
  Mary_Arena_Frame_t *chain = MARY_Vector_Point(&arena->frames, arena->frames.units - 2); // we're not checking bounds on points! need to fix this somehow.

  TRY_AVAILABLE_FRAME(frame);
  TRY_AVAILABLE_CHAIN(chain);
  TRY_INVALID_FRAME(frame, frame_id);

  void *data;

  if (Mary_Pool_Has_Free(arena->pool, bytes))
  {
    data = Mary_Pool_Alloc(arena->pool, bytes);
  }
  else
  {
    data = Mary_Alloc(bytes);
  }

  MARY_Assert(data != 0, "Out of memory.");

  Mary_Vector_Push(&chain->allocs, &data);

  return data;
}

void *Mary_Arena_Alloc_Error(Mary_Arena_Frame_id frame_id, Mary_Size_t bytes)
{
  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

  Mary_Arena_Frame_t *frame = MARY_Vector_Point_Back(&arena->frames);
  Mary_Arena_Frame_t *chain = MARY_Vector_Point(&arena->frames, arena->frames.units - 2);

  TRY_AVAILABLE_FRAME(frame);
  TRY_AVAILABLE_CHAIN(chain);
  TRY_INVALID_FRAME(frame, frame_id);

  void *data;

  if (Mary_Pool_Has_Free(arena->pool, bytes))
  {
    data = Mary_Pool_Alloc(arena->pool, bytes);
  }
  else
  {
    data = Mary_Alloc(bytes);
  }

  MARY_Assert(data != 0, "Out of memory.");

  Mary_Vector_Push(&chain->errors, &data);

  return data;
}

void Mary_Arena_Dealloc_Frame(Mary_Arena_Frame_id frame_id, void *data)
{
  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

  Mary_Arena_Frame_t *frame = MARY_Vector_Point_Back(&arena->frames);

  TRY_AVAILABLE_FRAME(frame);
  TRY_INVALID_FRAME(frame, frame_id);

  Mary_Bool_t was_found; Mary_Index_t idx =
    Mary_Vector_Index_Of_Reverse(&frame->allocs, &data, &was_found);

  MARY_Assert(was_found == MARY_TRUE, "Couldn't find pointer.");

  Mary_Vector_Erase_At(&frame->allocs, idx);

  if (Mary_Pool_Has_Data(arena->pool, data))
  {
    Mary_Pool_Dealloc(arena->pool, data);
  }
  else
  {
    Mary_Dealloc(data);
  }
}

void Mary_Arena_Dealloc_Chain(Mary_Arena_Frame_id frame_id, void *data)
{
  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

  Mary_Arena_Frame_t *frame = MARY_Vector_Point_Back(&arena->frames);
  Mary_Arena_Frame_t *chain = MARY_Vector_Point(&arena->frames, arena->frames.units - 2);

  TRY_AVAILABLE_FRAME(frame);
  TRY_AVAILABLE_CHAIN(chain);
  TRY_INVALID_FRAME(frame, frame_id);

  Mary_Bool_t was_found; Mary_Index_t idx =
    Mary_Vector_Index_Of_Reverse(&chain->allocs, &data, &was_found);

  MARY_Assert(was_found == MARY_TRUE, "Couldn't find pointer.");

  Mary_Vector_Erase_At(&chain->allocs, idx);

  if (Mary_Pool_Has_Data(arena->pool, data))
  {
    Mary_Pool_Dealloc(arena->pool, data);
  }
  else
  {
    Mary_Dealloc(data);
  }
}

void *Mary_Arena_Alloc(Mary_Enum_t zone, Mary_Arena_Frame_id frame_id, Mary_Size_t bytes)
{
  if (zone == MARY_ARENA_FRAME)
  {
    return Mary_Arena_Alloc_Frame(frame_id, bytes);
  }
  else if (zone == MARY_ARENA_CHAIN)
  {
    return Mary_Arena_Alloc_Chain(frame_id, bytes);
  }
  else if (zone == MARY_ARENA_ERROR)
  {
    return Mary_Arena_Alloc_Error(frame_id, bytes);
  }
  else
  {
    MARY_Assert(0, "Invalid zone.");
    return 0;
  }
}

void Mary_Arena_Dealloc(Mary_Enum_t zone, Mary_Arena_Frame_id frame_id, void *data)
{
  if (zone == MARY_ARENA_CHAIN)
  {
    Mary_Arena_Dealloc_Chain(frame_id, data);
  }
  else if (zone == MARY_ARENA_FRAME)
  {
    Mary_Arena_Dealloc_Frame(frame_id, data);
  }
  else
  {
    MARY_Assert(0, "Invalid zone.");
  }
}

void Mary_Arena_Chain(Mary_Arena_Frame_id frame_id, void *data)
{
  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

  Mary_Arena_Frame_t *frame = MARY_Vector_Point_Back(&arena->frames);
  Mary_Arena_Frame_t *chain = MARY_Vector_Point(&arena->frames, arena->frames.units - 2);

  TRY_AVAILABLE_FRAME(frame);
  TRY_AVAILABLE_CHAIN(chain);
  TRY_INVALID_FRAME(frame, frame_id);

  Mary_Bool_t was_found; Mary_Index_t idx =
    Mary_Vector_Index_Of_Reverse(&frame->allocs, &data, &was_found);

  MARY_Assert(was_found == MARY_TRUE, "Couldn't find pointer.");

  Mary_Vector_Erase_At(&frame->allocs, idx);

  Mary_Vector_Push(&chain->allocs, &data);
}

void Mary_Arena_Empty(Mary_Arena_t *arena)
{
  // need to check that there are no frames present.
}

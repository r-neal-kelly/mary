#pragma once

#include <Mary/Utils.h>

typedef struct Mary_Pool_t Mary_Pool_t;
typedef struct Mary_Arena_t Mary_Arena_t;

enum Mary_Allocator_e
{
  // we are limited to 32bit for enums
  // 0x000 - 0xFFF is for pool_ids
  MARY_STATIC = 0x1000,
  MARY_STACK,
  MARY_HEAP,
  MARY_FRAME,
  MARY_CHAIN,
  MARY_ERROR
};

#define MARY_Allocators\
  enum { STATIC = 0x1000, STACK, HEAP, FRAME, CHAIN, ERROR }

void *Mary_Allocator_Alloc(Mary_Allocator_t allocator, Mary_Size_t bytes);
void *Mary_Allocator_Calloc(Mary_Allocator_t allocator, Mary_Size_t unit, Mary_Size_t units);
void *Mary_Allocator_Realloc(Mary_Allocator_t allocator, void *data, Mary_Size_t bytes);
void Mary_Allocator_Dealloc(Mary_Allocator_t allocator, void *data);

#ifdef MARY_Debug
void Mary_Allocator_Validate(Mary_Allocator_t allocator, char *func_name);
#endif

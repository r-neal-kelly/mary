#define intern static
#include <stdlib.h>
#include <Mary/OS.h>
#include <Mary/OpenGL.h>
#include <Mary/Text.h>

void Mary_Text_Start();
void Mary_Text_Finish();
void Mary_Text_Create(Mary_Text_t *elem);
void Mary_Text_Destroy(Mary_Text_t *elem);
void Mary_Text_Text(Mary_Text_t *elem, uint16_t *text);
intern void Mary_Text_Buffer(Mary_Text_t *elem);
void Mary_Text_Render(Mary_Text_t *elem, Mary_Matrix_4x4f *projection);

intern HDC g_win32_context = 0;

void Mary_Text_Start()
{
  Mary_OpenGL_g g_opengl = Mary_OpenGL();
  g_win32_context = g_opengl.win32_context;
}

void Mary_Text_Finish()
{

}

void Mary_Text_Create(Mary_Text_t *elem)
{
  Mary_Vector_Create(&elem->v_text, sizeof(uint16_t));
  elem->pixel_buffer = (uint8_t *)malloc(1);
  elem->x = 0;
  elem->y = 0;
  elem->w = 100;
  elem->h = 100;
  elem->r = 1;
  elem->g = 1;
  elem->b = 1;
  elem->a = 1;
  Mary_Text_Text(elem, u"");
}

void Mary_Text_Destroy(Mary_Text_t *elem)
{
  Mary_Vector_Destroy(&elem->v_text);
  free(elem->pixel_buffer);
}

void Mary_Text_Text(Mary_Text_t *elem, uint16_t *text)
{
  Mary_Vector_t *v_text = &elem->v_text;
  Mary_Vector_Empty(v_text);
  uint16_t *c = text;
  while (*c != 0)
  {
    Mary_Vector_Push_Back(v_text, c);
    c += 1;
  }
  Mary_Text_Buffer(elem);
}

intern void Mary_Text_Buffer(Mary_Text_t *elem)
{
  Mary_Vector_t *v_text = &elem->v_text;
  int width = (int)elem->w;
  int height = (int)elem->h;
  unsigned int total_bytes = width * height * 4;

  BITMAPINFO bmi;
  memset(&bmi, 0, sizeof(bmi));
  bmi.bmiHeader.biSize = sizeof(bmi.bmiHeader);
  bmi.bmiHeader.biWidth = width;
  bmi.bmiHeader.biHeight = -height;
  bmi.bmiHeader.biPlanes = 1;
  bmi.bmiHeader.biBitCount = 32;
  bmi.bmiHeader.biCompression = BI_RGB;
  bmi.bmiHeader.biSizeImage = total_bytes;

  void *buffer;
  HDC memDC = CreateCompatibleDC(g_win32_context);
  HBITMAP memBM = CreateDIBSection(memDC, &bmi, DIB_RGB_COLORS, &buffer, 0, 0);
  SelectObject(memDC, memBM);

  RECT rect;
  rect.left = 0;
  rect.top = 0;
  rect.right = width;
  rect.bottom = height;

  SetBkColor(memDC, RGB(0, 0, 0)); // can invert these two for highlight!
  SetTextColor(memDC, RGB(255, 255, 255));
  //HGDIOBJ old_font = SelectObject(memDC, Win32FontHandle());

  unsigned int flags = DT_LEFT | DT_WORDBREAK; // temp, make more optional
  GdiFlush();
  DrawTextExW(memDC, v_text->data, (int)v_text->size, &rect, flags, 0);

  free(elem->pixel_buffer);
  elem->pixel_buffer = (uint8_t *)malloc(total_bytes);
  GdiFlush();
  memcpy(elem->pixel_buffer, buffer, total_bytes);

  //SelectObject(memDC, old_font);
  DeleteObject(memBM);
  DeleteDC(memDC);
}

void Mary_Text_Render(Mary_Text_t *elem, Mary_Matrix_4x4f *projection)
{
  static float vertices[] =
  {
    0.0f, 0.0f, 
    1.0f, 0.0f,
    1.0f, 1.0f,
    0.0f, 1.0f
  };
  static unsigned int indices[] =
  {
    0, 1, 2,
    2, 3, 0
  };
  static GLuint VAO = 0;
  if (!VAO)
  {
    glGenVertexArrays(1, &VAO);
    glBindVertexArray(VAO); // I think we only need to bind this after we've set everything up.
  }
  static GLuint VBO = 0;
  if (!VBO)
  {
    glGenBuffers(1, &VBO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, sizeof(float) * 2, (void *)0);
    glEnableVertexAttribArray(0);
  }
  static GLuint EBO = 0;
  if (!EBO)
  {
    glGenBuffers(1, &EBO);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
  }
  static GLuint texture = 0;
  if (!texture)
  {
    glGenTextures(1, &texture);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, texture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, (int)elem->w, (int)elem->h, 0, GL_BGRA, GL_UNSIGNED_BYTE, elem->pixel_buffer);
  }
  static GLuint program = 0;
  if (!program)
  {
    program = Mary_OpenGL_Program("Mary/shaders/text_v.shader", "Mary/shaders/text_f.shader");
    glUseProgram(program);
  }
  GLint u_model = glGetUniformLocation(program, "u_model");
  Mary_Matrix_4x4f model = Mary_OpenGL_Identity();
  Mary_OpenGL_Scale(&model, elem->w, elem->h, 1.0f);
  Mary_OpenGL_Translate(&model, elem->x, elem->y, 0.0f);
  glUniformMatrix4fv(u_model, 1, GL_TRUE, model.matrix);

  GLint u_projection = glGetUniformLocation(program, "u_projection");
  glUniformMatrix4fv(u_projection, 1, GL_TRUE, projection->matrix);

  GLint u_color = glGetUniformLocation(program, "u_color");
  glUniform4f(u_color, elem->r, elem->g, elem->b, elem->a);

  GLint u_texture = glGetUniformLocation(program, "u_texture");
  glUniform1i(u_texture, 0);

  glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
}

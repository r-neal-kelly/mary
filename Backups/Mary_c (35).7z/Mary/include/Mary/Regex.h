#pragma once

#include <stdint.h>
#include <Mary/Pool.h>
#include <Mary/Vector.h>
#include <Mary/String.h>

typedef struct
{
  Mary_Pool_t pool;
  Mary_String_t expression;
  void *machine;
}
Mary_Regex_t;

void Mary_Regex_Create(Mary_Regex_t *mary_regex, char bit_format, void *expression); // add flags field
void Mary_Regex_8bit_Create(Mary_Regex_t *mary_regex, uint8_t *expression);
void Mary_Regex_Destroy(Mary_Regex_t *mary_regex);
void Mary_Regex_Compile(Mary_Regex_t *mary_regex);
Mary_Vector_t Mary_Regex_Execute(Mary_Regex_t *mary_regex, char bit_format, void *search_string);
Mary_Vector_t Mary_Regex_8bit_Execute(Mary_Regex_t *mary_regex, uint8_t *search_string);
Mary_Vector_t Mary_Regex_16bit_Execute(Mary_Regex_t *mary_regex, uint16_t *search_string);
Mary_Vector_t Mary_Regex_32bit_Execute(Mary_Regex_t *mary_regex, uint32_t *search_string);

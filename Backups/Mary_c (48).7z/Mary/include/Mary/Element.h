#pragma once

#include <stdint.h>
#include <Mary/Vector.h>
#include <Mary/Hashmap.h>

enum
{
  MARY_ELEMENT_WINDOW = 1,
  MARY_ELEMENT_TEXT
};

enum
{
  MARY_EVENT_CHANGE = 1,
  MARY_EVENT_KEYBOARD,
  MARY_EVENT_MOUSE
};

#define MARY_Element_t\
  size_t type;\
  void *window;\
  void *parent;\
  Mary_Vector_t children_s; /* siblings */\
  Mary_Vector_t children_z; /* z-indices */\
  Mary_Vector_t events;\
  Mary_Hashmap_t listeners;\
  int z

typedef struct
{
  MARY_Element_t;
}
Mary_Element_t;

typedef Mary_Vector_t Mary_Element_v;

typedef struct
{
  const int type; // once we know the type, we convert to one of the below.
}
Mary_Event_t;

typedef struct
{
  const int type;
  const float x, y;
  const float w_out, h_out;
  const float w_in, h_in;
}
Mary_Event_Change;

typedef struct
{
  const int type;
  const uint32_t key;
}
Mary_Event_Keyboard;

typedef struct
{
  const int type;
  const uint8_t button;
}
Mary_Event_Mouse;

// when we have events, we make these global objects and put them on a pool.
// then we send out Mary_Event_t's in each elem's event queue, but then point
// to the real events in the pool. this way everyone is getting the same information.
// it may be a little slower this way though. but once the pool is in the cache, every other
// even it easy to access locally.

void Mary_Element_Start();
void Mary_Element_Finish();
void Mary_Element_Create(void *mary_element, char type);
void Mary_Element_Destroy(void *mary_element);
void Mary_Element_Append_To(void *mary_element, void *mary_element_parent);
void Mary_Element_Remove(void *mary_element);
void Mary_Element_Render(Mary_Element_t *mary_element);
void Mary_Element_Render_Children(Mary_Element_t *mary_element);

#define MARY_Element(VOID_PTR) ((Mary_Element_t *)(VOID_PTR))

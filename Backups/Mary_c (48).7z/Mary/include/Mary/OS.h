#pragma once

#include <stdint.h>
#include <Mary/Utils.h>
#include <Mary/Vector.h>

#if defined(_WIN32)
  #define WIN32_LEAN_AND_MEAN
  #define UNICODE
  #include <Windows.h>
  #include <usp10.h>
  #pragma comment (lib, "usp10.lib")
  #pragma comment (lib, "opengl32.lib") // maybe put this in opengl.h
  //#pragma comment (lib, "glu32.lib")
#elif defined(__linux__)
  #define tbd
#endif

void Mary_OS_Start();
void Mary_OS_Finish();

typedef struct
{
  Mary_Bitmap_t line;
  Mary_Vector_t widths;
}
Mary_Wordmap_t;

typedef Mary_Vector_t Mary_Wordmap_v; // maybe we should make this use a pool to keep it all in one area.

Mary_Wordmap_t Mary_OS_Text_To_Bitmap(uint16_t *text, int units);

#pragma once

#include <Mary/Utils.h>
#include <Mary/Allocator.h>

#define MARY_Vector_t\
  MARY_Pointer_t;\
  Mary_Allocator_u allocator;\
  Mary_Size_t unit;\
  Mary_Size_t units

#define MARY_Vector_Growth_Rate 1.7f

typedef struct
{
  MARY_Vector_t;
}
Mary_Vector_t;

// go through and make types uniform with Mary_Size_t, Mary_Index_t, Mary_Bool_t, etc.
void Mary_Vector_Create(Mary_Vector_t *vector, Mary_Allocator_u allocator, Mary_Size_t unit, Mary_Size_t opt_reserve_units);
void Mary_Vector_Create_At(Mary_Vector_t *vector, size_t unit, Mary_p ptr);
void Mary_Vector_Create_With(Mary_Vector_t *vector, size_t unit, Mary_p ptr);
void Mary_Vector_Repurpose(Mary_Vector_t *vector, size_t unit, size_t opt_units);
void Mary_Vector_Repurpose_With(Mary_Vector_t *vector, Mary_p *ptr, size_t ptr_unit, size_t ptr_units);
void Mary_Vector_Destroy(Mary_Vector_t *vector);
void Mary_Vector_Reserve(Mary_Vector_t *vector, size_t units);
void Mary_Vector_Fit(Mary_Vector_t *vector);
void Mary_Vector_Push_At(Mary_Vector_t *vector, size_t index, void *in_elem);
void Mary_Vector_Pop_At(Mary_Vector_t *vector, size_t index, void *out_elem);
void Mary_Vector_Assign(Mary_Vector_t *vector, size_t index, void *in_elem);
void Mary_Vector_Exchange(Mary_Vector_t *vector, size_t index, void *in_elem, void *out_elem);
void Mary_Vector_Copy(Mary_Vector_t *vector, Mary_Vector_t *out_copy);
void Mary_Vector_Add_Slice(Mary_Vector_t *vector, size_t from, size_t to_exclusive, void *opt_in_elems);
void Mary_Vector_Delete_Slice(Mary_Vector_t *vector, size_t from, size_t to_exclusive);
void Mary_Vector_Copy_Slice(Mary_Vector_t *vector, size_t from, size_t to_exclusive, void *out_elems);
void Mary_Vector_Take_Slice(Mary_Vector_t *vector, size_t from, size_t to_exclusive, void *out_elems);
void Mary_Vector_Put_Slice(Mary_Vector_t *vector, size_t from, size_t to_exclusive, void *in_elems);
void Mary_Vector_Push_Back(Mary_Vector_t *vector, void *in_elem);
void Mary_Vector_Push_Front(Mary_Vector_t *vector, void *in_elem);
void Mary_Vector_Pop_Back(Mary_Vector_t *vector, void *out_elem);
void Mary_Vector_Pop_Front(Mary_Vector_t *vector, void *out_elem);
void Mary_Vector_At(Mary_Vector_t *vector, size_t index, void *out_elem);
void Mary_Vector_At_Front(Mary_Vector_t *vector, void *out_elem);
void Mary_Vector_At_Back(Mary_Vector_t *vector, void *out_elem);
char Mary_Vector_Has_At(Mary_Vector_t *vector, size_t index); // maybe add a regular Has
void *Mary_Vector_Point(Mary_Vector_t *vector, Mary_Index_t index);
void *Mary_Vector_Point_Front(Mary_Vector_t *vector);
void *Mary_Vector_Point_Back(Mary_Vector_t *vector);
void *Mary_Vector_Point_Push_Back(Mary_Vector_t *vector);
void *Mary_Vector_Point_Pop_Back(Mary_Vector_t *vector);
void Mary_Vector_Empty(Mary_Vector_t *vector);
char Mary_Vector_Is_Empty(Mary_Vector_t *vector);
void Mary_Vector_Resize(Mary_Vector_t *vector, size_t units);
void Mary_Vector_Fill(Mary_Vector_t *vector, void *in_elem);
void Mary_Vector_Rotate(Mary_Vector_t *vector, void *out_elem);
void Mary_Vector_Reverse(Mary_Vector_t *vector);
char Mary_Vector_Contains(Mary_Vector_t *vector, void *elem);
char Mary_Vector_Contains_First_Bytes(Mary_Vector_t *vector, void *elem, size_t bytes);
Mary_Index_t Mary_Vector_Index_Of(Mary_Vector_t *vector, void *elem, char *out_was_found);
Mary_Index_t Mary_Vector_Index_Of_Reverse(Mary_Vector_t *vector, void *elem, Mary_Bool_t *out_was_found);
void Mary_Vector_Erase_At(Mary_Vector_t *vector, size_t index);
void Mary_Vector_Erase(Mary_Vector_t *vector, void *elem);
void Mary_Vector_Sort(Mary_Vector_t *vector);

// rethink names here
// also we could have separate functions for using Arena, and a namespace that conflates the names to their roots. opt int of course.
#define MARY_Vector_Namespace\
  <Mary/Namespace/Vector_Start.h>

#define MARY_Vector_Namespace_Start\
  <Mary/Namespace/Vector_Start.h>

#define MARY_Vector_Namespace_Start_Quick\
  <Mary/Namespace/Vector_Start_Quick.h>

#define MARY_Vector_Namespace_Finish\
  <Mary/Namespace/Vector_Finish.h>

#define MARY_Vector_Cast(PTR)\
  MARY_Cast(PTR, Mary_Vector_t)

#define MARY_Vector_Create_At_Stack(NAME, TYPE, UNITS)\
  TYPE NAME##_a[UNITS];\
  Mary_Vector_Create_At(&NAME, sizeof(TYPE), (Mary_p) { NAME##_a, sizeof(TYPE) * (UNITS) })

#define MARY_Vector_Has_At(PTR, IDX)\
  ( (IDX) < (PTR)->units )

#define MARY_Vector_Is_Empty(PTR)\
  ( !MARY_Vector_Has_At(PTR, 0) )

#define MARY_Vector_In_Bounds(PTR, IDX)\
  ( (IDX) <= (PTR)->units )

// I'm not sure how to do the Asserts in these right, without destroying their function
#define MARY_Vector_Point(PTR, IDX)\
(\
  /*MARY_Assert(MARY_Vector_Has_At(PTR, IDX), "Invalid index."),*/\
  MARY_Cast( (uint8_t *)(PTR)->data + (IDX) * (PTR)->unit, void )\
)

#define MARY_Vector_Point_Front(PTR)\
(\
  /*MARY_Assert(!MARY_Vector_Is_Empty(PTR), "Empty Vector."),*/\
  MARY_Cast( (PTR)->data, void )\
)

#define MARY_Vector_Point_Back(PTR)\
(\
  /*MARY_Assert(!MARY_Vector_Is_Empty(PTR), "Empty Vector."),*/\
  MARY_Cast( (uint8_t *)(PTR)->data + ((PTR)->units - 1) * (PTR)->unit, void )\
)

#define MARY_Vector_At(PTR, TYPE, IDX)\
(\
  MARY_Assert(MARY_Vector_Has_At(PTR, IDX), "Invalid index."),\
  *MARY_Cast( (uint8_t *)(PTR)->data + (IDX) * (PTR)->unit, TYPE )\
)

#define MARY_Vector_At_Front(PTR, TYPE)\
(\
  MARY_Assert(!MARY_Vector_Is_Empty(PTR), "Empty Vector."),\
  *MARY_Cast( (PTR)->data, TYPE )\
)

#define MARY_Vector_At_Back(PTR, TYPE)\
(\
  MARY_Assert(!MARY_Vector_Is_Empty(PTR), "Empty Vector."),\
  *MARY_Cast( (uint8_t *)(PTR)->data + ((PTR)->units - 1) * (PTR)->unit, TYPE )\
)

#define MARY_Vector_Each(PTR, TYPE)                                                                \
  for                                                                                              \
  (                                                                                                \
    struct { Mary_Vector_t *v; Mary_Index_t from, to, idx; TYPE *ptr; TYPE val; }                  \
    it =                                                                                           \
    {                                                                                              \
      (PTR), 0, it.v->units > 0 ? it.v->units - 1 : 0, 0, it.v->data, *it.ptr                      \
    };                                                                                             \
    it.idx < it.v->units;                                                                          \
    ++it.idx, it.ptr = MARY_Vector_Point(it.v, it.idx), it.val = *it.ptr                           \
  )

#define MARY_Vector_Each_Reverse(PTR, TYPE)                                                        \
  for                                                                                              \
  (                                                                                                \
    struct { Mary_Vector_t *v; Mary_Index_t from, to, idx; TYPE *ptr; TYPE val; }                  \
    it =                                                                                           \
    {                                                                                              \
      (PTR), it.v->units - 1, 0, it.from,                                                          \
      MARY_Vector_Is_Empty(it.v) ? it.v->data : MARY_Vector_Point_Back(it.v), *it.ptr              \
    };                                                                                             \
    it.idx + 1 > 0;                                                                                \
    --it.idx, it.ptr = MARY_Vector_Point(it.v, it.idx), it.val = *it.ptr                           \
  )

// I want to be able to combine these in a func so that it does the right one for the size.
#define MARY_Vector_Bubble_Sort(BOOL_EXPRESSION)

#define MARY_Vector_Quick_Sort(BOOL_EXPRESSION)

#define MARY_Vector_Linear_Search(BOOL_EXPRESSION)

#define MARY_Vector_Binary_Search(BOOL_EXPRESSION)

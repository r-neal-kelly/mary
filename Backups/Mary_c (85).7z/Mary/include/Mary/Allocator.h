#pragma once

#include <Mary/Utils.h>

typedef struct Mary_Pool_t Mary_Pool_t;
typedef struct Mary_Arena_t Mary_Arena_t;

extern const Mary_Pool_t *MARY_ALLOCATOR_POOLS;

enum Mary_Allocator_e
{
  MARY_STACK = 0,
  MARY_HEAP,
  MARY_POOL,
  MARY_ARENA,
  MARY_FRAME = 0,
  MARY_CHAIN,
  MARY_ERROR
};
#define MARY_Allocator_Enum\
  enum Mary_Allocator_e { STACK = 0, HEAP, POOL, ARENA, FRAME = 0, CHAIN, ERROR }

#define MARY_Allocator_t\
  Mary_Enum_8_t type

typedef struct
{
  MARY_Allocator_t;
  Mary_Enum_8_t a, b, c, d, e, f, g;
}
Mary_Allocator_t;

typedef struct
{
  MARY_Allocator_t;
}
Mary_Allocator_Stack_t,
Mary_Allocator_Heap_t;

typedef struct
{
  MARY_Allocator_t;
  Mary_Enum_16_t idx;
}
Mary_Allocator_Pool_t;

typedef struct
{
  MARY_Allocator_t;
  Mary_Enum_8_t zone;
}
Mary_Allocator_Arena_t;

// if for any reason we need more room, we can use a bitmask instead of union.
typedef union
{
  MARY_Allocator_t;
  Mary_Allocator_Stack_t stack;
  Mary_Allocator_Heap_t heap;
  Mary_Allocator_Pool_t pool;
  Mary_Allocator_Arena_t arena;
  Mary_Allocator_t allocator;
}
Mary_Allocator_u;

Mary_Allocator_u Mary_Allocator_Stack();
Mary_Allocator_u Mary_Allocator_Heap();
Mary_Allocator_u Mary_Allocator_Pool(Mary_Pool_t *pool);
Mary_Allocator_u Mary_Allocator_Arena(Mary_Enum_t zone);
void *Mary_Allocator_Alloc(Mary_Allocator_u allocator, Mary_Size_t bytes);
void *Mary_Allocator_Calloc(Mary_Allocator_u allocator, Mary_Size_t unit, Mary_Size_t units);
void *Mary_Allocator_Realloc(Mary_Allocator_u allocator, void *data, Mary_Size_t bytes);
void Mary_Allocator_Dealloc(Mary_Allocator_u allocator, void *data);

#define MARY_Allocator(ALLOCATOR, PARAM_A)\
(\
  ALLOCATOR == MARY_STACK ? (Mary_Allocator_u) { MARY_STACK } :\
  ALLOCATOR == MARY_HEAP  ? (Mary_Allocator_u) { MARY_HEAP } :\
  ALLOCATOR == MARY_POOL  ? Mary_Allocator_Pool((Mary_Pool_t *)PARAM_A) :\
  ALLOCATOR == MARY_ARENA ? Mary_Allocator_Arena((Mary_Enum_t)PARAM_A) :\
  (MARY_Assert(0, "Invalid allocator."), (Mary_Allocator_u) { 0 })\
)

#define MARY_a(ALLOCATOR, PARAM_A)\
  MARY_Allocator(ALLOCATOR, PARAM_A)

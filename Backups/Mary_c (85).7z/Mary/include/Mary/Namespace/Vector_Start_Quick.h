#define Vector_t Mary_Vector_t

#define Vector_Create Mary_Vector_Create
#define Vector_Destroy Mary_Vector_Destroy
#define Vector_Push_Back Mary_Vector_Push_Back

#define VECTOR_Cast MARY_Vector_Cast
#define VECTOR_Create_At_Stack MARY_Vector_Create_At_Stack
#define VECTOR_Point MARY_Vector_Point
#define VECTOR_Point_Back MARY_Vector_Point_Back
#define VECTOR_At MARY_Vector_At
#define VECTOR_At_Back MARY_Vector_At_Back
#define VECTOR_Each MARY_Vector_Each

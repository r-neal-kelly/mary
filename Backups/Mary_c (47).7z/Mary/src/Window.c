#include <stdio.h>
#include <stdlib.h>
#include <Mary/Utils.h>
#include <Mary/Bitbool.h>
#include <Mary/Vector.h>
#include <Mary/String.h>
#include <Mary/Window.h>
#include <Mary/Text.h>

MARY_PRIMITIVES;

void Mary_Window_Start();
void Mary_Window_Finish();
char Mary_Window_Can_Render();
void Mary_Window_Render();
void Mary_Window_Create(Mary_Window_t *window);
void Mary_Window_Destroy(Mary_Window_t *window);
void Mary_Window_Close(Mary_Window_t *window);
void Mary_Window_Show(Mary_Window_t *window);
void Mary_Window_Hide(Mary_Window_t *window);
static int64_t __stdcall Win32_Wnd_Proc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp);
static void Update_Dimensions(Mary_Window_t *window);
static void Render_Self(Mary_Window_t *window);

static Mary_Vector_t windows_v;
static const uint16_t win32_class_name[] = u"Mary_Win32";
static HGLRC g_opengl_context = 0;
static int g_opengl_pixel_format = 0;

enum WINDOW_FLAGS
{
  SHOULD_RENDER,
  MAXIMIZED,
  MINIMIZED,
  SHOULD_CONFIRM_CLOSE
};

void Mary_Window_Start()
{
  Mary_Vector_Create(&windows_v, sizeof(Mary_Window_t *), 0);

  WNDCLASSEX win32_class;
  memset(&win32_class, 0, sizeof(win32_class));
  win32_class.cbSize = sizeof(win32_class);
  win32_class.lpfnWndProc = Win32_Wnd_Proc;
  win32_class.hCursor = LoadCursor(0, IDC_ARROW);
  win32_class.hbrBackground = (HBRUSH)8;
  win32_class.lpszClassName = win32_class_name;
  win32_class.style = CS_OWNDC;
  RegisterClassEx(&win32_class);

  Mary_OpenGL_g g_opengl = Mary_OpenGL();
  g_opengl_context = g_opengl.opengl_context;
  g_opengl_pixel_format = g_opengl.pixel_format;
}

void Mary_Window_Finish()
{
  Mary_Vector_Destroy(&windows_v);
}

char Mary_Window_Can_Render()
{
  return Mary_Vector_Is_Empty(&windows_v);
}

void Mary_Window_Render()
{
  Mary_Window_t *window = 0;
  size_t size = windows_v.units;
  for (size_t i = 0; i < size; ++i)
  {
    Mary_Vector_At(&windows_v, i, &window);
    Render_Self(window);
  }
  Sleep(1);
}

void Mary_Window_Create(Mary_Window_t *window)
{
  memset(window, 0, sizeof(window));
  Mary_Vector_Push_Back(&windows_v, &window);

  Mary_Element_Create(window, MARY_ELEMENT_WINDOW);

  HWND win32_hwnd = CreateWindowEx
    ( WS_EX_CLIENTEDGE
    , win32_class_name
    , L"Praise Yahweh!"
    , WS_OVERLAPPEDWINDOW
    , 100, 100
    , 800, 600
    , 0, 0, 0, 0
    );
  window->win32_hwnd = win32_hwnd;
  
  HDC win32_hdc = GetDC(win32_hwnd);
  window->win32_hdc = win32_hdc;

  PIXELFORMATDESCRIPTOR pfd;
  memset(&pfd, 0, sizeof(pfd));
  SetPixelFormat(win32_hdc, g_opengl_pixel_format, &pfd);

  char flags = window->flags;
  Mary_Bitbool_Fill(&flags, sizeof(flags), 0);
  Mary_Bitbool_Assign(&flags, sizeof(flags), SHOULD_RENDER, 1);
  window->flags = flags;

  Mary_Window_Show(window);
}

void Mary_Window_Destroy(Mary_Window_t *window)
{
  MARY_Vector_Each(window->children_s, Mary_Element_t *)
  {
    Mary_Element_Remove(range.val);
  }
  Mary_Element_Destroy(window);
  ReleaseDC(window->win32_hwnd, window->win32_hdc);
  DestroyWindow(window->win32_hwnd);
  memset(window, 0, sizeof(window));
}

void Mary_Window_Close(Mary_Window_t *window)
{
  HWND win32_hwnd = window->win32_hwnd;
  // can send a confirm if a bitbool flag is set by user
  DestroyWindow(win32_hwnd);
  Mary_Vector_Erase(&windows_v, &window);
}

void Mary_Window_Show(Mary_Window_t *window)
{
  HWND win32_hwnd = window->win32_hwnd;
  ShowWindow(win32_hwnd, SW_NORMAL);
  UpdateWindow(win32_hwnd);
}

void Mary_Window_Hide(Mary_Window_t *window)
{
  ShowWindow(window->win32_hwnd, SW_HIDE);
}

static int64_t __stdcall Win32_Wnd_Proc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
{
  Mary_Window_t *window = 0;
  size_t size = windows_v.units;
  for (size_t i = 0; i < size; ++i)
  {
    Mary_Vector_At(&windows_v, i, &window);
    if (window->win32_hwnd == hwnd) break;
  }

  if (!window)
  {
    return DefWindowProc(hwnd, msg, wp, lp);
  }
  else if (msg == WM_CLOSE)
  {
    Mary_Window_Close(window);
    return 0;
  }
  else if (msg == WM_SIZE)
  {
    Update_Dimensions(window);
    Mary_Bitbool_Assign(&window->flags, sizeof(window->flags), SHOULD_RENDER, 1);
    Render_Self(window);
    return 0;
  }
  else if (msg == WM_MOVE)
  {
    Mary_Bitbool_Assign(&window->flags, sizeof(window->flags), SHOULD_RENDER, 1);
    Render_Self(window);
    return 0;
  }
  else
  {
    return DefWindowProc(hwnd, msg, wp, lp);
  }
}

static void Update_Dimensions(Mary_Window_t *window)
{
  RECT rect;
  GetClientRect(window->win32_hwnd, &rect);
  window->inner_width = (uint16_t)rect.right;
  window->inner_height = (uint16_t)rect.bottom;
  GetWindowRect(window->win32_hwnd, &rect);
  window->outer_width = (uint16_t)(rect.right - rect.left);
  window->outer_height = (uint16_t)(rect.bottom - rect.top);
}

static void Render_Self(Mary_Window_t *window)
{
  static MSG msg;
  HWND win32_hwnd = window->win32_hwnd;
  HDC win32_hdc = window->win32_hdc;
  char flags = window->flags;
  while (PeekMessage(&msg, win32_hwnd, 0, 0, PM_REMOVE))
  {
    TranslateMessage(&msg);
    DispatchMessage(&msg);
  }
  if (Mary_Bitbool_At(&flags, sizeof(flags), SHOULD_RENDER))
  {
    uint16_t w = window->inner_width;
    uint16_t h = window->inner_height;
    window->projection = Mary_OpenGL_Ortho(0.0f, (float)w, (float)h, 0.0f, 0.0f, 1.0f);
    wglMakeCurrent(win32_hdc, g_opengl_context);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glViewport(0, 0, w, h);
    glClearColor(1.0f, 0.4f, 0.8f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

    { ////// render children, but for now we do testing.
      static Mary_Text_t text;
      static int initialized = 0;
      if (!initialized)
      {
        Mary_File_t file; Mary_File_Read(&file, "test2.txt");
        Mary_Text_Create(&text, 8, file.data, file.size, w, h);
        Mary_Element_Append_To(&text, window);
        Mary_Text_Position(&text, 0, 0);
        Mary_Text_Color(&text, 1.0f, 1.0f, 1.0f, 1.0f);
        Mary_File_Destroy(&file);
        initialized = 1;
      }
      Mary_Text_Size(&text, w, h); // this will be a good test for event.
      Mary_Element_Render(MARY_Element(&text));
      //printf("%i ", glGetError());
    } //////

    //Mary_Element_Render(window); // causing infinite loop right now.
    SwapBuffers(win32_hdc);
    Mary_Bitbool_Assign(&flags, sizeof(flags), SHOULD_RENDER, 0);
    window->flags = flags;
  }
}

#pragma once

#include <stdint.h>
#include <Mary/OS.h>
#include <Mary/OpenGL.h>
#include <Mary/Hashmap.h>
#include <Mary/Element.h>

typedef struct
{
  MARY_Element_t;
  HWND win32_hwnd; // might want to make this more cross platform.
  HDC win32_hdc;
  char flags;
  uint16_t inner_width, inner_height;
  uint16_t outer_width, outer_height;
  Mary_Matrix_4x4f projection;
}
Mary_Window_t;

void Mary_Window_Start();
void Mary_Window_Finish();
char Mary_Window_Can_Render();
void Mary_Window_Render();
void Mary_Window_Create(Mary_Window_t *window);
void Mary_Window_Destroy(Mary_Window_t *window);
void Mary_Window_Close(Mary_Window_t *window);
void Mary_Window_Show(Mary_Window_t *window);
void Mary_Window_Hide(Mary_Window_t *window);

#define MARY_Window(VOID_PTR) ((Mary_Window_t *)(VOID_PTR))

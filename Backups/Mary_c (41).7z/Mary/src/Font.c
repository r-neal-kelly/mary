#include <stdint.h>
#include <Mary/Utils.h>
#include <Mary/Vector.h>
#include <Mary/String.h>
#include <Mary/Font.h>

MARY_PRIMITIVES;

#define RASTER_TRUETYPE     0x74727565
#define RASTER_POSTSCRIPT   0x74797031
#define RASTER_OPENTYPE_TTF 0x00010000
#define RASTER_OPENTYPE_CFF 0x4F54544F

#define UNICODE_PLAT 0
#define UNICODE_SPEC_DEF 0
#define UNICODE_SPEC_1 1
#define UNICODE_SPEC_BMP 3
#define UNICODE_SPEC_2 4
#define UNICODE_SPEC_VAR 5
#define UNICODE_SPEC_FULL 6
#define UNICODE_LANG_DEF 0
#define MICROSOFT_PLAT 3
#define MICROSOFT_SPEC_BMP 1
#define MICROSOFT_LANG_EN_US 0x0409

#define GSUB_SINGLE           0x01
#define GSUB_MULTIPLE         0x02
#define GSUB_ALTERNATE        0x03
#define GSUB_LIGATURE         0x04
#define GSUB_CONTEXTUAL       0x05
#define GSUB_CHAINING         0x06
#define GSUB_EXTENSION        0x07
#define GSUB_REVERSE_CHAINING 0x08

FT_Library g_ft_library;
u8 g_is_little_endian = 0;
#define U16(P) (g_is_little_endian ? MARY_SWAP_16(*(u16 *)(P)) : *(u16 *)(P))
#define U32(P) (g_is_little_endian ? MARY_SWAP_32(*(u32 *)(P)) : *(u32 *)(P))
#define U64(P) (g_is_little_endian ? MARY_SWAP_64(*(u64 *)(P)) : *(u64 *)(P))
#define S16(P) (g_is_little_endian ? MARY_SWAP_16(*(s16 *)(P)) : *(s16 *)(P))
#define S32(P) (g_is_little_endian ? MARY_SWAP_32(*(s32 *)(P)) : *(s32 *)(P))
#define S64(P) (g_is_little_endian ? MARY_SWAP_64(*(s64 *)(P)) : *(s64 *)(P))

void Mary_Font_Start()
{
  if (FT_Init_FreeType(&g_ft_library))
    Mary_Exit_Failure("Mary_Font_Start: Failed to init FreeType.");
  g_is_little_endian = Mary_Is_Little_Endian();
}

void Mary_Font_Finish()
{
  if (FT_Done_FreeType(g_ft_library))
    Mary_Exit_Failure("Mary_Font_Finish: Failed to free FreeType.");
}

void Mary_Font_Create(Mary_Font_t *mary_font, char *file_path)
{
  Mary_File_t file; Mary_File_Read(&file, file_path);
  mary_font->data = file.data;
  u8 *data_start = file.data;
  u8 *p = data_start;

  { ////// can we handle this type of font?
    u32 rasterizer = U32(p); p += 4;
    if (rasterizer != RASTER_OPENTYPE_TTF)
      Mary_Exit_Failure("Mary_Font_Create: Can only handle standard OpenType fonts.");
  }

  { ////// store tables in hashmap
    u16 num_tables = U16(p); p += 8;
    char table_tag[5]; memset(table_tag + 4, 0, 1);
    Mary_Hashmap_Create(&mary_font->tables, 5, sizeof(void *));
    for (int i = 0; i < num_tables; ++i)
    {
      memcpy(table_tag, p, 4); p += 8;
      u32 offset = U32(p); p += 4;
      u32 length = U32(p); p += 4;
      printf("%s %i\n", table_tag, length);//
      void *table_start = data_start + offset;
      Mary_Hashmap_Assign(&mary_font->tables, table_tag, &table_start);
    }
  }

  { ////// create freetype font face
    if (FT_New_Memory_Face(g_ft_library, file.data, (FT_Long)file.size, 0, &mary_font->ft_face))
      Mary_Exit_Failure("Mary_Font_Create: Couldn't creat FreeType font face.");
    FT_Set_Pixel_Sizes(mary_font->ft_face, 0, 16);
    mary_font->pixel_size = 16;
  }
}

void Mary_Font_Destroy(Mary_Font_t *mary_font)
{
  FT_Done_Face(mary_font->ft_face);
  Mary_Hashmap_Destroy(&mary_font->tables);
  free(mary_font->data);
}

void Mary_Font_Layout(Mary_Font_t *mary_font, Mary_String_t *string, char *FONT_SCRIPT)
{
  char string_format = Mary_String_Get_Format(string);
  if (string_format != 32)
  {
    Mary_String_Format(string, 32);
  }
  u32 *unicodes = string->data;
  Mary_Vector_t v_glyph_indices;
  MARY_Vector_Create(v_glyph_indices, FT_UInt, string->size);
  for (int i = 0; i < string->size; ++i)
  {
    FT_UInt glyph_index = FT_Get_Char_Index(mary_font->ft_face, unicodes[i]);
    MARY_Vector_Push_Back(v_glyph_indices, glyph_index);
  }

  ////// 'cmap' table
  {
    if (!Mary_Hashmap_Contains_Key(&mary_font->tables, "cmap"))
    {
      printf("no cmap\n"); return;
    }
    u8 *cmap, *p; Mary_Hashmap_At(&mary_font->tables, "cmap", &cmap); p = cmap;
    u16 version = U16(p); p += 2;
    u16 num_tables = U16(p); p += 2;
    //u8 *cmap_table;
    for (int rec_i = 0; rec_i < num_tables; ++rec_i)
    {
      u16 platform_id = U16(p); p += 2;
      u16 encoding_id = U16(p); p += 2;
      u32 sub_table_offset = U32(p); p += 4;
      printf("platform:%i, encoding:%i, offset:%i\n", platform_id, encoding_id, sub_table_offset);
      if (platform_id == UNICODE_PLAT && encoding_id == UNICODE_SPEC_2)
      {
        u8 *sub_table = cmap + sub_table_offset;
        u16 format = U16(cmap);
        if (format == 12)
        {
          //mary_font->cmap = cmap;
          //mary_font->Glyph_Index = Cmap_Format_12;
        }
        else if (1)
        {
          // add more
        }
        break;
      }
      else if (1)
      {
        // add more
      }
    }
  }

  { ////// HACKETY HACK HACK HACK
    u32 temp = 320;
    MARY_Vector_Assign(v_glyph_indices, 1, temp);
  }

  { ////// GDEF here?

  }

  { ////// GSUB
    if (!Mary_Hashmap_Contains_Key(&mary_font->tables, "GSUB"))
    {
      printf("no gsub\n"); return;
    }
    u8 *gsub, *p; Mary_Hashmap_At(&mary_font->tables, "GSUB", &gsub); p = gsub;
    u16 major_version = U16(p); p += 2;
    u16 minor_version = U16(p); p += 2;
    u8 *scripts = gsub + U16(p); p += 2;
    u8 *features = gsub + U16(p); p += 2;
    u8 *lookups = gsub + U16(p); p += 2;
    u8 tag[5]; memset(tag + 4, 0, 1);

    // scripts
    p = scripts;
    u16 script_count = U16(p); p += 2;
    u8 *default_script = 0, *target_script = 0;
    for (int i = 0; i < script_count; ++i)
    {
      u8 *script_name = memcpy(tag, p, 4); p += 4;
      if (!memcmp(script_name, "dflt", 4))
      {
        default_script = scripts + U16(p);
      }
      else if (FONT_SCRIPT && !memcmp(script_name, FONT_SCRIPT, 4))
      {
        target_script = scripts + U16(p);
      }
      p += 2;
    }
    if (!default_script && !target_script)
    {
      return;
    }
    u8 *script = p = (target_script) ? target_script : default_script;
    u8 *default_lang_sys = script + U16(p); p += 2;
    u16 lang_sys_count = U16(p); p += 2;
    u8 *lang_sys = default_lang_sys;
    for (int i = 0; i < lang_sys_count; ++i)
    {
      memcpy(tag, p, 4); p += 4;
      if (0) // need to add 'is target'
      {
        lang_sys = script + U16(p);
      }
      p += 2;
    }
    p = lang_sys + 2;
    u16 required_feature_index = U16(p); p += 2;
    u16 feature_index_count = U16(p); p += 2;
    u16 *feature_indices = (u16 *)p;
    Mary_Vector_t v_feature_indices;
    MARY_Vector_Create(v_feature_indices, u16, feature_index_count + 1);
    u16 feature_index;
    if (required_feature_index != 0xFFFF)
    {
      feature_index = required_feature_index;
      MARY_Vector_Push_Back(v_feature_indices, feature_index);
    }
    for (int i = 0; i < feature_index_count; ++i)
    {
      feature_index = U16(feature_indices + i);
      MARY_Vector_Push_Back(v_feature_indices, feature_index);
    }

    // features
    p = features;
    u16 feature_count = U16(p); p += 2;
    u8 *feature_records = p;
    u8 bytes_per_record = 20;
    for (int i = 0; i < v_feature_indices.size; ++i)
    {
      MARY_Vector_At(v_feature_indices, i, feature_index);
      u8 *feature_record = p = feature_records + feature_index * bytes_per_record;
      char *feature_name = memcpy(tag, p, 4); p += 4;
      u16 feature_offset = U16(p); p += 2;
      u8 *feature_table = p = features + feature_offset;
      u16 params_offset = U16(p); p += 2;
      u8 *params_table = (params_offset) ? feature_table + params_offset : 0;
      u16 lookup_index_count = U16(p); p += 2;
      u16 *lookup_indices = (u16 *)p;

      // lookups
      p = lookups;
      u16 lookup_count = U16(p); p += 2;
      u16 *lookup_offsets = (u16 *)p;
      for (int i = 0; i < lookup_index_count; ++i)
      {
        u16 lookup_index = U16(lookup_indices + i);
        u16 lookup_offset = U16(lookup_offsets + lookup_index);
        u8 *lookup_table = p = lookups + lookup_offset;
        u16 lookup_type = U16(p); p += 2;
        u16 lookup_flag = U16(p); p += 2;
        u16 sub_table_count = U16(p); p += 2;
        u16 *sub_table_offsets = (u16 *)p; p += sub_table_count;
        u8 right_to_left = lookup_flag & 0x0001;
        u8 ignore_base_glyphs = lookup_flag & 0x0002;
        u8 ignore_ligatures = lookup_flag & 0x0004;
        u8 ignore_marks = lookup_flag & 0x0008;
        u8 use_mark_filtering_set = lookup_flag & 0x0010;
        u16 mark_attachment_type = lookup_flag & 0xFF00;
        if (lookup_type == GSUB_SINGLE)
        {

        }
        else if (lookup_type == GSUB_MULTIPLE)
        {

        }
        else if (lookup_type == GSUB_ALTERNATE)
        {

        }
        else if (lookup_type == GSUB_LIGATURE)
        {
          // for each glyph index, we search through each sub_table
          // (which are separated for the sake of the coverage format)
          // and if our glyph is covered, we search through our ligas
          // for a match. if we find a match we skip the rest of the
          // ligas in the sub table, and the rest of the sub tables.
          for (size_t v_i = 0; v_i < v_glyph_indices.size; ++v_i)
          {
            for (int i = 0; i < sub_table_count; ++i)
            {
              u32 glyph_index; MARY_Vector_At(v_glyph_indices, v_i, glyph_index);
              // need to check for flags.
              b64 has_been_substituted = 0;
              u16 sub_table_offset = U16(sub_table_offsets + i);
              u8 *sub_table = p = lookup_table + sub_table_offset;
              u16 subst_format = U16(p); p += 2;
              u16 coverage_offset = U16(p); p += 2;
              u16 ligature_set_count = U16(p); p += 2;
              u16 *ligature_set_offsets = (u16 *)p;
              u8 *coverage_table = p = sub_table + coverage_offset;
              u16 coverage_format = U16(p); p += 2;
              u16 coverage_index;
              if (coverage_format == 1)
              {
                u16 glyph_count = U16(p); p += 2;
                u16 *glyph_array = (u16 *)p;
                coverage_index = glyph_count;
                for (u16 cov_i = 0; cov_i < glyph_count; ++cov_i)
                {
                  u16 covered_glyph_index = U16(glyph_array + cov_i);
                  if (glyph_index == covered_glyph_index)
                  {
                    coverage_index = cov_i; break;
                  }
                }
                if (coverage_index == glyph_count)
                {
                  continue;
                }
              }
              else if (coverage_format == 2)
              {
                u16 range_count = U16(p); p += 2;
                u8 *range_records = p;
                // tbd
              }
              else
              {
                continue;
              }
              // we don't need to loop through each ligature set
              u16 ligature_set_offset = U16(ligature_set_offsets + coverage_index);
              u8 *ligature_set_table = p = sub_table + ligature_set_offset;
              u16 ligature_count = U16(p); p += 2;
              u16 *ligature_offsets = (u16 *)p;
              for (int lig_i = 0; lig_i < ligature_count; ++lig_i)
              {
                u16 ligature_offset = U16(ligature_offsets + lig_i);
                u8 *ligature_table = p = ligature_set_table + ligature_offset;
                u16 ligature_glyph_index = U16(p); p += 2;
                u16 component_count = U16(p); p += 2;
                u16 *component_glyph_indices = (u16 *)p;
                u16 tail_count = component_count - 1;
                u32 string_glyph_index; u16 component_glyph_index;
                b64 is_not_a_match = 0;
                for (int com_i = 0; com_i < tail_count; ++com_i)
                {
                  MARY_Vector_At(v_glyph_indices, v_i + com_i + 1, string_glyph_index);
                  component_glyph_index = U16(component_glyph_indices + com_i);
                  if (string_glyph_index != component_glyph_index)
                  {
                    is_not_a_match = 1; break;
                  }
                }
                if (is_not_a_match)
                {
                  continue;
                }
                u32 replacement_glyph = ligature_glyph_index;
                MARY_Vector_Delete_Slice(v_glyph_indices, v_i + 1, v_i + component_count);
                MARY_Vector_Assign(v_glyph_indices, v_i, replacement_glyph);
                has_been_substituted = 1;
                break;
              }
              if (has_been_substituted)
              {
                break;
              }
            }
          }
        }
        else if (lookup_type == GSUB_CONTEXTUAL)
        {

        }
        else if (lookup_type == GSUB_CHAINING)
        {
          for (size_t v_i = 0; v_i < v_glyph_indices.size; ++v_i)
          {
            u32 glyph_index; MARY_Vector_At(v_glyph_indices, v_i, glyph_index);
            for (int i = 0; i < sub_table_count; ++i)
            {
              u16 sub_table_offset = U16(sub_table_offsets + i);
              u8 *sub_table = p = lookup_table + sub_table_offset;
              u16 subst_format = U16(p); p += 2;
              u16 coverage_offset = U16(p); p += 2;
              u16 chain_sub_rule_set_count = U16(p); p += 2;
              u16 *chain_sub_rule_set_count_offsets = (u16 *)p;
              u8 *coverage_table = p = sub_table + coverage_offset;
              u16 coverage_format = U16(p); p += 2;
              if (coverage_format == 1)
              {
                u16 glyph_count = U16(p); p += 2;
                u16 *glyph_array = (u16 *)p;
              }
              else
              {
                u16 range_count = U16(p); p += 2;
                u8 *range_records = p;
              }
            }
          }
        }
        else if (lookup_type == GSUB_EXTENSION)
        {

        }
        else if (lookup_type == GSUB_REVERSE_CHAINING)
        {

        }
      }
    }
    MARY_Vector_Destroy(v_feature_indices);
  }
  MARY_Vector_Destroy(v_glyph_indices);
}

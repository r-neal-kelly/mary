#pragma once

#include <Mary/Vector.h>

typedef struct
{
  void *data;
  size_t size; // bytes
  size_t free;
  Mary_Vector_t index;
}
Mary_Pool_t;

void Mary_Pool_Create(Mary_Pool_t *pool, size_t bytes);
void Mary_Pool_Destroy(Mary_Pool_t *pool);
void *Mary_Pool_Allocate(Mary_Pool_t *pool, size_t bytes);
void Mary_Pool_Deallocate(Mary_Pool_t *pool, void *ptr);
size_t Mary_Pool_Count_Used(Mary_Pool_t *pool); // how much is in use
size_t Mary_Pool_Count_Free(Mary_Pool_t *pool); // how much is free

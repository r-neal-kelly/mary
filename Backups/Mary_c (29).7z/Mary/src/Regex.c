#include <Mary/Utils.h>
#include <Mary/Pool.h>
#include <Mary/Regex.h>

// pretty sure that Mary_Pool_t is going to play a huge role in this
// to make mallocing automatons extremely fast.

MARY_PRIMITIVES;

void Mary_Regex_Create()
{

}

void Mary_Regex_Destroy()
{

}

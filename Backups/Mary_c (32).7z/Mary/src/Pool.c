#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <Mary/Utils.h>
#include <Mary/Pool.h>

MARY_PRIMITIVES;

typedef struct
{
  u32 from, to_exclusive;
}
Used_Space;

void Mary_Pool_Create(Mary_Pool_t *pool, size_t bytes)
{
  MARY_Assert(bytes > 0 && bytes <= 0x800000000); // 32 gigabyte max
  u64 size_8bit_data = bytes + 7 & -8;
  u8 *data = malloc(size_8bit_data + 8);
  if (data)
  {
    pool->data = data + 8;
    pool->size = size_8bit_data;
    MARY_Vector_Create(pool->index, Used_Space, 16);
  }
  else
  {
    Mary_Exit_Failure("out of memory");
  }
}

void Mary_Pool_Destroy(Mary_Pool_t *pool)
{
  MARY_Vector_Destroy(pool->index);
  free((u8 *)pool->data - 8);
}

void *Mary_Pool_Allocate(Mary_Pool_t *pool, size_t bytes)
{
  MARY_Assert(bytes > 0 && bytes <= pool->size);
  u32 size_64bit_alloc = (bytes + 7 & -8) >> 3;
  Used_Space index_new = { 0, 0 };
  if (!pool->index.size)
  {
    index_new.to_exclusive = size_64bit_alloc;
    MARY_Vector_Push_Back(pool->index, index_new);
  }
  else
  {
    Used_Space index_last = *((Used_Space *)pool->index.data + pool->index.size - 1);
    Used_Space index_first = *(Used_Space *)pool->index.data;
    if (size_64bit_alloc <= (pool->size >> 3) - index_last.to_exclusive)
    {
      index_new.from = index_last.to_exclusive;
      index_new.to_exclusive = index_new.from + size_64bit_alloc;
      MARY_Vector_Push_Back(pool->index, index_new);
    }
    else if (size_64bit_alloc <= index_first.from)
    {
      index_new.from = 0;
      index_new.to_exclusive = index_new.from + size_64bit_alloc;
      Mary_Vector_Insert(&pool->index, 0, &index_new);
    }
    else
    {
      MARY_Range(pool->index.data, Used_Space, 0, pool->index.size - 1)
      {
        if (size_64bit_alloc <= (range.ptr + 1)->from - range.val.to_exclusive)
        {
          index_new.from = range.val.to_exclusive;
          index_new.to_exclusive = index_new.from + size_64bit_alloc;
          Mary_Vector_Insert(&pool->index, range.idx + 1, &index_new);
          break;
        }
      }
    }
  }
  if (index_new.to_exclusive != 0)
  {
    return (u64 *)pool->data + index_new.from;
  }
  else
  {
    Mary_Exit_Failure("out of memory");
    return 0;
  }
}

void Mary_Pool_Deallocate(Mary_Pool_t *pool, void *ptr)
{
  u64 from_target = (u64 *)ptr - (u64 *)pool->data;
  u64 from_left = 0, from_right = pool->index.size - 1, from_middle;
  Used_Space index;
  while (from_left <= from_right)
  {
    from_middle = from_left + from_right >> 1;
    MARY_Vector_At(pool->index, from_middle, index);
    if (index.from < from_target)
    {
      from_left = from_middle + 1;
    }
    else if (index.from > from_target)
    {
      from_right = from_middle - 1;
    }
    else
    {
      Mary_Vector_Erase_At(&pool->index, from_middle); return;
    }
  }
  Mary_Exit_Failure("invalid pointer");
}

/* I think some of this bit work can go into bitbool_t
void *Mary_Pool_Allocate_OLD(Mary_Pool_t *pool, size_t bytes)
{
  u64 size_8bit_data = pool->size_data;
  u64 size_1bit_index = size_8bit_data >> 3;
  u64 size_8bit_alloc = bytes + 7 & -8;
  u64 size_64bit_alloc = size_8bit_alloc >> 3;
  u64 cursor = pool->cursor; cursor = cursor < size_1bit_index ? cursor : 0;
  u64 cursor_should_loop = cursor != 0;
  u8 *index = pool->index, *ptr_byte, val_byte;
  u64 bit_from = 0, bit_to_exclusive = 0;
  u64 i = cursor, i_old, bit, need_from = 1, free;
  while (1)
  {
    if (i >= size_1bit_index)
    {
      if (cursor_should_loop)
      {
        i = 0; cursor_should_loop = 0;
      }
      else
      {
        break;
      }
    }
    // add check to see if last needed bit is set, and if so, cursor is set after it
    ptr_byte = index + i / 8; val_byte = *ptr_byte;
    if (need_from)
    {
      if (val_byte == 0xFF)
      {
        if (i + 63 < size_1bit_index && *(u64 *)ptr_byte == 0xFFFFFFFFFFFFFFFF)
        {
          i = i + 64 & -8; continue;
        }
        else if (i + 31 < size_1bit_index && *(u32 *)ptr_byte == 0xFFFFFFFF)
        {
          i = i + 32 & -8; continue;
        }
        else if (i + 15 < size_1bit_index && *(u16 *)ptr_byte == 0xFFFF)
        {
          i = i + 16 & -8; continue;
        }
        else
        {
          i = i + 8 & -8; continue;
        }
      }
      else
      {
        bit = val_byte & 1 << i % 8;
        if (bit == 0)
        {
          need_from = 0, bit_from = i, free = 0; continue;
        }
        else
        {
          ++i; continue;
        }
      }
    }
    else
    {
      if (val_byte == 0)
      {
        if (i + 63 < size_1bit_index && *(u64 *)ptr_byte == 0)
        {
          i_old = i; i = i + 64 & -8; free += i - i_old;
        }
        else if (i + 31 < size_1bit_index && *(u32 *)ptr_byte == 0)
        {
          i_old = i; i = i + 32 & -8; free += i - i_old;
        }
        else if (i + 15 < size_1bit_index && *(u16 *)ptr_byte == 0)
        {
          i_old = i; i = i + 16 & -8; free += i - i_old;
        }
        else
        {
          i_old = i; i = i + 8 & -8; free += i - i_old;
        }
        if (free >= size_64bit_alloc)
        {
          bit_to_exclusive = i - (free - size_64bit_alloc); break;
        }
      }
      else
      {
        bit = val_byte & 1 << i % 8;
        if (bit == 0)
        {
          if (++free == size_64bit_alloc)
          {
            bit_to_exclusive = i + 1; break;
          }
        }
        else
        {
          need_from = 1;
        }
        ++i; continue;
      }
    }
  }
  if (bit_to_exclusive)
  {
    // clean this up!
    u64 total_bits = size_64bit_alloc;
    u64 full64 = 0xFFFFFFFFFFFFFFFF;
    u32 full32 = 0xFFFFFFFF;
    u16 full16 = 0xFFFF;
    u8 full8 = 0xFF;
    u64 i = bit_from;
    u64 bit_in_byte_index = i % 8;
    ptr_byte = index + i / 8;
    while (total_bits && bit_in_byte_index)
    {
      memset(ptr_byte, *ptr_byte | 1 << bit_in_byte_index, 1);
      bit_in_byte_index = ++i % 8; --total_bits;
      ptr_byte = index + i / 8;
    }
    while (total_bits >= 64)
    {
      memcpy(ptr_byte, &full64, 8);
      i += 64; total_bits -= 64;
      ptr_byte = index + i / 8;
    }
    while (total_bits >= 32)
    {
      memcpy(ptr_byte, &full32, 4);
      i += 32; total_bits -= 32;
      ptr_byte = index + i / 8;
    }
    while (total_bits >= 16)
    {
      memcpy(ptr_byte, &full16, 2);
      i += 16; total_bits -= 16;
      ptr_byte = index + i / 8;
    }
    while (total_bits >= 8)
    {
      memcpy(ptr_byte, &full8, 1);
      i += 8; total_bits -= 8;
      ptr_byte = index + i / 8;
    }
    while (total_bits)
    {
      bit_in_byte_index = i % 8;
      memset(ptr_byte, *ptr_byte | 1 << bit_in_byte_index, 1);
      ++i; --total_bits;
    }
    pool->cursor = bit_to_exclusive;
    return (u8 *)pool->data + (bit_from << 3);
  }
  else
  {
    Mary_Exit_Failure("out of memory");
    return 0;
  }
}
*/

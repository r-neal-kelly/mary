#pragma once

#include <Mary/Utils.h> // maybe don't put in here, cause of macros.
#include <Mary/Vector.h>
#include <Mary/Bitbool.h>
#include <Mary/Hashmap.h>
#include <Mary/String.h>
#include <Mary/Font.h>
#include <Mary/OpenGL.h> // maybe hide in .c?
#include <Mary/Window.h>
#include <Mary/Text.h>

void Mary_Start();
void Mary_Finish();

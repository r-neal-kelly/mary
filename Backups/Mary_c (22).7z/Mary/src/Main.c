﻿#include <stdio.h>
#include <stdlib.h>
#include <Mary/Mary.h>

MARY_PRIMITIVES;

int main()
{
  //Mary_Start();

#if 0
  Mary_Window_t window;
  Mary_Window_Create(&window);
  while (Mary_Window_Can_Render())
  {
    Mary_Window_Render();
  }
  Mary_Window_Destroy(&window);
#endif

#if 0
  u64 val = 345893427923479;
  Mary_Print_Binary(&val, 8);
#endif

#if 1
  Mary_Vector_t v; u16 in;
  MARY_Vector_Create(v, u16, 6);
  for (u16 i = 0; i < 6; ++i)
  {
    MARY_Vector_Push_Back(v, i);
    u16 out; MARY_Vector_At(v, i, out);
    printf("%i ", out);
  } printf("\n");
  MARY_Vector_Add_Slice(v, 1, 3);
  in = 55;
  MARY_Vector_Assign(v, 1, in);
  MARY_Vector_Assign(v, 2, in);
  for (int i = 0; i < v.size; ++i)
  {
    u16 out; MARY_Vector_At(v, i, out);
    printf("%i ", out);
  } printf("\n");
  u16 out_elems[5];
  MARY_Vector_Copy_Slice(v, 3, 3 + 5, out_elems);
  for (int i = 0; i < 5; ++i)
  {
    printf("%i ", out_elems[i]);
  } printf("\n");
  for (int i = 0; i < v.size; ++i)
  {
    u16 out; MARY_Vector_At(v, i, out);
    printf("%i ", out);
  } printf("\n");
  MARY_Vector_Take_Slice(v, 1, 1 + 5, out_elems);
  for (int i = 0; i < 5; ++i)
  {
    printf("%i ", out_elems[i]);
  } printf("\n");
  for (int i = 0; i < v.size; ++i)
  {
    u16 out; MARY_Vector_At(v, i, out);
    printf("%i ", out);
  } printf("\n");
  MARY_Vector_Delete_Slice(v, 1, 2);
  for (int i = 0; i < v.size; ++i)
  {
    u16 out; MARY_Vector_At(v, i, out);
    printf("%i ", out);
  } printf("\n");

  // these funcs will be great when copying, moving, etc. in strings.

  u16 *pointer_to_elem;
  Mary_Vector_Point(&v, 1, &pointer_to_elem);
  printf("%p: %i\n", pointer_to_elem, *pointer_to_elem);
  MARY_Vector_Point(v, 0, pointer_to_elem);
  printf("%p: %i\n", pointer_to_elem, *pointer_to_elem);

  Mary_Exit_Success();
#endif

  Mary_Font_Start();
  Mary_Font_t font; Mary_String_t string;
  Mary_Font_Create(&font, "SILEOTSR.ttf");
  //Mary_String_Create(&string, 16, u"אהב", 0);
  Mary_String_Create(&string, 32, U"\u05D0\u200D\u05DC", 0); // mid is turned to zero. check cmap
  Mary_Font_Layout(&font, &string, MARY_FONT_HEBREW);
  Mary_String_Destroy(&string);
  Mary_Font_Destroy(&font);
  Mary_Font_Finish();

  Mary_Exit_Success();

  //Mary_Finish();
}

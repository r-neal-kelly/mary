#include <Mary/Alloc.h>
#include <Mary/Arena.h>

MARY_Primitives;

static Mary_Arena_t g_arena;

void Mary_Arena_Create_g(Mary_Size_t bytes)
{
  Mary_Arena_Create(&g_arena, bytes);
}

void Mary_Arena_Destroy_g()
{
  Mary_Arena_Destroy(&g_arena);
}

Mary_Index_t Mary_Arena_Push_Frame_g()
{
  return Mary_Arena_Push_Frame(&g_arena);
}

void Mary_Arena_Pop_Frame_g(Mary_Index_t validation)
{
  Mary_Arena_Pop_Frame(&g_arena, validation);
}

void *Mary_Arena_Alloc_Frame_g(Mary_Size_t bytes)
{
  return Mary_Arena_Alloc_Frame(&g_arena, bytes);
}

void *Mary_Arena_Alloc_Store_g(Mary_Size_t bytes)
{
  return Mary_Arena_Alloc_Store(&g_arena, bytes);
}

void *Mary_Arena_Alloc_Error_g()
{
  return Mary_Arena_Alloc_Error(&g_arena);
}

void Mary_Arena_Store_g(void *data)
{
  Mary_Arena_Store(&g_arena, data);
}



void Mary_Arena_Create(Mary_Arena_t *arena, Mary_Size_t bytes)
{
  Mary_Pool_Create(&arena->pool, bytes);
  Mary_Vector_Create(&arena->frames, sizeof(Mary_Arena_Frame_t), 8);
}

void Mary_Arena_Destroy(Mary_Arena_t *arena)
{
  // I kinda want to assert here too, like in Pop(), at least in the global, so that even on the last fram it becomes apparent that something isn't quite right.
  while (arena->frames.units > 0)
  {
    Mary_Arena_Pop_Frame(arena, arena->frames.units - 1);
  }
  Mary_Vector_Destroy(&arena->frames);

  Mary_Pool_Destroy(&arena->pool);
}

Mary_Index_t Mary_Arena_Push_Frame(Mary_Arena_t *arena)
{
  // if we work some more on pool, add a realloc to it, and some on vector, add a realloc option, then we can prob. put
  // these vectos on the pool as well, which is better by far than allocing heap each function.
  // there is also the potential of useing the stack to store the vectors,
  // if they are not to grow...maybe with alloca()
  Mary_Arena_Frame_t *frame = Mary_Vector_Point_Push_Back(&arena->frames);
  Mary_Vector_Create(&frame->allocs, sizeof(void *), 8);
  Mary_Vector_Create(&frame->errors, sizeof(Mary_Error_t *), 1);
  return arena->frames.units - 1;
}

void Mary_Arena_Pop_Frame(Mary_Arena_t *arena, Mary_Index_t validation)
{
  // I could move the validation up to the globals. I think I want to further separate the globals somehow. Maybe even with a different name.
  MARY_Assert_Message(validation == arena->frames.units - 1,
                      "Check that there is one MARY_In for ever MARY_Out/MARY_Return.");
  // we can also throw an unhandled exception assert if there are any errors that are left in vector

  // we have a prob. where if we could allocate in pool, and we allocate in heap, that this doesn't know that.
  Mary_Arena_Frame_t *frame = Mary_Vector_Point_Pop_Back(&arena->frames);

  if (frame != 0)
  {
    MARY_Vector_Each(&frame->allocs, void *)
    {
      if (Mary_Pool_Has_Ptr(&arena->pool, it.val))
      {
        Mary_Pool_Deallocate(&arena->pool, it.val);
      }
      else
      {
        Mary_Dealloc(MARY_ALLOC_HEAP, it.val);
      }
    }
    Mary_Vector_Destroy(&frame->allocs);

    MARY_Vector_Each(&frame->errors, void *)
    {
      if (Mary_Pool_Has_Ptr(&arena->pool, it.val))
      {
        Mary_Pool_Deallocate(&arena->pool, it.val);
      }
      else
      {
        Mary_Dealloc(MARY_ALLOC_HEAP, it.val);
      }
    }
    Mary_Vector_Destroy(&frame->errors);
  }
  else
  {
    MARY_Assert_Message(0, "No frames to pop!");
  }
}

void *Mary_Arena_Alloc_Frame(Mary_Arena_t *arena, Mary_Size_t bytes)
{
  if (arena->frames.units > 0)
  {
    Mary_Arena_Frame_t *frame = MARY_Vector_Point_Back(&arena->frames);
    void *data;
    if (arena->pool.free >= bytes)
    {
      data = Mary_Pool_Allocate(&arena->pool, bytes);
    }
    else
    {
      data = Mary_Alloc(MARY_ALLOC_HEAP, bytes); // could assert here if wanted.
    }
    Mary_Vector_Push_Back(&frame->allocs, &data);
    return data;
  }
  else
  {
    return 0;
  }
}

void *Mary_Arena_Alloc_Store(Mary_Arena_t *arena, Mary_Size_t bytes)
{
  if (arena->frames.units > 1)
  {
    Mary_Arena_Frame_t *store = MARY_Vector_Point(&arena->frames, arena->frames.units - 2);
    void *data;
    if (arena->pool.free >= bytes)
    {
      data = Mary_Pool_Allocate(&arena->pool, bytes);
    }
    else
    {
      data = Mary_Alloc(MARY_ALLOC_HEAP, bytes); // could assert here if wanted.
    }
    Mary_Vector_Push_Back(&store->allocs, &data);
    return data;
  }
  else
  {
    return 0;
  }
}

void *Mary_Arena_Alloc_Error(Mary_Arena_t *arena)
{
  // also we may want to allow bytes as a param so there can be different kinds of errors, like the event system.

  // pretty much the same as Alloc_Store, except, it should perhaps return
  // a bool to let the user know if there is a store or not.
  // that way they can simply assert if needed.
  if (arena->frames.units > 1)
  {
    Mary_Arena_Frame_t *store = MARY_Vector_Point(&arena->frames, arena->frames.units - 2);
    void *data; Mary_Size_t bytes = sizeof(Mary_Error_t);
    if (arena->pool.free >= bytes)
    {
      data = Mary_Pool_Allocate(&arena->pool, bytes);
    }
    else
    {
      data = Mary_Alloc(MARY_ALLOC_HEAP, bytes); // could assert here if wanted.
    }
    Mary_Vector_Push_Back(&store->errors, &data);
    return data;
  }
  else
  {
    return 0;
  }
}

void Mary_Arena_Store(Mary_Arena_t *arena, void *data) // Defer
{
  if (arena->frames.units > 1)
  {
    Mary_Arena_Frame_t *store = MARY_Vector_Point(&arena->frames, arena->frames.units - 2);
    Mary_Vector_Push_Back(&store->allocs, &data);

    Mary_Arena_Frame_t *frame = MARY_Vector_Point_Back(&arena->frames);
    Mary_Bool_t was_found;
    Mary_Index_t idx = Mary_Vector_Index_Of_Reverse(&frame->allocs, data, &was_found);
    if (was_found)
    {
      Mary_Vector_Erase_At(&frame->allocs, idx);
    }
    else
    {
      MARY_Assert_Message(0, "Couldn't find the data ptr in frame.");
    }
  }
  else
  {
    MARY_Assert_Message(0, "Store operation failed.");
  }
}

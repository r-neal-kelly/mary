#include <stdlib.h>
#include <Mary/Alloc.h>
#include <Mary/Arena.h>

MARY_Primitives;

// I want to have a func lookup table to find registered allocators that the user can add.

// also, all null ptrs stop here, at least while Assert is active.

void *Mary_Alloc(Mary_Enum_t allocator, Mary_Size_t bytes)
{
  void *data;
  if (allocator == MARY_ALLOC_HEAP)
  {
    data = malloc(bytes);
  }
  else if (allocator == MARY_ALLOC_FRAME)
  {
    data = Mary_Arena_Alloc_Frame_g(bytes);
  }
  else if (allocator == MARY_ALLOC_STORE)
  {
    data = Mary_Arena_Alloc_Store_g(bytes);
  }
  else
  {
    MARY_Assert_Message(0, "Not a valid allocator.");
    data = 0;
  }

  if (data == 0)
  {
    MARY_Assert_Message(0, "Out of memory.");
    return 0;
  }
  else
  {
    return data;
  }
}

void Mary_Dealloc(Mary_Enum_t allocator, void *data)
{
  if (allocator == MARY_ALLOC_HEAP)
  {
    free(data);
  }
  else
  {
    MARY_Assert_Message(0, "Not a valid allocator.");
  }
}

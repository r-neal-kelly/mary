#pragma once

#include <Mary/Utils.h>

enum Mary_Alloc_e
{
  MARY_ALLOC_STACK,
  MARY_ALLOC_HEAP,
  MARY_ALLOC_FRAME, // for these two, we may want to define in a macro in Arena.h or hidden somehow, because we do not want a user accessing it unless they have added a frame to the stack.
  MARY_ALLOC_STORE // ""
};

void *Mary_Alloc(Mary_Enum_t allocator, Mary_Size_t bytes);
void *Mary_Realloc(Mary_Enum_t allocator, void *data, Mary_Size_t bytes);
void Mary_Dealloc(Mary_Enum_t allocator, void *data);
void Mary_Alloc_Register();

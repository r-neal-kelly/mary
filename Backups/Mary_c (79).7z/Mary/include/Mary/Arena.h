#pragma once

#include <Mary/Utils.h>
#include <Mary/Pool.h>
#include <Mary/Vector.h>

// the idea is that we macro start and macro end the arena session in each function.
// every Arena alloc goes into the arena pool, and is tracked in a vector with other
// allocs made in the same function.

// but on the macro return, all the items listed are taken out of the function's vector
// and put in the caller's vector, but the rest are dealloc'd in the function.
// the ones that traverse the tree are dealloc'd in the parent function that they are
// last returned to.

// we don't need to worry about allocs that are passed as params, unless we alloc them in that function.
// we could probable return those as well to erase from the list. and we can still have the regular return item as well
// also, we can use this system for trying and cactching errors too. in a try block, it simply sees if there was any error in 
// the delivery, a separate vector perhaps.

typedef struct
{
  Mary_Pool_t pool;
  Mary_Vector_t frames;
}
Mary_Arena_t;

typedef struct
{
  Mary_Vector_t allocs;
  Mary_Vector_t errors;
}
Mary_Arena_Frame_t;

// if we ever do threading, we will have to figure out how to make a global Arena_t for each thread. a simple lookup table
// would work if we can get thread details within the func, instead of passed in.

void Mary_Arena_Create_g(Mary_Size_t bytes); // can be passed in as a param by user in main before starting up Mary. also might change name. was using start/finish to make it distinctly global, but could come up with a better standard.
void Mary_Arena_Destroy_g();
Mary_Index_t Mary_Arena_Push_Frame_g();
void Mary_Arena_Pop_Frame_g(Mary_Index_t validation);
void *Mary_Arena_Alloc_Frame_g(Mary_Size_t bytes);
void *Mary_Arena_Alloc_Store_g(Mary_Size_t bytes);
void *Mary_Arena_Alloc_Error_g();
void Mary_Arena_Store_g(void *data);

void Mary_Arena_Create(Mary_Arena_t *arena, Mary_Size_t bytes);
void Mary_Arena_Destroy(Mary_Arena_t *arena);
Mary_Index_t Mary_Arena_Push_Frame(Mary_Arena_t *arena); // opt_units for allocs?
void Mary_Arena_Pop_Frame(Mary_Arena_t *arena, Mary_Index_t validation);
void *Mary_Arena_Alloc_Frame(Mary_Arena_t *arena, Mary_Size_t bytes);
void *Mary_Arena_Alloc_Store(Mary_Arena_t *arena, Mary_Size_t bytes);
void *Mary_Arena_Alloc_Error(Mary_Arena_t *arena);
void Mary_Arena_Store(Mary_Arena_t *arena, void *data);
// we'll also want a Save function so that it doesn't get freed.

#define MARY_Arena_In\
  enum Mary_Alloc_e { STACK, HEAP, FRAME, STORE };\
  const Mary_Index_t MARY_ARENA_FRAME_ID = Mary_Arena_Push_Frame_g()

#define MARY_Arena_Out\
  Mary_Arena_Pop_Frame_g(MARY_ARENA_FRAME_ID)

#define MARY_Arena_Return\
  Mary_Arena_Pop_Frame_g(MARY_ARENA_FRAME_ID); return

#define MARY_Arena_Store(DATA)\
  Mary_Arena_Store_g(DATA)

// too complicated?
#define MARY_Arena_Store_Return(DATA)\
  Mary_Arena_Store_g(DATA);\
  Mary_Arena_Pop_Frame_g(MARY_ARENA_FRAME_ID);\
  return DATA

#define intern static
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <Mary/Utils.h>
#include <Mary/Vector.h>
typedef uint8_t byte_t;

void   Mary_Vector_Create    (Mary_Vector_t *vector, size_t unit, size_t opt_reserve);
void   Mary_Vector_Destroy   (Mary_Vector_t *vector);
void   Mary_Vector_Reserve   (Mary_Vector_t *vector, size_t size);
void   Mary_Vector_Fit       (Mary_Vector_t *vector);
void   Mary_Vector_Insert    (Mary_Vector_t *vector, size_t index, void *elem_in);
void   Mary_Vector_Eject     (Mary_Vector_t *vector, size_t index, void *elem_out);
void   Mary_Vector_Assign    (Mary_Vector_t *vector, size_t index, void *elem_in);
void   Mary_Vector_Exchange  (Mary_Vector_t *vector, size_t index, void *elem_in, void *elem_out);
void   Mary_Vector_Push_Back (Mary_Vector_t *vector, void *elem_in);
void   Mary_Vector_Push_Front(Mary_Vector_t *vector, void *elem_in);
void   Mary_Vector_Pop_Back  (Mary_Vector_t *vector, void *elem_out);
void   Mary_Vector_Pop_Front (Mary_Vector_t *vector, void *elem_out);
void   Mary_Vector_At        (Mary_Vector_t *vector, size_t index, void *elem_out);
char   Mary_Vector_Has_At    (Mary_Vector_t *vector, size_t index);
void   Mary_Vector_Back      (Mary_Vector_t *vector, void *elem_out);
void   Mary_Vector_Front     (Mary_Vector_t *vector, void *elem_out);
void   Mary_Vector_Empty     (Mary_Vector_t *vector, size_t opt_reserve);
char   Mary_Vector_Is_Empty  (Mary_Vector_t *vector);
void   Mary_Vector_Resize    (Mary_Vector_t *vector, size_t size);
void   Mary_Vector_Fill      (Mary_Vector_t *vector, void *elem_in);
void   Mary_Vector_Rotate    (Mary_Vector_t *vector, void *elem_out);
void   Mary_Vector_Reverse   (Mary_Vector_t *vector);
char   Mary_Vector_Contains  (Mary_Vector_t *vector, void *elem);
size_t Mary_Vector_Index_Of  (Mary_Vector_t *vector, void *elem, char *out_was_found);
void   Mary_Vector_Erase_At  (Mary_Vector_t *vector, size_t index);
void   Mary_Vector_Erase     (Mary_Vector_t *vector, void *elem);

void Mary_Vector_Create(Mary_Vector_t *vector, size_t unit, size_t opt_reserve)
{
  void *data = malloc((opt_reserve) ? (opt_reserve * unit) : unit);
  if (data)
  {
    vector->data = data;
    vector->capacity = unit;
    vector->unit = unit;
    vector->size = 0;
  }
}

void Mary_Vector_Destroy(Mary_Vector_t *vector)
{
  free(vector->data);
}

void Mary_Vector_Reserve(Mary_Vector_t *vector, size_t size)
{
  size_t old_capacity = vector->capacity;
  size_t new_capacity = size * vector->unit;
  if (new_capacity > old_capacity)
  {
    void *data = vector->data;
    data = realloc(data, new_capacity);
    if (data)
    {
      vector->data = data;
      vector->capacity = new_capacity;
    }
  }
}

void Mary_Vector_Fit(Mary_Vector_t *vector)
{
  size_t capacity = vector->capacity;
  size_t unit = vector->unit;
  size_t size = vector->size;
  size_t fit_capacity = (size) ? (size * unit) : unit;
  if (capacity != fit_capacity)
  {
    void *data = vector->data;
    data = realloc(data, fit_capacity);
    if (data)
    {
      vector->data = data;
      vector->capacity = fit_capacity;
    }
  }
}

void Mary_Vector_Insert(Mary_Vector_t *vector, size_t index, void *elem_in)
{
  size_t capacity = vector->capacity;
  size_t unit = vector->unit;
  size_t size = vector->size + 1;
  if (size * unit > capacity)
  {
    Mary_Vector_Reserve(vector, size * 2);
  }

  void *data = vector->data;
  size_t i = size - 1;
  byte_t *p = (byte_t *)data + (i * unit);
  for (; i > index; --i, p -= unit)
  {
    memmove(p, p - unit, unit);
  }
  memmove(p, elem_in, unit);

  vector->size = size;
}

void Mary_Vector_Eject(Mary_Vector_t *vector, size_t index, void *elem_out)
{
  size_t unit = vector->unit;
  size_t size = vector->size - 1;
  void *data = vector->data;
  byte_t *p = (byte_t *)data + (index * unit);
  memmove(elem_out, p, unit);
  for (; index < size; ++index, p += unit)
  {
    memmove(p, p + unit, unit);
  }

  vector->size = size;
}

void Mary_Vector_Assign(Mary_Vector_t *vector, size_t index, void *elem_in)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  byte_t *p = (byte_t *)data + (index * unit);
  memmove(p, elem_in, unit);
}

void Mary_Vector_Exchange(Mary_Vector_t *vector, size_t index, void *elem_in, void *elem_out)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  byte_t *p = (byte_t *)data + (index * unit);
  memmove(elem_out, p, unit);
  memmove(p, elem_in, unit);
}

void Mary_Vector_Push_Back(Mary_Vector_t *vector, void *elem_in)
{
  Mary_Vector_Insert(vector, vector->size, elem_in);
}

void Mary_Vector_Push_Front(Mary_Vector_t *vector, void *elem_in)
{
  Mary_Vector_Insert(vector, 0, elem_in);
}

void Mary_Vector_Pop_Back(Mary_Vector_t *vector, void *elem_out)
{
  size_t size = vector->size;
  Mary_Vector_Eject(vector, (size) ? size - 1 : 0, elem_out);
}

void Mary_Vector_Pop_Front(Mary_Vector_t *vector, void *elem_out)
{
  Mary_Vector_Eject(vector, 0, elem_out);
}

void Mary_Vector_At(Mary_Vector_t *vector, size_t index, void *elem_out)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  byte_t *p = (byte_t *)data + (index * unit);
  memmove(elem_out, p, unit);
}

char Mary_Vector_Has_At(Mary_Vector_t *vector, size_t index)
{
  return index < vector->size;
}

void Mary_Vector_Back(Mary_Vector_t *vector, void *elem_out)
{
  size_t size = vector->size;
  Mary_Vector_At(vector, (size) ? size - 1 : 0, elem_out);
}

void Mary_Vector_Front(Mary_Vector_t *vector, void *elem_out)
{
  Mary_Vector_At(vector, 0, elem_out);
}

void Mary_Vector_Empty(Mary_Vector_t *vector, size_t opt_reserve)
{
  size_t unit = vector->unit;
  Mary_Vector_Destroy(vector);
  Mary_Vector_Create(vector, unit, opt_reserve);
}

char Mary_Vector_Is_Empty(Mary_Vector_t *vector)
{
  return vector->size != 0;
}

void Mary_Vector_Resize(Mary_Vector_t *vector, size_t size)
{
  vector->size = size;
  Mary_Vector_Fit(vector);
}

void Mary_Vector_Fill(Mary_Vector_t *vector, void *elem_in)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  size_t size = vector->size;
  byte_t *p = (byte_t *)data;
  for (size_t i = 0; i < size; ++i, p += unit)
  {
    memmove(p, elem_in, unit);
  }
}

void Mary_Vector_Rotate(Mary_Vector_t *vector, void *elem_out)
{
  size_t size = vector->size;
  if (size > 1)
  {
    void *data = vector->data;
    size_t unit = vector->unit;
    size_t i = size - 1;
    byte_t *first = (byte_t *)data;
    byte_t *last = first + (i * unit);
    memmove(elem_out, last, unit);
    for (; i > 0; --i, last -= unit)
    {
      memmove(last, last - unit, unit);
    }
    memmove(first, elem_out, unit);
  }
}

void Mary_Vector_Reverse(Mary_Vector_t *vector)
{
  size_t size = vector->size;
  if (size > 1)
  {
    size_t unit = vector->unit;
    byte_t *temp = malloc(unit);
    if (temp)
    {
      void *data = vector->data;
      size_t a = 0, b = size - 1;
      byte_t *pA = (byte_t *)data;
      byte_t *pB = pA + (b * unit);
      for (; a < b; ++a, --b, pA += unit, pB -= unit)
      {
        memcpy(temp, pA, unit);
        memmove(pA, pB, unit);
        memcpy(pB, temp, unit);
      }
      free(temp);
    }
  }
}

char Mary_Vector_Contains(Mary_Vector_t *vector, void *elem)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  size_t size = vector->size;
  byte_t *p = (byte_t *)data;
  for (size_t i = 0; i < size; ++i, p += unit)
  {
    if (memcmp(p, elem, unit) == 0)
    {
      return 1;
    }
  }
  return 0;
}

size_t Mary_Vector_Index_Of(Mary_Vector_t *vector, void *elem, char *out_was_found)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  size_t size = vector->size;
  byte_t *p = (byte_t *)data;
  size_t i = 0; char was_found;
  for (; i < size; ++i, p += unit)
  {
    if (memcmp(p, elem, unit) == 0)
    {
      was_found = 1;
      memmove(out_was_found, &was_found, sizeof(char));
      return i;
    }
  }
  was_found = 0;
  memmove(out_was_found, &was_found, sizeof(char));
  return i;
}

void Mary_Vector_Erase_At(Mary_Vector_t *vector, size_t index)
{
  size_t unit = vector->unit;
  size_t size = vector->size - 1;
  void *data = vector->data;
  byte_t *p = (byte_t *)data + (index * unit);
  for (; index < size; ++index, p += unit)
  {
    memmove(p, p + unit, unit);
  }

  vector->size = size;
}

void Mary_Vector_Erase(Mary_Vector_t *vector, void *elem)
{
  char was_found = 0;
  size_t index = Mary_Vector_Index_Of(vector, elem, &was_found);
  if (was_found)
  {
    Mary_Vector_Erase_At(vector, index);
  }
}

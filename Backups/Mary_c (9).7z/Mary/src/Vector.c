#define intern static
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <Mary/Utils.h>
#include <Mary/Vector.h>
typedef uint8_t byte_t;

const Mary_Vector_i *Mary_Vector();
intern void   Create    (Mary_Vector_t *vector, size_t unit);
intern void   Destroy   (Mary_Vector_t *vector);
intern void   Reserve   (Mary_Vector_t *vector, size_t size);
intern void   Fit       (Mary_Vector_t *vector);
intern void   Insert    (Mary_Vector_t *vector, size_t index, void *elem_in);
intern void   Eject     (Mary_Vector_t *vector, size_t index, void *elem_out);
intern void   Assign    (Mary_Vector_t *vector, size_t index, void *elem_in);
intern void   Exchange  (Mary_Vector_t *vector, size_t index, void *elem_in, void *elem_out);
intern void   Push_Back (Mary_Vector_t *vector, void *elem_in);
intern void   Push_Front(Mary_Vector_t *vector, void *elem_in);
intern void   Pop_Back  (Mary_Vector_t *vector, void *elem_out);
intern void   Pop_Front (Mary_Vector_t *vector, void *elem_out);
intern void   At        (Mary_Vector_t *vector, size_t index, void *elem_out);
intern char   Has_At    (Mary_Vector_t *vector, size_t index);
intern void   Back      (Mary_Vector_t *vector, void *elem_out);
intern void   Front     (Mary_Vector_t *vector, void *elem_out);
intern void   Empty     (Mary_Vector_t *vector);
intern char   Is_Empty  (Mary_Vector_t *vector);
intern void   Resize    (Mary_Vector_t *vector, size_t size);
intern void   Fill      (Mary_Vector_t *vector, void *elem_in);
intern void   Rotate    (Mary_Vector_t *vector, void *elem_out);
intern void   Reverse   (Mary_Vector_t *vector);
intern char   Contains  (Mary_Vector_t *vector, void *elem);
intern size_t Index_Of  (Mary_Vector_t *vector, void *elem, char *out_was_found);
intern void   Erase_At  (Mary_Vector_t *vector, size_t index);
intern void   Erase     (Mary_Vector_t *vector, void *elem);
// Filter
// Index_Of
// Copy
// Every/For_Each/Find/Find_Index
// Rotate_Right/Back and Rotate_Left/Front

const Mary_Vector_i *Mary_Vector()
{
  static const Mary_Vector_i interface =
    { Create, Destroy
    , Reserve, Fit
    , Insert, Eject
    , Assign, Exchange
    , Push_Back, Push_Front
    , Pop_Back, Pop_Front
    , At, Has_At
    , Back, Front
    , Empty, Is_Empty
    , Resize, Fill
    , Rotate, Reverse
    , Contains, Index_Of
    , Erase_At, Erase
    };

  return &interface;
}

intern void Create(Mary_Vector_t *vector, size_t unit)
{
  void *data = malloc(unit);
  if (data)
  {
    vector->data = data;
    vector->capacity = unit;
    vector->unit = unit;
    vector->size = 0;
  }
}

intern void Destroy(Mary_Vector_t *vector)
{
  free(vector->data);
}

intern void Reserve(Mary_Vector_t *vector, size_t size)
{
  size_t old_capacity = vector->capacity;
  size_t new_capacity = size * vector->unit;
  if (new_capacity > old_capacity)
  {
    void *data = vector->data;
    data = realloc(data, new_capacity);
    if (data)
    {
      vector->data = data;
      vector->capacity = new_capacity;
    }
  }
}

intern void Fit(Mary_Vector_t *vector)
{
  size_t capacity = vector->capacity;
  size_t unit = vector->unit;
  size_t size = vector->size;
  size_t fit_capacity = (size) ? (size * unit) : unit;
  if (capacity != fit_capacity)
  {
    void *data = vector->data;
    data = realloc(data, fit_capacity);
    if (data)
    {
      vector->data = data;
      vector->capacity = fit_capacity;
    }
  }
}

intern void Insert(Mary_Vector_t *vector, size_t index, void *elem_in)
{
  size_t capacity = vector->capacity;
  size_t unit = vector->unit;
  size_t size = vector->size + 1;
  if (size * unit > capacity)
  {
    Reserve(vector, size * 2);
  }

  void *data = vector->data;
  size_t i = size - 1;
  byte_t *p = (byte_t *)data + (i * unit);
  for (; i > index; --i, p -= unit)
  {
    memmove(p, p - unit, unit);
  }
  memmove(p, elem_in, unit);

  vector->size = size;
}

intern void Eject(Mary_Vector_t *vector, size_t index, void *elem_out)
{
  size_t unit = vector->unit;
  size_t size = vector->size - 1;
  void *data = vector->data;
  byte_t *p = (byte_t *)data + (index * unit);
  memmove(elem_out, p, unit);
  for (; index < size; ++index, p += unit)
  {
    memmove(p, p + unit, unit);
  }

  vector->size = size;
}

intern void Assign(Mary_Vector_t *vector, size_t index, void *elem_in)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  byte_t *p = (byte_t *)data + (index * unit);
  memmove(p, elem_in, unit);
}

intern void Exchange(Mary_Vector_t *vector, size_t index, void *elem_in, void *elem_out)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  byte_t *p = (byte_t *)data + (index * unit);
  memmove(elem_out, p, unit);
  memmove(p, elem_in, unit);
}

intern void Push_Back(Mary_Vector_t *vector, void *elem_in)
{
  Insert(vector, vector->size, elem_in);
}

intern void Push_Front(Mary_Vector_t *vector, void *elem_in)
{
  Insert(vector, 0, elem_in);
}

intern void Pop_Back(Mary_Vector_t *vector, void *elem_out)
{
  size_t size = vector->size;
  Eject(vector, (size) ? size - 1 : 0, elem_out);
}

intern void Pop_Front(Mary_Vector_t *vector, void *elem_out)
{
  Eject(vector, 0, elem_out);
}

intern void At(Mary_Vector_t *vector, size_t index, void *elem_out)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  byte_t *p = (byte_t *)data + (index * unit);
  memmove(elem_out, p, unit);
}

intern char Has_At(Mary_Vector_t *vector, size_t index)
{
  return index < vector->size;
}

intern void Back(Mary_Vector_t *vector, void *elem_out)
{
  size_t size = vector->size;
  At(vector, (size) ? size - 1 : 0, elem_out);
}

intern void Front(Mary_Vector_t *vector, void *elem_out)
{
  At(vector, 0, elem_out);
}

intern void Empty(Mary_Vector_t *vector)
{
  size_t unit = vector->unit;
  Destroy(vector);
  Create(vector, unit);
}

intern char Is_Empty(Mary_Vector_t *vector)
{
  return vector->size != 0;
}

intern void Resize(Mary_Vector_t *vector, size_t size)
{
  vector->size = size;
  Fit(vector);
}

intern void Fill(Mary_Vector_t *vector, void *elem_in)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  size_t size = vector->size;
  byte_t *p = (byte_t *)data;
  for (size_t i = 0; i < size; ++i, p += unit)
  {
    memmove(p, elem_in, unit);
  }
}

intern void Rotate(Mary_Vector_t *vector, void *elem_out)
{
  size_t size = vector->size;
  if (size > 1)
  {
    void *data = vector->data;
    size_t unit = vector->unit;
    size_t i = size - 1;
    byte_t *first = (byte_t *)data;
    byte_t *last = first + (i * unit);
    memmove(elem_out, last, unit);
    for (; i > 0; --i, last -= unit)
    {
      memmove(last, last - unit, unit);
    }
    memmove(first, elem_out, unit);
  }
}

intern void Reverse(Mary_Vector_t *vector)
{
  size_t size = vector->size;
  if (size > 1)
  {
    size_t unit = vector->unit;
    byte_t *temp = malloc(unit);
    if (temp)
    {
      void *data = vector->data;
      size_t a = 0, b = size - 1;
      byte_t *pA = (byte_t *)data;
      byte_t *pB = pA + (b * unit);
      for (; a < b; ++a, --b, pA += unit, pB -= unit)
      {
        memcpy(temp, pA, unit);
        memmove(pA, pB, unit);
        memcpy(pB, temp, unit);
      }
      free(temp);
    }
  }
}

intern char Contains(Mary_Vector_t *vector, void *elem)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  size_t size = vector->size;
  byte_t *p = (byte_t *)data;
  for (size_t i = 0; i < size; ++i, p += unit)
  {
    if (memcmp(p, elem, unit) == 0)
    {
      return 1;
    }
  }
  return 0;
}

intern size_t Index_Of(Mary_Vector_t *vector, void *elem, char *out_was_found)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  size_t size = vector->size;
  byte_t *p = (byte_t *)data;
  size_t i = 0; char was_found;
  for (; i < size; ++i, p += unit)
  {
    if (memcmp(p, elem, unit) == 0)
    {
      was_found = 1;
      memmove(out_was_found, &was_found, sizeof(char));
      return i;
    }
  }
  was_found = 0;
  memmove(out_was_found, &was_found, sizeof(char));
  return i;
}

intern void Erase_At(Mary_Vector_t *vector, size_t index)
{
  size_t unit = vector->unit;
  size_t size = vector->size - 1;
  void *data = vector->data;
  byte_t *p = (byte_t *)data + (index * unit);
  for (; index < size; ++index, p += unit)
  {
    memmove(p, p + unit, unit);
  }

  vector->size = size;
}

intern void Erase(Mary_Vector_t *vector, void *elem)
{
  char was_found = 0;
  size_t index = Index_Of(vector, elem, &was_found);
  if (was_found)
  {
    Erase_At(vector, index);
  }
}

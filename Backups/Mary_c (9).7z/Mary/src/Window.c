#define intern static
#define method static
#define global
#include <stdio.h>
#include <stdint.h>
#include <Mary/Bitbool.h>
#include <Mary/Vector.h>
#include <Mary/OpenGL.h>
#include <Mary/Window.h>

global void Mary_Window_Start();
global void Mary_Window_Finish();
global char Mary_Window_Can_Render();
global void Mary_Window_Render();
global const Mary_Window_i *Mary_Window();
method void Create(Mary_Window_t *window);
method void Destroy(Mary_Window_t *window);
intern int64_t __stdcall Win32_Wnd_Proc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp);
method void Close(Mary_Window_t *window);
method void Show(Mary_Window_t *window);
method void Hide(Mary_Window_t *window);
intern void Render_Self(Mary_Window_t *window);

intern const Mary_Vector_i *vector_i;
intern Mary_Vector_t windows_v;
intern const Mary_Bitbool_i *bb_i;
intern const uint16_t win32_class_name[] = u"Mary_Win32_Class";
intern HGLRC g_opengl_context = 0;
intern int g_opengl_pixel_format = 0;

enum WINDOW_FLAGS
{
  SHOULD_RENDER
};

// make a Mary_Win32_t interface for use in here an else where. static
global void Mary_Window_Start()
{
  vector_i = Mary_Vector();
  vector_i->Create(&windows_v, sizeof(Mary_Window_t *));

  bb_i = Mary_Bitbool();

  WNDCLASSEX win32_class;
  memset(&win32_class, 0, sizeof(win32_class));
  win32_class.cbSize = sizeof(win32_class);
  win32_class.lpfnWndProc = Win32_Wnd_Proc;
  win32_class.hCursor = LoadCursor(0, IDC_ARROW);
  win32_class.hbrBackground = (HBRUSH)8;
  win32_class.lpszClassName = win32_class_name;
  win32_class.style = CS_OWNDC;
  RegisterClassEx(&win32_class);

  Mary_OpenGL_g g_opengl = Mary_OpenGL();
  g_opengl_context = g_opengl.context;
  g_opengl_pixel_format = g_opengl.pixel_format;
}

global void Mary_Window_Finish()
{
  vector_i->Destroy(&windows_v);
}

global char Mary_Window_Can_Render()
{
  return vector_i->Is_Empty(&windows_v);
}

global void Mary_Window_Render()
{
  Mary_Window_t *window = 0;
  size_t size = windows_v.size;
  for (size_t i = 0; i < size; ++i)
  {
    vector_i->At(&windows_v, i, &window);
    Render_Self(window);
  }
  Sleep(1);
}

global const Mary_Window_i *Mary_Window()
{
  static const Mary_Window_i interface =
    { Create
    , Destroy
    , Close
    , Show
    , Hide
    };
  return &interface;
}

method void Create(Mary_Window_t *window)
{
  memset(window, 0, sizeof(window));
  vector_i->Push_Back(&windows_v, &window);

  HWND win32_hwnd = CreateWindowEx
    ( WS_EX_CLIENTEDGE
    , win32_class_name
    , L"Praise Yahweh!"
    , WS_OVERLAPPEDWINDOW
    , 100, 100
    , 800, 600
    , 0, 0, 0, 0
    );
  window->win32_hwnd = win32_hwnd;
  
  HDC win32_hdc = GetDC(win32_hwnd);
  window->win32_hdc = win32_hdc;

  PIXELFORMATDESCRIPTOR pfd;
  memset(&pfd, 0, sizeof(pfd));
  SetPixelFormat(win32_hdc, g_opengl_pixel_format, &pfd);

  char flags = window->flags;
  bb_i->Fill(&flags, sizeof(flags), 0);
  bb_i->Assign(&flags, sizeof(flags), SHOULD_RENDER, 1);
  window->flags = flags;

  Show(window);
}

method void Destroy(Mary_Window_t *window)
{
  HWND win32_hwnd = window->win32_hwnd;
  HDC win32_hdc = window->win32_hdc;
  ReleaseDC(win32_hwnd, win32_hdc);
  DestroyWindow(win32_hwnd);
  memset(window, 0, sizeof(window));
}

intern int64_t __stdcall Win32_Wnd_Proc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
{
  Mary_Window_t *window = 0;
  size_t size = windows_v.size;
  for (size_t i = 0; i < size; ++i)
  {
    vector_i->At(&windows_v, i, &window);
    if (window->win32_hwnd == hwnd) break;
  }

  if (!window)
  {
    return DefWindowProc(hwnd, msg, wp, lp);
  }
  else if (msg == WM_CLOSE)
  {
    Close(window);
    return 0;
  }
  else if (msg == WM_SIZE)
  {
    bb_i->Assign(&window->flags, sizeof(window->flags), SHOULD_RENDER, 1);
    Render_Self(window);
    return 0;
  }
  else if (msg == WM_MOVE)
  {
    bb_i->Assign(&window->flags, sizeof(window->flags), SHOULD_RENDER, 1);
    Render_Self(window);
    return 0;
  }
  else
  {
    return DefWindowProc(hwnd, msg, wp, lp);
  }
}

method void Close(Mary_Window_t *window)
{
  HWND win32_hwnd = window->win32_hwnd;
  // can send a confirm if a bitbool flag is set by user
  DestroyWindow(win32_hwnd);
  vector_i->Erase(&windows_v, &window);
}

method void Show(Mary_Window_t *window)
{
  HWND win32_hwnd = window->win32_hwnd;
  ShowWindow(win32_hwnd, SW_NORMAL);
  UpdateWindow(win32_hwnd);
}

method void Hide(Mary_Window_t *window)
{
  ShowWindow(window->win32_hwnd, SW_HIDE);
}

intern void Render_Self(Mary_Window_t *window)
{
  static MSG msg;
  HWND win32_hwnd = window->win32_hwnd;
  HDC win32_hdc = window->win32_hdc;
  char flags = window->flags;
  while (PeekMessage(&msg, win32_hwnd, 0, 0, PM_REMOVE))
  {
    TranslateMessage(&msg);
    DispatchMessage(&msg);
  }
  if (bb_i->At(&flags, sizeof(flags), SHOULD_RENDER))
  {
    wglMakeCurrent(win32_hdc, g_opengl_context);
    // maybe these things can go in a object
    glViewport(0, 0, 800, 600); // need to get inner dimensions from callback
    glClearColor(1.0f, 0.4f, 0.8f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    ////// render children, but for now we do testing.
    {
      static float vertices[] =
      { //  x,     y,     z,    r,    g,    b
        -0.6f, -0.6f, +0.0f, 1.0f, 0.0f, 0.0f,
        +0.0f, +0.6f, +0.0f, 0.0f, 1.0f, 0.0f,
        +0.6f, -0.6f, +0.0f, 0.0f, 0.0f, 1.0f
      };
      static GLuint program = 0;
      if (!program)
      {
        program = Mary_OpenGL_Shader("Mary/shaders/basic_v.shader", "Mary/shaders/basic_f.shader");
        glUseProgram(program);
      }
      static GLuint VAO = 0; // vertex array object
      static GLuint VBO = 0; // vertex buffer object
      if (!VAO || !VBO)
      {
        glGenVertexArrays(1, &VAO);
        glGenBuffers(1, &VBO);
        glBindVertexArray(VAO);
        glBindBuffer(GL_ARRAY_BUFFER, VBO);
        glEnableVertexAttribArray(0);
        glEnableVertexAttribArray(1);
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(float) * 6, (void *)(sizeof(float) * 0));
        glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(float) * 6, (void *)(sizeof(float) * 3));
        glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_DYNAMIC_DRAW);
      }
      glDrawArrays(GL_TRIANGLES, 0, 3);
      //printf("%i ", glGetError());
    }
    //////
    SwapBuffers(win32_hdc);
    bb_i->Assign(&flags, sizeof(flags), SHOULD_RENDER, 0);
    window->flags = flags;
  }
}

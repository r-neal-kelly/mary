#include <stdlib.h>
#include <stdio.h>
#include <Mary/Utils.h>

void Mary_Exit_Success()
{
  puts("press enter to exit...");
  getc(stdin);
  exit(EXIT_SUCCESS);
}

void Mary_Exit_Failure(const char *error_string)
{
  printf("MARY FATAL ERROR: %s\n", error_string);
  puts("press enter to exit...");
  getc(stdin);
  exit(EXIT_FAILURE);
}

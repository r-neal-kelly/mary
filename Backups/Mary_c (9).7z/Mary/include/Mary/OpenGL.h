#pragma once

#include <Mary/OS.h>

#define WGL_DRAW_TO_WINDOW_ARB 0x2001
#define WGL_SUPPORT_OPENGL_ARB 0x2010
#define WGL_DOUBLE_BUFFER_ARB 0x2011
#define WGL_PIXEL_TYPE_ARB 0x2013
#define WGL_COLOR_BITS_ARB 0x2014
#define WGL_DEPTH_BITS_ARB 0x2022
#define WGL_STENCIL_BITS_ARB 0x2023
#define WGL_TYPE_RGBA_ARB 0x202B
#define WGL_SAMPLE_BUFFERS_ARB 0x2041
#define WGL_SAMPLES_ARB 0x2042
#define WGL_CONTEXT_MAJOR_VERSION_ARB 0x2091
#define WGL_CONTEXT_MINOR_VERSION_ARB 0x2092
#define WGL_CONTEXT_PROFILE_MASK_ARB 0x9126
#define WGL_CONTEXT_CORE_PROFILE_BIT_ARB 0x0001
#define WGL_CONTEXT_COMPATIBILITY_PROFILE_BIT_ARB 0x0002

#define GL_FALSE 0x0000
#define GL_TRUE 0x0001
#define GL_VENDOR 0x1F00
#define GL_RENDERER 0x1F01
#define GL_VERSION 0x1F02
#define GL_EXTENSIONS 0x1F03
#define GL_COLOR_BUFFER_BIT 0x4000
#define GL_DEPTH_BUFFER_BIT 0x0100
#define GL_STENCIL_BUFFER_BIT 0x0400
#define GL_MODELVIEW 0x1700
#define GL_PROJECTION 0x1701
#define GL_TEXTURE 0x1702
#define GL_VERTEX_SHADER 0x8B31
#define GL_FRAGMENT_SHADER 0x8B30
#define GL_COMPUTE_SHADER 0x91B9
#define GL_COMPILE_STATUS 0x8B81
#define GL_INFO_LOG_LENGTH 0x8B84
#define GL_ARRAY_BUFFER 0x8892
#define GL_COPY_READ_BUFFER 0x8F36
#define GL_COPY_WRITE_BUFFER 0x8F37
#define GL_ELEMENT_ARRAY_BUFFER 0x8893
#define GL_PIXEL_PACK_BUFFER 0x88EB
#define GL_PIXEL_UNPACK_BUFFER 0x88EC
#define GL_TEXTURE_BUFFER 0x8C2A
#define GL_TRANSFORM_FEEDBACK_BUFFER 0x8C8E
#define GL_UNIFORM_BUFFER 0x8A11
#define GL_STREAM_DRAW 0x88E0
#define GL_STREAM_READ 0x88E1
#define GL_STREAM_COPY 0x88E2
#define GL_STATIC_DRAW 0x88E4
#define GL_STATIC_READ 0x88E5
#define GL_STATIC_COPY 0x88E6
#define GL_DYNAMIC_DRAW 0x88E8
#define GL_DYNAMIC_READ 0x88E9
#define GL_DYNAMIC_COPY 0x88EA
#define GL_BYTE 0x1400
#define GL_UNSIGNED_BYTE 0x1401
#define GL_SHORT 0x1402
#define GL_UNSIGNED_SHORT 0x1403
#define GL_INT 0x1404
#define GL_UNSIGNED_INT 0x1405
#define GL_HALF_FLOAT 0x140B
#define GL_FLOAT 0x1406
#define GL_DOUBLE 0x140A
#define GL_INT_2_10_10_10_REV 0x8D9F
#define GL_UNSIGNED_INT_2_10_10_10_REV 0x8368
#define GL_POINTS 0x0000
#define GL_LINE_STRIP 0x0003
#define GL_LINE_LOOP 0x0002
#define GL_LINES 0x0001
#define GL_LINE_STRIP_ADJACENCY 0x000B
#define GL_LINES_ADJACENCY 0x000A
#define GL_TRIANGLE_STRIP 0x0005
#define GL_TRIANGLE_FAN 0x0006
#define GL_TRIANGLES 0x0004
#define GL_TRIANGLE_STRIP_ADJACENCY 0x000D
#define GL_TRIANGLES_ADJACENCY 0x000C
#define GL_NO_ERROR 0x0000
#define GL_INVALID_ENUM 0x0500
#define GL_INVALID_VALUE 0x0501
#define GL_INVALID_OPERATION 0x0502
#define GL_INVALID_FRAMEBUFFER_OPERATION 0x0506
#define GL_OUT_OF_MEMORY 0x0505

typedef float GLfloat;
typedef double GLdouble;
typedef int GLint;
typedef char GLchar;
typedef void GLvoid;
typedef unsigned char GLboolean;
typedef unsigned int GLuint;
typedef unsigned int GLenum;
typedef unsigned int GLsizei;
typedef unsigned char GLubyte;
typedef unsigned int GLbitfield;
typedef size_t GLsizeiptr;

// Windows Extensions
BOOL (WINAPI *wglChoosePixelFormatARB)(HDC hdc, const int *attribs_i, const FLOAT *attribs_f, UINT max_count, int *out_format, UINT *out_count);
HGLRC (WINAPI *wglCreateContextAttribsARB)(HDC hdc, HGLRC share_context, const int *attribs_i);

// unsorted
const GLubyte *(WINAPI *glGetString)(GLenum name);
void (WINAPI *glViewport)(GLint x, GLint y, GLsizei width, GLsizei height);
void (WINAPI *glClearColor)(GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha);
void (WINAPI *glClear)(GLbitfield mask);
void (WINAPI *glLoadIdentity)(void);
void (WINAPI *glMatrixMode)(GLenum mode);
void (WINAPI *glOrtho)(GLdouble left, GLdouble right, GLdouble bottom, GLdouble top, GLdouble near_val, GLdouble far_val);

// Shaders
void (WINAPI *glAttachShader)(GLuint program, GLuint shader);
void (WINAPI *glCompileShader)(GLuint shader);
GLuint (WINAPI *glCreateProgram)(void);
GLuint (WINAPI *glCreateShader)(GLenum shader_type);
void (WINAPI *glDeleteProgram)(GLuint program);
void (WINAPI *glDeleteShader)(GLuint shader);
void (WINAPI *glDetachShader)(GLuint program, GLuint shader);
void (WINAPI *glGetShaderiv)(GLuint shader, GLenum parameter, GLint *out_params);
void (WINAPI *glGetShaderInfoLog)(GLuint shader, GLsizei max_length, GLsizei *length, GLchar *out_info_log);
void (WINAPI *glLinkProgram)(GLuint program);
void (WINAPI *glShaderSource)(GLuint shader, GLsizei count, const GLchar **out_string, const GLint *length);
void (WINAPI *glUseProgram)(GLuint program);
void (WINAPI *glValidateProgram)(GLuint program);

// Buffer Objects
void (WINAPI *glBindBuffer)(GLenum target, GLuint buffer);
void (WINAPI *glBufferData)(GLenum target, GLsizeiptr data_size, const GLvoid *data, GLenum usage);
void (WINAPI *glDeleteBuffers)(GLsizei count, const GLuint *buffers);
void (WINAPI *glDisableVertexAttribArray)(GLuint location_in_shader);
void (WINAPI *glDrawArrays)(GLenum mode, GLint first_vertex, GLsizei vertex_count);
void (WINAPI *glEnableVertexAttribArray)(GLuint location_in_shader);
void (WINAPI *glGenBuffers)(GLsizei count, GLuint *buffers);
void (WINAPI *glVertexAttribIPointer)(GLuint location_in_shader, GLint attrib_elem_count, GLenum attrib_elem_type, GLsizei vertex_size, const GLvoid *attrib_offset_size);
void (WINAPI *glVertexAttribPointer)(GLuint location_in_shader, GLint attrib_elem_count, GLenum attrib_elem_type, GLboolean normalize, GLsizei vertex_size, const GLvoid *attrib_offset_size);

// State Management
GLenum (WINAPI *glGetError)(void);

// Vertex Array Objects
void (WINAPI *glBindVertexArray)(GLuint array_object);
void (WINAPI *glDeleteVertexArrays)(GLsizei count, const GLuint *array_objects);
void (WINAPI *glGenVertexArrays)(GLsizei count, GLuint *array_objects);

typedef struct
{
  const HGLRC context;
  const int pixel_format;
}
Mary_OpenGL_g;

void Mary_OpenGL_Start();
void Mary_OpenGL_Finish();
const Mary_OpenGL_g Mary_OpenGL();
GLuint Mary_OpenGL_Shader(const char *vertex, const char *fragment);

#include <stdlib.h>
#include <string.h>
#include <Mary/String.h>
#include MARY_Vector_Namespace

#define Push Vector_Push_Back

MARY_Primitives;

// these need to be separated into their own funcs.
void Mary_String_Create(Mary_String_t *mary_string, Mary_UTF_t utf, void *string, Mary_Size_t opt_units)
{
  // in creation, make sure that we only get the one null ptr on end, in case there are more, even if we are given opt_units.
  Mary_Vector_t *mary_vector = (Mary_Vector_t *)mary_string;
  if (utf == 8)
  {
    Vector_Create(mary_vector, 1, opt_units || 64);
    u8 *p = string; u8 code = *p;
    for (; code; ++p, code = *p)
    {
      Vector_Push_Back(mary_vector, &code);
    }
    code = 0; Vector_Push_Back(mary_vector, &code);
    if (!opt_units)
    {
      Mary_Vector_Fit(mary_vector);
    }
  }
  else if (utf == 16)
  {
    Vector_Create(mary_vector, 2, opt_units || 64);
    u16 *p = string; u16 code = *p;
    for (; code; ++p, code = *p)
    {
      Vector_Push_Back(mary_vector, &code);
    }
    code = 0; Vector_Push_Back(mary_vector, &code);
    if (!opt_units)
    {
      Mary_Vector_Fit(mary_vector);
    }
  }
  else if (utf == 32)
  {
    Vector_Create(mary_vector, 4, opt_units || 64);
    u32 *p = string; u32 code = *p;
    for (; code; ++p, code = *p)
    {
      Vector_Push_Back(mary_vector, &code);
    }
    code = 0; Vector_Push_Back(mary_vector, &code);
    if (!opt_units)
    {
      Mary_Vector_Fit(mary_vector);
    }
  }
  mary_string->codes = Mary_C_String_Count_Codes(mary_string->data, utf, 1);
}

void Mary_String_Create_At(Mary_String_t *mary_string, Mary_UTF_t utf, Mary_p mary_ptr)
{
  MARY_Assert(utf == MARY_UTF_8 || utf == MARY_UTF_16 || utf == MARY_UTF_32);
  Mary_Vector_Create_At(MARY_Vector(mary_string), utf / 8, mary_ptr);
  mary_string->codes = 0;
}

void Mary_String_Create_With(Mary_String_t *mary_string, Mary_UTF_t utf, Mary_p mary_ptr)
{
  MARY_Assert(utf == MARY_UTF_8 || utf == MARY_UTF_16 || utf == MARY_UTF_32);
  Mary_Vector_Create_With(MARY_Vector(mary_string), utf / 8, mary_ptr);
  mary_string->codes = Mary_C_String_Count_Codes(mary_string->data, utf, 1);
}

void Mary_String_Create_With_Stack(Mary_String_t *mary_string, Mary_UTF_t utf, void *c_string)
{
  MARY_Assert(utf == MARY_UTF_8 || utf == MARY_UTF_16 || utf == MARY_UTF_32);
  u64 c_string_unit = utf / 8, c_string_bytes = Mary_C_String_Count_Bytes(c_string, c_string_unit, 1);
  Mary_Vector_Create_With(MARY_Vector(mary_string), c_string_unit, (Mary_p) { c_string, c_string_bytes });
  mary_string->codes = Mary_C_String_Count_Codes(mary_string->data, utf, 1);
}

void Mary_String_Destroy(Mary_String_t *mary_string)
{
  free(mary_string->data);
}

void Mary_String_Change(Mary_String_t *mary_string, void *c_string, Mary_UTF_t opt_utf_c_string)
{
  Mary_Vector_t *mary_vector = MARY_Vector(mary_string); Mary_Vector_Empty(mary_vector);
  Mary_UTF_t utf = mary_string->unit * 8;
  if (MARY_Truthy(opt_utf_c_string) && opt_utf_c_string != utf)
  {
    Mary_String_t mary_c_string; Mary_String_Create(&mary_c_string, opt_utf_c_string, c_string, 0);
    Mary_String_Recode(&mary_c_string, utf);
    Mary_Vector_Reserve(mary_vector, mary_c_string.units);
    Mary_Copy(mary_c_string.data, mary_string->data, mary_c_string.units * 8);
    Mary_String_Destroy(&mary_c_string);
    mary_string->units = mary_c_string.units;
  }
  else
  {
    u64 c_string_units = Mary_C_String_Count_Units(c_string, mary_string->unit, 1);
    Mary_Vector_Reserve(mary_vector, c_string_units);
    Mary_Copy(c_string, mary_string->data, c_string_units * 8);
    mary_string->units = c_string_units;
  }
  mary_string->codes = Mary_C_String_Count_Codes(mary_string->data, utf, 1);
}

void Mary_String_Concat(Mary_String_t *mary_string, void *c_string, Mary_UTF_t opt_utf_c_string)
{
  Mary_Vector_t *mary_vector = MARY_Vector(mary_string);
  Mary_UTF_t utf = mary_string->unit * 8;
  if (MARY_Truthy(opt_utf_c_string) && opt_utf_c_string != utf)
  {
    Mary_String_t mary_c_str; Mary_String_Create(&mary_c_str, opt_utf_c_string, c_string, 0);
    Mary_String_Recode(&mary_c_str, utf);
    Mary_Vector_Reserve(mary_vector, mary_string->units + mary_c_str.units - 1);
    Mary_Copy(mary_c_str.data, MARY_Vector_Point_Back(mary_vector), mary_c_str.units * mary_string->unit);
    Mary_String_Destroy(&mary_c_str);
    mary_string->units += mary_c_str.units - 1;
  }
  else
  {
    u64 c_string_units = Mary_C_String_Count_Units(c_string, mary_string->unit, 1);
    Mary_Vector_Reserve(mary_vector, mary_string->units + c_string_units - 1);
    Mary_Copy(c_string, MARY_Vector_Point_Back(mary_vector), c_string_units * mary_string->unit);
    mary_string->units += c_string_units - 1;
  }
  mary_string->codes = Mary_C_String_Count_Codes(mary_string->data, utf, 1);
}

void Mary_String_Copy(Mary_String_t *string, Mary_String_t *out_copy, Mary_UTF_t opt_new_utf)
{
  // it might be useful to set a timer relative to the codes in string, to make sure we don't go infinite.
  // also, I think we can actually calc the bytes enough so that we don't have to use push, but could 
  // do it more manually.
  Mary_UTF_t old_utf = string->unit * 8, new_utf = opt_new_utf;
  MARY_Assert(new_utf == MARY_FALSE || new_utf == MARY_UTF_8 ||
              new_utf == MARY_UTF_16 || new_utf == MARY_UTF_32);
  if (MARY_Truthy(opt_new_utf) && old_utf != new_utf)
  {
    Mary_Vector_t *copy = MARY_Vector(out_copy);
    if (old_utf == 8 && new_utf == 16)
    {
      Vector_Create(copy, sizeof(u16), string->bytes / sizeof(u16) + 8);
      u8 *p = string->data; Mary_UTF_8_t utf_8; utf_8.code = 1; Mary_UTF_16_t utf_16;
      while (utf_8.code != 0)
      {
        MARY_String_UTF_8_Decode(p, utf_8, p += 1, p += 2, p += 3, p += 4);
        MARY_String_UTF_16_Encode
        (
          utf_8.code, utf_16,
          (Push(copy, &utf_16.a)),
          (Push(copy, &utf_16.a), Push(copy, &utf_16.b))
        );
      }
    }
    else if (old_utf == 8 && new_utf == 32)
    {
      Vector_Create(copy, sizeof(u32), string->bytes / sizeof(u32) + 8);
      u8 *p = string->data; Mary_UTF_8_t utf_8; utf_8.code = 1;
      while (utf_8.code != 0)
      {
        MARY_String_UTF_8_Decode(p, utf_8, p += 1, p += 2, p += 3, p += 4);
        Push(copy, &utf_8.code);
      }
    }
    else if (old_utf == 16 && new_utf == 8)
    {
      Vector_Create(copy, sizeof(u8), string->bytes / sizeof(u8) + 8);
      u16 *p = string->data; Mary_UTF_16_t utf_16; utf_16.code = 1; Mary_UTF_8_t utf_8;
      while (utf_16.code != 0)
      {
        MARY_String_UTF_16_Decode(p, utf_16, p += 1, p += 2);
        MARY_String_UTF_8_Encode
        (
          utf_16.code, utf_8,
          (Push(copy, &utf_8.a)),
          (Push(copy, &utf_8.a), Push(copy, &utf_8.b)),
          (Push(copy, &utf_8.a), Push(copy, &utf_8.b), Push(copy, &utf_8.c)),
          (Push(copy, &utf_8.a), Push(copy, &utf_8.b), Push(copy, &utf_8.c), Push(copy, &utf_8.d))
        );
      }
    }
    else if (old_utf == 16 && new_utf == 32)
    {
      Vector_Create(copy, sizeof(u32), string->bytes / sizeof(u32) + 8);
      u16 *p = string->data; Mary_UTF_16_t utf_16; utf_16.code = 1;
      while (utf_16.code != 0)
      {
        MARY_String_UTF_16_Decode(p, utf_16, p += 1, p += 2);
        Push(copy, &utf_16.code);
      }
    }
    else if (old_utf == 32 && new_utf == 8)
    {
      Vector_Create(copy, sizeof(u8), string->bytes / sizeof(u8) + 8);
      u32 *p = string->data; u32 utf_32 = 1; Mary_UTF_8_t utf_8;
      while (utf_32 != 0)
      {
        utf_32 = *p; ++p;
        MARY_String_UTF_8_Encode
        (
          utf_32, utf_8,
          (Push(copy, &utf_8.a)),
          (Push(copy, &utf_8.a), Push(copy, &utf_8.b)),
          (Push(copy, &utf_8.a), Push(copy, &utf_8.b), Push(copy, &utf_8.c)),
          (Push(copy, &utf_8.a), Push(copy, &utf_8.b), Push(copy, &utf_8.c), Push(copy, &utf_8.d))
        );
      }
    }
    else if (old_utf == 32 && new_utf == 16)
    {
      Vector_Create(copy, sizeof(u16), string->bytes / sizeof(u16) + 8);
      u32 *p = string->data; u32 utf_32 = 1; Mary_UTF_16_t utf_16;
      while (utf_32 != 0)
      {
        utf_32 = *p; ++p;
        MARY_String_UTF_16_Encode
        (
          utf_32, utf_16,
          (Push(copy, &utf_16.a)),
          (Push(copy, &utf_16.a), Push(copy, &utf_16.b))
        );
      }
    }
    //Mary_Vector_Fit(copy); // maybe too slow?
  }
  else
  {
    Mary_Vector_Copy(MARY_Vector(string), MARY_Vector(out_copy));
  }
  out_copy->codes = string->codes;
}

void Mary_String_Copy_To(Mary_String_t *from, Mary_p *to, Mary_UTF_t opt_new_utf)
{
  #define A(THIS_IS_TRUE)\
    MARY_Assert_Message(THIS_IS_TRUE, "External array out of space.")

  Mary_UTF_t from_utf = from->unit * 8, to_utf = opt_new_utf;
  MARY_Assert_Message(to_utf == MARY_FALSE || to_utf == MARY_UTF_8 ||
                      to_utf == MARY_UTF_16 || to_utf == MARY_UTF_32,
                      "Can only accept a UTF of 0, 8, 16, or 32");

  if (MARY_Truthy(to_utf) && from_utf != to_utf)
  {
    if (from_utf == 8 && to_utf == 16)
    {
      u8 *f = from->data; Mary_UTF_8_t utf_8; utf_8.code = 1; Mary_UTF_16_t utf_16;
      for (u16 *t = to->data, *end = MARY_Add_Bytes(to->data, to->bytes); utf_8.code != 0;)
      {
        MARY_String_UTF_8_Decode(f, utf_8, f += 1, f += 2, f += 3, f += 4);
        MARY_String_UTF_16_Encode
        (
          utf_8.code, utf_16,
          (A(t + 1 <= end), *t++ = utf_16.a),
          (A(t + 2 <= end), *t++ = utf_16.a, *t++ = utf_16.b)
        );
      }
    }
    else if (from_utf == 8 && to_utf == 32)
    {
      u8 *f = from->data; Mary_UTF_8_t utf_8; utf_8.code = 1;
      for (u32 *t = to->data, *end = MARY_Add_Bytes(to->data, to->bytes); utf_8.code != 0;)
      {
        MARY_String_UTF_8_Decode(f, utf_8, f += 1, f += 2, f += 3, f += 4);
        (A(t + 1 <= end), *t++ = utf_8.code);
      }
    }
    else if (from_utf == 16 && to_utf == 8)
    {
      u16 *f = from->data; Mary_UTF_16_t utf_16; utf_16.code = 1; Mary_UTF_8_t utf_8;
      for (u8 *t = to->data, *end = MARY_Add_Bytes(to->data, to->bytes); utf_16.code != 0;)
      {
        MARY_String_UTF_16_Decode(f, utf_16, f += 1, f += 2);
        MARY_String_UTF_8_Encode
        (
          utf_16.code, utf_8,
          (A(t + 1 <= end), *t++ = utf_8.a),
          (A(t + 2 <= end), *t++ = utf_8.a, *t++ = utf_8.b),
          (A(t + 3 <= end), *t++ = utf_8.a, *t++ = utf_8.b, *t++ = utf_8.c),
          (A(t + 4 <= end), *t++ = utf_8.a, *t++ = utf_8.b, *t++ = utf_8.c, *t++ = utf_8.d)
        );
      }
    }
    else if (from_utf == 16 && to_utf == 32)
    {
      u16 *f = from->data; Mary_UTF_16_t utf_16; utf_16.code = 1;
      for (u32 *t = to->data, *end = MARY_Add_Bytes(to->data, to->bytes); utf_16.code != 0;)
      {
        MARY_String_UTF_16_Decode(f, utf_16, f += 1, f += 2);
        (A(t + 1 <= end), *t++ = utf_16.code);
      }
    }
    else if (from_utf == 32 && to_utf == 8)
    {
      u32 *f = from->data; u32 utf_32 = 1; Mary_UTF_8_t utf_8;
      for (u8 *t = to->data, *end = MARY_Add_Bytes(to->data, to->bytes); utf_32 != 0;)
      {
        utf_32 = *f++;
        MARY_String_UTF_8_Encode
        (
          utf_32, utf_8,
          (A(t + 1 <= end), *t++ = utf_8.a),
          (A(t + 2 <= end), *t++ = utf_8.a, *t++ = utf_8.b),
          (A(t + 3 <= end), *t++ = utf_8.a, *t++ = utf_8.b, *t++ = utf_8.c),
          (A(t + 4 <= end), *t++ = utf_8.a, *t++ = utf_8.b, *t++ = utf_8.c, *t++ = utf_8.d)
        );
      }
    }
    else if (from_utf == 32 && to_utf == 16)
    {
      u32 *f = from->data; u32 utf_32 = 1; Mary_UTF_16_t utf_16;
      for (u16 *t = to->data, *end = MARY_Add_Bytes(to->data, to->bytes); utf_32 != 0;)
      {
        utf_32 = *f++;
        MARY_String_UTF_16_Encode
        (
          utf_32, utf_16,
          (A(t + 1 <= end), *t++ = utf_16.a),
          (A(t + 2 <= end), *t++ = utf_16.a, *t++ = utf_16.b)
        );
      }
    }
  }
  else
  {
    A(from->bytes <= to->bytes);
    Mary_Copy(from->data, to->data, from->bytes);
  }

  #undef A
}

Mary_UTF_t Mary_String_Get_UTF(Mary_String_t *mary_string)
{
  return mary_string->unit * 8;
}

void Mary_String_Recode(Mary_String_t *mary_string, Mary_UTF_t new_utf)
{
  Mary_String_t copy; Mary_String_Copy(mary_string, &copy, new_utf);
  Mary_Vector_Repurpose_With(MARY_Vector(mary_string), MARY_p(&copy), copy.unit, copy.units);
  Mary_String_Destroy(&copy);
}

void Mary_String_8_Match(Mary_String_t *mary_string, Mary_String_t *regex)
{
  // take the matches from an Regex_Execute and narrow down by flags. Maybe we should do the flags in here, not the compiler.
}

void Mary_String_8_Replace(Mary_String_t *mary_string, u8 *regex, u8 *replacement)
{

}

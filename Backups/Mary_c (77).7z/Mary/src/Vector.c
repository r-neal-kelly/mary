#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <Mary/Vector.h>

MARY_Primitives;

static const r32 GROWTH_RATE = 1.7f;

void Mary_Vector_Create(Mary_Vector_t *v, size_t unit, size_t opt_units)
{
  size_t bytes = (opt_units) ? (opt_units * unit) : unit;
  void *data = malloc(bytes); MARY_Assert(data != 0);
  v->data = data;
  v->bytes = bytes;
  v->unit = unit;
  v->units = 0;
}

void Mary_Vector_Create_At(Mary_Vector_t *v, size_t unit, Mary_p ptr)
{
  v->data = ptr.data;
  v->bytes = ptr.bytes;
  v->unit = unit;
  v->units = 0;
}

void Mary_Vector_Create_With(Mary_Vector_t *v, size_t unit, Mary_p ptr)
{
  v->data = ptr.data;
  v->bytes = ptr.bytes;
  v->unit = unit;
  v->units = ptr.bytes / unit;
}

void Mary_Vector_Create_Copy(Mary_Vector_t *v, size_t unit, Mary_p ptr, size_t units)
{
  void *copy = malloc(ptr.bytes);
  if (copy)
  {
    v->data = copy;
    v->bytes = ptr.bytes;
    v->unit = unit;
    v->units = units;
    memcpy(copy, ptr.data, units * unit);
  }
}

void Mary_Vector_Repurpose(Mary_Vector_t *vector, size_t unit, size_t opt_units)
{
  vector->unit = unit;
  vector->units = 0;
  if (MARY_Truthy(opt_units))
  {
    Mary_Vector_Reserve(vector, opt_units);
  }
}

void Mary_Vector_Repurpose_With(Mary_Vector_t *vector, Mary_p *ptr, size_t ptr_unit, size_t ptr_units)
{
  vector->unit = ptr_unit;
  vector->units = ptr_units;
  Mary_Vector_Reserve(vector, ptr_units);
  Mary_Copy(ptr->data, vector->data, ptr_unit * ptr_units);
}

void Mary_Vector_Destroy(Mary_Vector_t *vector)
{
  free(vector->data);
}

void Mary_Vector_Reserve(Mary_Vector_t *vector, size_t units)
{
  size_t new_bytes = units * vector->unit;
  if (new_bytes > vector->bytes)
  {
    void *data = vector->data;
    data = realloc(data, new_bytes); MARY_Assert(data != 0);
    vector->data = data;
    vector->bytes = new_bytes;
  }
}

void Mary_Vector_Fit(Mary_Vector_t *vector)
{
  size_t fit_capacity = (vector->units) ? (vector->units * vector->unit) : vector->unit;
  if (vector->bytes != fit_capacity)
  {
    void *data = vector->data;
    data = realloc(data, fit_capacity); MARY_Assert(data != 0);
    vector->data = data;
    vector->bytes = fit_capacity;
  }
}

void Mary_Vector_Push_At(Mary_Vector_t *v, size_t index, void *in_elem)
{
  size_t unit = v->unit;
  size_t units = v->units;
  size_t new_units = units + 1;
  if (new_units * unit > v->bytes)
  {
    Mary_Vector_Reserve(v, (size_t)(units * GROWTH_RATE + 1));
  }
  u8 *p = (u8 *)v->data + index * unit;
  memmove(p + unit, p, (units - index) * unit);
  memcpy(p, in_elem, unit);
  v->units = new_units;
}

void Mary_Vector_Pop_At(Mary_Vector_t *vector, size_t index, void *out_elem)
{
  // optimize
  size_t unit = vector->unit;
  size_t units = vector->units - 1;
  void *data = vector->data;
  u8 *p = (u8 *)data + (index * unit);
  memmove(out_elem, p, unit);
  for (; index < units; ++index, p += unit)
  {
    memmove(p, p + unit, unit);
  }
  vector->units = units;
}

void Mary_Vector_Assign(Mary_Vector_t *vector, size_t index, void *in_elem)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  u8 *p = (u8 *)data + (index * unit);
  memmove(p, in_elem, unit);
}

void Mary_Vector_Exchange(Mary_Vector_t *vector, size_t index, void *in_elem, void *out_elem)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  u8 *p = (u8 *)data + (index * unit);
  memmove(out_elem, p, unit);
  memmove(p, in_elem, unit);
}

void Mary_Vector_Copy(Mary_Vector_t *vector, Mary_Vector_t *out_copy)
{
  out_copy->unit = vector->unit;
  out_copy->units = vector->units;
  out_copy->bytes = vector->unit * vector->units;
  out_copy->data = malloc(out_copy->bytes); MARY_Assert(out_copy->data != 0);
  Mary_Copy(vector->data, out_copy->data, out_copy->bytes);
}

void Mary_Vector_Add_Slice(Mary_Vector_t *vector, size_t from, size_t to_exclusive, void *opt_in_elems)
{
  size_t bytes = vector->bytes;
  size_t unit = vector->unit;
  size_t old_units = vector->units;
  size_t slice_units = to_exclusive - from;
  size_t new_units = old_units + slice_units;
  if (new_units * unit > bytes)
  {
    Mary_Vector_Reserve(vector, new_units);
  }
  void *data = vector->data;
  u8 *p_0 = (u8 *)data;
  u8 *p_from = p_0 + from * unit;
  u8 *p_to = p_0 + to_exclusive * unit;
  memmove(p_to, p_from, (old_units - from) * unit);
  if (opt_in_elems)
  {
    memcpy(p_from, opt_in_elems, slice_units * unit);
  }
  vector->units = new_units;
}

void Mary_Vector_Delete_Slice(Mary_Vector_t *vector, size_t from, size_t to_exclusive)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  size_t units = vector->units;
  u8 *p_0 = (u8 *)data;
  u8 *p_from = p_0 + from * unit;
  u8 *p_to = p_0 + to_exclusive * unit;
  memmove(p_from, p_to, (units - to_exclusive) * unit);
  vector->units = units - (to_exclusive - from);
}

void Mary_Vector_Copy_Slice(Mary_Vector_t *vector, size_t from, size_t to_exclusive, void *out_elems)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  u8 *p_0 = (u8 *)data;
  u8 *p_from = p_0 + from * unit;
  u8 *p_to = p_0 + to_exclusive * unit;
  memmove(out_elems, p_from, (to_exclusive - from) * unit);
}

void Mary_Vector_Take_Slice(Mary_Vector_t *vector, size_t from, size_t to_exclusive, void *out_elems)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  size_t units = vector->units;
  u8 *p_0 = (u8 *)data;
  u8 *p_from = p_0 + from * unit;
  u8 *p_to = p_0 + to_exclusive * unit;
  memmove(out_elems, p_from, (to_exclusive - from) * unit);
  memmove(p_from, p_to, (units - to_exclusive) * unit);
  vector->units = units - (to_exclusive - from);
}

void Mary_Vector_Put_Slice(Mary_Vector_t *v, size_t from, size_t to_exclusive, void *in_elems)
{
  memcpy((u8 *)v->data + from * v->unit, in_elems, (to_exclusive - from) * v->unit);
}

void Mary_Vector_Push_Back(Mary_Vector_t *v, void *in_elem)
{
  u64 old_units = v->units, new_units = old_units + 1;
  if (new_units * v->unit > v->bytes)
  {
    Mary_Vector_Reserve(v, (u64)(old_units * GROWTH_RATE + 1));
  }
  Mary_Copy(in_elem, MARY_Vector_Point(v, old_units), v->unit);
  v->units = new_units;
}

void Mary_Vector_Push_Front(Mary_Vector_t *vector, void *in_elem)
{
  Mary_Vector_Push_At(vector, 0, in_elem);
}

void Mary_Vector_Pop_Back(Mary_Vector_t *v, void *out_elem)
{
  size_t units = v->units ? --v->units : 0;
  size_t unit = v->unit;
  memcpy(out_elem, (u8 *)v->data + (units * unit), unit);
}

void Mary_Vector_Pop_Front(Mary_Vector_t *vector, void *out_elem)
{
  Mary_Vector_Pop_At(vector, 0, out_elem);
}

void Mary_Vector_At(Mary_Vector_t *vector, size_t index, void *out_elem)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  u8 *p = (u8 *)data + (index * unit);
  memmove(out_elem, p, unit);
}

void Mary_Vector_At_Front(Mary_Vector_t *vector, void *out_elem)
{
  Mary_Vector_At(vector, 0, out_elem);
}

void Mary_Vector_At_Back(Mary_Vector_t *vector, void *out_elem)
{
  Mary_Vector_At(vector, (vector->units) ? vector->units - 1 : 0, out_elem);
}

char Mary_Vector_Has_At(Mary_Vector_t *vector, size_t index)
{
  return index < vector->units;
}

void *Mary_Vector_Point(Mary_Vector_t *vector, size_t index)
{
  return (u8 *)vector->data + index * vector->unit;
}

void *Mary_Vector_Point_Front(Mary_Vector_t *vector)
{
  return vector->data;
}

void *Mary_Vector_Point_Back(Mary_Vector_t *vector)
{
  return (u8 *)vector->data + (vector->units - 1) * vector->unit;
}

void Mary_Vector_Empty(Mary_Vector_t *v)
{
  v->units = 0;
}

char Mary_Vector_Is_Empty(Mary_Vector_t *vector)
{
  return vector->units != 0;
}

void Mary_Vector_Resize(Mary_Vector_t *vector, size_t units)
{
  vector->units = units;
  Mary_Vector_Fit(vector);
}

void Mary_Vector_Fill(Mary_Vector_t *vector, void *in_elem)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  size_t units = vector->units;
  u8 *p = (u8 *)data;
  for (size_t i = 0; i < units; ++i, p += unit)
  {
    memmove(p, in_elem, unit);
  }
}

void Mary_Vector_Rotate(Mary_Vector_t *vector, void *out_elem)
{
  size_t units = vector->units;
  if (units > 1)
  {
    void *data = vector->data;
    size_t unit = vector->unit;
    size_t i = units - 1;
    u8 *first = (u8 *)data;
    u8 *last = first + (i * unit);
    memmove(out_elem, last, unit);
    for (; i > 0; --i, last -= unit)
    {
      memmove(last, last - unit, unit);
    }
    memmove(first, out_elem, unit);
  }
}

void Mary_Vector_Reverse(Mary_Vector_t *vector)
{
  size_t units = vector->units;
  if (units > 1)
  {
    size_t unit = vector->unit;
    u8 *temp = malloc(unit);
    if (temp)
    {
      void *data = vector->data;
      size_t a = 0, b = units - 1;
      u8 *pA = (u8 *)data;
      u8 *pB = pA + (b * unit);
      for (; a < b; ++a, --b, pA += unit, pB -= unit)
      {
        memcpy(temp, pA, unit);
        memmove(pA, pB, unit);
        memcpy(pB, temp, unit);
      }
      free(temp);
    }
  }
}

char Mary_Vector_Contains(Mary_Vector_t *vector, void *elem)
{
  u8 *p = (u8 *)vector->data;
  for (size_t i = 0; i < vector->units; ++i, p += vector->unit)
  {
    if (memcmp(p, elem, vector->unit) == 0)
    {
      return 1;
    }
  }
  return 0;
}

char Mary_Vector_Contains_First_Bytes(Mary_Vector_t *vector, void *elem, size_t bytes)
{
  u8 *p = (u8 *)vector->data;
  for (size_t i = 0; i < vector->units; ++i, p += vector->unit)
  {
    if (memcmp(p, elem, bytes) == 0)
    {
      return 1;
    }
  }
  return 0;
}

size_t Mary_Vector_Index_Of(Mary_Vector_t *vector, void *elem, char *out_was_found)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  size_t units = vector->units;
  u8 *p = (u8 *)data;
  size_t i = 0; char was_found;
  for (; i < units; ++i, p += unit)
  {
    if (memcmp(p, elem, unit) == 0)
    {
      was_found = 1;
      memmove(out_was_found, &was_found, sizeof(char));
      return i;
    }
  }
  was_found = 0;
  memmove(out_was_found, &was_found, sizeof(char));
  return i;
}

void Mary_Vector_Erase_At(Mary_Vector_t *v, size_t index)
{
  size_t unit = v->unit;
  size_t units = --v->units;
  u8 *p = (u8 *)v->data + index * unit;
  memmove(p, p + unit, (units - index) * unit);
}

void Mary_Vector_Erase(Mary_Vector_t *vector, void *elem)
{
  char was_found = 0;
  size_t index = Mary_Vector_Index_Of(vector, elem, &was_found);
  if (was_found)
  {
    Mary_Vector_Erase_At(vector, index);
  }
}

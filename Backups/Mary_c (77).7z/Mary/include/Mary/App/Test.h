#pragma once

void Test_String_Recode();
void Test_String_Loops();
void Test_String_Decode_Speed();
void Test_String_Copy_To();
void Test_Big_Return();

#include <Mary/Lang.h>

uint64_t Mary_Lang_Alphabet()
{
  return 0;
}

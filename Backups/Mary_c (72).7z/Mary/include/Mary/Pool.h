#pragma once

#include <Mary/Vector.h>

typedef struct
{
  MARY_Pointer_t;
  size_t free;
  Mary_Vector_t index;
}
Mary_Pool_t;

void Mary_Pool_Create(Mary_Pool_t *pool, size_t bytes);
void Mary_Pool_Create_At(Mary_Pool_t *pool, Mary_p with_ptr, Mary_p with_idx);
void Mary_Pool_Destroy(Mary_Pool_t *pool);
void *Mary_Pool_Allocate(Mary_Pool_t *pool, size_t bytes);
void Mary_Pool_Deallocate(Mary_Pool_t *pool, void *ptr);
void Mary_Pool_Empty(Mary_Pool_t *pool);
// might be cool to have a func that returns a vector of ptrs to each value in pool.

#define MARY_Pool_Create_At_Stack(POOL, BYTES, BYTES_IDX)\
  u8 POOL##_ary[(BYTES) + 7 & -8], POOL##_idx[(BYTES_IDX) + 7 & -8];\
  Mary_Pool_Create_At(&POOL, (Mary_p) { POOL##_ary, (BYTES) + 7 & -8 },\
                             (Mary_p) { POOL##_idx, (BYTES_IDX) + 7 & -8 })

#define MARY_Pool_Round(BYTES) ((BYTES) + 7 & -8)

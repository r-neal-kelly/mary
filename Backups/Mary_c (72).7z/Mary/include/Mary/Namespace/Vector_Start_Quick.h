#define Vector_t Mary_Vector_t

#define Vector_Create Mary_Vector_Create
#define Vector_Destroy Mary_Vector_Destroy
#define Vector_Push_Back Mary_Vector_Push_Back

#define VECTOR MARY_Vector
#define VECTOR_Each MARY_Vector_Each

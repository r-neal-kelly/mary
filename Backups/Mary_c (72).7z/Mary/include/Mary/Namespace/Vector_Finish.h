#undef Vector_t

#undef Vector_Create
#undef Vector_Destroy
#undef Vector_Push_Back

#undef VECTOR
#undef VECTOR_Each

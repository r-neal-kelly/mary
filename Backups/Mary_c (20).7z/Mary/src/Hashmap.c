#define intern static
#define method static
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <Mary/Hashmap.h>
#include <Mary/Bitbool.h>
typedef uint8_t byte_t;

void Mary_Hashmap_Create(Mary_Hashmap_t *hashmap, size_t size_key, size_t size_value);
void Mary_Hashmap_Destroy(Mary_Hashmap_t *hashmap);
void Mary_Hashmap_Insert(Mary_Hashmap_t *hashmap, void *in_key, void *in_value);
char Mary_Hashmap_At(Mary_Hashmap_t *hashmap, void *in_key, void *out_value);
char Mary_Hashmap_Contains_Key(Mary_Hashmap_t *hashmap, void *in_key);
// keys we need, but values?
intern uint64_t Hash_Key(void *key, size_t key_unit);
intern byte_t *Hash_Bucket(Mary_Hashmap_t *hashmap, void *key, size_t *out_index, char *out_occupied);
intern void Hash_Value(Mary_Hashmap_t *hashmap, void *key, void *value);
intern void Rehash(Mary_Hashmap_t *hashmap, size_t buckets_total);
intern const size_t default_buckets_total = 16;

void Mary_Hashmap_Create(Mary_Hashmap_t *hashmap, size_t size_key, size_t size_value)
{
  size_t size_buckets_bitbool = default_buckets_total / 8;
  void *buckets_data = malloc(default_buckets_total * (size_key + size_value));
  void *buckets_bitbool = malloc(size_buckets_bitbool);
  if (buckets_data && buckets_bitbool)
  {
    Mary_Bitbool_Fill(buckets_bitbool, size_buckets_bitbool, 0);
    hashmap->buckets_data = buckets_data;
    hashmap->buckets_bitbool = buckets_bitbool;
    hashmap->buckets_total = default_buckets_total;
    hashmap->buckets_occupied = 0;
    hashmap->size_key = size_key;
    hashmap->size_value = size_value;
  }
  else
  {
    // throw exception
  }
}

void Mary_Hashmap_Destroy(Mary_Hashmap_t *hashmap)
{
  free(hashmap->buckets_data);
  free(hashmap->buckets_bitbool);
}

void Mary_Hashmap_Insert(Mary_Hashmap_t *hashmap, void *in_key, void *in_value)
{
  size_t buckets_total = hashmap->buckets_total;
  size_t buckets_occupied = hashmap->buckets_occupied;

  if (buckets_occupied >= (84 * buckets_total / 100))
  {
    Rehash(hashmap, buckets_total * 2);
  }
  Hash_Value(hashmap, in_key, in_value);
}

char Mary_Hashmap_At(Mary_Hashmap_t *hashmap, void *in_key, void *out_value)
{
  size_t size_key = hashmap->size_key;
  size_t size_value = hashmap->size_value;

  size_t index; char occupied;
  byte_t *bucket_key = Hash_Bucket(hashmap, in_key, &index, &occupied);
  if (occupied)
  {
    byte_t *bucket_value = bucket_key + size_key;
    memmove(out_value, bucket_value, size_value);
    return 1;
  }
  else
  {
    return 0;
  }
}

char Mary_Hashmap_Contains_Key(Mary_Hashmap_t *hashmap, void *in_key)
{
  size_t index; char occupied;
  Hash_Bucket(hashmap, in_key, &index, &occupied);
  return occupied;
}

intern uint64_t Hash_Key(void *key, size_t key_unit)
{
  // FNV-1a
  uint64_t hash = 14695981039346656037;
  uint64_t prime = 1099511628211;
  byte_t *p = (byte_t *)key;
  for (size_t i = 0; i < key_unit; ++i, p += 1)
  {
    hash ^= *p;
    hash *= prime;
  }
  return hash;
}

intern byte_t *Hash_Bucket(Mary_Hashmap_t *hashmap, void *key, size_t *out_index, char *out_occupied)
{
  void *buckets_data = hashmap->buckets_data;
  void *buckets_bitbool = hashmap->buckets_bitbool;
  size_t buckets_total = hashmap->buckets_total;
  size_t size_key = hashmap->size_key;
  size_t size_value = hashmap->size_value;

  size_t bucket_index_last = buckets_total - 1;
  size_t bucket_index_curr = Hash_Key(key, size_key) & (bucket_index_last);  // instead of mod, we can & by keeping total buckets a power of 2
  size_t size_bucket = size_key + size_value;
  size_t size_buckets_bitbool = buckets_total / 8;
  byte_t *bucket_key = (byte_t *)buckets_data + (bucket_index_curr * size_bucket);
  char occupied = 0;

  while (1)
  {
    if (!Mary_Bitbool_At(buckets_bitbool, size_buckets_bitbool, bucket_index_curr))
    {
      occupied = 0;
      break;
    }
    else if (memcmp(bucket_key, key, size_key) == 0)
    {
      occupied = 1;
      break;
    }
    else if (bucket_index_curr == bucket_index_last)
    {
      bucket_index_curr = 0;
      bucket_key = (byte_t *)buckets_data;
    }
    else
    {
      ++bucket_index_curr;
      bucket_key += size_bucket;
    }
  }
  memcpy(out_index, &bucket_index_curr, sizeof(size_t));
  memcpy(out_occupied, &occupied, sizeof(char));
  return bucket_key;
}

intern void Hash_Value(Mary_Hashmap_t *hashmap, void *key, void *value)
{
  void *buckets_bitbool = hashmap->buckets_bitbool;
  size_t buckets_total = hashmap->buckets_total;
  size_t buckets_occupied = hashmap->buckets_occupied;
  size_t size_key = hashmap->size_key;
  size_t size_value = hashmap->size_value;

  size_t index; char occupied;
  byte_t *bucket_key = Hash_Bucket(hashmap, key, &index, &occupied);
  if (!occupied)
  {
    byte_t *bucket_value = bucket_key + size_key;
    size_t size_buckets_bitbool = buckets_total / 8;
    memmove(bucket_key, key, size_key);
    memmove(bucket_value, value, size_value);
    Mary_Bitbool_Assign(buckets_bitbool, size_buckets_bitbool, index, 1);
    buckets_occupied += 1;
    hashmap->buckets_occupied = buckets_occupied;
  }
  else
  {
    byte_t *bucket_value = bucket_key + size_key;
    memmove(bucket_value, value, size_value);
  }
}

intern void Rehash(Mary_Hashmap_t *hashmap, size_t new_buckets_total)
{
  void *old_buckets_data = hashmap->buckets_data;
  void *old_buckets_bitbool = hashmap->buckets_bitbool;
  size_t old_buckets_total = hashmap->buckets_total;
  size_t size_key = hashmap->size_key;
  size_t size_value = hashmap->size_value;

  size_t old_size_buckets_bitbool = old_buckets_total / 8;
  size_t new_size_buckets_bitbool = new_buckets_total / 8;
  size_t size_bucket = size_key + size_value;
  void *new_buckets_data = malloc(new_buckets_total * size_bucket);
  void *new_buckets_bitbool = malloc(new_size_buckets_bitbool);
  if (new_buckets_data && new_buckets_bitbool)
  {
    Mary_Bitbool_Fill(new_buckets_bitbool, new_size_buckets_bitbool, 0);
    hashmap->buckets_data = new_buckets_data;
    hashmap->buckets_bitbool = new_buckets_bitbool;
    hashmap->buckets_total = new_buckets_total;
    hashmap->buckets_occupied = 0;
    byte_t *old_bucket_key = (byte_t *)old_buckets_data;
    for (size_t i = 0; i < old_buckets_total; ++i, old_bucket_key += size_bucket)
    {
      if (Mary_Bitbool_At(old_buckets_bitbool, old_size_buckets_bitbool, i))
      {
        byte_t *old_bucket_value = old_bucket_key + size_key;
        Hash_Value(hashmap, old_bucket_key, old_bucket_value);
      }
    }
    free(old_buckets_data);
    free(old_buckets_bitbool);
  }
  else
  {
    // throw exception
  }
}

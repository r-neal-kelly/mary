﻿#pragma warning (disable: 4028)

#include <stdio.h>
#include <stdlib.h>
#include <Mary/Mary.h>

MARY_Primitives;

void mousewheel_pink(Mary_Event_t *event)
{
  printf("mousewheel on pink\n");
}

void mousewheel_blue(Mary_Event_t *event)
{
  printf("mousewheel on blue\n");
  Mary_Event_Stop_Propagation(event);
  //Mary_Event_Disable_Default(event);
}

void mousedown_orange(Mary_Event_t *event)
{
  printf("mousedown on orange.\n");
}

void mousedown_blue(Mary_Event_t *event)
{
  Mary_Event_Mousedown_t *e = MARY_Event_Mousedown(event);
  printf("mousedown on blue.\n");
}

void mouseclick_pink(Mary_Event_t *event)
{
  Mary_Event_Mouseclick_t *e = MARY_Event_Mouseclick(event);
  printf("mouseclick on pink.\n");
}

void mousein_purple(Mary_Event_t *event)
{
  printf("mousein on purple.\n");
}

void mouseout_green(Mary_Event_t *event)
{
  printf("mouseout on green.\n");
}

void keypress_pink(Mary_Event_Keypress_t *keypress)
{
  //MARY_Event_Declare_Keypress(event);
  printf("%c", (char)keypress->key);
}

int main()
{
#if 1
  Mary_Start();

  Mary_OS_Font_Info_t font_info;
  MARY_Zero(&font_info, sizeof(font_info));
  font_info.face = u"Times New Roman";
  font_info.hint_px = 36;
  Mary_OS_Font_Change(&font_info);

  Mary_Wordmap_t wordmap;
  Mary_Wordmap_Create(&wordmap, &font_info, 0);
  Mary_Wordmap_Add(&wordmap, u"love", 0);
  Mary_Wordmap_Add(&wordmap, u" ", 0);
  Mary_Wordmap_Add(&wordmap, u"Yahweh!", 0);
  for (u64 i = 0; i < 4800; ++i)
  {
    Mary_Wordmap_Add(&wordmap, u"testing", 0);
  }
  Mary_Wordmap_Add(&wordmap, u"testing", 0);
  Mary_Wordmap_Destroy(&wordmap);

  Mary_Finish();

  Mary_Exit_Success();
#endif

#if 0
  Mary_Start();

  // I'm wonder about how to make this interface easier, but still fast.

  Mary_Window_t pink; Mary_Window_Create(&pink);
  Mary_Window_Back_Color(&pink, 1.0f, 0.4f, 0.8f, 1.0f);
  Mary_Window_Padding(&pink, 84.0f, 24.0f, 84.0f, 24.0f);

  Mary_Div_t blue; Mary_Div_Create(&blue);
  Mary_Element_Append_To(&blue, &pink);
  Mary_Element_Back_Color(&blue, 0.0f, 0.0f, 1.0f, 1.0f);
  Mary_Element_Unit_Size(&blue, MARY_ELEMENT_UNIT_FIT_PARENT, MARY_ELEMENT_UNIT_PIXEL); // MARY_ELEMENT_UNIT_FIT_CHILDREN
  Mary_Element_Padding(&blue, 24.0f, 24.0f, 24.0f, 24.0f);
  Mary_Element_Size(&blue, 600, 250);

  Mary_Div_t purple; Mary_Div_Create(&purple);
  Mary_Element_Append_To(&purple, &blue);
  Mary_Element_Back_Color(&purple, 0.4f, 0.3f, 0.8f, 1.0f);
  Mary_Element_Unit_Size(&purple, MARY_ELEMENT_UNIT_PIXEL, MARY_ELEMENT_UNIT_PIXEL);
  Mary_Element_Size(&purple, 50, 100);
  Mary_Element_Display(&purple, MARY_ELEMENT_DISPLAY_INLINE_LOOSE);

  Mary_Div_t green; Mary_Div_Create(&green);
  Mary_Element_Append_To(&green, &blue);
  Mary_Element_Back_Color(&green, 0.4f, 0.7f, 0.3f, 1.0f);
  Mary_Element_Unit_Size(&green, MARY_ELEMENT_UNIT_PIXEL, MARY_ELEMENT_UNIT_PIXEL);
  Mary_Element_Size(&green, 50, 50);
  Mary_Element_Margin(&green, 12.0f, 12.0f, 0.0f, 12.0f);
  Mary_Element_Display(&green, MARY_ELEMENT_DISPLAY_INLINE_LOOSE);

  Mary_Div_t orange; Mary_Div_Create(&orange);
  Mary_Element_Append_To(&orange, &blue);
  Mary_Element_Back_Color(&orange, 0.8f, 0.3f, 0.3f, 1.0f);
  Mary_Element_Unit_Size(&orange, MARY_ELEMENT_UNIT_PIXEL, MARY_ELEMENT_UNIT_PIXEL);
  Mary_Element_Size(&orange, 500, 150);
  Mary_Element_Margin(&orange, 0.0f, 0.0f, 0.0f, 24.0f);
  Mary_Element_Display(&orange, MARY_ELEMENT_DISPLAY_INLINE_LOOSE);

  //Mary_Event_Add_Listener(&pink, MARY_EVENT_MOUSEWHEEL, mousewheel_pink, 0, 0);
  //Mary_Event_Add_Listener(&blue, MARY_EVENT_MOUSEWHEEL, mousewheel_blue, 0, 0);
  //Mary_Event_Add_Listener(&blue, MARY_EVENT_MOUSEDOWN, mousedown_blue, 1, 0);
  //Mary_Event_Add_Listener(&orange, MARY_EVENT_MOUSEDOWN, mousedown_orange, 0, 0);
  //Mary_Event_Add_Listener(&pink, MARY_EVENT_MOUSECLICK, mouseclick_pink, 0, 0);
  Mary_Event_Add_Listener(&purple, MARY_EVENT_MOUSEIN, mousein_purple, 0, 0);
  Mary_Event_Add_Listener(&green, MARY_EVENT_MOUSEOUT, mouseout_green, 0, 0);
  Mary_Event_Add_Listener(&pink, MARY_EVENT_KEYPRESS, keypress_pink, 0, 0);

  Mary_Window_Open(&pink);

  while (Mary_Window_Can_Render())
  {
    Mary_Window_Render_All();
  }

  Mary_Element_Destroy_Family(&pink);

  Mary_Finish();
#endif

#if 0
  Mary_Start();

  Mary_OS_Font_Info_t font_info; MARY_Zero(&font_info, sizeof(font_info));
  font_info.face = u"Segoe UI";
  font_info.hint_px = 16;
  Mary_OS_Font_Change(&font_info);

  Mary_Window_t window; Mary_Window_Create(&window);
  Mary_Window_Back_Color(&window, 1.0f, 1.0f, 1.0f, 1.0f);

  Mary_Div_t wrap1; Mary_Div_Create(&wrap1);
  Mary_Element_Append_To(&wrap1, &window);
  Mary_Element_Back_Color(&wrap1, 1.0f, 1.0f, 1.0f, 1.0f);
  Mary_Element_Unit_Size(&wrap1, MARY_ELEMENT_UNIT_FIT_PARENT, MARY_ELEMENT_UNIT_FIT_PARENT);
  Mary_Element_Padding(&wrap1, 24.0f, 24.0f, 24.0f, 24.0f);
  Mary_Element_Size(&wrap1, 0, 0);
  Mary_Element_Overflow(&wrap1, MARY_ELEMENT_OVERFLOW_Y);

  Mary_Text_t text; Mary_Text_Create_With_File(&text, 8, "test3.txt");
  Mary_Element_Append_To(&text, &wrap1);
  Mary_Element_Fore_Color(&text, 0.0f, 0.0f, 0.0f, 1.0f);

  Mary_Window_Open(&window); // should this be done automatically on create? I wonder...

  while (Mary_Window_Can_Render())
  {
    Mary_Window_Render_All();
  }

  Mary_Element_Destroy_Family(&window);

  Mary_Finish();
#endif

#if 0
  Mary_Regex_Start();

  #define PRINT_MATCHES(MATCHES)                                                         \
    MARY_Range(MATCHES.data, Mary_Slice_t, 0, MATCHES.units)                             \
      printf("from: %llu to_exclusive: %llu\n", it.val.from, it.val.to_exclusive);

  if (0)
  {
    Mary_Regex_t regex; Mary_Vector_t matches;

    //MARY_Benchmark(Mary_Regex_Create(&regex, 32, U"(?<[1-9]+z+)a", "g"), 1);
    //MARY_Benchmark(matches = Mary_Regex_Execute(&regex, 32, U"a12zzzza 5zza a"), 12);

    //MARY_Benchmark(Mary_Regex_Create(&regex, 32, U"b(?>12+3?)", "g"), 1);
    //MARY_Benchmark(matches = Mary_Regex_Execute(&regex, 32, U"b122222bdb123ba"), 12);

    //MARY_Benchmark(Mary_Regex_Create(&regex, 32, U"~:Hebrew Char:", "g"), 1);
    //MARY_Benchmark(matches = Mary_Regex_Execute(&regex, 32, U"Ἄνθρωπος בְּרֵאשִׁ֖ית בָּרָ֣א πρὸς πάντα"), 12);

    //MARY_Benchmark(Mary_Regex_Create(&regex, 32, U"^a$", "gm"), 1);
    //MARY_Benchmark(matches = Mary_Regex_Execute(&regex, 32, U"a\na"), 12);

    //MARY_Benchmark(Mary_Regex_Create(&regex, 32, U"a{3,2}", "g"), 1);
    //MARY_Benchmark(matches = Mary_Regex_Execute(&regex, 32, U"aaaaa"), 12);

    MARY_Benchmark(Mary_Regex_Create(&regex, 32, U"~:Latin:+", "g"), 1);
    MARY_Benchmark(matches = Mary_Regex_Execute(&regex, 32, U"abc"), 12);

    PRINT_MATCHES(matches);

    Mary_Vector_Destroy(&matches); Mary_Regex_Destroy(&regex);
  }

  if (1)
  {
    Mary_Regex_t _1, _2, _3, _4; Mary_Vector_t v_1, v_2, v_3, v_4;
    u32 *bound_test = U"This is a misty island.";
                       "01234567891111111111222";
                       "          0123456789012";
    MARY_Benchmark(Mary_Regex_Create(&_1, 32, U"~bis~b", "g"), 1);
    MARY_Benchmark(Mary_Regex_Create(&_2, 32, U"~bis~B", "g"), 1);
    MARY_Benchmark(Mary_Regex_Create(&_3, 32, U"~Bis~b", "g"), 1);
    MARY_Benchmark(Mary_Regex_Create(&_4, 32, U"~Bis~B", "g"), 1); printf("\n");
    MARY_Benchmark(v_1 = Mary_Regex_Execute(&_1, 32, bound_test), 12);
    MARY_Benchmark(v_2 = Mary_Regex_Execute(&_2, 32, bound_test), 12);
    MARY_Benchmark(v_3 = Mary_Regex_Execute(&_3, 32, bound_test), 12);
    MARY_Benchmark(v_4 = Mary_Regex_Execute(&_4, 32, bound_test), 12); printf("\n");
    PRINT_MATCHES(v_1); PRINT_MATCHES(v_2); PRINT_MATCHES(v_3); PRINT_MATCHES(v_4);
    MARY_Vector_Destroy(v_1); MARY_Vector_Destroy(v_2); MARY_Vector_Destroy(v_3); MARY_Vector_Destroy(v_4);
    Mary_Regex_Destroy(&_1); Mary_Regex_Destroy(&_2); Mary_Regex_Destroy(&_3); Mary_Regex_Destroy(&_4);
  }

  #undef PRINT_MATCHES

  Mary_Regex_Finish();
  Mary_Exit_Success();
#endif
  return 0;
}

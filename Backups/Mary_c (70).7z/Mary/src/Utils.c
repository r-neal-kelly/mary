#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <Mary/Utils.h>

MARY_Primitives;

void Mary_Exit_Success()
{
  puts("\npress enter to exit...");
  getc(stdin); exit(EXIT_SUCCESS);
}

void Mary_Exit_Failure(const char *error_string)
{
  printf("MARY FATAL ERROR: %s\n", error_string);
  puts("\npress enter to exit...");
  getc(stdin); exit(EXIT_FAILURE);
}

void Mary_Exit_Assert(const char *assertion, const char *file, int line)
{
  printf("MARY ASSERT: %s is not true!\n", assertion);
  printf("    in file: %s\n", file);
  printf("    on line: %i\n", line);
  printf("\npress enter to exit\n");
  getc(stdin); exit(EXIT_FAILURE);
}

char Mary_Is_Little_Endian()
{
  volatile u16 i = 0x0001;
  return *(u8 *)&i == 1;
}

char Mary_Is_Big_Endian()
{
  volatile u16 i = 0x0001;
  return *(u8 *)&i == 0;
}

void Mary_Print_Bits(void *value, size_t size, char little_endian)
{
  char *binary_digits[16] =
  {
    "0000", "0001", "0010", "0011",
    "0100", "0101", "0110", "0111",
    "1000", "1001", "1010", "1011",
    "1100", "1101", "1110", "1111"
  };
  u8 byte = 0, *p = little_endian ? (u8 *)value + size - 1 : value;
  for (int i = 0; i < 76; ++i) printf("-"); printf("\n");
  for (size_t i = 0; i < size; i += 8)
  {
    if (!i)
      printf("bin: ");
    else if (i % 8 == 0)
      printf("     ");
    for (int j = 0; j < 8; ++j)
    {
      if (i + j == size) break;
      byte = little_endian ? *(p - (i + j)) : *(p + i + j);
      printf("%s", binary_digits[(byte & 0xF0) >> 4]);
      printf("%s ", binary_digits[byte & 0x0F]);
    } printf("\n");

    if (!i)
      printf("hex: ");
    else if (i % 8 == 0)
      printf("     ");
    for (int j = 0; j < 8; ++j)
    {
      if (i + j == size) break;
      byte = little_endian ? *(p - (i + j)) : *(p + i + j);
      printf("%4X", (byte & 0xF0) >> 4);
      printf("%4X ", byte & 0x0F);
    } printf("\n");
  }
  for (int i = 0; i < 76; ++i) printf("-"); printf("\n");
}

size_t Mary_C_String_Bytes(void *string, size_t unit, uint8_t count_zero)
{
  size_t bytes = 0; u64 zero = 0;
  for (u8 *b = string; ; b += unit, bytes += unit)
  {
    if (memcmp(b, &zero, unit) == 0) break;
  }
  if (count_zero > 0) bytes += unit;
  return bytes;
}

size_t Mary_C_String_Units(void *string, size_t unit, uint8_t count_zero)
{
  size_t units = 0; u64 zero = 0;
  for (u8 *b = string; ; b += unit, ++units)
  {
    if (memcmp(b, &zero, unit) == 0) break;
  }
  if (count_zero > 0) ++units;
  return units;
}

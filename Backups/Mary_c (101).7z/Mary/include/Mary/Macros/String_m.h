#pragma once

#include <Mary/String.h>

#undef MARY_String_Static
#undef MARY_String_Stack
#undef MARY_String_Heap
#undef MARY_String_Pool
#undef MARY_String_Frame
#undef MARY_String_Chain
#undef MARY_String_Heap_p
#undef MARY_String_Pool_p
#undef MARY_String_Frame_p
#undef MARY_String_Chain_p
#undef MARY_String_Point_Front
#undef MARY_String_Point_Back
#undef MARY_String_Point_End
#undef MARY_String_Assign
#undef MARY_String_Append_Front
#undef MARY_String_Append_Back
#undef MARY_String_Get_UTF
#undef MARY_String_Code_32_To_Units_8
#undef MARY_String_Data_8_To_Units_8
#undef MARY_String_Code_32_To_Units_16
#undef MARY_String_Data_16_To_Units_16
#undef MARY_String_Encode_8
#undef MARY_String_Decode_8
#undef MARY_String_Decode_8_Reverse
#undef MARY_String_Encode_16
#undef MARY_String_Decode_16
#undef MARY_String_Decode_16_Reverse
#undef MARY_String_Encode_32
#undef MARY_String_Decode_32
#undef MARY_String_Decode_32_Reverse
#undef MARY_String_Each
#undef MARY_String_Each_To
#undef MARY_String_Each_8
#undef MARY_String_Each_8_To_16
#undef MARY_String_Each_8_To_32
#undef MARY_String_Each_16
#undef MARY_String_Each_16_To_8
#undef MARY_String_Each_16_To_32
#undef MARY_String_Each_32
#undef MARY_String_Each_32_To_8
#undef MARY_String_Each_32_To_16

////// Creation //////

#define MARY_String_Static(NAME, UTF, C_STR)\
  Mary_String_t NAME; Mary_String_Create_With(&NAME, C_STR, 0, MARY_Allocator_Static, UTF)

#define MARY_String_Stack(NAME, UTF, C_STR)\
  Mary_String_t NAME; uint##UTF##_t NAME##_stack[] = C_STR;\
  Mary_String_Create_With(&NAME, NAME##_stack, 0, MARY_Allocator_Stack, UTF)

#define MARY_String_Heap(NAME, UTF, C_STR)\
  Mary_String_t NAME; Mary_String_Create_From(&NAME, MARY_Allocator_Heap, UTF, C_STR, UTF)

#define MARY_String_Pool(NAME, POOL, UTF, C_STR)\
  Mary_String_t NAME; Mary_String_Create_From(&NAME, MARY_Allocator_Pool((POOL)->id), UTF, C_STR, UTF)

#define MARY_String_Frame(NAME, UTF, C_STR)\
  Mary_String_t NAME; Mary_String_Create_From(&NAME, MARY_Allocator_Frame, UTF, C_STR, UTF)

#define MARY_String_Chain(NAME, UTF, C_STR)\
  Mary_String_t NAME; Mary_String_Create_From(&NAME, MARY_Allocator_Chain, UTF, C_STR, UTF)

#define MARY_String_Heap_p(THIS, UTF, C_STR)\
  Mary_String_Create_From(THIS, MARY_Allocator_Heap, UTF, C_STR, UTF)

#define MARY_String_Pool_p(THIS, POOL, UTF, C_STR)\
  Mary_String_Create_From(THIS, MARY_Allocator_Pool((POOL)->id), UTF, C_STR, UTF)

#define MARY_String_Frame_p(THIS, UTF, C_STR)\
  Mary_String_Create_From(THIS, MARY_Allocator_Frame, UTF, C_STR, UTF)

#define MARY_String_Chain_p(THIS, UTF, C_STR)\
  Mary_String_Create_From(THIS, MARY_Allocator_Chain, UTF, C_STR, UTF)

////// Accessing //////

#define MARY_String_Point_Front(THIS)\
  MARY_Vector_Point_Front(THIS)

#define MARY_String_Point_Back(THIS)\
  MARY_Vector_Point_Back(THIS)

#define MARY_String_Point_End(THIS)\
  MARY_Vector_Point_End(THIS)

////// Altering //////

#define MARY_String_Assign(THIS, UTF, C_STR)  \
MARY_M                                        \
  MARY_String_Static(static_str, UTF, C_STR); \
  Mary_String_Assign(THIS, &static_str);      \
MARY_W

#define MARY_String_Append_Front(THIS, UTF, C_STR) \
MARY_M                                             \
  MARY_String_Static(static_str, UTF, C_STR);      \
  Mary_String_Append_Front(THIS, &static_str);     \
MARY_W

#define MARY_String_Append_Back(THIS, UTF, C_STR) \
MARY_M                                            \
  MARY_String_Static(static_str, UTF, C_STR);     \
  Mary_String_Append_Back(THIS, &static_str);     \
MARY_W

////// Sizing //////

#define MARY_String_Get_UTF(THIS)\
  MARY_Unit_To_UTF((THIS)->unit)

#define MARY_String_Code_32_To_Units_8(CODE) \
(                                            \
  (CODE) < 0x000080 ? 1 :                    \
  (CODE) < 0x000800 ? 2 :                    \
  (CODE) < 0x010000 ? 3 :                    \
  (CODE) < 0x110000 ? 4 : 0                  \
)

#define MARY_String_Data_8_To_Units_8(DATA) \
(                                           \
  *(DATA) >> 7 == 0x00 ? 1 :                \
  *(DATA) >> 5 == 0x06 ? 2 :                \
  *(DATA) >> 4 == 0x0E ? 3 :                \
  *(DATA) >> 3 == 0x1E ? 4 : 0              \
)

#define MARY_String_Code_32_To_Units_16(CODE) \
(                                             \
  (CODE) < 0x10000 ? 1 : 2                    \
)

#define MARY_String_Data_16_To_Units_16(DATA)  \
(                                              \
  *(DATA) < 0xD800 || *(DATA) > 0xDFFF ? 1 : 2 \
)

////// Encoding / Decoding //////

#define MARY_String_Encode_8(CODE, OUT, CASE_A, CASE_B, CASE_C, CASE_D) \
(                                                                       \
  (CODE) < 0x000080 ?                                                   \
      ( OUT.a    = (        (CODE)               ),                     \
        OUT.code = (CODE), OUT.units = 1, (CASE_A), OUT ) :             \
  (CODE) < 0x000800 ?                                                   \
      ( OUT.a    = ( 0xC0 | (CODE) >> 6          ),                     \
        OUT.b    = ( 0x80 | (CODE)       & 0x3F  ),                     \
        OUT.code = (CODE), OUT.units = 2, (CASE_B), OUT ) :             \
  (CODE) < 0x010000 ?                                                   \
      ( OUT.a    = ( 0xE0 | (CODE) >> 12         ),                     \
        OUT.b    = ( 0x80 | (CODE) >> 6  & 0x3F  ),                     \
        OUT.c    = ( 0x80 | (CODE)       & 0x3F  ),                     \
        OUT.code = (CODE), OUT.units = 3, (CASE_C), OUT ) :             \
  (CODE) < 0x110000 ?                                                   \
      ( OUT.a    = ( 0xF0 | (CODE) >> 18         ),                     \
        OUT.b    = ( 0x80 | (CODE) >> 12 & 0x3F  ),                     \
        OUT.c    = ( 0x80 | (CODE) >> 6  & 0x3F  ),                     \
        OUT.d    = ( 0x80 | (CODE)       & 0x3F  ),                     \
        OUT.code = (CODE), OUT.units = 4, (CASE_D), OUT ) : OUT         \
)

#define MARY_String_Decode_8(PTR, OUT)                            \
(                                                                 \
  *PTR >> 7 == 0x00 ?                                             \
      ( OUT.code  = ( ( OUT.a = *(PTR    ) )        )       ,     \
        OUT.units = 1,  PTR += 1, OUT )                     :     \
  *PTR >> 5 == 0x06 ?                                             \
      ( OUT.code  = ( ( OUT.a = *(PTR    ) ) ^ 0xC0 ) << 6  |     \
                    ( ( OUT.b = *(PTR + 1) ) ^ 0x80 )       ,     \
        OUT.units = 2,  PTR += 2, OUT )                     :     \
  *PTR >> 4 == 0x0E ?                                             \
      ( OUT.code  = ( ( OUT.a = *(PTR    ) ) ^ 0xE0 ) << 12 |     \
                    ( ( OUT.b = *(PTR + 1) ) ^ 0x80 ) << 6  |     \
                    ( ( OUT.c = *(PTR + 2) ) ^ 0x80 )       ,     \
        OUT.units = 3,  PTR += 3, OUT )                     :     \
  *PTR >> 3 == 0x1E ?                                             \
      ( OUT.code  = ( ( OUT.a = *(PTR    ) ) ^ 0xF0 ) << 18 |     \
                    ( ( OUT.b = *(PTR + 1) ) ^ 0x80 ) << 12 |     \
                    ( ( OUT.c = *(PTR + 2) ) ^ 0x80 ) << 6  |     \
                    ( ( OUT.d = *(PTR + 3) ) ^ 0x80 )       ,     \
        OUT.units = 4,  PTR += 4, OUT )                     : OUT \
)

#define MARY_String_Decode_8_Reverse(PTR, OUT)                    \
(                                                                 \
     PTR -= 1,                                                    \
  *  PTR >> 6 != 0x2 ? PTR :                                      \
  *--PTR >> 6 != 0x2 ? PTR :                                      \
  *--PTR >> 6 != 0x2 ? PTR : --PTR,                               \
  *PTR >> 7 == 0x00 ?                                             \
      ( OUT.code  = ( ( OUT.a = *(PTR    ) )        )       ,     \
        OUT.units = 1,  OUT )                               :     \
  *PTR >> 5 == 0x06 ?                                             \
      ( OUT.code  = ( ( OUT.a = *(PTR    ) ) ^ 0xC0 ) << 6  |     \
                    ( ( OUT.b = *(PTR + 1) ) ^ 0x80 )       ,     \
        OUT.units = 2,  OUT )                               :     \
  *PTR >> 4 == 0x0E ?                                             \
      ( OUT.code  = ( ( OUT.a = *(PTR    ) ) ^ 0xE0 ) << 12 |     \
                    ( ( OUT.b = *(PTR + 1) ) ^ 0x80 ) << 6  |     \
                    ( ( OUT.c = *(PTR + 2) ) ^ 0x80 )       ,     \
        OUT.units = 3,  OUT )                               :     \
  *PTR >> 3 == 0x1E ?                                             \
      ( OUT.code  = ( ( OUT.a = *(PTR    ) ) ^ 0xF0 ) << 18 |     \
                    ( ( OUT.b = *(PTR + 1) ) ^ 0x80 ) << 12 |     \
                    ( ( OUT.c = *(PTR + 2) ) ^ 0x80 ) << 6  |     \
                    ( ( OUT.d = *(PTR + 3) ) ^ 0x80 )       ,     \
        OUT.units = 4,  OUT )                               : OUT \
)

#define MARY_String_Encode_16(CODE, OUT, CASE_A, CASE_B)       \
(                                                              \
  (CODE) < 0x10000 ?                                           \
      ( OUT.a    = ( ( (CODE)                    )          ), \
        OUT.code = CODE, OUT.units = 1, (CASE_A), OUT )      : \
      ( OUT.a    = ( ( (CODE) - 0x10000 >> 10    ) + 0xD800 ), \
        OUT.b    = ( ( (CODE) - 0x10000 &  0x3FF ) + 0xDC00 ), \
        OUT.code = CODE, OUT.units = 2, (CASE_B), OUT )        \
)

#define MARY_String_Decode_16(PTR, OUT)                         \
(                                                               \
  *PTR < 0xD800 || 0xDBFF < *PTR ?                              \
      ( OUT.code = ( ( OUT.a = *(PTR    )  )                ) , \
        OUT.units = 1, PTR += 1, OUT )                        : \
      ( OUT.code = ( ( OUT.a = *(PTR    )  ) - 0xD800 << 10 ) + \
                   ( ( OUT.b = *(PTR + 1)  ) - 0xDC00       ) + \
                   0x10000                                    , \
        OUT.units = 2, PTR += 2, OUT )                          \
)

#define MARY_String_Decode_16_Reverse(PTR, OUT)                 \
(                                                               \
   PTR -= 1,                                                    \
  *PTR < 0xDC00 || 0xDFFF < *PTR ?                              \
      ( OUT.code = ( ( OUT.a = *(PTR    )  )                ) , \
        OUT.units = 1,           OUT )                        : \
      ( OUT.code = ( ( OUT.a = *(PTR - 1)  ) - 0xD800 << 10 ) + \
                   ( ( OUT.b = *(PTR    )  ) - 0xDC00       ) + \
                   0x10000                                    , \
        OUT.units = 2, PTR -= 1, OUT )                          \
)

#define MARY_String_Encode_32(CODE, OUT, CASE_A)\
  ( OUT = CODE, CASE_A, OUT )

#define MARY_String_Decode_32(PTR, OUT)\
  ( OUT = *PTR++ )

#define MARY_String_Decode_32_Reverse(PTR, OUT)\
  ( OUT = *--PTR )

////// Loops //////

#define MARY_String_Each_8(THIS)                                                                  \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx, unit_idx;                                                            \
      Mary_Size_t codes;                                                                          \
      uint8_t *ptr, *next;                                                                        \
      Mary_UTF_8_t utf_8;                                                                         \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(MARY_String_Get_UTF(THIS) == 8, 0), THIS ),                                   \
        0, 0, it.string->codes, it.string->data, it.ptr,                                          \
        MARY_String_Decode_8(it.next, it.utf_8)                                                   \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, it.unit_idx += it.utf_8.units, it.ptr = it.next,                               \
    MARY_String_Decode_8(it.next, it.utf_8)                                                       \
  )

#define MARY_String_Each_8_To_16(THIS)                                                            \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx, unit_idx;                                                            \
      Mary_Size_t codes;                                                                          \
      uint8_t *ptr, *next;                                                                        \
      Mary_UTF_8_t utf_8;                                                                         \
      Mary_UTF_16_t utf_16;                                                                       \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(MARY_String_Get_UTF(THIS) == 8, 0), THIS ),                                   \
        0, 0, it.string->codes, it.string->data, it.ptr,                                          \
        MARY_String_Decode_8(it.next, it.utf_8),                                                  \
        MARY_String_Encode_16(it.utf_8.code, it.utf_16, 0, 0)                                     \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, it.unit_idx += it.utf_8.units, it.ptr = it.next,                               \
    MARY_String_Decode_8(it.next, it.utf_8),                                                      \
    MARY_String_Encode_16(it.utf_8.code, it.utf_16, 0, 0)                                         \
  )

#define MARY_String_Each_8_To_32(THIS)                                                            \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx, unit_idx;                                                            \
      Mary_Size_t codes;                                                                          \
      uint8_t *ptr, *next;                                                                        \
      Mary_UTF_8_t utf_8;                                                                         \
      Mary_UTF_32_t utf_32;                                                                       \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(MARY_String_Get_UTF(THIS) == 8, 0), THIS ),                                   \
        0, 0, it.string->codes, it.string->data, it.ptr,                                          \
        MARY_String_Decode_8(it.next, it.utf_8),                                                  \
        it.utf_8.code                                                                             \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, it.unit_idx += it.utf_8.units, it.ptr = it.next,                               \
    MARY_String_Decode_8(it.next, it.utf_8),                                                      \
    it.utf_32 = it.utf_8.code                                                                     \
  )

#define MARY_String_Each_16(THIS)                                                                 \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx, unit_idx;                                                            \
      Mary_Size_t codes;                                                                          \
      uint16_t *ptr, *next;                                                                       \
      Mary_UTF_16_t utf_16;                                                                       \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(MARY_String_Get_UTF(THIS) == 16, 0), THIS ),                                  \
        0, 0, it.string->codes, it.string->data, it.ptr,                                          \
        MARY_String_Decode_16(it.next, it.utf_16)                                                 \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, it.unit_idx += it.utf_16.units, it.ptr = it.next,                              \
    MARY_String_Decode_16(it.next, it.utf_16)                                                     \
  )

#define MARY_String_Each_16_To_8(THIS)                                                            \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx, unit_idx;                                                            \
      Mary_Size_t codes;                                                                          \
      uint16_t *ptr, *next;                                                                       \
      Mary_UTF_16_t utf_16;                                                                       \
      Mary_UTF_8_t utf_8;                                                                         \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(MARY_String_Get_UTF(THIS) == 16, 0), THIS ),                                  \
        0, 0, it.string->codes, it.string->data, it.ptr,                                          \
        MARY_String_Decode_16(it.next, it.utf_16),                                                \
        MARY_String_Encode_8(it.utf_16.code, it.utf_8, 0, 0, 0, 0)                                \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, it.unit_idx += it.utf_16.units, it.ptr = it.next,                              \
    MARY_String_Decode_16(it.next, it.utf_16),                                                    \
    MARY_String_Encode_8(it.utf_16.code, it.utf_8, 0, 0, 0, 0)                                    \
  )

#define MARY_String_Each_16_To_32(THIS)                                                           \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx, unit_idx;                                                            \
      Mary_Size_t codes;                                                                          \
      uint16_t *ptr, *next;                                                                       \
      Mary_UTF_16_t utf_16;                                                                       \
      Mary_UTF_32_t utf_32;                                                                       \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(MARY_String_Get_UTF(THIS) == 16, 0), THIS ),                                  \
        0, 0, it.string->codes, it.string->data, it.ptr,                                          \
        MARY_String_Decode_16(it.next, it.utf_16),                                                \
        it.utf_16.code                                                                            \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, it.unit_idx += it.utf_16.units, it.ptr = it.next,                              \
    MARY_String_Decode_16(it.next, it.utf_16),                                                    \
    it.utf_32 = it.utf_16.code                                                                    \
  )

#define MARY_String_Each_32(THIS)                                                                 \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx;                                                                      \
      Mary_Size_t codes;                                                                          \
      uint32_t *ptr;                                                                              \
      Mary_UTF_32_t utf_32;                                                                       \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(MARY_String_Get_UTF(THIS) == 32, 0), THIS ),                                  \
        0, it.string->codes, it.string->data, *it.ptr                                             \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, ++it.ptr, it.utf_32 = *it.ptr                                                  \
  )

#define MARY_String_Each_32_To_8(THIS)                                                            \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx;                                                                      \
      Mary_Size_t codes;                                                                          \
      uint32_t *ptr;                                                                              \
      Mary_UTF_32_t utf_32;                                                                       \
      Mary_UTF_8_t utf_8;                                                                         \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(MARY_String_Get_UTF(THIS) == 32, 0), THIS ),                                  \
        0, it.string->codes, it.string->data, *it.ptr,                                            \
        MARY_String_Encode_8(it.utf_32, it.utf_8, 0, 0, 0, 0)                                     \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, ++it.ptr, it.utf_32 = *it.ptr,                                                 \
    MARY_String_Encode_8(it.utf_32, it.utf_8, 0, 0, 0, 0)                                         \
  )

#define MARY_String_Each_32_To_16(THIS)                                                           \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx;                                                                      \
      Mary_Size_t codes;                                                                          \
      uint32_t *ptr;                                                                              \
      Mary_UTF_32_t utf_32;                                                                       \
      Mary_UTF_16_t utf_16;                                                                       \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(MARY_String_Get_UTF(THIS) == 32, 0), THIS ),                                  \
        0, it.string->codes, it.string->data, *it.ptr,                                            \
        MARY_String_Encode_16(it.utf_32, it.utf_16, 0, 0)                                         \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, ++it.ptr, it.utf_32 = *it.ptr,                                                 \
    MARY_String_Encode_16(it.utf_32, it.utf_16, 0, 0)                                             \
  )

#define MARY_String_Each(THIS, UTF)\
  MARY_String_Each_##UTF(THIS)

#define MARY_String_Each_To(THIS, UTF, TO_UTF)\
  MARY_String_Each_##UTF##_To_##TO_UTF(THIS)

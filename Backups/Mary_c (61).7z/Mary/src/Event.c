#include <Mary/Event.h>
#include <Mary/Window.h>

MARY_PRIMITIVES;

typedef struct
{
  size_t bytes;
}
Type_Info;

// somehow, I am leaking variables here! Not sure how. these have the same names as in Element.c,
// but they are completely different translations units! Without the static, I get errors!!!
// even the type is somehow getting redefined, seemingly only in the debugger, but no errors with that!
// very strange!!!

static Mary_Vector_t type_infos;

void Mary_Event_Start()
{
  Type_Info type_info;
  Mary_Vector_Create(&type_infos, sizeof(Type_Info), 3); // make sure to increase the reserve size

  #define TYPE_INFO(TYPE)                           \
    type_info = (Type_Info)                         \
    {                                               \
      sizeof(Mary_Event_##TYPE##_t)                 \
    };                                              \
    Mary_Vector_Push_Back(&type_infos, &type_info)

  TYPE_INFO(Keyboard);
  TYPE_INFO(Mouse);
  TYPE_INFO(Mousewheel);

  #undef TYPE_INFO
}

void Mary_Event_Finish()
{
  Mary_Vector_Destroy(&type_infos);
}

void *Mary_Event_Create(Mary_Window_t *window, int enum_mary_event)
{
  Type_Info *info = Mary_Vector_Point(&type_infos, enum_mary_event);
  Mary_Event_t *event = Mary_Pool_Allocate(&window->event_pool, info->bytes);
  event->type = enum_mary_event;
  Mary_Vector_Push_Back(&window->messages, &event);
  return event;
}

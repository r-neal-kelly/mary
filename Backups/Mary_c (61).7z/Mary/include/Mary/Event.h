#pragma once

#include <Mary/Element.h>

enum
{
  MARY_EVENT_KEYBOARD,
  MARY_EVENT_MOUSE,
  MARY_EVENT_MOUSEWHEEL
};

typedef struct Mary_Event_Keyboard_t Mary_Event_Keyboard_t;

#define MARY_Event_t\
  int type;\
  Mary_Element_t *target

struct Mary_Event_t
{
  MARY_Event_t;
};

struct Mary_Event_Keyboard_t
{
  MARY_Event_t;
  uint32_t key;
};

typedef struct
{
  MARY_Event_t;
  uint8_t button;
}
Mary_Event_Mouse_t;

typedef struct
{
  MARY_Event_t;
  int16_t delta, x, y;
}
Mary_Event_Mousewheel_t;

void Mary_Event_Start();
void Mary_Event_Finish();
void *Mary_Event_Create(Mary_Window_t *window, int enum_mary_event);

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <Mary/Mary.h>

int main()
{
  //Mary_Start();

#if 0
  Mary_Hashmap_t hashmap;
  const Mary_Hashmap_i *hashmap_i = Mary_Hashmap();
  int key, val, out_val = 0;
  srand((uint32_t)time(0));

  hashmap_i->Create(&hashmap, sizeof(key), sizeof(val));
  for (int i = 0; i < 144000; ++i)
  {
    key = i, val = rand(); hashmap_i->Insert(&hashmap, &key, &val);
    hashmap_i->At(&hashmap, &key, &out_val);
    //printf("%i: %i\n", key, out_val);
  }
  hashmap_i->Destroy(&hashmap);
  
  Mary_Exit_Success();
#endif

#if 0
  Mary_Window_t window;
  Mary_Window_Create(&window);
  while (Mary_Window_Can_Render())
  {
    Mary_Window_Render();
  }
  Mary_Window_Destroy(&window);
#endif

  Mary_Font_TTF_t quivira = Mary_Font_TTF_Create("Quivira.ttf");
  Mary_Font_TTF_Destroy(&quivira);
  Mary_Exit_Success();

  //Mary_Finish();
}

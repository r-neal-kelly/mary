#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <Mary/Utils.h>
#include <Mary/Font_TTF.h>

Mary_Font_TTF_t Mary_Font_TTF_Create(char *file_path);
void Mary_Font_TTF_Destroy(Mary_Font_TTF_t *mary_font);

Mary_Font_TTF_t Mary_Font_TTF_Create(char *file_path)
{
  Mary_Font_TTF_t mary_font;
  Mary_File_t mary_file = Mary_File_Read(file_path);

  uint8_t *p = mary_file.data;
  mary_font.data = p;
  uint32_t scalar_type = *(uint32_t *)p; p += 4; // look at the hex for this, I think we have to swap bytes.
  uint16_t num_tables = *(uint16_t *)p; p += 8;

  uint8_t *table_directory = p;

  // can use a hashmap for this.
  char tag[5]; memset(tag, 0, 5);
  for (int i = 0; i < num_tables; ++i, p += 16)
  {
    memcpy(tag, p, 4);
    printf("%s\n", tag);
    if (strcmp(tag, "name") == 0)
    {
      puts("found it.\n");
      break;
    }
  }

  return mary_font;
}

void Mary_Font_TTF_Destroy(Mary_Font_TTF_t *mary_font)
{
  free(mary_font->data);
}

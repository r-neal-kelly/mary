#pragma once

#include <stdint.h>

typedef struct
{
  void *data;
}
Mary_Font_TTF_t;

Mary_Font_TTF_t Mary_Font_TTF_Create(char *file_path);
void Mary_Font_TTF_Destroy(Mary_Font_TTF_t *mary_font);

#include <stdio.h>
#include <stdlib.h>
#include <Mary/Utils.h>
#include <Mary/Regex.h>

MARY_PRIMITIVES;

const u32 MAX_CODEPOINTS = 64 * 4;

void Mary_Regex_Create(Mary_Regex_t *mary_regex, char bit_format, void *expression)
{
  if (bit_format == 8)
  {
    Mary_Regex_8bit_Create(mary_regex, expression);
  }
}

void Mary_Regex_8bit_Create(Mary_Regex_t *mary_regex, uint8_t *expression)
{
  Mary_Pool_Create(&mary_regex->pool, MAX_CODEPOINTS * 2);
  void *data_expression = Mary_Pool_Allocate(&mary_regex->pool, MAX_CODEPOINTS);
  Mary_Pointer_t ptr_expression = { data_expression, MAX_CODEPOINTS };
  Mary_String_Create_With(&mary_regex->expression, 8, expression, 0, ptr_expression);
  Mary_String_8bit_to_32bit(&mary_regex->expression);
  Mary_Regex_To_Postfix(mary_regex);
}

void Mary_Regex_Destroy(Mary_Regex_t *mary_regex)
{
  Mary_Pool_Destroy(&mary_regex->pool);
}

void Mary_Regex_Compile(Mary_Regex_t *mary_regex)
{

}

void Mary_Regex_Match()
{

}

void Mary_Regex_To_Postfix(Mary_Regex_t *mary_regex)
{
  MARY_Assert(mary_regex->expression.size <= 64);
  Mary_Vector_t v_stack; u32 a_stack[64];
  Mary_Vector_Create_With(&v_stack, 4, (Mary_Pointer_t){ a_stack, 64 });
  Mary_Vector_t v_input; u32 a_input[64];
  Mary_Vector_Create_With(&v_input, 4, (Mary_Pointer_t){ a_input, 64 });
  Mary_Vector_t v_output; u32 a_output[64];
  Mary_Vector_Create_With(&v_output, 4, (Mary_Pointer_t){ a_output, 64 });
  u32 concat_symbol = '&', top;
  MARY_Range(mary_regex->expression.data, u32, 0, mary_regex->expression.size)
  {
    Mary_Vector_Push_Back(&v_input, range.ptr);
    if (range.val != '(' && range.val != '|' && range.val != '\0')
    {
      u32 next = *(range.ptr + 1);
      if (next != '*' && next != ')' && next != '|' && next != '\0')
      {
        Mary_Vector_Push_Back(&v_input, &concat_symbol);
      }
    }
  }
  MARY_Range(v_input.data, u32, 0, v_input.size)
  {
    // precedence 1: (), *; 2: &; 3: |;
    if (range.val == 0)
    {
      while (v_stack.size)
      {
        Mary_Vector_Pop_Back(&v_stack, &top);
        Mary_Vector_Push_Back(&v_output, &top);
      }
      Mary_Vector_Push_Back(&v_output, &range.val);
      break;
    }
    else if (range.val == '|')
    {
      if (v_stack.size)
      {
        Mary_Vector_At(&v_stack, v_stack.size - 1, &top);
        if (top == '*' || top == '&' || top == '|')
        {
          Mary_Vector_Pop_Back(&v_stack, &top);
          Mary_Vector_Push_Back(&v_output, &top);
        }
      }
      Mary_Vector_Push_Back(&v_stack, &range.val);
    }
    else if (range.val == '&')
    {
      if (v_stack.size)
      {
        Mary_Vector_At(&v_stack, v_stack.size - 1, &top);
        if (top == '*' || top == '&')
        {
          Mary_Vector_Pop_Back(&v_stack, &top);
          Mary_Vector_Push_Back(&v_output, &top);
        }
      }
      top = '&'; Mary_Vector_Push_Back(&v_stack, &top);
    }
    else if (range.val == '*')
    {
      if (v_stack.size)
      {
        Mary_Vector_At(&v_stack, v_stack.size - 1, &top);
        if (top == '*')
        {
          Mary_Vector_Pop_Back(&v_stack, &top);
          Mary_Vector_Push_Back(&v_output, &top);
        }
      }
      Mary_Vector_Push_Back(&v_stack, &range.val);
    }
    else if (range.val == '(')
    {
      if (v_stack.size)
      {
        Mary_Vector_At(&v_stack, v_stack.size - 1, &top);
        if (top == '*')
        {
          Mary_Vector_Pop_Back(&v_stack, &top);
          Mary_Vector_Push_Back(&v_output, &top);
        }
      }
      Mary_Vector_Push_Back(&v_stack, &range.val);
    }
    else if (range.val == ')')
    {
      Mary_Vector_Pop_Back(&v_stack, &top);
      while (top != '(')
      {
        Mary_Vector_Push_Back(&v_output, &top);
        Mary_Vector_Pop_Back(&v_stack, &top);
      }
    }
    else
    {
      Mary_Vector_Push_Back(&v_output, &range.val);
    }
  }
  void *data_postfix = Mary_Pool_Allocate(&mary_regex->pool, MAX_CODEPOINTS);
  Mary_Pointer_t ptr_postfix = { data_postfix, MAX_CODEPOINTS };
  Mary_String_Create_With(&mary_regex->postfix, 32, a_output, v_output.size, ptr_postfix);
}

#define intern static
#include <stdlib.h>
#include <Mary/OS.h>
#include <Mary/OpenGL.h>
#include <Mary/Text.h>

void Mary_Text_Start();
void Mary_Text_Finish();
void Mary_Text_Create(Mary_Text_t *elem);
void Mary_Text_Destroy(Mary_Text_t *elem);
void Mary_Text_Text(Mary_Text_t *elem, uint16_t *text);
void Mary_Text_Buffer(Mary_Text_t *elem);
void Mary_Text_Render(Mary_Text_t *elem, Mary_Matrix_4x4f *projection);
void Mary_Text_Position(Mary_Text_t *elem, float x, float y);
void Mary_Text_Size(Mary_Text_t *elem, float w, float h);
void Mary_Text_Color(Mary_Text_t *elem, float r, float g, float b, float a);

intern HDC g_win32_context = 0;
intern GLuint g_VAO = 0;
intern GLuint g_VBO = 0;
intern GLuint g_EBO = 0;
intern GLuint g_program = 0;
intern GLint g_u_model = -1;
intern GLint g_u_projection = -1;
intern GLint g_u_color = -1;
intern GLint g_u_texture = -1;

void Mary_Text_Start()
{
  ////// OpenGL Globals
  Mary_OpenGL_g g_opengl = Mary_OpenGL();
  g_win32_context = g_opengl.win32_context;
  ////// Vertex Array Object
  glGenVertexArrays(1, &g_VAO);
  glBindVertexArray(g_VAO);
  ////// Vertex Buffer Object
  float vertices[] = { 0.0f, 0.0f,   1.0f, 0.0f,   1.0f, 1.0f,   0.0f, 1.0f };
  glGenBuffers(1, &g_VBO);
  glBindBuffer(GL_ARRAY_BUFFER, g_VBO);
  glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
  glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, sizeof(float) * 2, (void *)0);
  glEnableVertexAttribArray(0);
  ////// Element Buffer Object
  unsigned int indices[] = { 0, 1, 2,   2, 3, 0 };
  glGenBuffers(1, &g_EBO);
  glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, g_EBO);
  glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
  ////// Program
  g_program = Mary_OpenGL_Program("Mary/shaders/text_v.shader", "Mary/shaders/text_f.shader");
  ////// Uniforms
  g_u_model = glGetUniformLocation(g_program, "u_model");
  g_u_projection = glGetUniformLocation(g_program, "u_projection");
  g_u_color = glGetUniformLocation(g_program, "u_color");
  g_u_texture = glGetUniformLocation(g_program, "u_texture");
}

void Mary_Text_Finish()
{

}

void Mary_Text_Create(Mary_Text_t *elem)
{
  ////// Style
  elem->x = 0;
  elem->y = 0;
  elem->w = 0;
  elem->h = 0;
  elem->r = 0;
  elem->g = 0;
  elem->b = 0;
  elem->a = 1;
  ////// Texture
  glGenTextures(1, &elem->texture);
  glActiveTexture(GL_TEXTURE0); // maybe should have a vector that keeps a stack for all slots
  glBindTexture(GL_TEXTURE_2D, elem->texture);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  ////// Text
  Mary_Vector_Create(&elem->v_text, sizeof(uint16_t), 0);
  Mary_Text_Text(elem, u"");
}

void Mary_Text_Destroy(Mary_Text_t *elem)
{
  Mary_Vector_Destroy(&elem->v_text);
  glDeleteTextures(1, &elem->texture);
}

void Mary_Text_Text(Mary_Text_t *elem, uint16_t *text)
{
  Mary_Vector_t *v_text = &elem->v_text;
  Mary_Vector_Empty(v_text);
  uint16_t *c = text;
  while (*c != 0)
  {
    Mary_Vector_Push_Back(v_text, c);
    c += 1;
  }
}

void Mary_Text_Buffer(Mary_Text_t *elem)
{
  Mary_Vector_t *v_text = &elem->v_text;
  int w = (int)elem->w;
  int h = (int)elem->h;
  unsigned int total_bytes = w * h * 4;

  BITMAPINFO bmi;
  memset(&bmi, 0, sizeof(bmi));
  bmi.bmiHeader.biSize = sizeof(bmi.bmiHeader);
  bmi.bmiHeader.biWidth = w;
  bmi.bmiHeader.biHeight = -h;
  bmi.bmiHeader.biPlanes = 1;
  bmi.bmiHeader.biBitCount = 32;
  bmi.bmiHeader.biCompression = BI_RGB;
  bmi.bmiHeader.biSizeImage = total_bytes;

  void *dib_bfr;
  HDC dib_hdc = CreateCompatibleDC(g_win32_context);
  HBITMAP dib_bmp = CreateDIBSection(dib_hdc, &bmi, DIB_RGB_COLORS, &dib_bfr, 0, 0);
  SelectObject(dib_hdc, dib_bmp);

  RECT rect;
  rect.left = 0;
  rect.top = 0;
  rect.right = w;
  rect.bottom = h;
  SetBkColor(dib_hdc, RGB(0, 0, 0)); // can invert these two for highlight!
  SetTextColor(dib_hdc, RGB(255, 255, 255));
  //HGDIOBJ old_font = SelectObject(memDC, Win32FontHandle());
  unsigned int flags = DT_LEFT | DT_WORDBREAK; // temp, make more optional
  GdiFlush(); DrawTextEx(dib_hdc, v_text->data, (int)v_text->size, &rect, flags, 0); // slow!!!

  glActiveTexture(GL_TEXTURE0);
  GLuint current_texture; glGetIntegerv(GL_TEXTURE_BINDING_2D, &current_texture);
  if (current_texture != elem->texture)
  {
    glBindTexture(GL_TEXTURE_2D, elem->texture);
  }
  glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_BGRA, GL_UNSIGNED_BYTE, dib_bfr);

  //SelectObject(memDC, old_font);
  DeleteObject(dib_bmp);
  DeleteDC(dib_hdc);
}

void Mary_Text_Render(Mary_Text_t *elem, Mary_Matrix_4x4f *projection)
{
  ////// Set VBO
  GLuint current_VBO; glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &current_VBO);
  if (current_VBO != g_VBO)
  {
    glBindVertexArray(g_VAO);
  }
  ////// Set Program
  GLuint current_program; glGetIntegerv(GL_CURRENT_PROGRAM, &current_program);
  if (current_program != g_program)
  {
    glUseProgram(g_program);
  }
  ////// Set Texture
  glActiveTexture(GL_TEXTURE0);
  GLuint current_texture; glGetIntegerv(GL_TEXTURE_BINDING_2D, &current_texture);
  if (current_texture != elem->texture)
  {
    glBindTexture(GL_TEXTURE_2D, elem->texture);
  }
  ////// Set Uniforms
  Mary_Matrix_4x4f model = Mary_OpenGL_Identity();
  Mary_OpenGL_Scale(&model, elem->w, elem->h, 1.0f);
  Mary_OpenGL_Translate(&model, elem->x, elem->y, 0.0f);
  glUniformMatrix4fv(g_u_model, 1, GL_TRUE, model.matrix);
  glUniformMatrix4fv(g_u_projection, 1, GL_TRUE, projection->matrix);
  glUniform4f(g_u_color, elem->r, elem->g, elem->b, elem->a);
  glUniform1i(g_u_texture, 0);
  ////// Draw
  glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
}

void Mary_Text_Position(Mary_Text_t *elem, float x, float y)
{
  elem->x = x;
  elem->y = y;
}

void Mary_Text_Size(Mary_Text_t *elem, float w, float h)
{
  elem->w = w;
  elem->h = h;
}

void Mary_Text_Color(Mary_Text_t *elem, float r, float g, float b, float a)
{
  elem->r = r;
  elem->g = g;
  elem->b = b;
  elem->a = a;
}

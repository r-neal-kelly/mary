#pragma once

#include <stdint.h>

#define MARY_PRIMITIVES                                                                            \
  typedef uint8_t  u8;                                                                             \
  typedef uint16_t u16;                                                                            \
  typedef uint32_t u32;                                                                            \
  typedef uint64_t u64;                                                                            \
  typedef int8_t   s8;                                                                             \
  typedef int16_t  s16;                                                                            \
  typedef int32_t  s32;                                                                            \
  typedef int64_t  s64;                                                                            \
  typedef float    r32;                                                                            \
  typedef double   r64;                                                                            \
  typedef uint32_t b32;                                                                            \
  typedef uint64_t b64

#define MARY_SWAP_16(I)                                                                            \
(                                                                                                  \
  (I) >> 8 & 0x00FF |                                                                              \
  (I) << 8 & 0xFF00                                                                                \
)

#define MARY_SWAP_32(I)                                                                            \
(                                                                                                  \
  (I) >> 24 & 0x000000FF |                                                                         \
  (I) >> 8  & 0x0000FF00 |                                                                         \
  (I) << 8  & 0x00FF0000 |                                                                         \
  (I) << 24 & 0xFF000000                                                                           \
)

#define MARY_SWAP_64(I)                                                                            \
(                                                                                                  \
  (I) >> 56 & 0x00000000000000FF |                                                                 \
  (I) >> 48 & 0x000000000000FF00 |                                                                 \
  (I) >> 40 & 0x0000000000FF0000 |                                                                 \
  (I) >> 32 & 0x00000000FF000000 |                                                                 \
  (I) << 32 & 0x000000FF00000000 |                                                                 \
  (I) << 40 & 0x0000FF0000000000 |                                                                 \
  (i) << 48 & 0x00FF000000000000 |                                                                 \
  (I) << 56 & 0xFF00000000000000                                                                   \
)

#define MARY_Assert(THIS_IS_TRUE)                                                                  \
  if (!(THIS_IS_TRUE))                                                                             \
  {                                                                                                \
    Mary_Exit_Assert(#THIS_IS_TRUE, __FILE__, __LINE__);                                           \
  }

#define MARY_Range(POINTER, TYPE, FROM, TO_EXCLUSIVE)                                              \
  for                                                                                              \
  (                                                                                                \
    struct { size_t idx; size_t end; TYPE *ptr; TYPE val; }                                        \
    range = { (FROM), (TO_EXCLUSIVE), (POINTER), *(TYPE *)(POINTER) };                             \
    range.idx < range.end;                                                                         \
    ++range.idx, ++range.ptr, range.val = *range.ptr                                               \
  )

#define MARY_Range_Advance(INDICES)                                                                \
  range.idx += (INDICES), range.ptr += (INDICES), range.val = *range.ptr

#if defined(_WIN32)
  #define MARY_Benchmark(FUNCTION, TRIALS)                                                         \
  {                                                                                                \
    LARGE_INTEGER freq, start, finish, diff;                                                       \
    unsigned long long us = 0; double s = 0;                                                       \
    for (unsigned long long i = 0; i < (TRIALS); ++i)                                              \
    {                                                                                              \
      QueryPerformanceFrequency(&freq);                                                            \
      QueryPerformanceCounter(&start);                                                             \
      FUNCTION;                                                                                    \
      QueryPerformanceCounter(&finish);                                                            \
      diff.QuadPart = finish.QuadPart - start.QuadPart;                                            \
      us += diff.QuadPart * 1000000 / freq.QuadPart;                                               \
    }                                                                                              \
    if ((TRIALS)) us /= (TRIALS), s = us / 1000000.0;                                              \
    printf("%s\n", #FUNCTION);                                                                     \
    printf("%10i trials %10llu us %10g s\n", (TRIALS), us, s);                                     \
  }
#endif

#define MARY_Pointer_t(ID_DATA, ID_BYTES) struct { void *ID_DATA; size_t ID_BYTES; }

typedef struct
{
  void *data;
  size_t bytes;
}
Mary_Pointer_t;

typedef struct
{
  size_t from;
  size_t to_exclusive;
}
Mary_Index_t;

void Mary_Exit_Success();
void Mary_Exit_Failure(const char *error_string);
void Mary_Exit_Assert(const char *assertion, const char *file, int line);
char Mary_Is_Little_Endian();
char Mary_Is_Big_Endian();
void Mary_Print_Bits(void *value, size_t size, char little_endian);

typedef struct
{
  void *data;
  size_t size;
}
Mary_File_t;

void Mary_File_Read(Mary_File_t *mary_file, const char *file_path);
void Mary_File_Destroy(Mary_File_t *mary_file);

// planned types
// prob should separate Mary_File_t into its own unit.
// Mary_Polyarray_t for js like array.
// Mary_Biarray_t, quickly extendable on either side. Mary_Queue_t? Deque?
// Mary_Regex_t for regex implementation

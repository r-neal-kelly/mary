#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <Mary/Utils.h>
#include <Mary/Vector.h>

MARY_PRIMITIVES;

static const r32 GROWTH_RATE = 1.7f;

void Mary_Vector_Create(Mary_Vector_t *vector, size_t unit, size_t opt_reserve)
{
  size_t capacity = (opt_reserve) ? (opt_reserve * unit) : unit;
  void *data = malloc(capacity);
  if (data)
  {
    vector->data = data;
    vector->capacity = capacity;
    vector->unit = unit;
    vector->size = 0;
  }
}

void Mary_Vector_Create_With(Mary_Vector_t *vector, size_t unit, void *data, size_t capacity)
{
  void *copy = malloc(capacity);
  if (copy)
  {
    vector->data = copy;
    vector->capacity = capacity;
    vector->unit = unit;
    vector->size = capacity / unit;
    memcpy(copy, data, capacity);
  }
}

void Mary_Vector_Destroy(Mary_Vector_t *vector)
{
  free(vector->data);
}

void Mary_Vector_Reserve(Mary_Vector_t *vector, size_t size)
{
  size_t new_capacity = size * vector->unit;
  if (new_capacity > vector->capacity)
  {
    void *data = vector->data;
    data = realloc(data, new_capacity);
    if (data)
    {
      vector->data = data;
      vector->capacity = new_capacity;
    }
  }
}

void Mary_Vector_Fit(Mary_Vector_t *vector)
{
  size_t capacity = vector->capacity;
  size_t unit = vector->unit;
  size_t size = vector->size;
  size_t fit_capacity = (size) ? (size * unit) : unit;
  if (capacity != fit_capacity)
  {
    void *data = vector->data;
    data = realloc(data, fit_capacity);
    if (data)
    {
      vector->data = data;
      vector->capacity = fit_capacity;
    }
  }
}

void Mary_Vector_Insert(Mary_Vector_t *v, size_t index, void *in_elem)
{
  size_t unit = v->unit;
  size_t size = v->size;
  size_t new_size = size + 1;
  if (new_size * unit > v->capacity)
  {
    Mary_Vector_Reserve(v, (size_t)(size * GROWTH_RATE + 1));
  }
  u8 *p = (u8 *)v->data + index * unit;
  memmove(p + unit, p, (size - index) * unit);
  memcpy(p, in_elem, unit);
  v->size = new_size;
}

void Mary_Vector_Eject(Mary_Vector_t *vector, size_t index, void *out_elem)
{
  size_t unit = vector->unit;
  size_t size = vector->size - 1;
  void *data = vector->data;
  u8 *p = (u8 *)data + (index * unit);
  memmove(out_elem, p, unit);
  for (; index < size; ++index, p += unit)
  {
    memmove(p, p + unit, unit);
  }
  vector->size = size;
}

void Mary_Vector_Assign(Mary_Vector_t *vector, size_t index, void *in_elem)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  u8 *p = (u8 *)data + (index * unit);
  memmove(p, in_elem, unit);
}

void Mary_Vector_Exchange(Mary_Vector_t *vector, size_t index, void *in_elem, void *out_elem)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  u8 *p = (u8 *)data + (index * unit);
  memmove(out_elem, p, unit);
  memmove(p, in_elem, unit);
}

void Mary_Vector_Add_Slice(Mary_Vector_t *vector, size_t from, size_t to_exclusive)
{
  size_t capacity = vector->capacity;
  size_t unit = vector->unit;
  size_t old_size = vector->size;
  size_t slice_size = to_exclusive - from;
  size_t new_size = old_size + slice_size;
  if (new_size * unit > capacity)
  {
    Mary_Vector_Reserve(vector, (size_t)(old_size * GROWTH_RATE + 1));
  }
  void *data = vector->data;
  u8 *p_0 = (u8 *)data;
  u8 *p_from = p_0 + from * unit;
  u8 *p_to = p_0 + to_exclusive * unit;
  memmove(p_to, p_from, (old_size - from) * unit);
  vector->size = new_size;
}

void Mary_Vector_Delete_Slice(Mary_Vector_t *vector, size_t from, size_t to_exclusive)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  size_t size = vector->size;
  u8 *p_0 = (u8 *)data;
  u8 *p_from = p_0 + from * unit;
  u8 *p_to = p_0 + to_exclusive * unit;
  memmove(p_from, p_to, (size - to_exclusive) * unit);
  vector->size = size - (to_exclusive - from);
}

void Mary_Vector_Copy_Slice(Mary_Vector_t *vector, size_t from, size_t to_exclusive, void *out_elems)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  u8 *p_0 = (u8 *)data;
  u8 *p_from = p_0 + from * unit;
  u8 *p_to = p_0 + to_exclusive * unit;
  memmove(out_elems, p_from, (to_exclusive - from) * unit);
}

void Mary_Vector_Take_Slice(Mary_Vector_t *vector, size_t from, size_t to_exclusive, void *out_elems)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  size_t size = vector->size;
  u8 *p_0 = (u8 *)data;
  u8 *p_from = p_0 + from * unit;
  u8 *p_to = p_0 + to_exclusive * unit;
  memmove(out_elems, p_from, (to_exclusive - from) * unit);
  memmove(p_from, p_to, (size - to_exclusive) * unit);
  vector->size = size - (to_exclusive - from);
}

void Mary_Vector_Push_Back(Mary_Vector_t *v, void *in_elem)
{
  size_t unit = v->unit;
  size_t size = v->size;
  size_t new_size = size + 1;
  if (new_size * unit > v->capacity)
  {
    Mary_Vector_Reserve(v, (size_t)(size * GROWTH_RATE + 1));
  }
  memcpy((u8 *)v->data + size * unit, in_elem, unit);
  v->size = new_size;
}

void Mary_Vector_Push_Front(Mary_Vector_t *vector, void *in_elem)
{
  Mary_Vector_Insert(vector, 0, in_elem);
}

void Mary_Vector_Pop_Back(Mary_Vector_t *vector, void *out_elem)
{
  size_t size = vector->size;
  Mary_Vector_Eject(vector, (size) ? size - 1 : 0, out_elem);
}

void Mary_Vector_Pop_Front(Mary_Vector_t *vector, void *out_elem)
{
  Mary_Vector_Eject(vector, 0, out_elem);
}

void Mary_Vector_At(Mary_Vector_t *vector, size_t index, void *out_elem)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  u8 *p = (u8 *)data + (index * unit);
  memmove(out_elem, p, unit);
}

char Mary_Vector_Has_At(Mary_Vector_t *vector, size_t index)
{
  return index < vector->size;
}

void Mary_Vector_Point(Mary_Vector_t *vector, size_t index, void **out_pointer)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  u8 *p = (u8 *)data + index * unit;
  memcpy(out_pointer, &p, sizeof(void *));
}

void Mary_Vector_Back(Mary_Vector_t *vector, void *out_elem)
{
  size_t size = vector->size;
  Mary_Vector_At(vector, (size) ? size - 1 : 0, out_elem);
}

void Mary_Vector_Front(Mary_Vector_t *vector, void *out_elem)
{
  Mary_Vector_At(vector, 0, out_elem);
}

void Mary_Vector_Empty(Mary_Vector_t *vector, size_t opt_reserve)
{
  size_t unit = vector->unit;
  Mary_Vector_Destroy(vector);
  Mary_Vector_Create(vector, unit, opt_reserve);
}

char Mary_Vector_Is_Empty(Mary_Vector_t *vector)
{
  return vector->size != 0;
}

void Mary_Vector_Resize(Mary_Vector_t *vector, size_t size)
{
  vector->size = size;
  Mary_Vector_Fit(vector);
}

void Mary_Vector_Fill(Mary_Vector_t *vector, void *in_elem)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  size_t size = vector->size;
  u8 *p = (u8 *)data;
  for (size_t i = 0; i < size; ++i, p += unit)
  {
    memmove(p, in_elem, unit);
  }
}

void Mary_Vector_Rotate(Mary_Vector_t *vector, void *out_elem)
{
  size_t size = vector->size;
  if (size > 1)
  {
    void *data = vector->data;
    size_t unit = vector->unit;
    size_t i = size - 1;
    u8 *first = (u8 *)data;
    u8 *last = first + (i * unit);
    memmove(out_elem, last, unit);
    for (; i > 0; --i, last -= unit)
    {
      memmove(last, last - unit, unit);
    }
    memmove(first, out_elem, unit);
  }
}

void Mary_Vector_Reverse(Mary_Vector_t *vector)
{
  size_t size = vector->size;
  if (size > 1)
  {
    size_t unit = vector->unit;
    u8 *temp = malloc(unit);
    if (temp)
    {
      void *data = vector->data;
      size_t a = 0, b = size - 1;
      u8 *pA = (u8 *)data;
      u8 *pB = pA + (b * unit);
      for (; a < b; ++a, --b, pA += unit, pB -= unit)
      {
        memcpy(temp, pA, unit);
        memmove(pA, pB, unit);
        memcpy(pB, temp, unit);
      }
      free(temp);
    }
  }
}

char Mary_Vector_Contains(Mary_Vector_t *vector, void *elem)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  size_t size = vector->size;
  u8 *p = (u8 *)data;
  for (size_t i = 0; i < size; ++i, p += unit)
  {
    if (memcmp(p, elem, unit) == 0)
    {
      return 1;
    }
  }
  return 0;
}

size_t Mary_Vector_Index_Of(Mary_Vector_t *vector, void *elem, char *out_was_found)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  size_t size = vector->size;
  u8 *p = (u8 *)data;
  size_t i = 0; char was_found;
  for (; i < size; ++i, p += unit)
  {
    if (memcmp(p, elem, unit) == 0)
    {
      was_found = 1;
      memmove(out_was_found, &was_found, sizeof(char));
      return i;
    }
  }
  was_found = 0;
  memmove(out_was_found, &was_found, sizeof(char));
  return i;
}

void Mary_Vector_Erase_At(Mary_Vector_t *vector, size_t index)
{
  // optimize
  size_t unit = vector->unit;
  size_t size = vector->size - 1;
  void *data = vector->data;
  u8 *p = (u8 *)data + (index * unit);
  for (; index < size; ++index, p += unit)
  {
    memmove(p, p + unit, unit);
  }
  vector->size = size;
}

void Mary_Vector_Erase(Mary_Vector_t *vector, void *elem)
{
  char was_found = 0;
  size_t index = Mary_Vector_Index_Of(vector, elem, &was_found);
  if (was_found)
  {
    Mary_Vector_Erase_At(vector, index);
  }
}

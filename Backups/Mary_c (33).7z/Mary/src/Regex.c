#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <Mary/Utils.h>
#include <Mary/Regex.h>

MARY_PRIMITIVES;

#define STATE_MATCH 0xFFFFFFFF
#define STATE_SPLIT 0xF0000000

typedef struct
{
  u32 flag; // 0x0 - 0x10FFFF for unicode
  void *out_a; // State *
  void *out_b; // State *
}
State;

typedef struct
{
  State *in;
  Mary_Pointer_t outs; // [State **...]
}
Fragment;

void Mary_Regex_Create(Mary_Regex_t *mary_regex, char bit_format, void *expression)
{
  if (bit_format == 8)
  {
    Mary_Regex_8bit_Create(mary_regex, expression);
  }
}

void Mary_Regex_8bit_Create(Mary_Regex_t *mary_regex, uint8_t *expression)
{
  // can check codes on string_t to see if it's above 64.
  Mary_Pool_Create(&mary_regex->pool, 64 * sizeof(u32) + 64 * sizeof(State));
  void *data_expression = Mary_Pool_Allocate(&mary_regex->pool, 256);
  Mary_Pointer_t ptr_expression = { data_expression, 256 };
  Mary_String_Create_With(&mary_regex->expression, 8, expression, 0, ptr_expression);
  Mary_String_8bit_to_32bit(&mary_regex->expression);
  Mary_Regex_Compile(mary_regex);
  Mary_String_32bit_to_16bit(&mary_regex->expression); // maybe back to 8bit?
}

void Mary_Regex_Destroy(Mary_Regex_t *mary_regex)
{
  Mary_Pool_Destroy(&mary_regex->pool);
}

void Mary_Regex_Compile(Mary_Regex_t *mary_regex)
{
  Mary_Vector_t v_input; u32 a_input[64];
  Mary_Pointer_t p_input = { a_input, 256 };
  Mary_Vector_Create_With(&v_input, 4, p_input);

  Mary_Vector_t v_stack; u32 a_stack[64];
  Mary_Pointer_t p_stack = { a_stack, 256 };
  Mary_Vector_Create_With(&v_stack, 4, p_stack);

  Mary_Vector_t v_output; Fragment a_output[64];
  Mary_Pointer_t p_output = { a_output, 64 * sizeof(Fragment) };
  Mary_Vector_Create_With(&v_output, sizeof(Fragment), p_output);

  Mary_Vector_t v_no_concat_curr; u32 a_no_concat_curr[3] = { '(', '|', '\0' };
  Mary_Pointer_t p_no_concat_curr = { a_no_concat_curr, 3 * 4 };
  Mary_Vector_Create_With(&v_no_concat_curr, 4, p_no_concat_curr);
  v_no_concat_curr.size = 3;

  Mary_Vector_t v_no_concat_next; u32 a_no_concat_next[6] = { '*', '+', '?', ')', '|', '\0' };
  Mary_Pointer_t p_no_concat_next = { a_no_concat_next, 6 * 4 };
  Mary_Vector_Create_With(&v_no_concat_next, 4, p_no_concat_next);
  v_no_concat_next.size = 6;

  Mary_Pool_t pool_compiler;
  Mary_Pool_Create(&pool_compiler, 1024);

  u32 concat_symbol = '&', top;
  Fragment frag, frag_a, frag_b;
  State **ppState;

  MARY_Range(mary_regex->expression.data, u32, 0, mary_regex->expression.size)
  {
    // should do validation in here as well.
    Mary_Vector_Push_Back(&v_input, range.ptr);
    if (!Mary_Vector_Contains(&v_no_concat_curr, range.ptr))
    {
      u32 *next = range.ptr + 1;
      if (!Mary_Vector_Contains(&v_no_concat_next, next))
      {
        Mary_Vector_Push_Back(&v_input, &concat_symbol);
      }
    }
  }

  #define IN_CREATE(IN, FLAG, OUT_PTR_A, OUT_PTR_B)                                                \
  {                                                                                                \
    (IN) = Mary_Pool_Allocate(&mary_regex->pool, sizeof(State));                                   \
    (IN)->flag = (FLAG);                                                                           \
    (IN)->out_a = (OUT_PTR_A);                                                                     \
    (IN)->out_b = (OUT_PTR_B);                                                                     \
  }

  #define OUTS_CREATE(OUTS, OUT_PTR)                                                               \
  {                                                                                                \
    (OUTS).bytes = sizeof(State **);                                                               \
    (OUTS).data = Mary_Pool_Allocate(&pool_compiler, (OUTS).bytes);                                \
    ppState = &(State *)(OUT_PTR);                                                                 \
    memcpy((OUTS).data, &ppState, (OUTS).bytes);                                                   \
  }

  #define OUTS_CONCAT(OUTS, OUTS_A, OUTS_B)                                                        \
  {                                                                                                \
    (OUTS).bytes = (OUTS_A).bytes + (OUTS_B).bytes;                                                \
    (OUTS).data = Mary_Pool_Allocate(&pool_compiler, (OUTS).bytes);                                \
    memcpy((OUTS).data, (OUTS_A).data, (OUTS_A).bytes);                                            \
    memcpy((u8 *)(OUTS).data + (OUTS_A).bytes, (OUTS_B).data, (OUTS_B).bytes);                     \
  }

  #define OUTS_PATCH(OUTS, IN)                                                                     \
  {                                                                                                \
    MARY_Range((OUTS).data, State **, 0, (OUTS).bytes / sizeof(State **)) *range.val = IN;         \
  }

  #define OUTS_DELETE(OUTS)                                                                        \
  {                                                                                                \
    Mary_Pool_Deallocate(&pool_compiler, (OUTS).data);                                             \
  }

  #define EVAL_CHAR                                                                                \
  {                                                                                                \
    IN_CREATE(frag.in, range.val, 0, 0);                                                           \
    OUTS_CREATE(frag.outs, frag.in->out_a);                                                        \
    Mary_Vector_Push_Back(&v_output, &frag);                                                       \
  }

  #define EVAL_OR                                                                                  \
  {                                                                                                \
    Mary_Vector_Pop_Back(&v_output, &frag_b);                                                      \
    Mary_Vector_Pop_Back(&v_output, &frag_a);                                                      \
    IN_CREATE(frag.in, STATE_SPLIT, frag_a.in, frag_b.in);                                         \
    OUTS_CONCAT(frag.outs, frag_a.outs, frag_b.outs);                                              \
    OUTS_DELETE(frag_a.outs);                                                                      \
    OUTS_DELETE(frag_b.outs);                                                                      \
    Mary_Vector_Push_Back(&v_output, &frag);                                                       \
  }

  #define EVAL_AND                                                                                 \
  {                                                                                                \
    Mary_Vector_Pop_Back(&v_output, &frag_b);                                                      \
    Mary_Vector_Pop_Back(&v_output, &frag_a);                                                      \
    frag.in = frag_a.in;                                                                           \
    frag.outs = frag_b.outs;                                                                       \
    OUTS_PATCH(frag_a.outs, frag_b.in);                                                            \
    Mary_Vector_Push_Back(&v_output, &frag);                                                       \
  }

  #define EVAL_QUES                                                                                \
  {                                                                                                \
    Mary_Vector_Pop_Back(&v_output, &frag_a);                                                      \
    IN_CREATE(frag.in, STATE_SPLIT, frag_a.in, 0);                                                 \
    ppState = &(State *)frag.in->out_b;                                                            \
    frag_b.outs.data = &ppState;                                                                   \
    frag_b.outs.bytes = sizeof(State **);                                                          \
    OUTS_CONCAT(frag.outs, frag_a.outs, frag_b.outs);                                              \
    OUTS_DELETE(frag_a.outs);                                                                      \
    Mary_Vector_Push_Back(&v_output, &frag);                                                       \
  }

  #define EVAL_STAR                                                                                \
  {                                                                                                \
    Mary_Vector_Pop_Back(&v_output, &frag_a);                                                      \
    IN_CREATE(frag.in, STATE_SPLIT, frag_a.in, 0);                                                 \
    OUTS_PATCH(frag_a.outs, frag.in);                                                              \
    OUTS_DELETE(frag_a.outs);                                                                      \
    OUTS_CREATE(frag.outs, frag.in->out_b);                                                        \
    Mary_Vector_Push_Back(&v_output, &frag);                                                       \
  }

  #define EVAL_PLUS                                                                                \
  {                                                                                                \
    Mary_Vector_Pop_Back(&v_output, &frag_a);                                                      \
    IN_CREATE(frag.in, STATE_SPLIT, frag_a.in, 0);                                                 \
    OUTS_PATCH(frag_a.outs, frag.in);                                                              \
    OUTS_DELETE(frag_a.outs);                                                                      \
    OUTS_CREATE(frag.outs, frag.in->out_b);                                                        \
    frag.in = frag_a.in;                                                                           \
    Mary_Vector_Push_Back(&v_output, &frag);                                                       \
  }

  #define EVAL_MATCH                                                                               \
  {                                                                                                \
    Mary_Vector_Pop_Back(&v_output, &frag_a);                                                      \
    IN_CREATE(frag.in, STATE_MATCH, 0, 0);                                                         \
    OUTS_PATCH(frag_a.outs, frag.in);                                                              \
    mary_regex->machine = frag_a.in;                                                               \
  }

  #define EVAL_WHILE(CONDITION)                                                                    \
  {                                                                                                \
    if (v_stack.size)                                                                              \
    {                                                                                              \
      Mary_Vector_At(&v_stack, v_stack.size - 1, &top);                                            \
      while ((CONDITION))                                                                          \
      {                                                                                            \
        if (top == '+') EVAL_PLUS                                                                  \
        else if (top == '*') EVAL_STAR                                                             \
        else if (top == '?') EVAL_QUES                                                             \
        else if (top == '&') EVAL_AND                                                              \
        else if (top == '|') EVAL_OR;                                                              \
        if (--v_stack.size == 0) break;                                                            \
        else Mary_Vector_At(&v_stack, v_stack.size - 1, &top);                                     \
      }                                                                                            \
    }                                                                                              \
  }

  MARY_Range(v_input.data, u32, 0, v_input.size)
  {
    // precedence 1: +, *, ? 2: () 3: & 4: |
    if (range.val == 0)
    {
      EVAL_WHILE(v_stack.size != 0);
      EVAL_MATCH; break;
    }
    else if (range.val == '+' || range.val == '*' || range.val == '?')
    {
      EVAL_WHILE(top == '+' || top == '*' || top == '?');
      Mary_Vector_Push_Back(&v_stack, range.ptr);
    }
    else if (range.val == '(')
    {
      EVAL_WHILE(top == '+' || top == '*' || top == '?');
      Mary_Vector_Push_Back(&v_stack, range.ptr);
    }
    else if (range.val == ')')
    {
      EVAL_WHILE(top != '(');
      --v_stack.size; // pop '('
    }
    else if (range.val == '&')
    {
      EVAL_WHILE(top == '+' || top == '*' || top == '?' || top == '&');
      Mary_Vector_Push_Back(&v_stack, range.ptr);
    }
    else if (range.val == '|')
    {
      EVAL_WHILE(top == '+' || top == '*' || top == '?' || top == '&' || top == '|');
      Mary_Vector_Push_Back(&v_stack, range.ptr);
    }
    else
    {
      EVAL_CHAR
    }
  }

  #undef IN_CREATE
  #undef OUTS_CREATE
  #undef OUTS_CONCAT
  #undef OUTS_PATCH
  #undef OUTS_DELETE
  #undef EVAL_CHAR
  #undef EVAL_OR
  #undef EVAL_AND
  #undef EVAL_QUES
  #undef EVAL_STAR
  #undef EVAL_PLUS
  #undef EVAL_MATCH
  #undef EVAL_WHILE

  Mary_Pool_Destroy(&pool_compiler);
}

void Mary_Regex_Execute(Mary_Regex_t *mary_regex, char bit_format, void *string)
{
  if (bit_format == 8)
  {
    Mary_Regex_8bit_Execute(mary_regex, string);
  }
}

void Mary_Regex_8bit_Execute(Mary_Regex_t *mary_regex, uint8_t *string)
{
  Mary_String_t s_subject; // convert to 32bits to match against.
}

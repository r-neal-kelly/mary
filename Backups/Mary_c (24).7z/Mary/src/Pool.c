#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <Mary/Utils.h>
#include <Mary/Bitbool.h>
#include <Mary/Pool.h>

MARY_PRIMITIVES;

void Mary_Pool_Create(Mary_Pool_t *pool, size_t bytes)
{
  MARY_Assert(bytes >= 0);
  u64 size_8bit_data = bytes + 7 & -8;
  u64 size_8bit_index = (size_8bit_data + 63 & -64) >> 6;
  u8 *p = malloc(size_8bit_data + size_8bit_index);
  u8 *data = p, *index = p + size_8bit_data;
  if (p)
  {
    pool->data = data;
    pool->index = index;
    pool->size_data = size_8bit_data;
    pool->size_index = size_8bit_index;
    memset(index, 0, size_8bit_index);
  }
  else
  {
    Mary_Exit_Failure("out of memory");
  }
}

void Mary_Pool_Destroy(Mary_Pool_t *pool)
{
  free(pool->data);
}

void *Mary_Pool_Allocate(Mary_Pool_t *pool, size_t bytes)
{
  u64 size_8bit_data = pool->size_data;
  u64 size_1bit_index = size_8bit_data >> 3;
  u64 size_8bit_alloc = bytes + 7 & -8;
  u64 size_64bit_alloc = size_8bit_alloc >> 3;
  u8 *index = pool->index, *ptr_byte, val_byte;
  u64 bit_from = 0, bit_to_exclusive = 0;
  for (u64 i = 0, bit, need_from = 1, free_size; i < size_1bit_index;)
  {
    ptr_byte = index + i / 8; val_byte = *ptr_byte;
    if (need_from)
    {
      if (val_byte == 0xFF)
      {
        if (i + 63 < size_1bit_index && *(u64 *)ptr_byte == 0xFFFFFFFFFFFFFFFF)
        {
          i = i + 64 & -64; continue;
        }
        else if (i + 31 < size_1bit_index && *(u32 *)ptr_byte == 0xFFFFFFFF)
        {
          i = i + 32 & -32; continue;
        }
        else if (i + 15 < size_1bit_index && *(u16 *)ptr_byte == 0xFFFF)
        {
          i = i + 16 & -16; continue;
        }
        else
        {
          i = i + 8 & -8; continue;
        }
      }
      else
      {
        bit = val_byte & 1 << i % 8;
        if (bit == 0)
        {
          need_from = 0, bit_from = i, free_size = 1;
        }
        ++i; continue;
      }
    }
    else
    {
      // we can also check to see if there is enough free space quicker, like above for used space
      bit = val_byte & 1 << i % 8;
      if (bit == 0)
      {
        if (++free_size == size_64bit_alloc)
        {
          bit_to_exclusive = i + 1; break;
        }
      }
      else
      {
        need_from = 1;
      }
      ++i; continue;
    }
  }
  if (bit_to_exclusive)
  {
    u8 *byte;
    for (u64 i = bit_from; i < bit_to_exclusive; ++i)
    {
      byte = index + i / 8;
      memset(byte, *byte | 1 << i % 8, 1);
    }
    return (u8 *)pool->data + (bit_from << 3);
  }
  else
  {
    Mary_Exit_Failure("out of memory");
    return 0;
  }
}

void Mary_Pool_Deallocate(Mary_Pool_t *pool, void *ptr, size_t bytes)
{
  u64 size_8bit_alloc = bytes + 7 & -8;
  u64 size_64bit_alloc = size_8bit_alloc >> 3;
  u64 bit_from = ((u64)ptr - (u64)pool->data) >> 3;
  u64 bit_to_exclusive = bit_from + size_64bit_alloc;
  u8 *index = pool->index, *byte;
  for (u64 i = bit_from; i < bit_to_exclusive; ++i)
  {
    byte = index + i / 8;
    memset(byte, *byte & ~(1 << i % 8), 1);
  }
}

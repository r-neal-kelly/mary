#pragma once

#include <stdint.h>
#include <Mary/OS.h>
#include <Mary/OpenGL.h>
#include <Mary/Hashmap.h>
#include <Mary/Element.h>

struct Mary_Window_t
{
  MARY_Element_t;
  Mary_OS_Window_t os;
  uint64_t is_dirty;
  Mary_Matrix_4x4f projection;
  Mary_Element_t *active;
};

void Mary_Window_Start();
void Mary_Window_Finish();
char Mary_Window_Can_Render();
void Mary_Window_Render_All();
void Mary_Window_Create(Mary_Window_t *mary_window);
void Mary_Window_Destroy(Mary_Window_t *mary_window);
void Mary_Window_Render(void *mary_window);
void Mary_Window_Flag_Dirty(Mary_Window_t *mary_window);
//void Mary_Window_Close(Mary_Window_t *mary_window);
void Mary_Window_Show(Mary_Window_t *mary_window);
void Mary_Window_Hide(Mary_Window_t *mary_window);
void Mary_Window_Activate_Element(Mary_Window_t *mary_window, void *mary_element);
void Mary_Window_Back_Color(Mary_Window_t *mary_window, float r, float g, float b, float a);

#define MARY_Window(VOID_PTR) ((Mary_Window_t *)(VOID_PTR))

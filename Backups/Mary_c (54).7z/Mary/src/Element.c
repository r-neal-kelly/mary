#include <string.h>
#include <Mary/Element.h>
#include <Mary/Window.h>
#include <Mary/Div.h>
#include <Mary/Text.h>

MARY_PRIMITIVES;

typedef void (*Render_f)(void *);

Mary_Hashmap_t type_sizes; // these can just be a vector of structs!!! our type can be the index.
Mary_Hashmap_t render_funcs;
// instead of having multiple hashmaps, better make a generic object.
// it should have the size of the type, the render func, and other funcs too.
// I want to call Mary_Element_Back_Color on a window and have it just do this extra stuff.
// if an element doesn't have that extra feature, then it should be set to zero.
// there could be problems though, since they will have to be public pointers. Recursive probs.
// this might be getting too close to object oriented.

void Mary_Element_Start()
{
  #define ASSIGN_TYPE_SIZE(TYPE, TYPE_NAME)\
    type = TYPE, size = sizeof(TYPE_NAME), Mary_Hashmap_Assign(&type_sizes, &type, &size)

  #define ASSIGN_RENDER_FUNC(TYPE, RENDER_FUNC)\
    type = TYPE, Render = RENDER_FUNC, Mary_Hashmap_Assign(&render_funcs, &type, &Render)

  size_t type, size;
  Mary_Hashmap_Create(&type_sizes, sizeof(size_t), sizeof(size_t));
  ASSIGN_TYPE_SIZE(MARY_ELEMENT_WINDOW, Mary_Window_t);
  ASSIGN_TYPE_SIZE(MARY_ELEMENT_DIV, Mary_Div_t);
  ASSIGN_TYPE_SIZE(MARY_ELEMENT_TEXT, Mary_Text_t);

  Render_f Render;
  Mary_Hashmap_Create(&render_funcs, sizeof(size_t), sizeof(Render_f));
  ASSIGN_RENDER_FUNC(MARY_ELEMENT_WINDOW, Mary_Window_Render);
  ASSIGN_RENDER_FUNC(MARY_ELEMENT_DIV, Mary_Div_Render);
  ASSIGN_RENDER_FUNC(MARY_ELEMENT_TEXT, Mary_Text_Render);

  #undef ASSIGN_TYPE_SIZE
  #undef ASSIGN_RENDER_FUNC
}

void Mary_Element_Finish()
{
  Mary_Hashmap_Destroy(&type_sizes);
  Mary_Hashmap_Destroy(&render_funcs);
}

void Mary_Element_Create(void *mary_element, size_t type)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  size_t type_size; Mary_Hashmap_At(&type_sizes, &type, &type_size);
  memset(element, 0, type_size);
  element->type = type;
  if (type == MARY_ELEMENT_WINDOW) element->window = MARY_Window(element);
  Mary_Vector_Create(&element->children_s, sizeof(Mary_Element_t *), 0);
  Mary_Vector_Create(&element->children_z, sizeof(Mary_Element_t *), 0);
  Mary_Vector_Create(&element->events, sizeof(Mary_Event_t *), 0);
  Mary_Hashmap_Create(&element->listeners, sizeof(Mary_Element_t *), sizeof(u64));
  element->display = MARY_ELEMENT_DISPLAY_LINE;
  element->unit_w = MARY_ELEMENT_UNIT_FIT_PARENT;
  element->unit_h = MARY_ELEMENT_UNIT_FIT_CHILDREN;
  element->back_a = 1, element->fore_a = 1, element->border_a = 1;
}

void Mary_Element_Destroy(void *mary_element)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  size_t type_size; Mary_Hashmap_At(&type_sizes, &element->type, &type_size);
  Mary_Vector_Destroy(&element->children_s);
  Mary_Vector_Destroy(&element->children_z);
  Mary_Vector_Destroy(&element->events);
  Mary_Hashmap_Destroy(&element->listeners);
  memset(element, 0, type_size); // may just want to memset the element size here?
}

typedef struct { float width, height; } Size; // I think we have this in utils. but it's not official yet.

static Size Compute_Children(Mary_Element_t *parent)
{
  Mary_Element_t *width_parent = parent;
  float margin_l = 0.0f, margin_r = 0.0f;
  float padding_l = parent->padding_l, padding_r = parent->padding_r;
  Mary_Element_t *height_parent = parent;
  float margin_t = 0.0f, margin_b = 0.0f;
  float padding_t = parent->padding_t, padding_b = parent->padding_b;

  while (width_parent->type != MARY_ELEMENT_WINDOW && width_parent->unit_w == MARY_ELEMENT_UNIT_FIT_CHILDREN)
  {
    margin_l += width_parent->margin_l, margin_r += width_parent->margin_r;
    width_parent = width_parent->parent;
    padding_l += width_parent->padding_l, padding_r += width_parent->padding_r;
  }
  while (height_parent->type != MARY_ELEMENT_WINDOW && height_parent->unit_h == MARY_ELEMENT_UNIT_FIT_CHILDREN)
  {
    margin_t += height_parent->margin_t, margin_b += height_parent->margin_b;
    height_parent = height_parent->parent;
    padding_t += height_parent->padding_t, padding_b += height_parent->padding_b;
  }

  float left = width_parent->x1 + margin_l + padding_l;
  float right = width_parent->x2 - margin_r - padding_r;
  float top = height_parent->y1 + margin_t + padding_t;
  float bottom = height_parent->y2 - margin_b - padding_b;

  MARY_Vector_Each(&parent->children_s, Mary_Element_t *)
  {
    Mary_Element_t *child = range.val;

    if (child->display == MARY_ELEMENT_DISPLAY_NONE)
    {
      continue;
    }

    if (child->unit_w == MARY_ELEMENT_UNIT_FIT_PARENT)
    {
      child->x1 = left + child->margin_l;
      child->x2 = right - child->margin_r;
      left += child->margin_l + child->x2 - child->x1 + child->margin_r;
      Compute_Children(child);
    }
    else if (child->unit_w == MARY_ELEMENT_UNIT_FIT_CHILDREN)
    {
      float width = Compute_Children(child).width;
      child->x1 = left + child->margin_l;
      child->x2 = child->x1 + child->padding_l + width + child->padding_r;
      left += child->margin_l + width + child->margin_r;
    }
    else if (child->unit_w == MARY_ELEMENT_UNIT_PIXEL)
    {
      child->x1 = left + child->margin_l;
      child->x2 = child->x1 + child->w;
      left += child->margin_l + child->w + child->margin_r;
      Compute_Children(child);
    }
    else if (child->unit_w == MARY_ELEMENT_UNIT_PERCENT)
    {

    }

    if (child->unit_h == MARY_ELEMENT_UNIT_FIT_PARENT)
    {
      child->y1 = top + child->margin_t;
      child->y2 = bottom - child->margin_b;
      Compute_Children(child);
    }
    else if (child->unit_h == MARY_ELEMENT_UNIT_FIT_CHILDREN)
    {
      float height = Compute_Children(child).height;
      child->y1 = top + child->margin_t;
      child->y2 = child->y1  + child->padding_t + height + child->padding_b;
    }
    else if (child->unit_h == MARY_ELEMENT_UNIT_PIXEL)
    {
      child->y1 = top + child->margin_t;
      child->y2 = child->y1 + child->h;
      Compute_Children(child);
    }
    else if (child->unit_h == MARY_ELEMENT_UNIT_PERCENT)
    {

    }

    if (child->display == MARY_ELEMENT_DISPLAY_LINE)
    {
      left = width_parent->x1 + margin_l + padding_l;
      top = child->y2 + child->margin_b;
    }
    else if (child->display == MARY_ELEMENT_DISPLAY_INLINE_LOOSE)
    {
      if (child->x2 > right)
      {
        left = width_parent->x1 + margin_l + padding_l;
        top += 0; // this needs to increase by the largest child's height? not sure...
        MARY_Range_Regress(1);
      }
    }
  }

  return (Size) { left - margin_l - padding_l, top - margin_t - padding_t };
}

static void Render_Children(Mary_Element_t *parent)
{
  Render_f Render;
  MARY_Vector_Each(&parent->children_z, Mary_Element_t *)
  {
    Mary_Hashmap_At(&render_funcs, &range.val->type, &Render);
    Render(range.val);
    Render_Children(range.val);
  }
}

void Mary_Element_Compute_Children(Mary_Window_t *window)
{
  // this allows for the Window_t contraint and also
  // for quicker recursion, it doesn't have to cast each time.
  Compute_Children(MARY_Element(window));
}

void Mary_Element_Render_Children(Mary_Window_t *window)
{
  Render_Children(MARY_Element(window));
}

static void Mary_Element_Window(Mary_Element_t *element, Mary_Window_t *window)
{
  element->window = window;
  MARY_Vector_Each(&element->children_s, Mary_Element_t *)
  {
    Mary_Element_Window(range.val, window);
  }
}

void Mary_Element_Append_To(void *mary_element, void *mary_element_parent)
{
  #define LAST_CHILD_Z(PARENT_PTR)\
    (*(Mary_Element_t **)Mary_Vector_Point(&PARENT_PTR->children_z, PARENT_PTR->children_z.units - 1))

  Mary_Element_t *element = MARY_Element(mary_element);
  Mary_Element_t *parent = MARY_Element(mary_element_parent);

  ////// remove from old parent
  if (element->parent != 0)
  {
    MARY_Vector_Each(&element->parent->children_s, Mary_Element_t *)
    {
      if (range.val == element)
      {
        Mary_Vector_Erase_At(&element->parent->children_s, range.idx); break;
      }
    }
    MARY_Vector_Each(&element->parent->children_z, Mary_Element_t *)
    {
      if (range.val == element)
      {
        Mary_Vector_Erase_At(&element->parent->children_z, range.idx); break;
      }
    }
    Mary_Window_Flag_Dirty(element->window);
  }

  ////// add to new parent
  Mary_Vector_Push_Back(&parent->children_s, &element);
  if (parent->children_z.units == 0)
  {
    Mary_Vector_Push_Back(&parent->children_z, &element);
  }
  else if (LAST_CHILD_Z(parent)->z <= element->z)
  {
    Mary_Vector_Push_Back(&parent->children_z, &element);
  }
  else
  {
    MARY_Vector_Each(&parent->children_z, Mary_Element_t *)
    {
      if (range.val->z > element->z)
      {
        Mary_Vector_Push_At(&parent->children_z, range.idx, &element);
      }
    }
  }
  Mary_Element_Window(element, parent->window);
  Mary_Window_Flag_Dirty(element->window);
  element->parent = parent;

  #undef LAST_CHILD_Z
}

void Mary_Element_Remove(void *mary_element)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  if (element->parent != 0)
  {
    MARY_Vector_Each(&element->parent->children_s, Mary_Element_t *)
    {
      if (range.val == element)
      {
        Mary_Vector_Erase_At(&element->parent->children_s, range.idx); break;
      }
    }
    MARY_Vector_Each(&element->parent->children_z, Mary_Element_t *)
    {
      if (range.val == element)
      {
        Mary_Vector_Erase_At(&element->parent->children_z, range.idx); break;
      }
    }
    Mary_Window_Flag_Dirty(element->window);
    Mary_Element_Window(element, 0);
    element->parent = 0;
  }
}

void Mary_Element_Position(void *mary_element, float x, float y, int z)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  element->x = x, element->y = y, element->z = z;
}

void Mary_Element_Size(void *mary_element, float w, float h)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  element->w = w, element->h = h;
}

void Mary_Element_Unit_Size(void *mary_element, int unit_w, int unit_h)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  element->unit_w = unit_w, element->unit_h = unit_h;
  // we shouldn't allow this to change window_t...
  // makes me think we should have these funcs in each of their own types...
}

void Mary_Element_Back_Color(void *mary_element, float r, float g, float b, float a)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  element->back_r = r, element->back_g = g, element->back_b = b, element->back_a = a;
}

void Mary_Element_Fore_Color(void *mary_element, float r, float g, float b, float a)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  element->fore_r = r, element->fore_g = g, element->fore_b = b, element->fore_a = a;
}

void Mary_Element_Border_Color(void *mary_element, float r, float g, float b, float a)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  element->border_r = r, element->border_g = g, element->border_b = b, element->border_a = a;
}

void Mary_Element_Margin(void *mary_element, float l, float t, float r, float b)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  element->margin_l = l, element->margin_t = t, element->margin_r = r, element->margin_b = b;
}

void Mary_Element_Padding(void *mary_element, float l, float t, float r, float b)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  element->padding_l = l, element->padding_t = t, element->padding_r = r, element->padding_b = b;
}

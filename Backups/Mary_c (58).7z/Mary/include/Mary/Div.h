#pragma once

#include <Mary/Element.h>

struct Mary_Div_t
{
  MARY_Element_t;
};

void Mary_Div_Start();
void Mary_Div_Finish();
void Mary_Div_Create(Mary_Div_t *mary_div);
void Mary_Div_Destroy(Mary_Div_t *mary_div);
void Mary_Div_Render(void *mary_div);

#define MARY_Div(VOID_PTR) ((Mary_Div_t *)(VOID_PTR))

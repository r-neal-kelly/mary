#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <Mary/Utils.h>
#include <Mary/Bitbool.h>
#include <Mary/Vector.h>
#include <Mary/String.h>
#include <Mary/Window.h>
#include <Mary/Text.h>

MARY_PRIMITIVES;

Mary_Vector_t windows_v;

enum WINDOW_FLAGS
{
  DIRTY,
  MAXIMIZED,
  MINIMIZED,
  SHOULD_CONFIRM_CLOSE
};

void Mary_Window_Start()
{
  Mary_Vector_Create(&windows_v, sizeof(Mary_Window_t *), 0);
}

void Mary_Window_Finish()
{
  Mary_Vector_Destroy(&windows_v);
}

char Mary_Window_Can_Render()
{
  return Mary_Vector_Is_Empty(&windows_v);
}

void Mary_Window_Render_All()
{
  Mary_Window_t *window = 0;
  MARY_Vector_Each(&windows_v, Mary_Window_t *)
  {
    Mary_Window_Render(range.val);
  }
  Mary_OS_Sleep(1);
}

void Mary_Window_Create(Mary_Window_t *window)
{
  Mary_Vector_Push_Back(&windows_v, &window);
  Mary_Element_Create(window, MARY_ELEMENT_WINDOW);
  Mary_Element_Unit_Size(window, MARY_ELEMENT_UNIT_PIXEL, MARY_ELEMENT_UNIT_PIXEL);
  Mary_OS_Window_Create(window);
  window->is_dirty = 1;
  Mary_Window_Show(window);
}

void Mary_Window_Destroy(Mary_Window_t *window)
{
  MARY_Vector_Each(&window->children_s, Mary_Element_t *)
  {
    Mary_Element_Remove(range.val);
  }
  Mary_Vector_Erase(&windows_v, &window);
  Mary_OS_Window_Destroy(window);
  Mary_Element_Destroy(window);
}

inline void Mary_Window_Show(Mary_Window_t *window)
{
  Mary_OS_Window_Show(window);
}

inline void Mary_Window_Hide(Mary_Window_t *window)
{
  Mary_OS_Window_Hide(window);
}

void Mary_Window_Render(void *mary_window)
{
  Mary_Window_t *window = MARY_Window(mary_window);
  Mary_OS_Window_Handle_Messages(window);
  if (window->is_dirty)
  {
    window->projection = Mary_OpenGL_Ortho(0.0f, window->w, window->h, 0.0f, 0.0f, 1.0f);
    Mary_OS_Window_Make_Current(window);
    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glViewport(0, 0, (u32)window->w, (u32)window->h);
    glEnable(GL_SCISSOR_TEST); glScissor(0, 0, (u32)window->w, (u32)window->h);
    glClearColor(window->back_r, window->back_g, window->back_b, window->back_a);
    glClear(GL_COLOR_BUFFER_BIT);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    Mary_Element_Compute_Children(window);
    Mary_Element_Render_Children(window);
    Mary_OS_Window_Swap_Buffers(window);
    window->is_dirty = 0;
    //printf("%i ", glGetError());
  }
}

void Mary_Window_Flag_Dirty(Mary_Window_t *window) // Mary_Window_Updata?
{
  window->is_dirty = 1;
}

void Mary_Window_Activate_Element(Mary_Window_t *window, void *mary_element)
{
  // prob will want to set render flag, or something to notify the system
  // also check to make sure the element is attached to this window.
  window->active = mary_element;
}

void Mary_Window_Back_Color(Mary_Window_t *window, float r, float g, float b, float a)
{
  Mary_Element_Back_Color(window, r, g, b, a); // might want this as a macro.
  Mary_OS_Window_Back_Color(window);
  window->is_dirty = 1;
}

void Mary_Window_Padding(Mary_Window_t *win, float l, float t, float r, float b)
{
  win->pad_l = l, win->pad_t = t, win->pad_r = r, win->pad_b = b; // might want to have this part as a macro, so that it can act like a super.
  win->clip_pad_l = l, win->clip_pad_t = t, win->clip_pad_r = r, win->clip_pad_b = b;
  // maybe we can put this in OS_Window_Measure?
}

#include <Mary/Vector.h>

typedef Mary_Vector_t Vector_t;

void (*Vector_Create)(Mary_Vector_t *vector, size_t unit, size_t opt_units) = Mary_Vector_Create;
void (*Vector_Destroy)(Mary_Vector_t *vector) = Mary_Vector_Destroy;
void (*Vector_Push_Back)(Mary_Vector_t *vector, void *in_elem) = Mary_Vector_Push_Back;
void (*Vector_Empty)(Mary_Vector_t *vector) = Mary_Vector_Empty;

#define VECTOR MARY_Vector
#define VECTOR_Create_At_Stack MARY_Vector_Create_At_Stack
#define VECTOR_Point MARY_Vector_Point
#define VECTOR_Point_Back MARY_Vector_Point_Back
#define VECTOR_At MARY_Vector_At
#define VECTOR_At_Back MARY_Vector_At_Back
#define VECTOR_Each MARY_Vector_Each

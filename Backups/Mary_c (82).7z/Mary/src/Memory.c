#include <stdlib.h>
#include <Mary/Memory.h>
#include <Mary/Hashmap.h>

MARY_Primitives;

static Mary_Allocator_u stack_allocator;
static Mary_Allocator_u heap_allocator;
static Mary_Hashmap_t ptrs_to_allocators;

void Mary_Memory_Start()
{
  MARY_Assert(sizeof(Mary_Allocator_u) <= 16, "Limit union to 16 bytes.");
  stack_allocator.type = MARY_ALLOCATOR_STACK;
  heap_allocator.type = MARY_ALLOCATOR_HEAP;
  Mary_Hashmap_Create(&ptrs_to_allocators, sizeof(Mary_Allocator_u *), sizeof(Mary_Allocator_u));
}

void Mary_Memory_Stop()
{
  Mary_Hashmap_Destroy(&ptrs_to_allocators);
}

Mary_Allocator_u *Mary_Allocator_Create(Mary_Enum_t type)
{
  if (type == MARY_ALLOCATOR_STACK)
  {
    return &stack_allocator;
  }
  else if (type == MARY_ALLOCATOR_HEAP)
  {
    return &heap_allocator;
  }
  else if (type == MARY_ALLOCATOR_POOL)
  {
    //Mary_Allocator_u * ptr = Mary_Hashmap_Point(&ptrs_to_allocators, &)
  }
}

void Mary_Allocator_Destroy(Mary_Allocator_u *allocator)
{

}

void *Mary_Allocator_Alloc(Mary_Allocator_u *allocator, Mary_Size_t bytes)
{
  return 0;
}

void *Mary_Allocator_Calloc(Mary_Allocator_u *allocator, Mary_Size_t unit, Mary_Size_t units)
{
  return 0;
}

void *Mary_Allocator_Realloc(Mary_Allocator_u *allocator, void *data, Mary_Size_t bytes)
{
  return 0;
}

void Mary_Allocator_Dealloc(Mary_Allocator_u *allocator, void *data)
{

}



// should probably go into utils.h
void *Mary_Memory_Alloc(Mary_Size_t bytes)
{
  void *data = malloc(bytes);
  MARY_Assert(data != 0, "Out of memory.");
  return data;
}

void *Mary_Memory_Calloc(Mary_Size_t unit, Mary_Size_t units)
{
  void *data = calloc(units, unit);
  MARY_Assert(data != 0, "Out of memory.");
  return data;
}

void *Mary_Memory_Realloc(void *data, Mary_Size_t bytes)
{
  void *new_data = realloc(data, bytes);
  MARY_Assert(new_data != 0, "Out of memory.");
  return new_data;
}

void Mary_Memory_Dealloc(void *data)
{
  free(data);
}

#pragma once

#include <Mary/Utils.h>

void Mary_Memory_Start();
void Mary_Memory_Stop();

enum Mary_Memory_Allocator_e
{
  MARY_MEMORY_STACK,
  MARY_MEMORY_HEAP
};

// should these go into utils?
// and then we would rename this to Allocator.h
typedef struct
{
  void *(*const alloc)(Mary_Size_t bytes);
  void *(*const calloc)(Mary_Size_t unit, Mary_Size_t units);
  void *(*const realloc)(void *data, Mary_Size_t bytes);
  void (*const dealloc)(void *data);
}
Mary_Memory_i;

void *Mary_Memory_Alloc(Mary_Size_t bytes);
void *Mary_Memory_Calloc(Mary_Size_t unit, Mary_Size_t units);
void *Mary_Memory_Realloc(void *data, Mary_Size_t bytes);
void Mary_Memory_Dealloc(void *data);

#define MARY_Memory_i(NAME)\
  const Mary_Memory_i NAME =\
  {\
    Mary_Memory_Alloc,\
    Mary_Memory_Calloc,\
    Mary_Memory_Realloc,\
    Mary_Memory_Dealloc\
  }

// it might be good to have a varying Allocator type like the event system has varying types.
// we could use an allocator type that stores the actual instance, or a struct of array about each
// instance and the user of the allocator only need pass in the allocator ptr, and the rest of the
// standard params for the operation. A Pool allocator would have to keep an instance of the pool
// that it's attached to.

// another trobule is how to store the allocators in here, when all custom types need an allocator.
// we may have to make our own data type just for use in Memory.c. It should be capable of growing,
// so probably a sorted vector would be just fine.


// it might be worth it to just have different types after all. doing the allocator seems near impossible to get right.
// the primary problem is that it can't keep track of each pool/arena withough acutally having created it.
// but I wan't the locality of the pools at least, although I'm considering getting rid of user arenas, which there
// does not seem to be more point of, so that's a moot point. but they still need different params.
// not sure what to do!!! I could just let a pointer dangle if a pool_t or arena_t has moved.
// I can't expect my hashmap or vector to update the pools if they have to regrow and they contain any.
// maybe it would be better after all to just have pools dished out globally. They are kind of the antithesis of an arena.
// it kind of makes sense to do that anyway, there is limited memory on the system after all.
// so that would mean that the only actual variable is which pool and arena id dished out from allocator, and a zone in the case of arena.
// I'm seriously considering putting the pool and the arena only in Allocator.

// essentially, we should hide Pool_t and Arena_t creation and deletion behind Allocator_t. we'll return pointer when user requests a pool.
// and I think it will be wise to just have the single arena per thread.

enum Mary_Allocator_e
{
  MARY_ALLOCATOR_STACK, // useful for at least throwing clear errors on a realloc
  MARY_ALLOCATOR_HEAP,
  MARY_ALLOCATOR_POOL,
  MARY_ALLOCATOR_ARENA
};

typedef struct Mary_Pool_t Mary_Pool_t;
typedef struct Mary_Arena_t Mary_Arena_t;

#define MARY_Allocator_t\
  Mary_Enum_8_t type

typedef struct
{
  MARY_Allocator_t;
}
Mary_Allocator_Stack_t,
Mary_Allocator_Heap_t;

typedef struct
{
  MARY_Allocator_t;
  Mary_Pool_t *pool;
}
Mary_Allocator_Pool_t;

typedef struct
{
  MARY_Allocator_t;
  Mary_Enum_8_t zone;
  Mary_Arena_t *arena; // if zero, uses global
}
Mary_Allocator_Arena_t;

typedef union
{
  MARY_Allocator_t;
  Mary_Allocator_Stack_t stack;
  Mary_Allocator_Heap_t heap;
  Mary_Allocator_Pool_t pool;
  Mary_Allocator_Arena_t arena;
}
Mary_Allocator_u;

Mary_Allocator_u *Mary_Allocator_Create(Mary_Enum_t type);
void Mary_Allocator_Destroy(Mary_Allocator_u *allocator);
void *Mary_Allocator_Alloc(Mary_Allocator_u *allocator, Mary_Size_t bytes); // make sure that when you branch the types, that you copy out the u8 to a u64 first.
void *Mary_Allocator_Calloc(Mary_Allocator_u *allocator, Mary_Size_t unit, Mary_Size_t units);
void *Mary_Allocator_Realloc(Mary_Allocator_u *allocator, void *data, Mary_Size_t bytes);
void Mary_Allocator_Dealloc(Mary_Allocator_u *allocator, void *data);

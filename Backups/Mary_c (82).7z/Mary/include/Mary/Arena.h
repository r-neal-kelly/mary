#pragma once

#include <Mary/Utils.h>
#include <Mary/Vector.h>
#include <Mary/Pool.h>

#define MARY_ARENA_GLOBAL_BYTES 0x300000

enum Mary_Arena_Zone_e
{
  MARY_ARENA_FRAME,
  MARY_ARENA_CHAIN,
  MARY_ARENA_VAULT,
  MARY_ARENA_ERROR
};

typedef struct Mary_Arena_t Mary_Arena_t;

struct Mary_Arena_t
{
  Mary_Pool_t pool;
  Mary_Vector_t vault;
  Mary_Vector_t frames;
};

typedef void *Mary_Arena_Frame_ID_t; // consider dropping the id part

void Mary_Arena_Start();
void Mary_Arena_Stop();

void Mary_Arena_Create(Mary_Arena_t *arena, Mary_Size_t bytes);
void Mary_Arena_Destroy(Mary_Arena_t *arena);
Mary_Arena_Frame_ID_t Mary_Arena_Push(Mary_Arena_t *arena);
void Mary_Arena_Pop(Mary_Arena_t *arena, Mary_Arena_Frame_ID_t frame_id);
void *Mary_Arena_Alloc_Frame(Mary_Arena_t *arena, Mary_Arena_Frame_ID_t frame_id, Mary_Size_t bytes);
void *Mary_Arena_Alloc_Chain(Mary_Arena_t *arena, Mary_Arena_Frame_ID_t frame_id, Mary_Size_t bytes);
void *Mary_Arena_Alloc_Error(Mary_Arena_t *arena, Mary_Arena_Frame_ID_t frame_id, Mary_Size_t bytes);
void *Mary_Arena_Alloc_Vault(Mary_Arena_t *arena, Mary_Size_t bytes);
void Mary_Arena_Dealloc_Frame(Mary_Arena_t *arena, Mary_Arena_Frame_ID_t frame_id, void *data);
void Mary_Arena_Dealloc_Chain(Mary_Arena_t *arena, Mary_Arena_Frame_ID_t frame_id, void *data);
void Mary_Arena_Dealloc_Vault(Mary_Arena_t *arena, void *data);
void *Mary_Arena_Alloc(Mary_Arena_t *arena, Mary_Enum_t zone, Mary_Arena_Frame_ID_t frame_id, Mary_Size_t bytes);
void Mary_Arena_Dealloc(Mary_Arena_t *arena, Mary_Enum_t zone, Mary_Arena_Frame_ID_t frame_id, void *data);
void Mary_Arena_Keep(Mary_Arena_t *arena, Mary_Arena_Frame_ID_t frame_id, void *data); // Backup? Reserve? Defer? Delay? Preserve might be best, even though it's long.
void *Mary_Arena_Cut(Mary_Arena_t *arena, void *data); // maybe one for Frame and one for Store?
void Mary_Arena_Empty(Mary_Arena_t *arena); // clears the entire allocation both in pool and in heap.

// I'm consider just making the global available, and junking the local user level version. We can make it more useful if we focus on it that way,
// and then we can also use the allocator.c file to deal with this very personally.

void Mary_Arena_Create_g();
void Mary_Arena_Destroy_g();
Mary_Arena_Frame_ID_t Mary_Arena_Push_g();
void Mary_Arena_Pop_g(Mary_Arena_Frame_ID_t frame_id);
void *Mary_Arena_Alloc_Frame_g(Mary_Arena_Frame_ID_t frame_id, Mary_Size_t bytes);
void *Mary_Arena_Alloc_Chain_g(Mary_Arena_Frame_ID_t frame_id, Mary_Size_t bytes);
void *Mary_Arena_Alloc_Error_g(Mary_Arena_Frame_ID_t frame_id, Mary_Size_t bytes);
void *Mary_Arena_Alloc_Vault_g(Mary_Size_t bytes);
void Mary_Arena_Dealloc_Frame_g(Mary_Arena_Frame_ID_t frame_id, void *data);
void Mary_Arena_Dealloc_Chain_g(Mary_Arena_Frame_ID_t frame_id, void *data);
void Mary_Arena_Dealloc_Vault_g(void *data);
void *Mary_Arena_Alloc_g(Mary_Enum_t zone, Mary_Arena_Frame_ID_t frame_id, Mary_Size_t bytes);
void Mary_Arena_Dealloc_g(Mary_Enum_t zone, Mary_Arena_Frame_ID_t frame_id, void *data);
void Mary_Arena_Keep_g(Mary_Arena_Frame_ID_t frame_id, void *data);

#define MARY_Arena_In\
  enum Mary_Arena_Zone_e { HEAP, FRAME, CHAIN, ERROR, VAULT };\
  const Mary_Arena_Frame_ID_t MARY_ARENA_FRAME_ID = Mary_Arena_Push_g()

#define MARY_Arena_Out\
  Mary_Arena_Pop_g(MARY_ARENA_FRAME_ID)

#define MARY_Arena_Return\
  Mary_Arena_Pop_g(MARY_ARENA_FRAME_ID); return

#define MARY_Arena_Keep(DATA)\
  Mary_Arena_Keep_g(MARY_ARENA_FRAME_ID, DATA)

#define MARY_Arena_Keep_Return(DATA)\
  MARY_Arena_Keep(DATA); MARY_Arena_Return DATA

#define MARY_Arena_Alloc(ENUM, BYTES)\
(\
  ENUM == FRAME ? Mary_Arena_Alloc_Frame_g(MARY_ARENA_FRAME_ID, BYTES) :\
  ENUM == CHAIN ? Mary_Arena_Alloc_Chain_g(MARY_ARENA_FRAME_ID, BYTES) :\
  ENUM == ERROR ? Mary_Arena_Alloc_Error_g(MARY_ARENA_FRAME_ID, BYTES) :\
  ENUM == VAULT ? Mary_Arena_Alloc_Vault_g(BYTES) :\
  ENUM == HEAP ? Mary_Memory_Alloc(BYTES) :\
  (MARY_Assert(0, "Invalid allocator"), 0)\
)

#define MARY_Arena_Dealloc(ENUM, BYTES)\
(\
  ENUM == VAULT ? Mary_Arena_Dealloc_Vault_g(BYTES) :\
  ENUM == HEAP ? Mary_Memory_Dealloc(BYTES) :\
  ENUM == CHAIN ? Mary_Arena_Dealloc_Chain_g(MARY_ARENA_FRAME_ID, BYTES) :\
  ENUM == FRAME ? Mary_Arena_Dealloc_Frame_g(MARY_ARENA_FRAME_ID, BYTES) :\
  (MARY_Assert(0, "Invalid allocator"), 0)\
)

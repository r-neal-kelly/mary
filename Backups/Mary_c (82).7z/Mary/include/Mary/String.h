#pragma once

#include <Mary/Utils.h>
#include <Mary/Memory.h>
#include <Mary/Vector.h>

enum Mary_String_Error_e
{
  MARY_STRING_ERROR_NONE = 0,
  MARY_STRING_ERROR_OUT_OF_SPACE
};

enum Mary_String_Append_e
{
  MARY_STRING_APPEND_BEFORE,
  MARY_STRING_APPEND_AFTER
};

enum Mary_String_Flag_e
{
  MARY_STRING_STACK,
  MARY_STRING_HEAP,
  MARY_STRING_AREANA
};

typedef struct
{
  MARY_Vector_t;
  Mary_Size_t codes;
  Mary_Enum_t flags;
}
Mary_String_t;

typedef struct Mary_Vector_t Mary_String_v;

void Mary_String_Create(Mary_String_t *mary_string, Mary_UTF_t utf, Mary_Size_t opt_units);
void Mary_String_Create_With_C_String(Mary_String_t *mary_string, Mary_UTF_t utf, Mary_C_String_t c_string, Mary_Size_t opt_units); // need to make param order consistent with Append
void Mary_String_Create_Empty(Mary_String_t *mary_string, Mary_UTF_t utf, Mary_Size_t opt_units);
void Mary_String_Create_At(Mary_String_t *mary_string, Mary_UTF_t utf, Mary_p mary_ptr);
void Mary_String_Create_With(Mary_String_t *mary_string, Mary_UTF_t utf, Mary_p mary_ptr);
void Mary_String_Create_With_Stack(Mary_String_t *mary_string, Mary_UTF_t utf, Mary_C_String_t c_string);
void Mary_String_Destroy(Mary_String_t *mary_string);
// prob should have a change and concat with String_t too. also, we need to know where to put it on the string, before or after. add a param.
void Mary_String_Change_C_String(Mary_String_t *mary_string, Mary_C_String_t c_string, Mary_UTF_t utf_c_string, Mary_Size_t opt_units_c_string);
void Mary_String_Append(Mary_String_t *mary_string, Mary_String_t *other, Mary_Enum_t position);
void Mary_String_Append_C_String(Mary_String_t *mary_string, Mary_C_String_t c_string, Mary_UTF_t utf_c_string, Mary_Size_t opt_units_c_string);
void Mary_String_Copy(Mary_String_t *string, Mary_String_t *out_copy, Mary_UTF_t opt_new_utf);
void Mary_String_Copy_To(Mary_String_t *from, Mary_p *to, Mary_UTF_t opt_new_utf); // add with_null
void Mary_String_Trim(Mary_String_t *mary_string);
// I think Mary_Error_t can be used to index into a function or something that relates what the problem is.
// we return a ptr because the Error might be large! so we can store it static in an array, or on the heap.
// this is too hard of a prob right now. but something to think about.
Mary_UTF_t Mary_String_Get_UTF(Mary_String_t *mary_string);
void Mary_String_Recode(Mary_String_t *mary_string, Mary_UTF_t new_utf);
// Cluster() should group the clusters in the string together
// Alphabet() should return whatever lang it is, see Lang.h

#define MARY_String(NAME, ALLOC, TYPE, STR)\
  Mary_String_t NAME =\
  {\
    MARY_C_String(TYPE, STR),\
    Mary_C_String_Count_Bytes(NAME.data, sizeof(TYPE), 1),\
    0,\
    sizeof(TYPE),\
    NAME.bytes / NAME.unit,\
    Mary_C_String_Count_Codes(NAME.data, NAME.unit, 1),\
    ( ALLOC == MARY_MEMORY_HEAP ? NAME.data = Mary_Memory_Alloc(NAME.bytes), Mary_Copy(STR, NAME.data, NAME.bytes) : 0, 0)\
  }

#define MARY_String_Get_UTF(S)\
  ( (S)->unit * 8 )

// we could have a function version of these macros, that takes a call back.
#define MARY_String_UTF_8_Encode(CODE, OUT, CASE_A, CASE_B, CASE_C, CASE_D) \
(                                                                           \
  (CODE) < 0x000080 ?                                                       \
      ( OUT.a    = (        (CODE)              ),                          \
        OUT.code = (CODE), OUT.units = 1, (CASE_A), OUT ) :                 \
  (CODE) < 0x000800 ?                                                       \
      ( OUT.a    = ( 0xC0 | (CODE) >> 6         ),                          \
        OUT.b    = ( 0x80 | (CODE)       & 0x3F ),                          \
        OUT.code = (CODE), OUT.units = 2, (CASE_B), OUT ) :                 \
  (CODE) < 0x010000 ?                                                       \
      ( OUT.a    = ( 0xE0 | (CODE) >> 12        ),                          \
        OUT.b    = ( 0x80 | (CODE) >> 6  & 0x3F ),                          \
        OUT.c    = ( 0x80 | (CODE)       & 0x3F ),                          \
        OUT.code = (CODE), OUT.units = 3, (CASE_C), OUT ) :                 \
  (CODE) < 0x110000 ?                                                       \
      ( OUT.a    = ( 0xF0 | (CODE) >> 18        ),                          \
        OUT.b    = ( 0x80 | (CODE) >> 12 & 0x3F ),                          \
        OUT.c    = ( 0x80 | (CODE) >> 6  & 0x3F ),                          \
        OUT.d    = ( 0x80 | (CODE)       & 0x3F ),                          \
        OUT.code = (CODE), OUT.units = 4, (CASE_D), OUT ) : OUT             \
)

#define MARY_String_UTF_8_Decode(PTR, OUT, CASE_A, CASE_B, CASE_C, CASE_D) \
(                                                                          \
  *(PTR) >> 7 == 0x00 ?                                                    \
      ( OUT.code  = ( ( OUT.a = * (PTR)      )        )       ,            \
        OUT.units = 1, (CASE_A), OUT )                        :            \
  *(PTR) >> 5 == 0x06 ?                                                    \
      ( OUT.code  = ( ( OUT.a = * (PTR)      ) ^ 0xC0 ) << 6  |            \
                    ( ( OUT.b = *((PTR) + 1) ) ^ 0x80 )       ,            \
        OUT.units = 2, (CASE_B), OUT )                        :            \
  *(PTR) >> 4 == 0x0E ?                                                    \
      ( OUT.code  = ( ( OUT.a = * (PTR)      ) ^ 0xE0 ) << 12 |            \
                    ( ( OUT.b = *((PTR) + 1) ) ^ 0x80 ) << 6  |            \
                    ( ( OUT.c = *((PTR) + 2) ) ^ 0x80 )       ,            \
        OUT.units = 3, (CASE_C), OUT )                        :            \
  *(PTR) >> 3 == 0x1E ?                                                    \
      ( OUT.code  = ( ( OUT.a = * (PTR)      ) ^ 0xF0 ) << 18 |            \
                    ( ( OUT.b = *((PTR) + 1) ) ^ 0x80 ) << 12 |            \
                    ( ( OUT.c = *((PTR) + 2) ) ^ 0x80 ) << 6  |            \
                    ( ( OUT.d = *((PTR) + 3) ) ^ 0x80 )       ,            \
        OUT.units = 4, (CASE_D), OUT )                        : OUT        \
)

#define MARY_String_UTF_16_Encode(CODE, OUT, CASE_A, CASE_B)   \
(                                                              \
  (CODE) < 0x10000 ?                                           \
      ( OUT.a    =     (CODE)                                , \
        OUT.code = (CODE), OUT.units = 1, (CASE_A), OUT )    : \
      ( OUT.a    = ( ( (CODE) - 0x10000 >> 10    ) + 0xD800 ), \
        OUT.b    = ( ( (CODE) - 0x10000 &  0x3FF ) + 0xDC00 ), \
        OUT.code = (CODE), OUT.units = 2, (CASE_B), OUT )      \
)

#define MARY_String_UTF_16_Decode(PTR, OUT, CASE_A, CASE_B)               \
(                                                                         \
  *(PTR) < 0xD800 || *(PTR) > 0xDFFF ?                                    \
      ( OUT.code = ( ( OUT.a = * (PTR)      )                )          , \
                       OUT.units = 1, (CASE_A), OUT )                   : \
      ( OUT.code = ( ( OUT.a = * (PTR)      ) - 0xD800 << 10 ) +          \
                   ( ( OUT.b = *((PTR) + 1) ) - 0xDC00       ) + 0x10000, \
                       OUT.units = 2, (CASE_B), OUT )                     \
)

#define MARY_String_UTF_8_Code_To_Units(CODE) \
(                                             \
  (CODE) < 0x000080 ? 1 :                     \
  (CODE) < 0x000800 ? 2 :                     \
  (CODE) < 0x010000 ? 3 :                     \
  (CODE) < 0x110000 ? 4 : 0                   \
)

#define MARY_String_UTF_8_Ptr_To_Units(PTR) \
(                                           \
  *(PTR) >> 7 == 0x00 ? 1 :                 \
  *(PTR) >> 5 == 0x06 ? 2 :                 \
  *(PTR) >> 4 == 0x0E ? 3 :                 \
  *(PTR) >> 3 == 0x1E ? 4 : 0               \
)

#define MARY_String_UTF_16_Code_To_Units(CODE) \
(                                              \
  (CODE) < 0x10000 ? 1 : 2                     \
)

#define MARY_String_UTF_16_Ptr_To_Units(PTR) \
(                                            \
  *(PTR) < 0xD800 || *(PTR) > 0xDFFF ? 2 : 1 \
)

#define MARY_String_Each_UTF_8(S)                                                                 \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx, unit_idx;                                                            \
      Mary_Size_t codes;                                                                          \
      uint8_t *ptr;                                                                               \
      Mary_UTF_8_t utf_8;                                                                         \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(Mary_String_Get_UTF(S) == MARY_UTF_8, 0), (S) ),                              \
        0, 0, it.string->codes, it.string->data,                                                  \
        MARY_String_UTF_8_Decode(it.ptr, it.utf_8, 0, 0, 0, 0)                                    \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, it.unit_idx += it.utf_8.units, it.ptr += it.utf_8.units,                       \
    MARY_String_UTF_8_Decode(it.ptr, it.utf_8, 0, 0, 0, 0)                                        \
  )

#define MARY_String_Each_UTF_8_To_16(S)                                                           \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx, unit_idx;                                                            \
      Mary_Size_t codes;                                                                          \
      uint8_t *ptr;                                                                               \
      Mary_UTF_8_t utf_8;                                                                         \
      Mary_UTF_16_t utf_16;                                                                       \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(Mary_String_Get_UTF(S) == MARY_UTF_8, 0), (S) ),                              \
        0, 0, it.string->codes, it.string->data,                                                  \
        MARY_String_UTF_8_Decode(it.ptr, it.utf_8, 0, 0, 0, 0),                                   \
        MARY_String_UTF_16_Encode(it.utf_8.code, it.utf_16, 0, 0)                                 \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, it.unit_idx += it.utf_8.units, it.ptr += it.utf_8.units,                       \
    MARY_String_UTF_8_Decode(it.ptr, it.utf_8, 0, 0, 0, 0),                                       \
    MARY_String_UTF_16_Encode(it.utf_8.code, it.utf_16, 0, 0)                                     \
  )

#define MARY_String_Each_UTF_8_To_32(S)                                                           \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx, unit_idx;                                                            \
      Mary_Size_t codes;                                                                          \
      uint8_t *ptr;                                                                               \
      Mary_UTF_8_t utf_8;                                                                         \
      Mary_UTF_32_t utf_32;                                                                       \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(Mary_String_Get_UTF(S) == MARY_UTF_8, 0), (S) ),                              \
        0, 0, it.string->codes, it.string->data,                                                  \
        MARY_String_UTF_8_Decode(it.ptr, it.utf_8, 0, 0, 0, 0),                                   \
        it.utf_8.code                                                                             \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, it.unit_idx += it.utf_8.units, it.ptr += it.utf_8.units,                       \
    MARY_String_UTF_8_Decode(it.ptr, it.utf_8, 0, 0, 0, 0),                                       \
    it.utf_32 = it.utf_8.code                                                                     \
  )

#define MARY_String_Each_UTF_16(S)                                                                \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx, unit_idx;                                                            \
      Mary_Size_t codes;                                                                          \
      uint16_t *ptr;                                                                              \
      Mary_UTF_16_t utf_16;                                                                       \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(Mary_String_Get_UTF(S) == MARY_UTF_16, 0), (S) ),                             \
        0, 0, it.string->codes, it.string->data,                                                  \
        MARY_String_UTF_16_Decode(it.ptr, it.utf_16, 0, 0)                                        \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, it.unit_idx += it.utf_16.units, it.ptr += it.utf_16.units,                     \
    MARY_String_UTF_16_Decode(it.ptr, it.utf_16, 0, 0)                                            \
  )

#define MARY_String_Each_UTF_16_To_8(S)                                                           \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx, unit_idx;                                                            \
      Mary_Size_t codes;                                                                          \
      uint16_t *ptr;                                                                              \
      Mary_UTF_16_t utf_16;                                                                       \
      Mary_UTF_8_t utf_8;                                                                         \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(Mary_String_Get_UTF(S) == MARY_UTF_16, 0), (S) ),                             \
        0, 0, it.string->codes, it.string->data,                                                  \
        MARY_String_UTF_16_Decode(it.ptr, it.utf_16, 0, 0),                                       \
        MARY_String_UTF_8_Encode(it.utf_16.code, it.utf_8, 0, 0, 0, 0)                            \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, it.unit_idx += it.utf_16.units, it.ptr += it.utf_16.units,                     \
    MARY_String_UTF_16_Decode(it.ptr, it.utf_16, 0, 0),                                           \
    MARY_String_UTF_8_Encode(it.utf_16.code, it.utf_8, 0, 0, 0, 0)                                \
  )

#define MARY_String_Each_UTF_16_To_32(S)                                                          \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx, unit_idx;                                                            \
      Mary_Size_t codes;                                                                          \
      uint16_t *ptr;                                                                              \
      Mary_UTF_16_t utf_16;                                                                       \
      Mary_UTF_32_t utf_32;                                                                       \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(Mary_String_Get_UTF(S) == MARY_UTF_16, 0), (S) ),                             \
        0, 0, it.string->codes, it.string->data,                                                  \
        MARY_String_UTF_16_Decode(it.ptr, it.utf_16, 0, 0),                                       \
        it.utf_16.code                                                                            \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, it.unit_idx += it.utf_16.units, it.ptr += it.utf_16.units,                     \
    MARY_String_UTF_16_Decode(it.ptr, it.utf_16, 0, 0),                                           \
    it.utf_32 = it.utf_16.code                                                                    \
  )

#define MARY_String_Each_UTF_32(S)                                                                \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx;                                                                      \
      Mary_Size_t codes;                                                                          \
      uint32_t *ptr;                                                                              \
      Mary_UTF_32_t utf_32;                                                                       \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(Mary_String_Get_UTF(S) == MARY_UTF_32, 0), (S) ),                             \
        0, it.string->codes, it.string->data, *it.ptr                                             \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, ++it.ptr, it.utf_32 = *it.ptr                                                  \
  )

#define MARY_String_Each_UTF_32_To_8(S)                                                           \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx;                                                                      \
      Mary_Size_t codes;                                                                          \
      uint32_t *ptr;                                                                              \
      Mary_UTF_32_t utf_32;                                                                       \
      Mary_UTF_8_t utf_8;                                                                         \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(Mary_String_Get_UTF(S) == MARY_UTF_32, 0), (S) ),                             \
        0, it.string->codes, it.string->data, *it.ptr,                                            \
        MARY_String_UTF_8_Encode(it.utf_32, it.utf_8, 0, 0, 0, 0)                                 \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, ++it.ptr, it.utf_32 = *it.ptr,                                                 \
    MARY_String_UTF_8_Encode(it.utf_32, it.utf_8, 0, 0, 0, 0)                                     \
  )

#define MARY_String_Each_UTF_32_To_16(S)                                                          \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx;                                                                      \
      Mary_Size_t codes;                                                                          \
      uint32_t *ptr;                                                                              \
      Mary_UTF_32_t utf_32;                                                                       \
      Mary_UTF_16_t utf_16;                                                                       \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(Mary_String_Get_UTF(S) == MARY_UTF_32, 0), (S) ),                             \
        0, it.string->codes, it.string->data, *it.ptr,                                            \
        MARY_String_UTF_16_Encode(it.utf_32, it.utf_16, 0, 0)                                     \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, ++it.ptr, it.utf_32 = *it.ptr,                                                 \
    MARY_String_UTF_16_Encode(it.utf_32, it.utf_16, 0, 0)                                         \
  )

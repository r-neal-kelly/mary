#define intern static
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <Mary/Utils.h>
#include <Mary/Vector.h>
typedef char byte_t;

const Mary_Vector_i Mary_Vector();
intern void Create    (Mary_Vector_t *vector, size_t unit);
intern void Destroy   (Mary_Vector_t *vector);
intern void Grow_By   (Mary_Vector_t *vector, size_t units);
intern void Fit       (Mary_Vector_t *vector);
intern void Insert    (Mary_Vector_t *vector, size_t index, void *elem_in);
intern void Extract   (Mary_Vector_t *vector, size_t index, void *elem_out);
intern void Replace   (Mary_Vector_t *vector, size_t index, void *elem_in);
intern void Exchange  (Mary_Vector_t *vector, size_t index, void *elem_in, void *elem_out);
intern void Push_Back (Mary_Vector_t *vector, void *elem_in);
intern void Push_Front(Mary_Vector_t *vector, void *elem_in);
intern void Pop_Back  (Mary_Vector_t *vector, void *elem_out);
intern void Pop_Front (Mary_Vector_t *vector, void *elem_out);
intern void At        (Mary_Vector_t *vector, size_t index, void *elem_out);
intern char Has_At    (Mary_Vector_t *vector, size_t index);
intern void Back      (Mary_Vector_t *vector, void *elem_out);
intern void Front     (Mary_Vector_t *vector, void *elem_out);
intern void Do_Empty  (Mary_Vector_t *vector);
intern char Is_Empty  (Mary_Vector_t *vector);

const Mary_Vector_i Mary_Vector()
{
  const Mary_Vector_i interface =
    { Create, Destroy
    , Grow_By, Fit
    , Insert, Extract
    , Replace, Exchange
    , Push_Back, Push_Front
    , Pop_Back, Pop_Front
    , At, Has_At
    , Back, Front
    , Do_Empty, Is_Empty
    };

  return interface;
}

intern void Create(Mary_Vector_t *vector, size_t unit)
{
  void *data = calloc(1, unit);
  if (data)
  {
    vector->data = data;
    vector->capacity = unit;
    vector->unit = unit;
    vector->length = 0;
  }
}

intern void Destroy(Mary_Vector_t *vector)
{
  free(vector->data);
}

intern void Grow_By(Mary_Vector_t *vector, size_t units)
{
  void *data = vector->data;
  size_t capacity = vector->capacity;
  size_t unit = vector->unit;
  size_t length = vector->length;

  if (capacity < ((length + units) * unit))
  {
    capacity *= 2;
    void *result = realloc(data, capacity);
    if (result)
    {
      data = result;
      vector->data = data;
      vector->capacity = capacity;
    }
  }
}

intern void Fit(Mary_Vector_t *vector)
{
  void *data = vector->data;
  size_t capacity = vector->capacity;
  size_t length = vector->length;
  size_t capacity_fitted = (length) ? (length * 64) : 64;

  if (capacity != capacity_fitted)
  {
    void *result = realloc(data, capacity_fitted);
    if (result)
    {
      data = result;
      vector->data = data;
      vector->capacity = capacity_fitted;
    }
  }
}

intern void Insert(Mary_Vector_t *vector, size_t index, void *elem_in)
{
  size_t unit = vector->unit;
  size_t length = vector->length;
  Grow_By(vector, 1);
  length += 1;

  void *data = vector->data;
  size_t l = length - 1;
  byte_t *p = (byte_t *)data + (l * unit);
  for (; l > index; --l, p -= unit)
  {
    memmove(p, p - unit, unit);
  }
  memcpy(p, elem_in, unit);

  vector->length = length;
}

intern void Extract(Mary_Vector_t *vector, size_t index, void *elem_out)
{
  size_t unit = vector->unit;
  size_t length = vector->length;
  length -= 1;

  void *data = vector->data;
  byte_t *p = (byte_t *)data + (index * unit);
  memcpy(elem_out, p, unit);
  for (; index < length; ++index, p += unit)
  {
    memmove(p, p + unit, unit);
  }

  vector->length = length;
}

intern void Replace(Mary_Vector_t *vector, size_t index, void *elem_in)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  byte_t *p = (byte_t *)data + (index * unit);
  memcpy(p, elem_in, unit);
}

intern void Exchange(Mary_Vector_t *vector, size_t index, void *elem_in, void *elem_out)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  byte_t *p = (byte_t *)data + (index * unit);
  memcpy(elem_out, p, unit);
  memcpy(p, elem_in, unit);
}

intern void Push_Back(Mary_Vector_t *vector, void *elem_in)
{
  Insert(vector, vector->length, elem_in);
}

intern void Push_Front(Mary_Vector_t *vector, void *elem_in)
{
  Insert(vector, 0, elem_in);
}

intern void Pop_Back(Mary_Vector_t *vector, void *elem_out)
{
  size_t length = vector->length;
  Extract(vector, (length) ? length - 1 : 0, elem_out);
}

intern void Pop_Front(Mary_Vector_t *vector, void *elem_out)
{
  Extract(vector, 0, elem_out);
}

intern void At(Mary_Vector_t *vector, size_t index, void *elem_out)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  byte_t *p = (byte_t *)data + (index * unit);
  memcpy(elem_out, p, unit);
}

intern char Has_At(Mary_Vector_t *vector, size_t index)
{
  return index < vector->length;
}

intern void Back(Mary_Vector_t *vector, void *elem_out)
{
  size_t length = vector->length;
  At(vector, (length) ? length - 1 : 0, elem_out);
}

intern void Front(Mary_Vector_t *vector, void *elem_out)
{
  At(vector, 0, elem_out);
}

intern void Do_Empty(Mary_Vector_t *vector)
{
  size_t unit = vector->unit;
  Destroy(vector);
  Create(vector, unit);
}

intern char Is_Empty(Mary_Vector_t *vector)
{
  return vector->length != 0;
}

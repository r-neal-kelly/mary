#define intern static
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <Mary/Utils.h>
#include <Mary/Vector64.h>

////// Public Functions
const Mary_Vector64_i Mary_Vector64();

////// Private Functions
intern void    Create    (Mary_Vector64_t *vector);
intern void    Destroy   (Mary_Vector64_t *vector);
intern int64_t At        (Mary_Vector64_t *vector, size_t index);
intern int8_t  Has_At    (Mary_Vector64_t *vector, size_t index);
intern int64_t Front     (Mary_Vector64_t *vector);
intern int64_t Back      (Mary_Vector64_t *vector);
intern void    Push_Back (Mary_Vector64_t *vector, int64_t element);
intern void    Push_Front(Mary_Vector64_t *vector, int64_t element);
intern int64_t Pop_Back  (Mary_Vector64_t *vector);
intern int64_t Pop_Front (Mary_Vector64_t *vector);
intern void    Insert    (Mary_Vector64_t *vector, size_t index, int64_t element);
intern int64_t Remove    (Mary_Vector64_t *vector, size_t index);
intern int64_t Replace   (Mary_Vector64_t *vector, size_t index, int64_t element);
intern int8_t  Is_Empty  (Mary_Vector64_t *vector);
intern void    Do_Empty  (Mary_Vector64_t *vector);
intern void    Grow      (Mary_Vector64_t *vector, size_t bytes);
intern void    Fit       (Mary_Vector64_t *vector);
intern void    Print     (Mary_Vector64_t *vector, uint8_t elements_per_line);

////// Interface
const Mary_Vector64_i Mary_Vector64()
{
  // not static, in case of threading.
  const Mary_Vector64_i interface =
    { Create
    , Destroy
    , At
    , Has_At
    , Front
    , Back
    , Push_Back
    , Push_Front
    , Pop_Back
    , Pop_Front
    , Insert
    , Remove
    , Replace
    , Is_Empty
    , Do_Empty
    , Grow
    , Fit
    , Print
    };

  return interface;
}

////// Creation
intern void Create(Mary_Vector64_t *vector)
{
  int64_t *data = malloc(64);
  if (!data)
  {
    Mary_Exit_Failure("Failed to malloc 'Mary_Vector'!");
  }

  vector->data = data;
  vector->capacity = 64;
  vector->length = 0;
}

intern void Destroy(Mary_Vector64_t *vector)
{
  free(vector->data);
}

////// Access
intern int64_t At(Mary_Vector64_t *vector, size_t index)
{
  if (index >= vector->length)
  {
    Mary_Exit_Failure("'At' index is out of bounds for 'Mary_Vector'!");

    return 1;
  }
  else
  {
    return vector->data[index];
  }
}

intern int8_t Has_At(Mary_Vector64_t *vector, size_t index)
{
  return index < vector->length;
}

intern int64_t Front(Mary_Vector64_t *vector)
{
  return vector->data[0];
}

intern int64_t Back(Mary_Vector64_t *vector)
{
  return vector->data[vector->length - 1];
}

////// Alteration
intern void Push_Back(Mary_Vector64_t *vector, int64_t element)
{
  int64_t *data = vector->data;
  size_t capacity = vector->capacity;
  size_t length = vector->length;

  length += 1;

  if (capacity < (length * 64))
  {
    // could just send to Grow. but this might be faster?
    capacity *= 2;

    int64_t *result = realloc(data, capacity);
    if (!result)
    {
      free(data);
      printf("megabytes: %f ", (double)capacity / 1000 / 1000);
      printf("length: %zu\n", length);
      Mary_Exit_Failure("Failed to realloc 'Mary_Vector'!");
    }
    else
    {
      data = result;
    }
  }

  data[length - 1] = element;
  vector->data = data;
  vector->capacity = capacity;
  vector->length = length;
}

intern void Push_Front(Mary_Vector64_t *vector, int64_t element)
{
  int64_t *data = vector->data;

  Push_Back(vector, 0);

  for (size_t i = vector->length - 1; i > 0; --i)
  {
    data[i] = data[i - 1];
  }

  data[0] = element;
}

intern int64_t Pop_Back(Mary_Vector64_t *vector)
{
  size_t length = vector->length;

  if (length == 0)
  {
    Mary_Exit_Failure("Cannot 'Pop_Back' an empty 'Mary_Vector'!");
  }

  length -= 1;
  int64_t element = vector->data[length];
  vector->length = length;

  return element;
}

intern int64_t Pop_Front(Mary_Vector64_t *vector)
{
  size_t length = vector->length;

  if (length == 0)
  {
    Mary_Exit_Failure("Cannot 'Pop_Front' an empty 'Mary_Vector'!");
  }

  int64_t *data = vector->data;
  int64_t element = data[0];

  for (size_t i = 0; i < length; ++i)
  {
    data[i] = data[i + 1];
  }

  length -= 1;
  vector->length = length;

  return element;
}

intern void Insert(Mary_Vector64_t *vector, size_t index, int64_t element)
{
  size_t last_index = vector->length - 1;

  if (index > last_index)
  {
    Mary_Exit_Failure("'Insert' index is out of bounds for 'Mary_Vector'!");
  }
  else if (index == last_index)
  {
    Push_Back(vector, element);
  }
  else if (index == 0)
  {
    Push_Front(vector, element);
  }
  else
  {
    Push_Back(vector, 0);

    int64_t *data = vector->data;

    for (size_t i = vector->length - 1; i > index; --i)
    {
      data[i] = data[i - 1];
    }

    data[index] = element;
  }
}

intern int64_t Remove(Mary_Vector64_t *vector, size_t index)
{
  size_t last_index = vector->length - 1;

  if (index > last_index)
  {
    Mary_Exit_Failure("'Remove' index is out of bounds for 'Mary_Vector'!");

    return 1;
  }
  else if (index == last_index)
  {
    return Pop_Back(vector);
  }
  else if (index == 0)
  {
    return Pop_Front(vector);
  }
  else
  {
    int64_t *data = vector->data;
    size_t length = vector->length;
    int64_t element = data[index];

    for (size_t i = index; i < length; ++i)
    {
      data[i] = data[i + 1];
    }

    length -= 1;
    vector->length = length;

    return element;
  }
}

intern int64_t Replace(Mary_Vector64_t *vector, size_t index, int64_t element)
{
  size_t last_index = vector->length - 1;

  if (index > last_index)
  {
    Mary_Exit_Failure("'Replace' index is out of bounds for 'Mary_Vector'!");
  }

  int64_t *data = vector->data;
  int64_t old_element = data[index];
  vector->data[index] = element;

  return old_element;
}

intern int8_t Is_Empty(Mary_Vector64_t *vector)
{
  return vector->length != 0;
}

intern void Do_Empty(Mary_Vector64_t *vector)
{
  Destroy(vector);
  Create(vector);
}

intern void Grow(Mary_Vector64_t *vector, size_t byte_capacity)
{
  void *data = vector->data;
  size_t capacity = vector->capacity;

  if (byte_capacity < capacity)
  {
    Mary_Exit_Failure("'Grow' byte_capacity smaller than 'Mary_Vector'!");
  }
  else if (byte_capacity == capacity)
  {
    return;
  }
  else
  {
    capacity = byte_capacity;
  }

  void *result = realloc(data, capacity);
  if (!result)
  {
    Mary_Exit_Failure("Failed 'Grow' realloc with 'Mary_Vector'!");
  }
  else
  {
    data = result;
  }

  vector->data = data;
  vector->capacity = capacity;
}

intern void Fit(Mary_Vector64_t *vector)
{
  void *data = vector->data;
  size_t capacity = vector->capacity;
  size_t length = vector->length;
  size_t capacity_fitted = (length) ? (length * 64) : 64;

  if (capacity_fitted == capacity)
  {
    return;
  }

  void *result = realloc(data, capacity_fitted);
  if (!result)
  {
    Mary_Exit_Failure("Failed 'Fit' realloc with 'Mary_Vector'!");
  }
  else
  {
    data = result;
  }

  vector->data = data;
  vector->capacity = capacity_fitted;
}

////// Helpers
intern void Print(Mary_Vector64_t *vector, uint8_t elements_per_line)
{
  if (elements_per_line == 0)
  {
    elements_per_line = (uint8_t)~0;
  }

  for (int i = 0, j = 1; i < vector->length; ++i, ++j)
  {
    if (j > elements_per_line)
    {
      printf("\n");
      j = 1;
    }

    printf("%i:%lli ", i, vector->data[i]);
  }

  printf("\n");
}

#define intern static
#include <Mary/Window.h>

////// Public Functions
void Mary_Window_Start();
void Mary_Window_Finish();
void Mary_Window_Create(Mary_Window_t *window);
void Mary_Window_Destroy(Mary_Window_t *window);
void Mary_Window_Show(Mary_Window_t *window);
void Mary_Window_Hide(Mary_Window_t *window);

////// Private Functions
intern int64_t __stdcall Win32_Wnd_Proc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp);

////// Private Data
intern const uint16_t win32_class_name[] = u"Mary_Win32_Class";

// might be good to wrap all windows funcs in a struct
// cause it makes easier reading. Mary_Win32_t

////// Type Initialization
void Mary_Window_Start()
{
  WNDCLASSEX win32_class;
  memset(&win32_class, 0, sizeof(win32_class));
  win32_class.cbSize = sizeof(win32_class);
  win32_class.lpfnWndProc = Win32_Wnd_Proc;
  win32_class.hCursor = LoadCursor(0, IDC_ARROW);
  win32_class.hbrBackground = (HBRUSH)8;
  win32_class.lpszClassName = win32_class_name;
  win32_class.style = CS_OWNDC;
  RegisterClassEx(&win32_class);

  return;
}

void Mary_Window_Finish()
{
  return;
}

////// Creation
void Mary_Window_Create(Mary_Window_t *window)
{
  memset(window, 0, sizeof(window));

  HWND win32_hwnd = CreateWindowEx
    ( WS_EX_CLIENTEDGE
    , win32_class_name
    , L"Praise Yahweh!"
    , WS_OVERLAPPEDWINDOW
    , 100, 100
    , 800, 600
    , 0, 0, 0, 0
    );
  window->win32_hwnd = win32_hwnd;
  
  HDC win32_hdc = GetDC(win32_hwnd);
  window->win32_hdc = win32_hdc;

  Mary_Window_Show(window);

  return;
}

void Mary_Window_Destroy(Mary_Window_t *window)
{
  HWND win32_hwnd = window->win32_hwnd;
  HDC win32_hdc = window->win32_hdc;
  ReleaseDC(win32_hwnd, win32_hdc);
  DestroyWindow(win32_hwnd);
  memset(window, 0, sizeof(window));

  return;
}

intern int64_t __stdcall Win32_Wnd_Proc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
{
  return DefWindowProc(hwnd, msg, wp, lp);
}

////// Status
void Mary_Window_Show(Mary_Window_t *window)
{
  HWND win32_hwnd = window->win32_hwnd;
  ShowWindow(win32_hwnd, SW_NORMAL);
  UpdateWindow(win32_hwnd);

  return;
}

void Mary_Window_Hide(Mary_Window_t *window)
{
  ShowWindow(window->win32_hwnd, SW_HIDE);

  return;
}

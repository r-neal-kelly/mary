#define intern static
#define global
#include <stdio.h>
#include <Mary/OpenGL.h>

global void Mary_OpenGL_Start();
global void Mary_OpenGL_Finish();
global const Mary_OpenGL_g Mary_OpenGL();

intern HWND g_hwnd = 0;
intern HDC g_hdc = 0;
intern HGLRC g_hglrc = 0;
intern int g_pixel_format = 0;

global void Mary_OpenGL_Start()
{
  WNDCLASSEX wndclass;
  memset(&wndclass, 0, sizeof(wndclass));
  wndclass.cbSize = sizeof(wndclass);
  wndclass.lpfnWndProc = DefWindowProc;
  wndclass.lpszClassName = u"Mary_OpenGL";
  wndclass.style = CS_OWNDC;
  RegisterClassEx(&wndclass);

  g_hwnd = CreateWindowEx
    ( 0
    , u"Mary_OpenGL"
    , 0
    , 0, 0
    , 0, 0
    , 0, 0, 0, 0, 0
    );
  g_hdc = GetDC(g_hwnd);

  PIXELFORMATDESCRIPTOR pfd;
  memset(&pfd, 0, sizeof(pfd));
  SetPixelFormat(g_hdc, ChoosePixelFormat(g_hdc, &pfd), &pfd);

  g_hglrc = wglCreateContext(g_hdc);
  wglMakeCurrent(g_hdc, g_hglrc);

  wglChoosePixelFormatARB = (void *)wglGetProcAddress("wglChoosePixelFormatARB");

  const int attribute_list[] =
    { WGL_DRAW_TO_WINDOW_ARB, GL_TRUE
    , WGL_SUPPORT_OPENGL_ARB, GL_TRUE
    , WGL_DOUBLE_BUFFER_ARB, GL_TRUE
    , WGL_PIXEL_TYPE_ARB, WGL_TYPE_RGBA_ARB
    , WGL_COLOR_BITS_ARB, 32
    , WGL_DEPTH_BITS_ARB, 24
    , WGL_STENCIL_BITS_ARB, 8
    , WGL_SAMPLE_BUFFERS_ARB, 1
    , WGL_SAMPLES_ARB, 4
    , 0
    };
  uint32_t number_of_formats = 0;
  wglChoosePixelFormatARB
    ( g_hdc
    , attribute_list
    , 0, 1
    , &g_pixel_format
    , &number_of_formats
    );

  wglMakeCurrent(g_hdc, 0);
  wglDeleteContext(g_hglrc);
  ReleaseDC(g_hwnd, g_hdc);
  DestroyWindow(g_hwnd);

  g_hwnd = CreateWindowEx
    ( 0
    , u"Mary_OpenGL"
    , 0
    , 0, 0
    , 0, 0
    , 0, 0, 0, 0, 0
    );
  g_hdc = GetDC(g_hwnd);

  memset(&pfd, 0, sizeof(pfd));
  SetPixelFormat(g_hdc, g_pixel_format, &pfd);

  g_hglrc = wglCreateContext(g_hdc);
  wglMakeCurrent(g_hdc, g_hglrc);

  HMODULE opengl_dll = LoadLibrary(u"opengl32.dll");
  glGetString    = (void *)GetProcAddress(opengl_dll, "glGetString");
  glViewport     = (void *)GetProcAddress(opengl_dll, "glViewport");
  glClearColor   = (void *)GetProcAddress(opengl_dll, "glClearColor");
  glClear        = (void *)GetProcAddress(opengl_dll, "glClear");
  glLoadIdentity = (void *)GetProcAddress(opengl_dll, "glLoadIdentity");
  glMatrixMode   = (void *)GetProcAddress(opengl_dll, "glMatrixMode");
  glOrtho        = (void *)GetProcAddress(opengl_dll, "glOrtho");
  FreeLibrary(opengl_dll);
}

global void Mary_OpenGL_Finish()
{
  wglMakeCurrent(g_hdc, 0);
  wglDeleteContext(g_hglrc);
  ReleaseDC(g_hwnd, g_hdc);
  DestroyWindow(g_hwnd);
}

global const Mary_OpenGL_g Mary_OpenGL()
{
  const Mary_OpenGL_g interface =
    { g_hglrc
    , g_pixel_format
    };

  return interface;
}

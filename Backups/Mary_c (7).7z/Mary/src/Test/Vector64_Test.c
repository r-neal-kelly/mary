#include <Mary/Test/Vector64_Test.h>

void Mary_Vector64_Test()
{
  Mary_Vector64_i vec64 = Mary_Vector64();
  Mary_Vector64_t vector;

  vec64.Create(&vector);

  puts("\n\n Push_Back \n------------");
  {
    vec64.Push_Back(&vector, INT16_MAX);
    vec64.Push_Back(&vector, INT64_MAX);
    vec64.Print(&vector, 0);
  }

  puts("\n\n Push_Front \n------------");
  {
    vec64.Push_Front(&vector, 200);
    vec64.Push_Front(&vector, 100);
    vec64.Print(&vector, 0);
  }

  puts("\n\n Insert \n------------");
  {
    vec64.Insert(&vector, 2, 12);
    vec64.Print(&vector, 0);
  }

  puts("\n\n Replace \n------------");
  {
    vec64.Replace(&vector, 3, 72);
    vec64.Print(&vector, 0);
  }

  puts("\n\n Remove \n------------");
  {
    int64_t removed = vec64.Remove(&vector, 3);
    vec64.Print(&vector, 0);
    printf("%lli\n", removed);
  }

  puts("\n\n Pop_Back \n------------");
  {
    int64_t elem_back = vec64.Pop_Back(&vector);
    vec64.Print(&vector, 0);
    printf("%lli\n", elem_back);
  }

  puts("\n\n Pop_Front \n------------");
  {
    int64_t elem_front = vec64.Pop_Front(&vector);
    vec64.Print(&vector, 0);
    printf("%lli\n", elem_front);
  }

  puts("\n\n Is_Empty \n------------");
  {
    printf("empty?: %i\n", vec64.Is_Empty(&vector));
  }

  puts("\n\n Do_Empty \n------------");
  {
    vec64.Do_Empty(&vector);
    vec64.Print(&vector, 0);
  }

  puts("\n\n Grow \n------------");
  {
    printf("capacity: %zu\n", vector.capacity);
    vec64.Grow(&vector, 1200);
    printf("capacity: %zu\n", vector.capacity);
  }

  puts("\n\n Fit \n------------");
  {
    printf("capacity: %zu\n", vector.capacity);
    vec64.Fit(&vector);
    printf("capacity: %zu\n", vector.capacity);
  }

  puts("\n\n press enter to continue...");
  getc(stdin);

  puts("\n\n Big Test \n------------");
  {
    for (int i = 0; i <= 9029328439; ++i)
    {
      vec64.Push_Back(&vector, i);
    }
  }

  vec64.Destroy(&vector);

  Mary_Exit_Success();
}

#include <stdio.h>
#include <stdint.h>

int main()
{
  enum FLAGS
    { ONE = 1 << 0
    , TWO = 1 << 1
    , THREE = 1 << 2
    , FOUR = 1 << 3
    , FIVE = 1 << 4
    , SIX = 1 << 5
    , SEVEN = 1 << 6
    , EIGHT = 1 << 7
    };

  uint8_t flags = 0;

  printf("%s\n", "set bits");
  flags |= SEVEN | ONE;
  printf("%u\n", flags); // 65

  printf("%s\n", "unset a bit");
  flags &= ~SEVEN;
  printf("%u\n", flags); // 1

  printf("%s\n", "unset multiple bits");
  flags = 0;
  flags |= SEVEN | ONE | TWO;
  flags &= ~(SEVEN | ONE | EIGHT);
  printf("%u\n", flags); // 2

  printf("%s\n", "check if bit is set");
  printf("%u\n", flags & TWO); // non zero
  printf("%u\n", flags & EIGHT); // 0

  printf("%s\n", "check if multiple bits are set");
  flags |= SIX;
  printf("%u\n", flags & (SIX | TWO)); // non zero

  printf("\n%s\n", "press enter to exit...");
  getc(stdin);
  return 0;
}

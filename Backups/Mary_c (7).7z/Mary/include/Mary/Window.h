#pragma once

#include <Mary/OS.h>

typedef struct
{
  HWND win32_hwnd;
  HDC win32_hdc;
  char flags;
}
Mary_Window_t;

typedef struct
{
  void (*const Create) (Mary_Window_t *window);
  void (*const Destroy)(Mary_Window_t *window);
  void (*const Close)  (Mary_Window_t *window);
  void (*const Show)   (Mary_Window_t *window);
  void (*const Hide)   (Mary_Window_t *window);
}
Mary_Window_i;

void Mary_Window_Start();
void Mary_Window_Finish();
char Mary_Window_Can_Render();
void Mary_Window_Render();
const Mary_Window_i *Mary_Window();

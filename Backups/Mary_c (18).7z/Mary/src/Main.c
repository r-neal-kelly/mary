#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <Mary/Mary.h>


int main()
{
  //Mary_Start();

#if 0
  Mary_Window_t window;
  Mary_Window_Create(&window);
  while (Mary_Window_Can_Render())
  {
    Mary_Window_Render();
  }
  Mary_Window_Destroy(&window);
#endif

  Mary_String_t string;
  Mary_String_Create(&string, 16, u"Praise Yahweh!", 0);
  wprintf(u"%s\n", (wchar_t *)string.data);
  printf("size:%zu\n", string.size);
  Mary_String_Destroy(&string);

  Mary_String_Create(&string, 8, "Amen!!!", 0);
  Mary_String_Convert(&string, 32);
  Mary_String_Convert(&string, 16);
  wprintf(u"%s\n", (wchar_t *)string.data);
  printf("size:%zu\n", string.size);
  Mary_String_Destroy(&string);

  Mary_Exit_Success();

  Mary_Font_Start();
  Mary_Font_t font;
  Mary_Font_Create(&font, "Quivira.otf");
  //Mary_Font_Layout(&font, u"Hello, World!");
  Mary_Font_Destroy(&font);
  Mary_Font_Finish();

  Mary_Exit_Success();

  //Mary_Finish();
}

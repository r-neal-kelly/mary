#include <stdlib.h>
#include <string.h>
#include <Mary/Utils.h>
#include <Mary/Vector.h>
#include <Mary/String.h>

void Mary_String_Create(Mary_String_t *mary_string, uint8_t bit_format, void *string, size_t opt_size);
void Mary_String_Destroy(Mary_String_t *mary_string);
void Mary_String_Convert(Mary_String_t *mary_string, uint8_t bit_format);
Mary_String_t Mary_8bit_to_32bit(Mary_String_t *s_8bit);
Mary_String_t Mary_32bit_to_16bit(Mary_String_t *s_32bit);

void Mary_String_Create(Mary_String_t *mary_string, uint8_t bit_format, void *string, size_t opt_size)
{
  Mary_Vector_t *mary_vector = (Mary_Vector_t *)mary_string;
  if (bit_format == 8)
  {
    Mary_Vector_Create(mary_vector, 1, opt_size || 64);
    uint8_t *p = string; uint8_t code = *p;
    for (; code; ++p, code = *p)
    {
      Mary_Vector_Push_Back(mary_vector, &code);
    }
    code = 0; Mary_Vector_Push_Back(mary_vector, &code);
    if (!opt_size)
    {
      Mary_Vector_Fit(mary_vector);
    }
  }
  else if (bit_format == 16)
  {
    Mary_Vector_Create(mary_vector, 2, opt_size || 64);
    uint16_t *p = string; uint16_t code = *p;
    for (; code; ++p, code = *p)
    {
      Mary_Vector_Push_Back(mary_vector, &code);
    }
    code = 0; Mary_Vector_Push_Back(mary_vector, &code);
    if (!opt_size)
    {
      Mary_Vector_Fit(mary_vector);
    }
  }
  else if (bit_format == 32)
  {
    Mary_Vector_Create(mary_vector, 4, opt_size || 64);
    uint32_t *p = string; uint32_t code = *p;
    for (; code; ++p, code = *p)
    {
      Mary_Vector_Push_Back(mary_vector, &code);
    }
    code = 0; Mary_Vector_Push_Back(mary_vector, &code);
    if (!opt_size)
    {
      Mary_Vector_Fit(mary_vector);
    }
  }
}

void Mary_String_Destroy(Mary_String_t *mary_string)
{
  free(mary_string->data);
}

void Mary_String_Convert(Mary_String_t *mary_string, uint8_t new_bit_format)
{
  uint8_t old_bit_format = (uint8_t)mary_string->unit * 8;
  if (old_bit_format == 8 && new_bit_format == 16)
  {

  }
  else if (old_bit_format == 8 && new_bit_format == 32)
  {
    Mary_String_t s_32bit = Mary_8bit_to_32bit(mary_string);
    free(mary_string->data);
    memcpy(mary_string, &s_32bit, sizeof(Mary_String_t));
  }
  else if (old_bit_format == 16 && new_bit_format == 8)
  {

  }
  else if (old_bit_format == 16 && new_bit_format == 32)
  {

  }
  else if (old_bit_format == 32 && new_bit_format == 8)
  {

  }
  else if (old_bit_format == 32 && new_bit_format == 16)
  {
    Mary_String_t s_16bit = Mary_32bit_to_16bit(mary_string);
    free(mary_string->data);
    memcpy(mary_string, &s_16bit, sizeof(Mary_String_t));
  }
}

Mary_String_t Mary_8bit_to_32bit(Mary_String_t *s_8bit)
{
  Mary_String_t s_32bit;
  Mary_Vector_t *v_32bit = (Mary_Vector_t *)&s_32bit;
  Mary_Vector_Create(v_32bit, 4, s_8bit->size);
  uint8_t *p = s_8bit->data, v = *p; uint32_t a, b, c, d;
  while (1)
  {
    if (v == 0)
    { // last byte
      a = v;
      Mary_Vector_Push_Back(v_32bit, &a);
      break;
    }
    else if (v >> 7 == 0)
    { // 1 byte
      a = v; ++p, v = *p;
      Mary_Vector_Push_Back(v_32bit, &a);
    }
    else if (v >> 5 == 6)
    { // 2 bytes
      a = (v ^ 192) << 6; ++p, v = *p;
      b = (v ^ 128); ++p, v = *p;
      a = a | b;
      Mary_Vector_Push_Back(v_32bit, &a);
    }
    else if (v >> 4 == 14)
    { // 3 bytes
      a = (v ^ 224) << 12; ++p, v = *p;
      b = (v ^ 128) << 6; ++p, v = *p;
      c = (v ^ 128); ++p, v = *p;
      a = a | b | c;
      Mary_Vector_Push_Back(v_32bit, &a);
    }
    else
    { // 4 bytes
      a = (v ^ 240) << 18; ++p, v = *p;
      b = (v ^ 128) << 12; ++p, v = *p;
      c = (v ^ 128) << 6; ++p, v = *p;
      d = (v ^ 128); ++p, v = *p;
      a = a | b | c | d;
      Mary_Vector_Push_Back(v_32bit, &a);
    }
  }
  Mary_Vector_Fit(v_32bit);
  return s_32bit;
}

Mary_String_t Mary_32bit_to_16bit(Mary_String_t *s_32bit)
{
  Mary_String_t s_16bit;
  Mary_Vector_t *v_16bit = (Mary_Vector_t *)&s_16bit;
  Mary_Vector_Create(v_16bit, 2, s_32bit->size);
  uint32_t *p = s_32bit->data, v = *p; uint16_t a, b;
  while (1)
  {
    if (v == 0)
    { // last char
      a = v;
      Mary_Vector_Push_Back(v_16bit, &a);
      break;
    }
    else if (v < 0x10000)
    { // bmp
      a = v; ++p, v = *p;
      Mary_Vector_Push_Back(v_16bit, &a);
    }
    else
    { // surrogate pair
      static const uint32_t low = ~(~0 << 10);
      v -= 0x10000;
      a = (v >> 10) + 0xD800;
      b = (v & low) + 0xDC00;
      ++p, v = *p;
      Mary_Vector_Push_Back(v_16bit, &a);
      Mary_Vector_Push_Back(v_16bit, &b);
    }
  }
  Mary_Vector_Fit(v_16bit);
  return s_16bit;
}

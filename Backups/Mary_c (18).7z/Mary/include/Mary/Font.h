#pragma once

#pragma comment (lib, "freetype_release_static.lib")
#include <ft2build.h>
#include FT_FREETYPE_H
#include <Mary/Hashmap.h>

typedef struct
{
  void *data;
  Mary_Hashmap_t tables;
  FT_Face ft_face;
  uint16_t pixel_size;
}
Mary_Font_t;

void Mary_Font_Start();
void Mary_Font_Finish();
void Mary_Font_Create(Mary_Font_t *mary_font, char *file_path);
void Mary_Font_Destroy(Mary_Font_t *mary_font);
void Mary_Font_Layout(Mary_Font_t *mary_font, uint16_t *utf16_string);

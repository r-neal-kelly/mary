#pragma once

#include <Mary/Utils.h>
#include <Mary/Arena.h>

enum Mary_Memory_Allocator_e
{
  MARY_MEMORY_STACK,
  MARY_MEMORY_HEAP
};

typedef struct
{
  void *(*const alloc)(Mary_Size_t bytes);
  void *(*const calloc)(Mary_Size_t unit, Mary_Size_t units);
  void *(*const realloc)(void *data, Mary_Size_t bytes);
  void (*const dealloc)(void *data);
}
Mary_Memory_i;

void Mary_Memory_Start();
void Mary_Memory_Stop();

void *Mary_Memory_Alloc(Mary_Size_t bytes);
void *Mary_Memory_Calloc(Mary_Size_t unit, Mary_Size_t units);
void *Mary_Memory_Realloc(void *data, Mary_Size_t bytes);
void Mary_Memory_Dealloc(void *data);

#define MARY_Memory_i(NAME)\
  const Mary_Memory_i NAME =\
  {\
    Mary_Memory_Alloc,\
    Mary_Memory_Calloc,\
    Mary_Memory_Realloc,\
    Mary_Memory_Dealloc\
  }

#define MARY_Memory_In\
  enum Mary_Memory_Allocator_e { HEAP, FRAME, CHAIN, ERROR, VAULT };\
  const Mary_Arena_Frame_ID_t MARY_MEMORY_FRAME_ID = Mary_Arena_Push_g()

#define MARY_Memory_Out\
  Mary_Arena_Pop_g(MARY_MEMORY_FRAME_ID)

#define MARY_Memory_Return\
  Mary_Arena_Pop_g(MARY_MEMORY_FRAME_ID); return

#define MARY_Memory_Keep(DATA)\
  Mary_Arena_Keep_g(MARY_MEMORY_FRAME_ID, DATA)

#define MARY_Memory_Keep_Return(DATA)\
  MARY_Memory_Keep(DATA); MARY_Memory_Return DATA

#define MARY_Memory_Alloc(ENUM, BYTES)\
(\
  ENUM == FRAME ? Mary_Arena_Alloc_Frame_g(MARY_MEMORY_FRAME_ID, BYTES) :\
  ENUM == CHAIN ? Mary_Arena_Alloc_Chain_g(MARY_MEMORY_FRAME_ID, BYTES) :\
  ENUM == ERROR ? Mary_Arena_Alloc_Error_g(MARY_MEMORY_FRAME_ID, BYTES) :\
  ENUM == VAULT ? Mary_Arena_Alloc_Vault_g(BYTES) :\
  ENUM == HEAP ? Mary_Memory_Alloc(BYTES) :\
  (MARY_Assert(0, "Invalid allocator"), 0)\
)

#define MARY_Memory_Dealloc(ENUM, BYTES)\
(\
  ENUM == VAULT ? Mary_Arena_Dealloc_Vault_g(BYTES) :\
  ENUM == HEAP ? Mary_Memory_Dealloc(BYTES) :\
  ENUM == CHAIN ? Mary_Arena_Dealloc_Chain_g(MARY_MEMORY_FRAME_ID, BYTES) :\
  ENUM == FRAME ? Mary_Arena_Dealloc_Frame_g(MARY_MEMORY_FRAME_ID, BYTES) :\
  (MARY_Assert(0, "Invalid allocator"), 0)\
)

#include <stdlib.h>
#include <Mary/Memory.h>
#include <Mary/Arena.h>

MARY_Primitives;

void Mary_Memory_Start()
{
  Mary_Arena_Create_g();
}

void Mary_Memory_Stop()
{
  Mary_Arena_Destroy_g();
}

void *Mary_Memory_Alloc(Mary_Size_t bytes)
{
  void *data = malloc(bytes);
  MARY_Assert(data != 0, "Out of memory.");
  return data;
}

void *Mary_Memory_Calloc(Mary_Size_t unit, Mary_Size_t units)
{
  void *data = calloc(units, unit);
  MARY_Assert(data != 0, "Out of memory.");
  return data;
}

void *Mary_Memory_Realloc(void *data, Mary_Size_t bytes)
{
  void *new_data = realloc(data, bytes);
  MARY_Assert(new_data != 0, "Out of memory.");
  return new_data;
}

void Mary_Memory_Dealloc(void *data)
{
  free(data);
}

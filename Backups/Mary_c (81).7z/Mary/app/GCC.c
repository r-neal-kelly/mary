#include <stdio.h>
#include <Mary/Utils.h>
#include <Mary/Regex.h>
#include <Mary/OS.h>
#include <Mary/App/GCC.h>
#include MARY_Vector_Namespace

MARY_Primitives;

// will need to have a func in OS that gives me a directory list
// also, this might be a good time to try out Regex, even though it's not perfect.
// it will be useful in getting the ranges we need to work in our mmake file.

void Mary_GCC_Create_Bat()
{
  // I would also like to have bin, and name of exe in make file.

  Mary_C_String_8_t compiler_path = MARY_C_String(u8, "\"%HOMEDRIVE%/Program Files/mingw-w64/x86_64-8.1.0-win32-seh-rt_v6-rev0/mingw64/bin/gcc\"\n");

  MARY_String(make_file_path, MARY_MEMORY_STACK, u8, "./gcc.mmake");
  //Mary_String_t make_file_path; Mary_String_Create_With_C_String(&make_file_path, MARY_UTF_8, MARY_C_String(u8, "./gcc.mmake"), 12);
  Mary_File_t make_file; Mary_File_String_Create(&make_file, &make_file_path, MARY_FILE_READ, sizeof(u8));
  Mary_Vector_t make_file_lines; Mary_Vector_Create(&make_file_lines, sizeof(Mary_String_t), 0);
  Mary_String_t *make_file_line;
  while (MARY_False(Mary_File_Has_Ended(&make_file)))
  {
    make_file_line = Mary_Vector_Point_Push_Back(&make_file_lines);
    Mary_File_String_Read_Line(&make_file, make_file_line, 0);
  }
  Mary_File_Destroy(&make_file);
  Mary_String_Destroy(&make_file_path);

  Mary_String_t build_debug_str, build_release_str, run_debug_str, run_release_str;

  Mary_String_Create(&build_debug_str, 8, 256); // might be faster if we make these 16bit, and then do the conversion before file transfer.
  Mary_String_Create(&build_release_str, 8, 256);
  Mary_String_Create(&run_debug_str, 8, 256);
  Mary_String_Create(&run_release_str, 8, 256);

  Mary_String_Append_C_String(&build_debug_str, MARY_C_String(u8, "@echo off\n"), MARY_UTF_8, 11);
  Mary_String_Append_C_String(&build_debug_str, MARY_C_String(u8, "set GCC="), MARY_UTF_8, 9);
  Mary_String_Append_C_String(&build_debug_str, compiler_path, MARY_UTF_8, 89);
  Mary_String_Append_C_String(&build_debug_str, MARY_C_String(u8, "if not exist \"bin/debug\" mkdir \"bin/debug\"\n"), MARY_UTF_8, 43);
  Mary_String_Append_C_String(&build_debug_str, MARY_C_String(u8, "@echo on\n"), MARY_UTF_8, 10);
  Mary_String_Append_C_String(&build_debug_str, MARY_C_String(u8, "%GCC% -O0 -Wall "), MARY_UTF_8, 17);

  // this is a hack just to get includes and srcs in there.
  Mary_String_Append_C_String(&build_debug_str, MARY_C_String(u8, "-I ./Mary/include "), MARY_UTF_8, 17);

  Mary_String_t src_path; Mary_String_Create_With_C_String(&src_path, MARY_UTF_16, MARY_C_String(u16, "./Mary/src/"), 0);
  Mary_OS_Directory_t src_dir; Mary_OS_Directory_Create(&src_dir, &src_path);
  MARY_Vector_Each(&src_dir.items, Mary_OS_Directory_Item_t)
  {
    Mary_String_Append_C_String(&build_debug_str, MARY_C_String(u8, "./Mary/src/"), MARY_UTF_8, 1); // these are the same as path. but we haven't got the right func yet.
    Mary_String_Append_C_String(&build_debug_str, it.ptr->name.data, MARY_UTF_16, it.ptr->name.bytes / sizeof(u16));
    Mary_String_Append_C_String(&build_debug_str, MARY_C_String(u8, " "), MARY_UTF_8, 1);
  }
  Mary_OS_Directory_Destroy(&src_dir);

  Mary_String_t app_path; Mary_String_Create_With_C_String(&app_path, MARY_UTF_16, MARY_C_String(u16, "./Mary/app/"), 0);
  Mary_OS_Directory_t app_dir; Mary_OS_Directory_Create(&app_dir, &app_path);
  MARY_Vector_Each(&app_dir.items, Mary_OS_Directory_Item_t)
  {
    Mary_String_Append_C_String(&build_debug_str, MARY_C_String(u8, "./Mary/app/"), MARY_UTF_8, 1);
    Mary_String_Append_C_String(&build_debug_str, it.ptr->name.data, MARY_UTF_16, it.ptr->name.bytes / sizeof(u16));
    Mary_String_Append_C_String(&build_debug_str, MARY_C_String(u8, " "), MARY_UTF_8, 1);
  }
  Mary_OS_Directory_Destroy(&app_dir);

  Mary_String_Append_C_String(&build_debug_str, MARY_C_String(u8, "-o bin/debug/main\n"), MARY_UTF_8, 19);

  printf("%s\n", (u8 *)build_debug_str.data);

  Mary_String_t build_debug_path; Mary_String_Create_With_Stack(&build_debug_path, MARY_UTF_8, MARY_C_String(u8, "build_debug.bat"));
  Mary_File_t build_debug_file; Mary_File_String_Create(&build_debug_file, &build_debug_path, MARY_FILE_WRITE, sizeof(u8));
  Mary_File_String_Write_All(&build_debug_file, &build_debug_str);
  Mary_File_Destroy(&build_debug_file);

  Mary_String_Destroy(&build_debug_str);
  Mary_String_Destroy(&build_release_str);
  Mary_String_Destroy(&run_debug_str);
  Mary_String_Destroy(&run_release_str);

  MARY_Vector_Each(&make_file_lines, Mary_String_t)
  {
    Mary_String_Destroy(it.ptr);
  }
  Mary_Vector_Destroy(&make_file_lines);

  Mary_Exit_Success();
}

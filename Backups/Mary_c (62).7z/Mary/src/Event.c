#include <Mary/Event.h>
#include <Mary/Window.h>

MARY_PRIMITIVES;

typedef void (*Event_f)(void *);

typedef struct
{
  size_t bytes;
}
Type_Info;

static Mary_Vector_t type_infos;

void Mary_Event_Start()
{
  Type_Info type_info;
  Mary_Vector_Create(&type_infos, sizeof(Type_Info), 3); // make sure to increase the reserve size

  #define TYPE_INFO(TYPE)                           \
    type_info = (Type_Info)                         \
    {                                               \
      sizeof(Mary_Event_##TYPE##_t)                 \
    };                                              \
    Mary_Vector_Push_Back(&type_infos, &type_info)

  TYPE_INFO(Keyboard);
  TYPE_INFO(Mouse);
  TYPE_INFO(Mousewheel);

  #undef TYPE_INFO
}

void Mary_Event_Finish()
{
  Mary_Vector_Destroy(&type_infos);
}

void *Mary_Event_Create(Mary_Window_t *window, int enum_mary_event)
{
  Type_Info *info = Mary_Vector_Point(&type_infos, enum_mary_event);
  Mary_Event_t *event = Mary_Pool_Allocate(&window->event_pool, info->bytes);
  event->type = enum_mary_event;
  event->target = 0;
  event->capture = MARY_EVENT_CAPTURE_BUBBLE;
  Mary_Vector_Push_Back(&window->messages, &event);
  return event;
}

void Mary_Event_Dispatch(void *mary_event, void *mary_element_target)
{
  Mary_Event_t *event = MARY_Event(mary_event);
  Mary_Element_t *target = MARY_Element(mary_element_target);
  event->target = target;
  Mary_Element_Event(target, event);
}

void Mary_Event_Bubble(Mary_Event_t *event, void *mary_element)
{
  Mary_Element_t *elem = MARY_Element(mary_element);
  if (elem->parent != 0)
  {
    Mary_Element_Event(elem->parent, event);
  }
}

void Mary_Event_Trickle(Mary_Event_t *event, void *mary_element)
{
  Mary_Element_t *elem = MARY_Element(mary_element);
  MARY_Vector_Each(&elem->children_s, Mary_Element_t *)
  {
    Mary_Element_Event(range.val, event);
  }
}

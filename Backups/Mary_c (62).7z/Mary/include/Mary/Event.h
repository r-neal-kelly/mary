#pragma once

#include <Mary/Element.h>

enum
{
  MARY_EVENT_KEYBOARD,
  MARY_EVENT_MOUSE,
  MARY_EVENT_MOUSEWHEEL
};

enum
{
  MARY_EVENT_CAPTURE_BUBBLE,
  MARY_EVENT_CAPTURE_TRICKLE
};

typedef struct Mary_Event_Keyboard_t Mary_Event_Keyboard_t;
typedef struct Mary_Event_Mouse_t Mary_Event_Mouse_t;
typedef struct Mary_Event_Mousewheel_t Mary_Event_Mousewheel_t;

#define MARY_Event_t\
  int type;\
  Mary_Element_t *target;\
  int capture

struct Mary_Event_t
{
  MARY_Event_t;
};

struct Mary_Event_Keyboard_t
{
  MARY_Event_t;
  uint32_t key;
};

struct Mary_Event_Mouse_t
{
  MARY_Event_t;
  uint8_t button;
};

struct Mary_Event_Mousewheel_t
{
  MARY_Event_t;
  int16_t delta, key, x, y;
};

void Mary_Event_Start();
void Mary_Event_Finish();
void *Mary_Event_Create(Mary_Window_t *window, int enum_mary_event);
void Mary_Event_Dispatch(void *mary_event, void *mary_element_target);
void Mary_Event_Bubble(Mary_Event_t *event, void *mary_element);
void Mary_Event_Trickle(Mary_Event_t *event, void *mary_element);

#define MARY_Event(PTR) ((Mary_Event_t *)(PTR))

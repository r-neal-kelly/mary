#pragma once

void Mary_Exit_Success();
void Mary_Exit_Failure(const char *error_string);

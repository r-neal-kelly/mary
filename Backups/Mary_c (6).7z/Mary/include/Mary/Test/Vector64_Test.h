#pragma once

#include <stdio.h>
#include <stdint.h>
#include <limits.h>
#include <Mary/Utils.h>
#include <Mary/Vector64.h>

void Mary_Vector64_Test();

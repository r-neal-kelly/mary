#pragma once

//#include <GL/GL.h>
//#include <gl/GLU.h>
#include <stdint.h>
#include <Mary/OS.h>

#define WGL_DRAW_TO_WINDOW_ARB 0x2001
#define WGL_SUPPORT_OPENGL_ARB 0x2010
#define WGL_DOUBLE_BUFFER_ARB  0x2011
#define WGL_PIXEL_TYPE_ARB     0x2013
#define WGL_COLOR_BITS_ARB     0x2014
#define WGL_DEPTH_BITS_ARB     0x2022
#define WGL_STENCIL_BITS_ARB   0x2023
#define WGL_TYPE_RGBA_ARB      0x202B
#define WGL_SAMPLE_BUFFERS_ARB 0x2041
#define WGL_SAMPLES_ARB        0x2042

#define GL_FALSE 0x0000
#define GL_TRUE  0x0001

#define GL_VENDOR     0x1F00
#define GL_RENDERER   0x1F01
#define GL_VERSION    0x1F02
#define GL_EXTENSIONS 0x1F03

#define GL_COLOR_BUFFER_BIT   0x4000
#define GL_DEPTH_BUFFER_BIT   0x0100
#define GL_STENCIL_BUFFER_BIT 0x0400

typedef uint8_t  GLubyte;
typedef uint32_t GLenum;
typedef uint32_t GLbitfield;
typedef float    GLfloat;
typedef int32_t  GLint;
typedef uint32_t GLsizei; // maybe int32_t

BOOL (WINAPI *wglChoosePixelFormatARB)(HDC hdc, const int *piAttribIList, const FLOAT *pfAttribFList, UINT nMaxFormats, int *piFormats, UINT *nNumFormats);

const GLubyte *(WINAPI *glGetString) (GLenum name);
      void     (WINAPI *glViewport)  (GLint x, GLint y, GLsizei width, GLsizei height);
      void     (WINAPI *glClearColor)(GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha);
      void     (WINAPI *glClear)     (GLbitfield mask);

typedef struct
{
  const HGLRC context;
  const int pixel_format;
}
Mary_OpenGL_g;

void Mary_OpenGL_Start();
void Mary_OpenGL_Finish();
const Mary_OpenGL_g Mary_OpenGL();

#pragma once

#include <Mary/Element.h>

#define MARY_EVENT_TYPES 5

enum
{
  MARY_EVENT_KEYDOWN,
  MARY_EVENT_MOUSEDOWN,
  MARY_EVENT_MOUSEUP,
  MARY_EVENT_MOUSECLICK,
  MARY_EVENT_MOUSEWHEEL
};

enum
{
  MARY_EVENT_MOUSE_LEFT,
  MARY_EVENT_MOUSE_MIDDLE,
  MARY_EVENT_MOUSE_RIGHT
};

typedef struct Mary_Event_t Mary_Event_t;
typedef struct Mary_Event_Keydown_t Mary_Event_Keydown_t;
typedef struct Mary_Event_Mousedown_t Mary_Event_Mousedown_t;
typedef struct Mary_Event_Mouseup_t Mary_Event_Mouseup_t;
typedef struct Mary_Event_Mouseclick_t Mary_Event_Mouseclick_t;
typedef struct Mary_Event_Mousewheel_t Mary_Event_Mousewheel_t;

#define MARY_Event_t\
  uint32_t type;\
  Mary_Element_t *target, *current;\
  uint8_t canceled, skipped, stopped, defaulted

struct Mary_Event_t
{
  MARY_Event_t;
};

struct Mary_Event_Keydown_t
{
  MARY_Event_t;
  uint32_t key;
};

struct Mary_Event_Mousedown_t
{
  MARY_Event_t;
  int16_t button, key, x, y;
};

struct Mary_Event_Mouseup_t
{
  MARY_Event_t;
  int16_t button, key, x, y;
};

struct Mary_Event_Mouseclick_t
{
  MARY_Event_t;
  int16_t button, key, x, y;
};

struct Mary_Event_Mousewheel_t
{
  MARY_Event_t;
  int16_t delta, key, x, y;
};

typedef void (*Mary_Event_f)(Mary_Event_t *);
typedef struct Mary_Event_Listener_t Mary_Event_Listener_t;

struct Mary_Event_Listener_t
{
  Mary_Event_f function;
  uint8_t capture, once;
};

void Mary_Event_Start();
void Mary_Event_Finish();
void *Mary_Event_Create(Mary_Window_t *window, int enum_mary_event);
void Mary_Event_Create_Listeners(Mary_Vector_t *listeners);
void Mary_Event_Destroy_Listeners(Mary_Vector_t *listeners);
void Mary_Event_Dispatch(void *mary_event, void *mary_element_target);
void Mary_Event_Cancel(void *mary_event); // cancels event and any further listeners completely
void Mary_Event_Skip_Current(void *mary_event); // skips events on the same element, but only after itself
void Mary_Event_Stop_Propagation(void *mary_event); // stops capture phase and bubbling phase
void Mary_Event_Disable_Default(void *mary_event); // disables any default behavior, if present
void Mary_Event_Add_Listener(void *mary_element, int enum_mary_event, Mary_Event_f func, char capture, char once);
void Mary_Event_Del_Listener(void *mary_element, int enum_mary_event, Mary_Event_f func, char capture, char once);
void Mary_Event_Empty_Listeners(void *mary_element, int enum_mary_event);

#define MARY_Event(PTR) ((Mary_Event_t *)(PTR))
#define MARY_Event_Mousedown(PTR) ((Mary_Event_Mousedown_t *)(PTR))
#define MARY_Event_Mouseclick(PTR) ((Mary_Event_Mouseclick_t *)(PTR))



#undef Vector_t

#undef Vector_Create
#undef Vector_Create_At
#undef Vector_Create_With
#undef Vector_Repurpose
#undef Vector_Repurpose_With
#undef Vector_Copy
#undef Vector_Destroy
#undef Vector_Reserve
#undef Vector_Grow
#undef Vector_Fit
#undef Vector_Push_At
#undef Vector_Pop_At
#undef Vector_Erase
#undef Vector_Erase_At
#undef Vector_Index_Of
#undef Vector_Index_Of_Reverse

#undef VECTOR_Static
#undef VECTOR_Stack
#undef VECTOR_Heap
#undef VECTOR_Pool
#undef VECTOR_Frame
#undef VECTOR_Chain
#undef VECTOR_Heap_p
#undef VECTOR_Pool_p
#undef VECTOR_Frame_p
#undef VECTOR_Chain_p
#undef VECTOR_Has_Index
#undef VECTOR_Is_Empty
#undef VECTOR_Point
#undef VECTOR_Point_Front
#undef VECTOR_Point_Back
#undef VECTOR_Point_End
#undef VECTOR_At
#undef VECTOR_At_Front
#undef VECTOR_At_Back
#undef VECTOR_Push
#undef VECTOR_Pop
#undef VECTOR_Point_Push
#undef VECTOR_Point_Pop
#undef VECTOR_Empty
#undef VECTOR_Cast
#undef VECTOR_Each
#undef VECTOR_Each_Reverse

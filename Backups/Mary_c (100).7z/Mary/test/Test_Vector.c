#include <Mary/Utils.h>
#include <Mary/Vector.h>
#include <Mary/Arena.h>
#include <Mary/Test/Test.h>
#include MARY_Vector_Namespace

MARY_Primitives;

static void Test_Vector_Create_A();
static void Test_Vector_Create_B();
static void Test_Vector_Loops();

void Test_Vector()
{
    Test_Vector_Create_A();
    Test_Vector_Loops();
}

static void Test_Vector_Create_A()
{

}

static void Test_Vector_Create_B()
{

}

static void Test_Vector_Loops()
{

}

#include <Mary/OS.h>
#include <Mary/Memory.h>
#include <Mary/Hashmap.h>
#include <Mary/Arena.h>

MARY_Primitives;

typedef struct
{
  Mary_Vector_t allocs;
  Mary_Vector_t errors;
}
Mary_Arena_Frame_t;

static Mary_Hashmap_t global_arenas;

void Mary_Arena_Start()
{
  Mary_Hashmap_Create(&global_arenas, sizeof(u64), sizeof(Mary_Arena_t));
}

void Mary_Arena_Stop()
{
  Mary_Hashmap_Destroy(&global_arenas);
}

void Mary_Arena_Create(Mary_Size_t bytes)
{
  u64 arena_id = Mary_OS_Thread_Current_ID();
  MARY_Assert(!Mary_Hashmap_Contains_Key(&global_arenas, &arena_id),
              "Thread's arena already created.");
  Mary_Arena_t arena;
  arena.pool = Mary_Pool_Create(bytes);
  Mary_Vector_Create(&arena.vault, sizeof(void *), 8);
  Mary_Vector_Create(&arena.frames, sizeof(Mary_Arena_Frame_t), 8);
  Mary_Hashmap_Assign(&global_arenas, &arena_id, &arena);
}

void Mary_Arena_Destroy()
{
  u64 arena_id = Mary_OS_Thread_Current_ID();
  MARY_Assert(Mary_Hashmap_Contains_Key(&global_arenas, &arena_id),
              "Thread's arena never created.");
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

  MARY_Assert(arena->frames.units == 0, "There are still unpopped frames.");

  Mary_Vector_Destroy(&arena->frames);

  MARY_Vector_Each(&arena->vault, void *)
  {
    if (Mary_Pool_Has_Data(arena->pool, it.val))
    {
      Mary_Pool_Deallocate(arena->pool, it.val);
    }
    else
    {
      Mary_Memory_Dealloc(it.val);
    }
  }
  Mary_Vector_Destroy(&arena->vault);

  Mary_Pool_Destroy(arena->pool);

  Mary_Hashmap_Erase(&global_arenas, &arena_id);
}

Mary_Arena_Frame_id Mary_Arena_Push()
{
  // if we work some more on pool, add a realloc to it, and some on vector, add a realloc func ptr, then we can prob. put
  // these vectos on the pool as well, which is better by far than allocing heap each function.
  // there is also the potential of using the stack to store the vectors, through a macro
  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

  Mary_Arena_Frame_t *frame = Mary_Vector_Point_Push_Back(&arena->frames);
  Mary_Vector_Create(&frame->allocs, sizeof(void *), 8);
  Mary_Vector_Create(&frame->errors, sizeof(Mary_Error_t *), 1);
  return MARY_Vector_Point_Back(&arena->frames);
}

void Mary_Arena_Pop(Mary_Arena_Frame_id frame_id)
{
  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

  Mary_Arena_Frame_t *frame = Mary_Vector_Point_Pop_Back(&arena->frames);

  MARY_Assert(frame != 0, "No frames available.");
  MARY_Assert(frame == frame_id, "Invalid frame_id. Check for an unpopped frame.");
  MARY_Assert(frame->errors.units == 0, "Unhandled error in arena!");

  MARY_Vector_Each(&frame->allocs, void *)
  {
    if (Mary_Pool_Has_Data(arena->pool, it.val))
    {
      Mary_Pool_Deallocate(arena->pool, it.val);
    }
    else
    {
      Mary_Memory_Dealloc(it.val);
    }
  }
  Mary_Vector_Destroy(&frame->allocs);

  MARY_Vector_Each(&frame->errors, void *)
  {
    if (Mary_Pool_Has_Data(arena->pool, it.val))
    {
      Mary_Pool_Deallocate(arena->pool, it.val);
    }
    else
    {
      Mary_Memory_Dealloc(it.val);
    }
  }
  Mary_Vector_Destroy(&frame->errors);
}

// should we assert in these when the data ptr is null?
void *Mary_Arena_Alloc_Frame(Mary_Arena_Frame_id frame_id, Mary_Size_t bytes)
{
  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

  Mary_Arena_Frame_t *frame = MARY_Vector_Point_Back(&arena->frames);

  MARY_Assert(frame != 0, "No frames available.");
  MARY_Assert(frame == frame_id, "Invalid frame_id. Check for an unpopped frame.");

  void *data;

  if (Mary_Pool_Has_Free(arena->pool, bytes))
  {
    data = Mary_Pool_Allocate(arena->pool, bytes);
  }
  else
  {
    data = Mary_Memory_Alloc(bytes);
  }

  MARY_Assert(data != 0, "Out of memory.");

  Mary_Vector_Push_Back(&frame->allocs, &data);

  return data;
}

void *Mary_Arena_Alloc_Chain(Mary_Arena_Frame_id frame_id, Mary_Size_t bytes)
{
  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

  Mary_Arena_Frame_t *frame = MARY_Vector_Point_Back(&arena->frames);
  Mary_Arena_Frame_t *chain = MARY_Vector_Point(&arena->frames, arena->frames.units - 2);

  MARY_Assert(frame != 0, "No frames available.");
  MARY_Assert(chain != 0, "No chain available.");
  MARY_Assert(frame == frame_id, "Invalid frame_id. Check for an unpopped frame.");

  void *data;

  if (Mary_Pool_Has_Free(arena->pool, bytes))
  {
    data = Mary_Pool_Allocate(arena->pool, bytes);
  }
  else
  {
    data = Mary_Memory_Alloc(bytes);
  }

  MARY_Assert(data != 0, "Out of memory.");

  Mary_Vector_Push_Back(&chain->allocs, &data);

  return data;
}

void *Mary_Arena_Alloc_Error(Mary_Arena_Frame_id frame_id, Mary_Size_t bytes)
{
  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

  Mary_Arena_Frame_t *frame = MARY_Vector_Point_Back(&arena->frames);
  Mary_Arena_Frame_t *chain = MARY_Vector_Point(&arena->frames, arena->frames.units - 2);

  MARY_Assert(frame != 0, "No frames available.");
  MARY_Assert(chain != 0, "No chain available.");
  MARY_Assert(frame == frame_id, "Invalid frame_id. Check for an unpopped frame.");

  void *data;

  if (Mary_Pool_Has_Free(arena->pool, bytes))
  {
    data = Mary_Pool_Allocate(arena->pool, bytes);
  }
  else
  {
    data = Mary_Memory_Alloc(bytes);
  }

  MARY_Assert(data != 0, "Out of memory.");

  Mary_Vector_Push_Back(&chain->errors, &data);

  return data;
}

void *Mary_Arena_Alloc_Vault(Mary_Size_t bytes)
{
  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

  void *data;

  if (Mary_Pool_Has_Free(arena->pool, bytes))
  {
    data = Mary_Pool_Allocate(arena->pool, bytes);
  }
  else
  {
    data = Mary_Memory_Alloc(bytes);
  }

  MARY_Assert(data != 0, "Out of memory.");

  Mary_Vector_Push_Back(&arena->vault, &data);

  return data;
}

void Mary_Arena_Dealloc_Frame(Mary_Arena_Frame_id frame_id, void *data)
{
  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

  Mary_Arena_Frame_t *frame = MARY_Vector_Point_Back(&arena->frames);

  MARY_Assert(frame != 0, "No frames available.");
  MARY_Assert(frame == frame_id, "Invalid frame_id. Check for an unpopped frame.");

  Mary_Bool_t was_found; Mary_Index_t idx =
    Mary_Vector_Index_Of_Reverse(&frame->allocs, data, &was_found);

  MARY_Assert(was_found == MARY_TRUE, "Couldn't find pointer.");

  Mary_Vector_Erase_At(&frame->allocs, idx);

  if (Mary_Pool_Has_Data(arena->pool, data))
  {
    Mary_Pool_Deallocate(arena->pool, data);
  }
  else
  {
    Mary_Memory_Dealloc(data);
  }
}

void Mary_Arena_Dealloc_Chain(Mary_Arena_Frame_id frame_id, void *data)
{
  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

  Mary_Arena_Frame_t *frame = MARY_Vector_Point_Back(&arena->frames);
  Mary_Arena_Frame_t *chain = MARY_Vector_Point(&arena->frames, arena->frames.units - 2);

  MARY_Assert(frame != 0, "No frames available.");
  MARY_Assert(chain != 0, "No chain available.");
  MARY_Assert(frame == frame_id, "Invalid frame_id. Check for an unpopped frame.");

  Mary_Bool_t was_found; Mary_Index_t idx =
    Mary_Vector_Index_Of_Reverse(&chain->allocs, data, &was_found);

  MARY_Assert(was_found == MARY_TRUE, "Couldn't find pointer.");

  Mary_Vector_Erase_At(&chain->allocs, idx);

  if (Mary_Pool_Has_Data(arena->pool, data))
  {
    Mary_Pool_Deallocate(arena->pool, data);
  }
  else
  {
    Mary_Memory_Dealloc(data);
  }
}

void Mary_Arena_Dealloc_Vault(void *data)
{
  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

  Mary_Bool_t was_found; Mary_Index_t idx =
    Mary_Vector_Index_Of_Reverse(&arena->vault, data, &was_found);

  MARY_Assert(was_found == MARY_TRUE, "Couldn't find pointer.");

  Mary_Vector_Erase_At(&arena->vault, idx);

  if (Mary_Pool_Has_Data(arena->pool, data))
  {
    Mary_Pool_Deallocate(arena->pool, data);
  }
  else
  {
    Mary_Memory_Dealloc(data);
  }
}

void *Mary_Arena_Alloc(Mary_Enum_t zone, Mary_Arena_Frame_id frame_id, Mary_Size_t bytes)
{
  if (zone == MARY_ARENA_FRAME)
  {
    return Mary_Arena_Alloc_Frame(frame_id, bytes);
  }
  else if (zone == MARY_ARENA_CHAIN)
  {
    return Mary_Arena_Alloc_Chain(frame_id, bytes);
  }
  else if (zone == MARY_ARENA_ERROR)
  {
    return Mary_Arena_Alloc_Error(frame_id, bytes);
  }
  else if (zone == MARY_ARENA_VAULT)
  {
    return Mary_Arena_Alloc_Vault(bytes);
  }
  else
  {
    MARY_Assert(0, "Invalid zone.");
    return 0;
  }
}

void Mary_Arena_Dealloc(Mary_Enum_t zone, Mary_Arena_Frame_id frame_id, void *data)
{
  if (zone == MARY_ARENA_VAULT)
  {
    Mary_Arena_Dealloc_Vault(data);
  }
  else if (zone == MARY_ARENA_CHAIN)
  {
    Mary_Arena_Dealloc_Chain(frame_id, data);
  }
  else if (zone == MARY_ARENA_FRAME)
  {
    Mary_Arena_Dealloc_Frame(frame_id, data);
  }
  else
  {
    MARY_Assert(0, "Invalid zone.");
  }
}

void Mary_Arena_Chain(Mary_Arena_Frame_id frame_id, void *data)
{
  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

  Mary_Arena_Frame_t *frame = MARY_Vector_Point_Back(&arena->frames);
  Mary_Arena_Frame_t *chain = MARY_Vector_Point(&arena->frames, arena->frames.units - 2);

  MARY_Assert(frame != 0, "No frames available.");
  MARY_Assert(chain != 0, "No chain available.");
  MARY_Assert(frame == frame_id, "Invalid frame_id. Check for an unpopped frame.");

  Mary_Bool_t was_found; Mary_Index_t idx =
    Mary_Vector_Index_Of_Reverse(&frame->allocs, data, &was_found);

  MARY_Assert(was_found == MARY_TRUE, "Couldn't find pointer.");

  Mary_Vector_Erase_At(&frame->allocs, idx);

  Mary_Vector_Push_Back(&chain->allocs, &data);
}

void Mary_Arena_Empty(Mary_Arena_t *arena)
{
  // need to check that there are no frames present.
}

#pragma once

#include <Mary/Memory.h>
#include <Mary/Vector.h>

typedef struct Mary_Pool_t Mary_Pool_t;

struct Mary_Pool_t
{
  MARY_Pointer_t;
  Mary_Size_t free;
  Mary_Vector_t index; // consider making this always go on the pool. or at least an option for user?
};

Mary_Pool_t *Mary_Pool_Create(Mary_Size_t bytes);
void Mary_Pool_Create_At(Mary_Pool_t *pool, Mary_p with_ptr, Mary_p with_idx); // this is only being used by the At_Stack macro below.
void Mary_Pool_Destroy(Mary_Pool_t *pool);
void *Mary_Pool_Allocate(Mary_Pool_t *pool, Mary_Size_t bytes); // rename these to be more consist. add Calloc
void *Mary_Pool_Reallocate(Mary_Pool_t *pool, void *data, Mary_Size_t bytes);
void Mary_Pool_Deallocate(Mary_Pool_t *pool, void *data);
void Mary_Pool_Empty(Mary_Pool_t *pool);
Mary_Bool_t Mary_Pool_Has_Data(Mary_Pool_t *pool, void *data);
Mary_Bool_t Mary_Pool_Has_Free(Mary_Pool_t *pool, Mary_Size_t bytes);
// might be cool to have a func that returns a vector of ptrs to each value in pool.

#define MARY_Pool_Round(BYTES)\
  MARY_Round_to_64bit(BYTES)

#define MARY_Pool_Create_At_Stack(POOL, BYTES, BYTES_IDX)\
  uint8_t POOL##_ary[MARY_Pool_Round(BYTES)], POOL##_idx[MARY_Pool_Round(BYTES_IDX)];\
  Mary_Pool_Create_At(&POOL, (Mary_p) { POOL##_ary, sizeof(POOL##_ary) },\
                             (Mary_p) { POOL##_idx, sizeof(POOL##_idx) })

#define MARY_Pool_Has_Free(POOL, BYTES)\
  ( (POOL)->free >= MARY_Pool_Round(bytes) )

#if 0
typedef struct
{
  MARY_Vector_t;
  Mary_Pool_t *pool;
}
Mary_Pool_Vector_t;

void Mary_Pool_Vector_Create(Mary_Pool_Vector_t *vector, Mary_Pool_t *pool, Mary_Size_t unit, Mary_Size_t opt_reserve_units);
void Mary_Pool_Vector_Destroy(Mary_Pool_Vector_t *vector);
void Mary_Pool_Vector_Reserve(Mary_Pool_Vector_t *vector, Mary_Size_t units);
void Mary_Pool_Vector_Push_Back(Mary_Pool_Vector_t *vector, void *in_elem);
void *Mary_Pool_Vector_Point_Push_Back(Mary_Pool_Vector_t *vector);
extern void *(*const Mary_Pool_Vector_Point)(Mary_Pool_Vector_t *vector, Mary_Index_t index);
extern void *(*const Mary_Pool_Vector_Point_Pop_Back)(Mary_Pool_Vector_t *vector);
extern Mary_Index_t (*const Mary_Pool_Vector_Index_Of_Reverse)(Mary_Pool_Vector_t *vector, void *elem, Mary_Bool_t *out_was_found);
extern void (*const Mary_Pool_Vector_Erase_At)(Mary_Pool_Vector_t *vector, Mary_Index_t index);
#endif

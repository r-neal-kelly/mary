#pragma once

#include <Mary/Utils.h>

typedef struct Mary_Pool_t Mary_Pool_t;
typedef struct Mary_Arena_t Mary_Arena_t;

enum Mary_Memory_Allocator_e
{
  MARY_STACK,
  MARY_HEAP,
  MARY_POOL,
  MARY_ARENA,
  MARY_FRAME,
  MARY_CHAIN,
  MARY_VAULT,
  MARY_ERROR
};

void Mary_Memory_Start();
void Mary_Memory_Stop();

Mary_Pool_t *Mary_Memory_Pool();

typedef struct
{
  void *(*const alloc)(Mary_Size_t bytes);
  void *(*const calloc)(Mary_Size_t unit, Mary_Size_t units);
  void *(*const realloc)(void *data, Mary_Size_t bytes);
  void (*const dealloc)(void *data);
}
Mary_Memory_i;

void *Mary_Memory_Alloc(Mary_Size_t bytes);
void *Mary_Memory_Calloc(Mary_Size_t unit, Mary_Size_t units);
void *Mary_Memory_Realloc(void *data, Mary_Size_t bytes);
void Mary_Memory_Dealloc(void *data);

#define MARY_Memory_i(NAME)\
  const Mary_Memory_i NAME =\
  {\
    Mary_Memory_Alloc,\
    Mary_Memory_Calloc,\
    Mary_Memory_Realloc,\
    Mary_Memory_Dealloc\
  }

#define MARY_Allocator_t\
  Mary_Enum_8_t type

typedef struct
{
  MARY_Allocator_t;
}
Mary_Allocator_Stack_t,
Mary_Allocator_Heap_t;

typedef struct
{
  MARY_Allocator_t;
  Mary_Enum_8_t pool;
}
Mary_Allocator_Pool_t;

typedef struct
{
  MARY_Allocator_t;
  Mary_Enum_8_t zone;
}
Mary_Allocator_Arena_t;

typedef union
{
  MARY_Allocator_t;
  Mary_Allocator_Stack_t stack;
  Mary_Allocator_Heap_t heap;
  Mary_Allocator_Pool_t pool;
  Mary_Allocator_Arena_t arena;
}
Mary_Allocator_u;

Mary_Allocator_u Mary_Allocator_Create(Mary_Enum_t type);
void Mary_Allocator_Destroy(Mary_Allocator_u allocator);
void *Mary_Allocator_Alloc(Mary_Allocator_u allocator, Mary_Size_t bytes); // make sure that when you branch the types, that you copy out the u8 to a u64 first.
void *Mary_Allocator_Calloc(Mary_Allocator_u allocator, Mary_Size_t unit, Mary_Size_t units);
void *Mary_Allocator_Realloc(Mary_Allocator_u allocator, void *data, Mary_Size_t bytes);
void Mary_Allocator_Dealloc(Mary_Allocator_u allocator, void *data);

#pragma once

#include <Mary/Utils.h>
#include <Mary/Vector.h>
#include <Mary/Pool.h>

#define MARY_ARENA_GLOBAL_BYTES 0x300000

enum Mary_Arena_Zone_e
{
  MARY_ARENA_FRAME,
  MARY_ARENA_CHAIN,
  MARY_ARENA_VAULT,
  MARY_ARENA_ERROR
};

typedef struct Mary_Arena_t Mary_Arena_t;

struct Mary_Arena_t
{
  Mary_Pool_t *pool;
  Mary_Vector_t vault;
  Mary_Vector_t frames;
};

typedef void *Mary_Arena_Frame_id; // consider casting to u64

void Mary_Arena_Start();
void Mary_Arena_Stop();

void Mary_Arena_Create();
void Mary_Arena_Destroy();
Mary_Arena_Frame_id Mary_Arena_Push();
void Mary_Arena_Pop(Mary_Arena_Frame_id frame_id);
void *Mary_Arena_Alloc_Frame(Mary_Arena_Frame_id frame_id, Mary_Size_t bytes);
void *Mary_Arena_Alloc_Chain(Mary_Arena_Frame_id frame_id, Mary_Size_t bytes);
void *Mary_Arena_Alloc_Error(Mary_Arena_Frame_id frame_id, Mary_Size_t bytes);
void *Mary_Arena_Alloc_Vault(Mary_Size_t bytes); // Safe instead of Vault?
void Mary_Arena_Dealloc_Frame(Mary_Arena_Frame_id frame_id, void *data);
void Mary_Arena_Dealloc_Chain(Mary_Arena_Frame_id frame_id, void *data);
void Mary_Arena_Dealloc_Vault(void *data);
void *Mary_Arena_Alloc(Mary_Enum_t zone, Mary_Arena_Frame_id frame_id, Mary_Size_t bytes);
void Mary_Arena_Dealloc(Mary_Enum_t zone, Mary_Arena_Frame_id frame_id, void *data);
void Mary_Arena_Chain(Mary_Arena_Frame_id frame_id, void *data);
void Mary_Arena_Empty(); // clears the entire allocation both in pool and in heap.

#define MARY_Arena_In\
  enum Mary_Arena_Zone_e { HEAP, FRAME, CHAIN, ERROR, VAULT };\
  const Mary_Arena_Frame_id MARY_ARENA_FRAME_ID = Mary_Arena_Push()

#define MARY_Arena_Out\
  Mary_Arena_Pop(MARY_ARENA_FRAME_ID)

#define MARY_Arena_Return\
  MARY_Arena_Out; return

#define MARY_Arena_Chain(DATA)\
  Mary_Arena_Chain(MARY_ARENA_FRAME_ID, DATA)

#define MARY_Arena_Chain_Return(DATA)\
  MARY_Arena_Chain(DATA); MARY_Arena_Out; return DATA

#define MARY_Arena_Alloc(ENUM, BYTES)\
(\
  ENUM == FRAME ? Mary_Arena_Alloc_Frame(MARY_ARENA_FRAME_ID, BYTES) :\
  ENUM == CHAIN ? Mary_Arena_Alloc_Chain(MARY_ARENA_FRAME_ID, BYTES) :\
  ENUM == ERROR ? Mary_Arena_Alloc_Error(MARY_ARENA_FRAME_ID, BYTES) :\
  ENUM == VAULT ? Mary_Arena_Alloc_Vault(BYTES) :\
  ENUM == HEAP ? Mary_Memory_Alloc(BYTES) :\
  (MARY_Assert(0, "Invalid allocator"), 0)\
)

#define MARY_Arena_Dealloc(ENUM, BYTES)\
(\
  ENUM == VAULT ? Mary_Arena_Dealloc_Vault_g(BYTES) :\
  ENUM == HEAP ? Mary_Memory_Dealloc(BYTES) :\
  ENUM == CHAIN ? Mary_Arena_Dealloc_Chain(MARY_ARENA_FRAME_ID, BYTES) :\
  ENUM == FRAME ? Mary_Arena_Dealloc_Frame(MARY_ARENA_FRAME_ID, BYTES) :\
  (MARY_Assert(0, "Invalid allocator"), 0)\
)

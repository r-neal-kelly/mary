#pragma once

#include <stdint.h>
#include <Mary/Vector.h>

#if defined(_WIN32)

#define WIN32_LEAN_AND_MEAN
#define UNICODE
#include <Windows.h>
#define MARY_CALL WINAPI

typedef struct
{
  HWND handle;
  HDC context;
  HBRUSH brush;
}
Mary_OS_Window_t;

#elif defined(__linux__)

#define to_be_done

#endif

typedef struct Mary_Window_t Mary_Window_t;

void Mary_OS_Start();
void Mary_OS_Finish();
void Mary_OS_Window_Create(Mary_Window_t *window);
void Mary_OS_Window_Destroy(Mary_Window_t *window);
void Mary_OS_Window_Show(Mary_Window_t *window);
void Mary_OS_Window_Hide(Mary_Window_t *window);
void Mary_OS_Window_Measure(Mary_Window_t *window);
void Mary_OS_Window_Handle_Messages(Mary_Window_t *window);
void Mary_OS_Window_Make_Current(Mary_Window_t *window);
void Mary_OS_Window_Swap_Buffers(Mary_Window_t *window);
void Mary_OS_Window_Back_Color(Mary_Window_t *window);
void Mary_OS_Sleep(size_t milliseconds);

// all of the following needs to be made a lot better.
typedef struct
{
  Mary_Bitmap_t line;
  Mary_Vector_t widths;
}
Mary_Wordmap_t;

typedef Mary_Vector_t Mary_Wordmap_v; // maybe we should make this use a pool to keep it all in one area.

Mary_Wordmap_t Mary_OS_Text_To_Bitmap(uint16_t *text, int units);

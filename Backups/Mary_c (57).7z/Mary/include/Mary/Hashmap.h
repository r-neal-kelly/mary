#pragma once

typedef struct
{
  void *buckets_data;
  void *buckets_bitbool;
  size_t buckets_total;
  size_t buckets_occupied;
  size_t size_key;
  size_t size_value;
}
Mary_Hashmap_t;

void Mary_Hashmap_Create(Mary_Hashmap_t *hashmap, size_t size_key, size_t size_value);
void Mary_Hashmap_Destroy(Mary_Hashmap_t *hashmap);
void Mary_Hashmap_Assign(Mary_Hashmap_t *hashmap, void *in_key, void *in_value);
char Mary_Hashmap_At(Mary_Hashmap_t *hashmap, void *in_key, void *out_value);
void *Mary_Hashmap_Point(Mary_Hashmap_t *hashmap, void *in_key);
char Mary_Hashmap_Contains_Key(Mary_Hashmap_t *hashmap, void *in_key);
void Mary_Hashmap_Erase(Mary_Hashmap_t *hashmap, void *in_key);

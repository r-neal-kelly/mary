#include <stdio.h>
#include <stdlib.h>
#include <Mary/File.h>

void Mary_File_Create(Mary_File_t *mary_file, const char *file_path, const char *mode)
{
  FILE *file = fopen(file_path, mode);
  if (file == 0)
  {
    Mary_Exit_Failure("File_Read: could not open.");
  }

  if (fseek(file, 0, SEEK_END))
  {
    Mary_Exit_Failure("File_Read: could not read.");
  }

  int bytes = ftell(file);
  if (bytes == -1)
  {
    Mary_Exit_Failure("File_Read: could not find end.");
  }

  char *data = calloc(bytes, sizeof(char));
  if (data == 0)
  {
    Mary_Exit_Failure("File_Read: could not allocate buffer.");
  }

  rewind(file); fread(data, sizeof(char), bytes, file);
  if (ferror(file))
  {
    Mary_Exit_Failure("File_Read: could not read into buffer.");
  }

  if (fclose(file) == EOF)
  {
    Mary_Exit_Failure("File_Read: could not close.");
  }

  mary_file->data = data;
  mary_file->bytes = bytes;
}

void Mary_File_Destroy(Mary_File_t *mary_file)
{
  free(mary_file->data);
}

#pragma once

#include <stdint.h>
#include <Mary/Vector.h>

typedef struct
{
  Mary_Vector_t v_text;
  float x, y;
  float w, h;
  float r, g, b, a;
  unsigned int texture;
}
Mary_Text_t;

void Mary_Text_Start();
void Mary_Text_Finish();
void Mary_Text_Create(Mary_Text_t *elem);
void Mary_Text_Destroy(Mary_Text_t *elem);
void Mary_Text_Text(Mary_Text_t *elem, uint16_t *text);
void Mary_Text_Buffer(Mary_Text_t *elem);
void Mary_Text_Render(Mary_Text_t *elem, Mary_Matrix_4x4f *projection);
void Mary_Text_Position(Mary_Text_t *elem, float x, float y);
void Mary_Text_Size(Mary_Text_t *elem, float w, float h);
void Mary_Text_Color(Mary_Text_t *elem, float r, float g, float b, float a);

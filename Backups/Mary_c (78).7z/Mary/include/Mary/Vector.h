#pragma once

#include <Mary/Utils.h>

#define MARY_Vector_t\
  MARY_Pointer_t;\
  Mary_Size_t unit;\
  Mary_Size_t units

// something I've been feeling a need for is a flag that lets me know if the data is on the heap or stack.
// would be helpful to know in sub-types as well (String_t). also, I want to have optional allocators,
// like with Pool_t. this is a hard proposition in particular I think. I could implement funcs for eac
// allocator myself, but at some point, we may want user to be able to do it instead.

typedef struct
{
  MARY_Vector_t;
}
Mary_Vector_t;

void Mary_Vector_Create(Mary_Vector_t *vector, size_t unit, size_t opt_units);
void Mary_Vector_Create_At(Mary_Vector_t *vector, size_t unit, Mary_p ptr);
void Mary_Vector_Create_With(Mary_Vector_t *vector, size_t unit, Mary_p ptr);
void Mary_Vector_Create_Copy(Mary_Vector_t *vector, size_t unit, Mary_p ptr, size_t units);
void Mary_Vector_Repurpose(Mary_Vector_t *vector, size_t unit, size_t opt_units);
void Mary_Vector_Repurpose_With(Mary_Vector_t *vector, Mary_p *ptr, size_t ptr_unit, size_t ptr_units);
void Mary_Vector_Destroy(Mary_Vector_t *vector);
void Mary_Vector_Reserve(Mary_Vector_t *vector, size_t units);
void Mary_Vector_Fit(Mary_Vector_t *vector);
void Mary_Vector_Push_At(Mary_Vector_t *vector, size_t index, void *in_elem);
void Mary_Vector_Pop_At(Mary_Vector_t *vector, size_t index, void *out_elem);
void Mary_Vector_Assign(Mary_Vector_t *vector, size_t index, void *in_elem);
void Mary_Vector_Exchange(Mary_Vector_t *vector, size_t index, void *in_elem, void *out_elem);
void Mary_Vector_Copy(Mary_Vector_t *vector, Mary_Vector_t *out_copy);
void Mary_Vector_Add_Slice(Mary_Vector_t *vector, size_t from, size_t to_exclusive, void *opt_in_elems);
void Mary_Vector_Delete_Slice(Mary_Vector_t *vector, size_t from, size_t to_exclusive);
void Mary_Vector_Copy_Slice(Mary_Vector_t *vector, size_t from, size_t to_exclusive, void *out_elems);
void Mary_Vector_Take_Slice(Mary_Vector_t *vector, size_t from, size_t to_exclusive, void *out_elems);
void Mary_Vector_Put_Slice(Mary_Vector_t *vector, size_t from, size_t to_exclusive, void *in_elems);
void Mary_Vector_Push_Back(Mary_Vector_t *vector, void *in_elem);
void Mary_Vector_Push_Front(Mary_Vector_t *vector, void *in_elem);
void Mary_Vector_Pop_Back(Mary_Vector_t *vector, void *out_elem);
void Mary_Vector_Pop_Front(Mary_Vector_t *vector, void *out_elem);
void Mary_Vector_At(Mary_Vector_t *vector, size_t index, void *out_elem);
void Mary_Vector_At_Front(Mary_Vector_t *vector, void *out_elem);
void Mary_Vector_At_Back(Mary_Vector_t *vector, void *out_elem);
char Mary_Vector_Has_At(Mary_Vector_t *vector, size_t index);
void *Mary_Vector_Point(Mary_Vector_t *vector, size_t index);
void *Mary_Vector_Point_Front(Mary_Vector_t *vector);
void *Mary_Vector_Point_Back(Mary_Vector_t *vector);
void *Mary_Vector_Point_Push_Back(Mary_Vector_t *vector);
void Mary_Vector_Empty(Mary_Vector_t *vector);
char Mary_Vector_Is_Empty(Mary_Vector_t *vector);
void Mary_Vector_Resize(Mary_Vector_t *vector, size_t units);
void Mary_Vector_Fill(Mary_Vector_t *vector, void *in_elem);
void Mary_Vector_Rotate(Mary_Vector_t *vector, void *out_elem);
void Mary_Vector_Reverse(Mary_Vector_t *vector);
char Mary_Vector_Contains(Mary_Vector_t *vector, void *elem);
char Mary_Vector_Contains_First_Bytes(Mary_Vector_t *vector, void *elem, size_t bytes);
size_t Mary_Vector_Index_Of(Mary_Vector_t *vector, void *elem, char *out_was_found);
void Mary_Vector_Erase_At(Mary_Vector_t *vector, size_t index);
void Mary_Vector_Erase(Mary_Vector_t *vector, void *elem);
void Mary_Vector_Sort(Mary_Vector_t *vector);

#define MARY_Vector_Create(VECTOR, TYPE, OPT_UNITS)\
  Mary_Vector_Create(&VECTOR, sizeof(TYPE), (OPT_UNITS))



#define MARY_Vector_Namespace\
  <Mary/Namespace/Vector_Start.h>

#define MARY_Vector_Namespace_Start\
  <Mary/Namespace/Vector_Start.h>

#define MARY_Vector_Namespace_Start_Quick\
  <Mary/Namespace/Vector_Start_Quick.h>

#define MARY_Vector_Namespace_Finish\
  <Mary/Namespace/Vector_Finish.h>

#define MARY_Vector(PTR)\
  MARY_Cast(PTR, Mary_Vector_t)

#define MARY_Vector_Create_At_Stack(VECTOR, TYPE, UNITS)\
  TYPE VECTOR##_a[UNITS];\
  Mary_Vector_Create_At(&VECTOR, sizeof(TYPE), (Mary_p) { VECTOR##_a, sizeof(TYPE) * (UNITS) })

#define MARY_Vector_Point(PTR, IDX)\
  MARY_Cast( (uint8_t *)(PTR)->data + (IDX) * (PTR)->unit, void )

#define MARY_Vector_Point_Front(PTR)\
  MARY_Cast( (PTR)->data, void )

#define MARY_Vector_Point_Back(PTR)\
  MARY_Cast( (uint8_t *)(PTR)->data + ((PTR)->units - 1) * (PTR)->unit, void )

#define MARY_Vector_At(PTR, TYPE, IDX)\
  ( *MARY_Cast( (uint8_t *)(PTR)->data + (IDX) * (PTR)->unit, TYPE ) )

#define MARY_Vector_At_Front(PTR, TYPE)\
  ( *MARY_Cast( (PTR)->data, TYPE ) )

#define MARY_Vector_At_Back(PTR, TYPE)\
  ( *MARY_Cast( (uint8_t *)(PTR)->data + ((PTR)->units - 1) * (PTR)->unit, TYPE ) )

// add asserts that the vector has more than 0 units. or see everything to zero, no -
#define MARY_Vector_Each(PTR, TYPE)                                                                \
  for                                                                                              \
  (                                                                                                \
    struct { Mary_Vector_t *v; Mary_Index_t from, to, idx; TYPE *ptr; TYPE val; }                  \
    it =                                                                                           \
    {                                                                                              \
      (PTR), 0, it.v->units > 0 ? it.v->units - 1 : 0, 0,                                          \
      MARY_Vector_Point_Front(it.v), *it.ptr                                                       \
    };                                                                                             \
    it.idx < it.v->units;                                                                          \
    ++it.idx, it.ptr = MARY_Vector_Point(it.v, it.idx), it.val = *it.ptr                           \
  )

#define MARY_Vector_Each_Reverse(PTR, TYPE)                                                        \
  for                                                                                              \
  (                                                                                                \
    struct { Mary_Vector_t *v; Mary_Index_t from, to, idx; TYPE *ptr; TYPE val; }                  \
    it =                                                                                           \
    {                                                                                              \
      (PTR), it.v->units - 1, 0, it.from,                                                          \
      MARY_Vector_Point_Back(it.v), *it.ptr                                                        \
    };                                                                                             \
    it.idx + 1 > 0;                                                                                \
    --it.idx, it.ptr = MARY_Vector_Point(it.v, it.idx), it.val = *it.ptr                           \
  )

// I want to be able to combine these in a func so that it does the right one for the size.
#define MARY_Vector_Bubble_Sort(BOOL_EXPRESSION)

#define MARY_Vector_Quick_Sort(BOOL_EXPRESSION)

#define MARY_Vector_Linear_Search(BOOL_EXPRESSION)

#define MARY_Vector_Binary_Search(BOOL_EXPRESSION)

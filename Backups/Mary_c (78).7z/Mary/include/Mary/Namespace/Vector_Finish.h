#undef Vector_t

#undef Vector_Create
#undef Vector_Destroy
#undef Vector_Push_Back

#undef VECTOR
#undef VECTOR_Create_At_Stack
#undef VECTOR_Point
#undef VECTOR_Point_Back
#undef VECTOR_At
#undef VECTOR_At_Back
#undef VECTOR_Each

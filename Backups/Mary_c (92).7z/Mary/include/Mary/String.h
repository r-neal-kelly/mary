#pragma once

#include <Mary/Utils.h>
#include <Mary/Allocator.h>
#include <Mary/Vector.h>

enum Mary_String_Append_e
{
  MARY_STRING_APPEND_BEFORE,
  MARY_STRING_APPEND_AFTER
};

typedef struct { MARY_Vector_t; Mary_Size_t codes; } Mary_String_t;

void Mary_String_Create(Mary_String_t *this, Mary_Allocator_t allocator, Mary_UTF_t utf, Mary_Size_t opt_reserve_units);
void Mary_String_Create_At(Mary_String_t *this, void *at_data, Mary_Size_t at_bytes, Mary_Allocator_t at_allocator, Mary_UTF_t at_utf);
void Mary_String_Create_With(Mary_String_t *this, void *with_data, Mary_Size_t opt_with_bytes, Mary_Allocator_t with_allocator, Mary_UTF_t with_utf);
void Mary_String_Create_From(Mary_String_t *this, Mary_Allocator_t allocator, Mary_UTF_t utf, void *from_data, Mary_UTF_t from_utf);
void Mary_String_Copy(Mary_String_t *from, Mary_String_t *to, Mary_Allocator_t to_allocator, Mary_UTF_t to_utf);
void Mary_String_Destroy(Mary_String_t *this);
void Mary_String_Recode(Mary_String_t *this, Mary_UTF_t utf);

#define MARY_String(NAME, ALLOCATOR, UTF, OPT_RESERVE_UNITS)
#define MARY_String_Stack(NAME, UTF, C_STR)
#define MARY_String_Create(NAME, ALLOCATOR, UTF, OPT_RESERVE_UNITS)
#define MARY_String_Create_At(NAME, AT_DATA, AT_BYTES, AT_ALLOCATOR, AT_UTF)
#define MARY_String_Create_With(NAME, WITH_DATA, OPT_WITH_BYTES, WITH_ALLOCATOR, WITH_UTF)
#define MARY_String_Create_From(NAME, ALLOCATOR, UTF, FROM_DATA, FROM_UTF)
#define MARY_String_Create_Stack(NAME, UTF, C_STR)
#define MARY_String_Get_UTF(THIS)
#define MARY_String_UTF_8_Code_To_Units(CODE)
#define MARY_String_UTF_8_Ptr_To_Units(PTR)
#define MARY_String_UTF_16_Code_To_Units(CODE)
#define MARY_String_UTF_16_Ptr_To_Units(PTR)
#define MARY_String_UTF_8_Encode(CODE, OUT, CASE_A, CASE_B, CASE_C, CASE_D)
#define MARY_String_UTF_8_Decode(PTR, OUT, CASE_A, CASE_B, CASE_C, CASE_D)
#define MARY_String_UTF_16_Encode(CODE, OUT, CASE_A, CASE_B)
#define MARY_String_UTF_16_Decode(PTR, OUT, CASE_A, CASE_B)
#define MARY_String_Each_UTF_8(THIS)
#define MARY_String_Each_UTF_8_To_16(THIS)
#define MARY_String_Each_UTF_8_To_32(THIS)
#define MARY_String_Each_UTF_16(THIS)
#define MARY_String_Each_UTF_16_To_8(THIS)
#define MARY_String_Each_UTF_16_To_32(THIS)
#define MARY_String_Each_UTF_32(THIS)
#define MARY_String_Each_UTF_32_To_8(THIS)
#define MARY_String_Each_UTF_32_To_16(THIS)

#include <Mary/Macros/String_m.h>

//////////////////////////////////////////////////////////

// prob should have a change and concat with String_t too. also, we need to know where to put it on the string, before or after. add a param.
void Mary_String_Change_C_String(Mary_String_t *this, Mary_C_String_t c_string, Mary_UTF_t utf_c_string, Mary_Size_t opt_units_c_string);
void Mary_String_Append(Mary_String_t *this, Mary_String_t *other, Mary_Enum_t position);
void Mary_String_Append_C_String(Mary_String_t *this, Mary_C_String_t c_string, Mary_UTF_t utf_c_string, Mary_Size_t opt_units_c_string);
void Mary_String_Trim(Mary_String_t *this);
// Cluster() should group the clusters in the string together (clusters are letters along with combining marks, it's lang specific)
// Alphabet() should return whatever lang it is, see Lang.h

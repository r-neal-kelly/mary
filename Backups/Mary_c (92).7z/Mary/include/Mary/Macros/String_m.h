#pragma once

#include <Mary/String.h>

#undef MARY_String
#undef MARY_String_Stack
#undef MARY_String_Create
#undef MARY_String_Create_At
#undef MARY_String_Create_With
#undef MARY_String_Create_From
#undef MARY_String_Create_Stack
#undef MARY_String_Get_UTF
#undef MARY_String_UTF_8_Code_To_Units
#undef MARY_String_UTF_8_Ptr_To_Units
#undef MARY_String_UTF_16_Code_To_Units
#undef MARY_String_UTF_16_Ptr_To_Units
#undef MARY_String_UTF_8_Encode
#undef MARY_String_UTF_8_Decode
#undef MARY_String_UTF_16_Encode
#undef MARY_String_UTF_16_Decode
#undef MARY_String_Each_UTF_8
#undef MARY_String_Each_UTF_8_To_16
#undef MARY_String_Each_UTF_8_To_32
#undef MARY_String_Each_UTF_16
#undef MARY_String_Each_UTF_16_To_8
#undef MARY_String_Each_UTF_16_To_32
#undef MARY_String_Each_UTF_32
#undef MARY_String_Each_UTF_32_To_8
#undef MARY_String_Each_UTF_32_To_16

////// Creation //////

#define MARY_String_Create(NAME, ALLOCATOR, UTF, OPT_RESERVE_UNITS)\
  Mary_String_t NAME; Mary_String_Create(&NAME, ALLOCATOR, UTF, OPT_RESERVE_UNITS)

#define MARY_String_Create_At(NAME, AT_DATA, AT_BYTES, AT_ALLOCATOR, AT_UTF)\
  Mary_String_t NAME; Mary_String_Create_At(&NAME, AT_DATA, AT_BYTES, AT_ALLOCATOR, AT_UTF)

#define MARY_String_Create_With(NAME, WITH_DATA, OPT_WITH_BYTES, WITH_ALLOCATOR, WITH_UTF)\
  Mary_String_t NAME; Mary_String_Create_With(&NAME, WITH_DATA, OPT_WITH_BYTES, WITH_ALLOCATOR, WITH_UTF)

#define MARY_String_Create_From(NAME, ALLOCATOR, UTF, FROM_DATA, FROM_UTF)\
  Mary_String_t NAME; Mary_String_Create_From(&NAME, ALLOCATOR, UTF, FROM_DATA, FROM_UTF)

#define MARY_String_Create_Stack(NAME, UTF, C_STR)\
  Mary_String_t NAME; Mary_String_Create_With(&NAME, C_STR, 0, MARY_STACK, UTF)

#define MARY_String(NAME, ALLOCATOR, UTF, OPT_RESERVE_UNITS)\
  MARY_String_Create(NAME, ALLOCATOR, UTF, OPT_RESERVE_UNITS)

#define MARY_String_Stack(NAME, UTF, C_STR)\
  MARY_String_Create_Stack(NAME, UTF, C_STR)

////// Sizing //////

#define MARY_String_Get_UTF(THIS)\
  MARY_Unit_To_UTF((THIS)->unit)

#define MARY_String_UTF_8_Code_To_Units(CODE) \
(                                             \
  (CODE) < 0x000080 ? 1 :                     \
  (CODE) < 0x000800 ? 2 :                     \
  (CODE) < 0x010000 ? 3 :                     \
  (CODE) < 0x110000 ? 4 : 0                   \
)

#define MARY_String_UTF_8_Ptr_To_Units(PTR) \
(                                           \
  *(PTR) >> 7 == 0x00 ? 1 :                 \
  *(PTR) >> 5 == 0x06 ? 2 :                 \
  *(PTR) >> 4 == 0x0E ? 3 :                 \
  *(PTR) >> 3 == 0x1E ? 4 : 0               \
)

#define MARY_String_UTF_16_Code_To_Units(CODE) \
(                                              \
  (CODE) < 0x10000 ? 1 : 2                     \
)

#define MARY_String_UTF_16_Ptr_To_Units(PTR) \
(                                            \
  *(PTR) < 0xD800 || *(PTR) > 0xDFFF ? 2 : 1 \
)

////// Encoding/Decoding //////

#define MARY_String_UTF_8_Encode(CODE, OUT, CASE_A, CASE_B, CASE_C, CASE_D) \
(                                                                           \
  (CODE) < 0x000080 ?                                                       \
      ( OUT.a    = (        (CODE)              ),                          \
        OUT.code = (CODE), OUT.units = 1, (CASE_A), OUT ) :                 \
  (CODE) < 0x000800 ?                                                       \
      ( OUT.a    = ( 0xC0 | (CODE) >> 6         ),                          \
        OUT.b    = ( 0x80 | (CODE)       & 0x3F ),                          \
        OUT.code = (CODE), OUT.units = 2, (CASE_B), OUT ) :                 \
  (CODE) < 0x010000 ?                                                       \
      ( OUT.a    = ( 0xE0 | (CODE) >> 12        ),                          \
        OUT.b    = ( 0x80 | (CODE) >> 6  & 0x3F ),                          \
        OUT.c    = ( 0x80 | (CODE)       & 0x3F ),                          \
        OUT.code = (CODE), OUT.units = 3, (CASE_C), OUT ) :                 \
  (CODE) < 0x110000 ?                                                       \
      ( OUT.a    = ( 0xF0 | (CODE) >> 18        ),                          \
        OUT.b    = ( 0x80 | (CODE) >> 12 & 0x3F ),                          \
        OUT.c    = ( 0x80 | (CODE) >> 6  & 0x3F ),                          \
        OUT.d    = ( 0x80 | (CODE)       & 0x3F ),                          \
        OUT.code = (CODE), OUT.units = 4, (CASE_D), OUT ) : OUT             \
)

#define MARY_String_UTF_8_Decode(PTR, OUT, CASE_A, CASE_B, CASE_C, CASE_D) \
(                                                                          \
  *(PTR) >> 7 == 0x00 ?                                                    \
      ( OUT.code  = ( ( OUT.a = * (PTR)      )        )       ,            \
        OUT.units = 1, (CASE_A), OUT )                        :            \
  *(PTR) >> 5 == 0x06 ?                                                    \
      ( OUT.code  = ( ( OUT.a = * (PTR)      ) ^ 0xC0 ) << 6  |            \
                    ( ( OUT.b = *((PTR) + 1) ) ^ 0x80 )       ,            \
        OUT.units = 2, (CASE_B), OUT )                        :            \
  *(PTR) >> 4 == 0x0E ?                                                    \
      ( OUT.code  = ( ( OUT.a = * (PTR)      ) ^ 0xE0 ) << 12 |            \
                    ( ( OUT.b = *((PTR) + 1) ) ^ 0x80 ) << 6  |            \
                    ( ( OUT.c = *((PTR) + 2) ) ^ 0x80 )       ,            \
        OUT.units = 3, (CASE_C), OUT )                        :            \
  *(PTR) >> 3 == 0x1E ?                                                    \
      ( OUT.code  = ( ( OUT.a = * (PTR)      ) ^ 0xF0 ) << 18 |            \
                    ( ( OUT.b = *((PTR) + 1) ) ^ 0x80 ) << 12 |            \
                    ( ( OUT.c = *((PTR) + 2) ) ^ 0x80 ) << 6  |            \
                    ( ( OUT.d = *((PTR) + 3) ) ^ 0x80 )       ,            \
        OUT.units = 4, (CASE_D), OUT )                        : OUT        \
)

#define MARY_String_UTF_16_Encode(CODE, OUT, CASE_A, CASE_B)   \
(                                                              \
  (CODE) < 0x10000 ?                                           \
      ( OUT.a    =     (CODE)                                , \
        OUT.code = (CODE), OUT.units = 1, (CASE_A), OUT )    : \
      ( OUT.a    = ( ( (CODE) - 0x10000 >> 10    ) + 0xD800 ), \
        OUT.b    = ( ( (CODE) - 0x10000 &  0x3FF ) + 0xDC00 ), \
        OUT.code = (CODE), OUT.units = 2, (CASE_B), OUT )      \
)

#define MARY_String_UTF_16_Decode(PTR, OUT, CASE_A, CASE_B)               \
(                                                                         \
  *(PTR) < 0xD800 || *(PTR) > 0xDFFF ?                                    \
      ( OUT.code = ( ( OUT.a = * (PTR)      )                )          , \
                       OUT.units = 1, (CASE_A), OUT )                   : \
      ( OUT.code = ( ( OUT.a = * (PTR)      ) - 0xD800 << 10 ) +          \
                   ( ( OUT.b = *((PTR) + 1) ) - 0xDC00       ) + 0x10000, \
                       OUT.units = 2, (CASE_B), OUT )                     \
)

////// Loops //////

#define MARY_String_Each_UTF_8(THIS)                                                              \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx, unit_idx;                                                            \
      Mary_Size_t codes;                                                                          \
      uint8_t *ptr;                                                                               \
      Mary_UTF_8_t utf_8;                                                                         \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(MARY_String_Get_UTF(THIS) == MARY_UTF_8, 0), THIS ),                          \
        0, 0, it.string->codes, it.string->data,                                                  \
        MARY_String_UTF_8_Decode(it.ptr, it.utf_8, 0, 0, 0, 0)                                    \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, it.unit_idx += it.utf_8.units, it.ptr += it.utf_8.units,                       \
    MARY_String_UTF_8_Decode(it.ptr, it.utf_8, 0, 0, 0, 0)                                        \
  )

#define MARY_String_Each_UTF_8_To_16(THIS)                                                        \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx, unit_idx;                                                            \
      Mary_Size_t codes;                                                                          \
      uint8_t *ptr;                                                                               \
      Mary_UTF_8_t utf_8;                                                                         \
      Mary_UTF_16_t utf_16;                                                                       \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(MARY_String_Get_UTF(THIS) == MARY_UTF_8, 0), THIS ),                          \
        0, 0, it.string->codes, it.string->data,                                                  \
        MARY_String_UTF_8_Decode(it.ptr, it.utf_8, 0, 0, 0, 0),                                   \
        MARY_String_UTF_16_Encode(it.utf_8.code, it.utf_16, 0, 0)                                 \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, it.unit_idx += it.utf_8.units, it.ptr += it.utf_8.units,                       \
    MARY_String_UTF_8_Decode(it.ptr, it.utf_8, 0, 0, 0, 0),                                       \
    MARY_String_UTF_16_Encode(it.utf_8.code, it.utf_16, 0, 0)                                     \
  )

#define MARY_String_Each_UTF_8_To_32(THIS)                                                        \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx, unit_idx;                                                            \
      Mary_Size_t codes;                                                                          \
      uint8_t *ptr;                                                                               \
      Mary_UTF_8_t utf_8;                                                                         \
      Mary_UTF_32_t utf_32;                                                                       \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(MARY_String_Get_UTF(THIS) == MARY_UTF_8, 0), THIS ),                          \
        0, 0, it.string->codes, it.string->data,                                                  \
        MARY_String_UTF_8_Decode(it.ptr, it.utf_8, 0, 0, 0, 0),                                   \
        it.utf_8.code                                                                             \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, it.unit_idx += it.utf_8.units, it.ptr += it.utf_8.units,                       \
    MARY_String_UTF_8_Decode(it.ptr, it.utf_8, 0, 0, 0, 0),                                       \
    it.utf_32 = it.utf_8.code                                                                     \
  )

#define MARY_String_Each_UTF_16(THIS)                                                             \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx, unit_idx;                                                            \
      Mary_Size_t codes;                                                                          \
      uint16_t *ptr;                                                                              \
      Mary_UTF_16_t utf_16;                                                                       \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(MARY_String_Get_UTF(THIS) == MARY_UTF_16, 0), THIS ),                         \
        0, 0, it.string->codes, it.string->data,                                                  \
        MARY_String_UTF_16_Decode(it.ptr, it.utf_16, 0, 0)                                        \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, it.unit_idx += it.utf_16.units, it.ptr += it.utf_16.units,                     \
    MARY_String_UTF_16_Decode(it.ptr, it.utf_16, 0, 0)                                            \
  )

#define MARY_String_Each_UTF_16_To_8(THIS)                                                        \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx, unit_idx;                                                            \
      Mary_Size_t codes;                                                                          \
      uint16_t *ptr;                                                                              \
      Mary_UTF_16_t utf_16;                                                                       \
      Mary_UTF_8_t utf_8;                                                                         \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(MARY_String_Get_UTF(THIS) == MARY_UTF_16, 0), THIS ),                         \
        0, 0, it.string->codes, it.string->data,                                                  \
        MARY_String_UTF_16_Decode(it.ptr, it.utf_16, 0, 0),                                       \
        MARY_String_UTF_8_Encode(it.utf_16.code, it.utf_8, 0, 0, 0, 0)                            \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, it.unit_idx += it.utf_16.units, it.ptr += it.utf_16.units,                     \
    MARY_String_UTF_16_Decode(it.ptr, it.utf_16, 0, 0),                                           \
    MARY_String_UTF_8_Encode(it.utf_16.code, it.utf_8, 0, 0, 0, 0)                                \
  )

#define MARY_String_Each_UTF_16_To_32(THIS)                                                       \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx, unit_idx;                                                            \
      Mary_Size_t codes;                                                                          \
      uint16_t *ptr;                                                                              \
      Mary_UTF_16_t utf_16;                                                                       \
      Mary_UTF_32_t utf_32;                                                                       \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(MARY_String_Get_UTF(THIS) == MARY_UTF_16, 0), THIS ),                         \
        0, 0, it.string->codes, it.string->data,                                                  \
        MARY_String_UTF_16_Decode(it.ptr, it.utf_16, 0, 0),                                       \
        it.utf_16.code                                                                            \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, it.unit_idx += it.utf_16.units, it.ptr += it.utf_16.units,                     \
    MARY_String_UTF_16_Decode(it.ptr, it.utf_16, 0, 0),                                           \
    it.utf_32 = it.utf_16.code                                                                    \
  )

#define MARY_String_Each_UTF_32(THIS)                                                             \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx;                                                                      \
      Mary_Size_t codes;                                                                          \
      uint32_t *ptr;                                                                              \
      Mary_UTF_32_t utf_32;                                                                       \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(MARY_String_Get_UTF(THIS) == MARY_UTF_32, 0), THIS ),                         \
        0, it.string->codes, it.string->data, *it.ptr                                             \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, ++it.ptr, it.utf_32 = *it.ptr                                                  \
  )

#define MARY_String_Each_UTF_32_To_8(THIS)                                                        \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx;                                                                      \
      Mary_Size_t codes;                                                                          \
      uint32_t *ptr;                                                                              \
      Mary_UTF_32_t utf_32;                                                                       \
      Mary_UTF_8_t utf_8;                                                                         \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(MARY_String_Get_UTF(THIS) == MARY_UTF_32, 0), THIS ),                         \
        0, it.string->codes, it.string->data, *it.ptr,                                            \
        MARY_String_UTF_8_Encode(it.utf_32, it.utf_8, 0, 0, 0, 0)                                 \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, ++it.ptr, it.utf_32 = *it.ptr,                                                 \
    MARY_String_UTF_8_Encode(it.utf_32, it.utf_8, 0, 0, 0, 0)                                     \
  )

#define MARY_String_Each_UTF_32_To_16(THIS)                                                       \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx;                                                                      \
      Mary_Size_t codes;                                                                          \
      uint32_t *ptr;                                                                              \
      Mary_UTF_32_t utf_32;                                                                       \
      Mary_UTF_16_t utf_16;                                                                       \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(MARY_String_Get_UTF(THIS) == MARY_UTF_32, 0), THIS ),                         \
        0, it.string->codes, it.string->data, *it.ptr,                                            \
        MARY_String_UTF_16_Encode(it.utf_32, it.utf_16, 0, 0)                                     \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, ++it.ptr, it.utf_32 = *it.ptr,                                                 \
    MARY_String_UTF_16_Encode(it.utf_32, it.utf_16, 0, 0)                                         \
  )

#pragma once

#include <Mary/Utils.h>

// I think we can probably make a sparse array for folding, or a hashmap.
// the sparse array would probably just be binary searched.
// I wonder if I can make a macro binary search. see pool.c implemetation.

// Mary_Unicode_To_Lowercase();
// Mary_Unicode_To_Uppercase();
// Mary_Unicode_To_Titlecase();
// Mary_Unicode_Is_Lowercase();
// Mary_Unicode_Is_Uppercase();
// Mary_Unicode_Is_Titlecase();
// Mary_Unicode_Fold_Case();

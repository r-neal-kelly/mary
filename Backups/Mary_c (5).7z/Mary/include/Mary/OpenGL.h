#pragma once

// I think we'll make a context this way
// so that we can have as many as we need
// and keep opengl init separate from window.
// I have it void at the moment, so that
// we could potentially make this work for
// linux as well.

//#include <GL/GL.h>
//#include <gl/GLU.h>
#include <stdint.h>

#define GL_VENDOR     0x1f00
#define GL_RENDERER   0x1f01
#define GL_VERSION    0x1f02
#define GL_EXTENSIONS 0x1f03

typedef uint8_t GLubyte;
typedef uint32_t GLenum;

const GLubyte *(__stdcall *glGetString)(GLenum name);

void Mary_OpenGL_Start();

typedef struct
{
  void *context;
}
Mary_OpenGL_t;

typedef struct
{
  void (*const Create) (Mary_OpenGL_t *opengl);
  void (*const Destroy)(Mary_OpenGL_t *opengl);
}
Mary_OpenGL_i;

const Mary_OpenGL_i Mary_OpenGL();

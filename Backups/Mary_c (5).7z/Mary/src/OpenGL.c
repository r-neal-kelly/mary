#define intern static
#define method static
#include <stdio.h>
#include <Mary/OS.h>
#include <Mary/OpenGL.h>

void Mary_OpenGL_Start()
{
  WNDCLASSEX wndclass;
  memset(&wndclass, 0, sizeof(wndclass));
  wndclass.cbSize = sizeof(wndclass);
  wndclass.lpfnWndProc = DefWindowProc;
  wndclass.lpszClassName = u"Mary_OpenGL";
  wndclass.style = CS_OWNDC;
  RegisterClassEx(&wndclass);

  HWND hwnd = CreateWindowEx
    ( 0
    , u"Mary_OpenGL"
    , 0
    , 0, 0
    , 0, 0
    , 0, 0, 0, 0, 0
    );
  HDC hdc = GetDC(hwnd);

  PIXELFORMATDESCRIPTOR pfd;
  memset(&pfd, 0, sizeof(pfd));
  int pf = ChoosePixelFormat(hdc, &pfd);
  SetPixelFormat(hdc, pf, &pfd);

  HGLRC hglrc = wglCreateContext(hdc);
  wglMakeCurrent(hdc, hglrc);

  HMODULE opengl_dll = LoadLibrary(u"opengl32.dll");
  glGetString = (void *)GetProcAddress(opengl_dll, "glGetString");
  //glGetStringi = wglGetProcAddress("glGetStringi");

  //wglMakeCurrent(hdc, 0);
  //wglDeleteContext(hglrc);
  //ReleaseDC(hwnd, hdc);
  //DestroyWindow(hwnd);
  //UnregisterClass(u"Mary_OpenGL", GetModuleHandle(0));
  FreeLibrary(opengl_dll);
}

method void Create (Mary_OpenGL_t *opengl);
method void Destroy(Mary_OpenGL_t *opengl);

const Mary_OpenGL_i Mary_OpenGL()
{
  // can't be static, because we need to init first.
  const Mary_OpenGL_i interface =
    { Create
    , Destroy
    };

  return interface;
}

method void Create(Mary_OpenGL_t *opengl)
{

}

method void Destroy(Mary_OpenGL_t *opengl)
{

}

#define intern static
#define global
#include <stdio.h>
#include <stdlib.h>
#include <Mary/Utils.h>
#include <Mary/OpenGL.h>

global void Mary_OpenGL_Start();
global void Mary_OpenGL_Finish();
global const Mary_OpenGL_g Mary_OpenGL();
global GLuint Mary_OpenGL_Shader(const char *vertex, const char *fragment);
intern GLuint Load_Shader(const char *file_path, GLenum shader_type);

intern HWND g_hwnd = 0;
intern HDC g_hdc = 0;
intern HGLRC g_hglrc = 0;
intern int g_pixel_format = 0;

global void Mary_OpenGL_Start()
{
  WNDCLASSEX wndclass;
  memset(&wndclass, 0, sizeof(wndclass));
  wndclass.cbSize = sizeof(wndclass);
  wndclass.lpfnWndProc = DefWindowProc;
  wndclass.lpszClassName = u"Mary_OpenGL";
  wndclass.style = CS_OWNDC;
  RegisterClassEx(&wndclass);

  g_hwnd = CreateWindowEx
    ( 0
    , u"Mary_OpenGL"
    , 0
    , 0, 0
    , 0, 0
    , 0, 0, 0, 0, 0
    );
  g_hdc = GetDC(g_hwnd);

  PIXELFORMATDESCRIPTOR pfd;
  memset(&pfd, 0, sizeof(pfd));
  SetPixelFormat(g_hdc, ChoosePixelFormat(g_hdc, &pfd), &pfd);

  g_hglrc = wglCreateContext(g_hdc);
  wglMakeCurrent(g_hdc, g_hglrc);

  HMODULE opengl_dll = LoadLibrary(u"opengl32.dll");

  // Windows Extensions
  wglChoosePixelFormatARB = (void *)wglGetProcAddress("wglChoosePixelFormatARB");
  wglCreateContextAttribsARB = (void *)wglGetProcAddress("wglCreateContextAttribsARB");

  // unsorted
  glGetString = (void *)GetProcAddress(opengl_dll, "glGetString");
  glViewport = (void *)GetProcAddress(opengl_dll, "glViewport");
  glClearColor = (void *)GetProcAddress(opengl_dll, "glClearColor");
  glClear = (void *)GetProcAddress(opengl_dll, "glClear");
  glLoadIdentity = (void *)GetProcAddress(opengl_dll, "glLoadIdentity");
  glMatrixMode = (void *)GetProcAddress(opengl_dll, "glMatrixMode");
  glOrtho = (void *)GetProcAddress(opengl_dll, "glOrtho");
  
  // Shaders
  glAttachShader = (void *)wglGetProcAddress("glAttachShader");
  glCompileShader = (void *)wglGetProcAddress("glCompileShader");
  glCreateProgram = (void *)wglGetProcAddress("glCreateProgram");
  glCreateShader = (void *)wglGetProcAddress("glCreateShader");
  glDeleteProgram = (void *)wglGetProcAddress("glDeleteProgram");
  glDeleteShader = (void *)wglGetProcAddress("glDeleteShader");
  glDetachShader = (void *)wglGetProcAddress("glDetachShader");
  glGetShaderiv = (void *)wglGetProcAddress("glGetShaderiv");
  glGetShaderInfoLog = (void *)wglGetProcAddress("glGetShaderInfoLog");
  glGetUniformLocation = (void *)wglGetProcAddress("glGetUniformLocation");
  glLinkProgram = (void *)wglGetProcAddress("glLinkProgram");
  glShaderSource = (void *)wglGetProcAddress("glShaderSource");
  glUniform4f = (void *)wglGetProcAddress("glUniform4f");
  glUseProgram = (void *)wglGetProcAddress("glUseProgram");
  glValidateProgram = (void *)wglGetProcAddress("glValidateProgram");
  
  // Buffer Objects
  glBindBuffer = (void *)wglGetProcAddress("glBindBuffer");
  glBufferData = (void *)wglGetProcAddress("glBufferData");
  glDeleteBuffers = (void *)wglGetProcAddress("glDeleteBuffers");
  glDisableVertexAttribArray = (void *)wglGetProcAddress("glDisableVertexAttribArray");
  glDrawArrays = (void *)GetProcAddress(opengl_dll, "glDrawArrays");
  glDrawElements = (void *)GetProcAddress(opengl_dll, "glDrawElements");
  glEnableVertexAttribArray = (void *)wglGetProcAddress("glEnableVertexAttribArray");
  glGenBuffers = (void *)wglGetProcAddress("glGenBuffers");
  glVertexAttribIPointer = (void *)wglGetProcAddress("glVertexAttribIPointer");
  glVertexAttribPointer = (void *)wglGetProcAddress("glVertexAttribPointer");

  // State Management
  glGetIntegerv = (void *)GetProcAddress(opengl_dll, "glGetIntegerv");
  glGetError = (void *)GetProcAddress(opengl_dll, "glGetError");
  glPolygonMode = (void *)GetProcAddress(opengl_dll, "glPolygonMode");

  // Vertex Array Objects
  glBindVertexArray = (void *)wglGetProcAddress("glBindVertexArray");
  glDeleteVertexArrays = (void *)wglGetProcAddress("glDeleteVertexArrays");
  glGenVertexArrays = (void *)wglGetProcAddress("glGenVertexArrays");

  FreeLibrary(opengl_dll);

  const int pf_attribs[] =
    { WGL_DRAW_TO_WINDOW_ARB, GL_TRUE
    , WGL_SUPPORT_OPENGL_ARB, GL_TRUE
    , WGL_DOUBLE_BUFFER_ARB, GL_TRUE
    , WGL_PIXEL_TYPE_ARB, WGL_TYPE_RGBA_ARB
    , WGL_COLOR_BITS_ARB, 32
    , WGL_DEPTH_BITS_ARB, 24
    , WGL_STENCIL_BITS_ARB, 8
    , WGL_SAMPLE_BUFFERS_ARB, 1
    , WGL_SAMPLES_ARB, 4
    , 0
    };
  unsigned int num_formats = 0;
  wglChoosePixelFormatARB(g_hdc, pf_attribs, 0, 1, &g_pixel_format, &num_formats);

  wglMakeCurrent(g_hdc, 0);
  wglDeleteContext(g_hglrc);
  ReleaseDC(g_hwnd, g_hdc);
  DestroyWindow(g_hwnd);

  g_hwnd = CreateWindowEx
    ( 0
    , u"Mary_OpenGL"
    , 0
    , 0, 0
    , 0, 0
    , 0, 0, 0, 0, 0
    );
  g_hdc = GetDC(g_hwnd);

  memset(&pfd, 0, sizeof(pfd));
  SetPixelFormat(g_hdc, g_pixel_format, &pfd);

  const int context_attribs[] =
    { WGL_CONTEXT_MAJOR_VERSION_ARB, 3
    , WGL_CONTEXT_MINOR_VERSION_ARB, 3
    , WGL_CONTEXT_PROFILE_MASK_ARB, WGL_CONTEXT_CORE_PROFILE_BIT_ARB
    , 0
    };
  g_hglrc = wglCreateContextAttribsARB(g_hdc, 0, context_attribs);
  wglMakeCurrent(g_hdc, g_hglrc);

  puts((char *)glGetString(GL_VERSION)); // temp
}

global void Mary_OpenGL_Finish()
{
  wglMakeCurrent(g_hdc, 0);
  wglDeleteContext(g_hglrc);
  ReleaseDC(g_hwnd, g_hdc);
  DestroyWindow(g_hwnd);
}

global const Mary_OpenGL_g Mary_OpenGL()
{
  const Mary_OpenGL_g interface =
    { g_hglrc
    , g_pixel_format
    };

  return interface;
}

global GLuint Mary_OpenGL_Shader(const char *vertex, const char *fragment)
{
  GLuint program = glCreateProgram();
  GLuint shader_vertex = Load_Shader(vertex, GL_VERTEX_SHADER);
  GLuint shader_fragment = Load_Shader(fragment, GL_FRAGMENT_SHADER);
  glAttachShader(program, shader_vertex);
  glAttachShader(program, shader_fragment);
  glLinkProgram(program);
  glValidateProgram(program);
  // need to make sure program is valid with glGetProgramiv

  glDetachShader(program, shader_vertex);
  glDetachShader(program, shader_fragment);
  glDeleteShader(shader_vertex);
  glDeleteShader(shader_fragment);
  return program;
}

intern GLuint Load_Shader(const char *file_path, GLenum shader_type)
{
  ////// load the file from disk
  FILE *file = fopen(file_path, "r");
  if (file == 0)
  {
    Mary_Exit_Failure("Shader_Load: could not open file.");
  }

  if (fseek(file, 0, SEEK_END))
  {
    Mary_Exit_Failure("Shader_Load: trouble reading file.");
  }

  int length = ftell(file); // 0 == 0
  if (length == -1)
  {
    Mary_Exit_Failure("Shader_Load: trouble reading file length.");
  }

  char *source = malloc(sizeof(char) * (length + 1));
  if (source == 0)
  {
    Mary_Exit_Failure("Shader_Load: problem allocating buffer.");
  }

  rewind(file);
  fread(source, sizeof(char), length, file);
  if (ferror(file))
  {
    Mary_Exit_Failure("Shader_Load: trouble reading into buffer.");
  }
  source[length] = '\0';

  ////// compile shader
  GLuint shader = glCreateShader(shader_type);
  glShaderSource(shader, 1, &source, 0);
  glCompileShader(shader);

  int did_compile;
  glGetShaderiv(shader, GL_COMPILE_STATUS, &did_compile);
  if (did_compile == GL_FALSE)
  {
    int length;
    glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &length);
    char errorMsg[1024];
    glGetShaderInfoLog(shader, length, &length, errorMsg);
    glDeleteShader(shader);
    Mary_Exit_Failure(errorMsg);
  }

  ////// clean up and return
  free(source);
  return shader;
}

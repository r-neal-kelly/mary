#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <Mary/Utils.h>
#include <Mary/Hashmap.h>
#include <Mary/Regex.h>

MARY_PRIMITIVES;

#define ESC  '~'        // NOT backslash
#define DOT  0xF0000000 // .
#define BAR  0xF0000001 // |
#define AND  0xF0000002 // & (implicit)
#define QUES 0xF0000003 // ?
#define STAR 0xF0000004 // *
#define PLUS 0xF0000005 // +
#define EXPO 0xF0000006 // ^
#define CASH 0xF0000007 // $
#define LPAR 0xF0000008 // (
#define RPAR 0xF0000009 // )
#define LSQU 0xF000000A // [
#define RSQU 0xF000000B // ]
#define HYPH 0xF000000C // -
#define APOS 0xF000000D // ?>
#define ANEG 0xF000000E // ?>!
#define BPOS 0xF000000F // ?<
#define BNEG 0xF0000010 // ?<!

#define FLAG_GLOBAL 0x01 // 'g'

#define SHORT_SPACES 0x00000000

#define STATE_DOT        0xF0000000 // .
#define STATE_XOR        0xF0000001 // []
#define STATE_NOR        0xF0000002 // [^]
#define STATE_SPLIT      0xF0000003 // *, +, ?, |
#define STATE_AHEAD_POS  0xF0000004 // (?>)
#define STATE_AHEAD_NEG  0xF0000005 // (?>!)
#define STATE_BEHIND_POS 0xF0000006 // (?<)
#define STATE_BEHIND_NEG 0xF0000007 // (?<!)
#define STATE_MATCH      0xF0000008

typedef struct
{
  u32 size;
  u32 str[64];
}
Shortcut;

typedef struct
{
  u32 flag; // 0x0 - 0x10FFFF for unicode
  void *out_a; // State *
  void *out_b; // State *
}
State;

typedef struct
{
  State *in;
  Mary_Pointer_t outs; // [State **...]
}
Fragment;

typedef struct
{
  State *state;
  u64 from;
}
Candidate;

typedef Mary_Slice_t Match;

b64 mary_regex_is_started = 0;
Mary_Hashmap_t hm_shortcuts;

void Mary_Regex_Start()
{
  u32 short_id, *str; Shortcut shortcut;
  Mary_Hashmap_Create(&hm_shortcuts, sizeof(u32), sizeof(Shortcut));

  #define SET_STR                                               \
    MARY_Range(str, u32, 0, shortcut.size)                      \
    {                                                           \
      if (range.val == '-') shortcut.str[range.idx] = HYPH;     \
      else  shortcut.str[range.idx] = range.val;                \
    }

  short_id = SHORT_SPACES; shortcut.size = 21;
  str = U" \n\r\t\f\u00A0\u2002-\u200B"; SET_STR;
  Mary_Hashmap_Assign(&hm_shortcuts, &short_id, &shortcut);

  #undef SET_STR

  mary_regex_is_started = 1;
}

void Mary_Regex_Finish()
{
  Mary_Hashmap_Destroy(&hm_shortcuts);
  mary_regex_is_started = 0;
}

void Mary_Regex_Create(Mary_Regex_t *mary_regex, char bit_format, void *expression, char *flags)
{
  if (!mary_regex_is_started) Mary_Exit_Failure("Need to run 'Mary_Regex_Start()'.");
  Mary_Pool_Create(&mary_regex->pool, 64 * sizeof(u32) + 64 * sizeof(State));
  void *data_expression = Mary_Pool_Allocate(&mary_regex->pool, 256);
  Mary_Pointer_t ptr_expression = { data_expression, 256 };
  Mary_String_Create_With(&mary_regex->expression, bit_format, expression, 0, ptr_expression);
  Mary_String_Format(&mary_regex->expression, 32);
  Mary_Regex_Compile(mary_regex);
  mary_regex->flags = 0;
  if (flags)
  {
    while (*flags != 0)
    {
      if (*flags == 'g') mary_regex->flags |= FLAG_GLOBAL;
      ++flags;
    }
  }
}

void Mary_Regex_Destroy(Mary_Regex_t *mary_regex)
{
  Mary_Pool_Destroy(&mary_regex->pool);
}

void Mary_Regex_Compile(Mary_Regex_t *mary_regex)
{
  {
    u32 *expression_back = (u32 *)mary_regex->expression.data + mary_regex->expression.codes - 1;
    if (mary_regex->expression.codes == 0)
    {
      Mary_Exit_Failure("Regex is empty.");
    }
    else if (mary_regex->expression.codes == 1 && *expression_back == ESC)
    {
      Mary_Exit_Failure("Regex has a dangling escape character.");
    }
    else if (*expression_back == ESC && *(expression_back - 1) != ESC)
    {
      Mary_Exit_Failure("Regex has a dangling escape character.");
    }
  }

  Mary_Vector_t v_input; u32 a_input[64];
  Mary_Pointer_t p_input = { a_input, 64 * sizeof(u32) };
  Mary_Vector_Create_With(&v_input, sizeof(u32), p_input);

  {
    Mary_Vector_t v_no_concat_next; u32 a_no_concat_next[7] = { '*', '+', '?', '{', ')', '|', '\0' };
    Mary_Pointer_t p_no_concat_next = { a_no_concat_next, 7 * sizeof(u32) };
    Mary_Vector_Create_With(&v_no_concat_next, sizeof(u32), p_no_concat_next);
    v_no_concat_next.size = 7;

    Mary_Vector_t v_codepoints; u32 a_codepoints[64];
    Mary_Pointer_t p_codepoints = { a_codepoints, 64 * sizeof(u32) };
    Mary_Vector_Create_With(&v_codepoints, sizeof(u32), p_codepoints);

    u32 symbol, symbol_and = AND;
    s64 bracket_balance = 0;
    u32 short_id; Shortcut shortcut;

    MARY_Range(mary_regex->expression.data, u32, 0, mary_regex->expression.size)
    {
      if (range.val == ESC)
      {
        MARY_Range_Advance(1);
        if (range.val == 's')
        {
          short_id = SHORT_SPACES; Mary_Hashmap_At(&hm_shortcuts, &short_id, &shortcut);
          symbol = LSQU; Mary_Vector_Push_Back(&v_input, &symbol);
          u64 from = v_input.size, to_exclusive = from + shortcut.size;
          Mary_Vector_Add_Slice(&v_input, from, to_exclusive, shortcut.str);
          symbol = RSQU; Mary_Vector_Push_Back(&v_input, &symbol);
        }
        else if (range.val == 'S')
        {
          short_id = SHORT_SPACES; Mary_Hashmap_At(&hm_shortcuts, &short_id, &shortcut);
          symbol = LSQU; Mary_Vector_Push_Back(&v_input, &symbol);
          symbol = EXPO; Mary_Vector_Push_Back(&v_input, &symbol);
          u64 from = v_input.size, to_exclusive = from + shortcut.size;
          Mary_Vector_Add_Slice(&v_input, from, to_exclusive, shortcut.str);
          symbol = RSQU; Mary_Vector_Push_Back(&v_input, &symbol);
        }
        else
        {
          Mary_Vector_Push_Back(&v_input, range.ptr);
        }
        if (!Mary_Vector_Contains(&v_no_concat_next, range.ptr + 1))
        {
          Mary_Vector_Push_Back(&v_input, &symbol_and);
        }
      }
      else if (range.val == '.')
      {
        symbol = DOT; Mary_Vector_Push_Back(&v_input, &symbol);
        if (!Mary_Vector_Contains(&v_no_concat_next, range.ptr + 1))
        {
          Mary_Vector_Push_Back(&v_input, &symbol_and);
        }
      }
      else if (range.val == '|')
      {
        symbol = BAR; Mary_Vector_Push_Back(&v_input, &symbol);
      }
      else if (range.val == '?')
      {
        u32 next = *(range.ptr + 1);
        if (next == '>')
        {
          next = *(range.ptr + 2);
          if (next == '!')
          {
            symbol = ANEG; Mary_Vector_Push_Back(&v_input, &symbol);
            MARY_Range_Advance(2);
          }
          else
          {
            symbol = APOS; Mary_Vector_Push_Back(&v_input, &symbol);
            MARY_Range_Advance(1);
          }
        }
        else if (next == '<')
        {
          next = *(range.ptr + 2);
          if (next == '!')
          {
            symbol = BNEG; Mary_Vector_Push_Back(&v_input, &symbol);
            MARY_Range_Advance(2);
          }
          else
          {
            symbol = BPOS; Mary_Vector_Push_Back(&v_input, &symbol);
            MARY_Range_Advance(1);
          }
        }
        else
        {
          symbol = QUES; Mary_Vector_Push_Back(&v_input, &symbol);
          if (!Mary_Vector_Contains(&v_no_concat_next, range.ptr + 1))
          {
            Mary_Vector_Push_Back(&v_input, &symbol_and);
          }
        }
      }
      else if (range.val == '*')
      {
        symbol = STAR; Mary_Vector_Push_Back(&v_input, &symbol);
        if (!Mary_Vector_Contains(&v_no_concat_next, range.ptr + 1))
        {
          Mary_Vector_Push_Back(&v_input, &symbol_and);
        }
      }
      else if (range.val == '+')
      {
        symbol = PLUS; Mary_Vector_Push_Back(&v_input, &symbol);
        if (!Mary_Vector_Contains(&v_no_concat_next, range.ptr + 1))
        {
          Mary_Vector_Push_Back(&v_input, &symbol_and);
        }
      }
      else if (range.val == '^')
      {
        symbol = EXPO; Mary_Vector_Push_Back(&v_input, &symbol);
      }
      else if (range.val == '$')
      {
        symbol = CASH; Mary_Vector_Push_Back(&v_input, &symbol);
      }
      else if (range.val == '(')
      {
        symbol = LPAR; Mary_Vector_Push_Back(&v_input, &symbol);
        ++bracket_balance;
      }
      else if (range.val == ')')
      {
        symbol = RPAR; Mary_Vector_Push_Back(&v_input, &symbol);
        if (!Mary_Vector_Contains(&v_no_concat_next, range.ptr + 1))
        {
          Mary_Vector_Push_Back(&v_input, &symbol_and);
        }
        --bracket_balance;
      }
      else if (range.val == '[')
      {
        symbol = LSQU; Mary_Vector_Push_Back(&v_input, &symbol);
        ++bracket_balance;
        MARY_Range_Advance(1);
        if (range.val == '^')
        {
          symbol = EXPO; Mary_Vector_Push_Back(&v_input, &symbol);
          MARY_Range_Advance(1);
        }
        while (range.val != ']' && range.val != 0)
        {
          if (range.val == '-')
          {
            symbol = HYPH; Mary_Vector_Push_Back(&v_input, &symbol);
            MARY_Range_Advance(1);
          }
          else if (range.val == ESC)
          {
            Mary_Vector_Push_Back(&v_input, range.ptr + 1);
            MARY_Range_Advance(2);
          }
          else
          {
            Mary_Vector_Push_Back(&v_input, range.ptr);
            MARY_Range_Advance(1);
          }
        }
        if (range.val == ']')
        {
          symbol = RSQU; Mary_Vector_Push_Back(&v_input, &symbol);
          if (!Mary_Vector_Contains(&v_no_concat_next, range.ptr + 1))
          {
            Mary_Vector_Push_Back(&v_input, &symbol_and);
          }
          --bracket_balance;
        }
      }
      else if (range.val == '{')
      {
        ++bracket_balance;
        MARY_Range_Advance(1);
        u64 m = 0, n = 0;
        while (range.val != ',') // might want string->number conversion in String_t, one for each format
        {
          if (range.val >= '0' && range.val <= '9')
          {
            Mary_Vector_Push_Back(&v_codepoints, &range.val);
          }
          MARY_Range_Advance(1);
        }
        for (u32 codepoint, pow = 1; v_codepoints.size; pow *= 10)
        {
          Mary_Vector_Pop_Back(&v_codepoints, &codepoint);
          m += (codepoint - '0') * pow;
        }
        MARY_Range_Advance(1);
        while (range.val != '}')
        {
          if (range.val >= '0' && range.val <= '9')
          {
            Mary_Vector_Push_Back(&v_codepoints, &range.val);
          }
          MARY_Range_Advance(1);
        }
        for (u32 codepoint, pow = 1; v_codepoints.size; pow *= 10)
        {
          Mary_Vector_Pop_Back(&v_codepoints, &codepoint);
          n += (codepoint - '0') * pow;
        }
        if (m == 0 && n == 1)
        {
          symbol = QUES; Mary_Vector_Push_Back(&v_input, &symbol);
        }
        else if (m == 0 && n == 0)
        {
          symbol = STAR; Mary_Vector_Push_Back(&v_input, &symbol);
        }
        else if (m == 1 && n == 0)
        {
          symbol = PLUS; Mary_Vector_Push_Back(&v_input, &symbol);
        }
        else if (!(m == 1 && n == 1))
        {
          u32 *input = v_input.size - 1 + a_input;
          u32 code = *input;
          if (code == RPAR || code == RSQU)
          {
            Mary_Vector_Push_Back(&v_codepoints, input);
            u64 balance = 1;
            while (balance)
            {
              code = *--input;
              Mary_Vector_Push_Back(&v_codepoints, input);
              if (code == RPAR || code == RSQU) ++balance;
              else if (code == LPAR || code == LSQU) --balance;
            }
            Mary_Vector_Reverse(&v_codepoints);
            if (m == 0)
            {
              symbol = QUES; Mary_Vector_Push_Back(&v_input, &symbol);
            }
            for (u64 i_m = m; i_m > 1; --i_m)
            {
              symbol = AND; Mary_Vector_Push_Back(&v_input, &symbol);
              MARY_Range(v_codepoints.data, u32, 0, v_codepoints.size)
              {
                Mary_Vector_Push_Back(&v_input, range.ptr);
              }
            }
            for (u64 i_n = n - m; i_n > 0; --i_n)
            {
              symbol = AND; Mary_Vector_Push_Back(&v_input, &symbol);
              MARY_Range(v_codepoints.data, u32, 0, v_codepoints.size)
              {
                Mary_Vector_Push_Back(&v_input, range.ptr);
              }
              symbol = QUES; Mary_Vector_Push_Back(&v_input, &symbol);
            }
            Mary_Vector_Empty(&v_codepoints);
          }
          else
          {
            if (m == 0)
            {
              symbol = QUES; Mary_Vector_Push_Back(&v_input, &symbol);
            }
            for (u64 i_m = m; i_m > 1; --i_m)
            {
              symbol = AND; Mary_Vector_Push_Back(&v_input, &symbol);
              Mary_Vector_Push_Back(&v_input, &code);
            }
            for (u64 i_n = n - m; i_n > 0; --i_n)
            {
              symbol = AND; Mary_Vector_Push_Back(&v_input, &symbol);
              Mary_Vector_Push_Back(&v_input, &code);
              symbol = QUES; Mary_Vector_Push_Back(&v_input, &symbol);
            }
          }
        }
        if (range.val == '}')
        {
          if (!Mary_Vector_Contains(&v_no_concat_next, range.ptr + 1))
          {
            Mary_Vector_Push_Back(&v_input, &symbol_and);
          }
          --bracket_balance;
        }
      }
      else if (range.val == 0)
      {
        Mary_Vector_Push_Back(&v_input, range.ptr);
      }
      else
      {
        Mary_Vector_Push_Back(&v_input, range.ptr);
        if (!Mary_Vector_Contains(&v_no_concat_next, range.ptr + 1))
        {
          Mary_Vector_Push_Back(&v_input, &symbol_and);
        }
      }
    }

    if (bracket_balance != 0)
    {
      Mary_Exit_Failure("Regex has an unclosed emphasis."); // this doesn't check for ([)] problems.
      // maybe instead we could make a stack of these things and push and pop to make sure everything's right.
    }
  }

  Mary_Vector_t v_stack; u32 a_stack[64];
  Mary_Pointer_t p_stack = { a_stack, 256 };
  Mary_Vector_Create_With(&v_stack, sizeof(u32), p_stack);

  Mary_Vector_t v_output; Fragment a_output[64];
  Mary_Pointer_t p_output = { a_output, 64 * sizeof(Fragment) };
  Mary_Vector_Create_With(&v_output, sizeof(Fragment), p_output);

  Mary_Vector_t v_codepoints; u32 a_codepoints[64];
  Mary_Pointer_t p_codepoints = { a_codepoints, 256 };
  Mary_Vector_Create_With(&v_codepoints, sizeof(u32), p_codepoints);

  Mary_Pool_t pool_compiler;
  Mary_Pool_Create(&pool_compiler, 1024);

  u32 top, *codepoints;
  Fragment frag, frag_a, frag_b;
  State **ppState;

  #define IN_CREATE(IN, FLAG, OUT_PTR_A, OUT_PTR_B)                                                \
  {                                                                                                \
    (IN) = Mary_Pool_Allocate(&mary_regex->pool, sizeof(State));                                   \
    (IN)->flag = (FLAG);                                                                           \
    (IN)->out_a = (OUT_PTR_A);                                                                     \
    (IN)->out_b = (OUT_PTR_B);                                                                     \
  }

  #define OUTS_CREATE(OUTS, OUT_PTR)                                                               \
  {                                                                                                \
    (OUTS).bytes = sizeof(State **);                                                               \
    (OUTS).data = Mary_Pool_Allocate(&pool_compiler, (OUTS).bytes);                                \
    ppState = &(State *)(OUT_PTR);                                                                 \
    memcpy((OUTS).data, &ppState, (OUTS).bytes);                                                   \
  }

  #define OUTS_CONCAT(OUTS, OUTS_A, OUTS_B)                                                        \
  {                                                                                                \
    (OUTS).bytes = (OUTS_A).bytes + (OUTS_B).bytes;                                                \
    (OUTS).data = Mary_Pool_Allocate(&pool_compiler, (OUTS).bytes);                                \
    memcpy((OUTS).data, (OUTS_A).data, (OUTS_A).bytes);                                            \
    memcpy((u8 *)(OUTS).data + (OUTS_A).bytes, (OUTS_B).data, (OUTS_B).bytes);                     \
  }

  #define OUTS_PATCH(OUTS, IN)                                                                     \
  {                                                                                                \
    MARY_Range((OUTS).data, State **, 0, (OUTS).bytes / sizeof(State **)) *range.val = IN;         \
  }

  #define OUTS_DELETE(OUTS)                                                                        \
  {                                                                                                \
    Mary_Pool_Deallocate(&pool_compiler, (OUTS).data);                                             \
  }

  #define EVAL_WHILE(CONDITION)                                                                    \
  {                                                                                                \
    if (v_stack.size)                                                                              \
    {                                                                                              \
      Mary_Vector_At(&v_stack, v_stack.size - 1, &top);                                            \
      while ((CONDITION))                                                                          \
      {                                                                                            \
        if (top == PLUS)                                                                           \
        {                                                                                          \
          Mary_Vector_Pop_Back(&v_output, &frag_a);                                                \
          IN_CREATE(frag.in, STATE_SPLIT, frag_a.in, 0);                                           \
          OUTS_PATCH(frag_a.outs, frag.in);                                                        \
          OUTS_DELETE(frag_a.outs);                                                                \
          OUTS_CREATE(frag.outs, frag.in->out_b);                                                  \
          frag.in = frag_a.in;                                                                     \
          Mary_Vector_Push_Back(&v_output, &frag);                                                 \
        }                                                                                          \
        else if (top == STAR)                                                                      \
        {                                                                                          \
          Mary_Vector_Pop_Back(&v_output, &frag_a);                                                \
          IN_CREATE(frag.in, STATE_SPLIT, frag_a.in, 0);                                           \
          OUTS_PATCH(frag_a.outs, frag.in);                                                        \
          OUTS_DELETE(frag_a.outs);                                                                \
          OUTS_CREATE(frag.outs, frag.in->out_b);                                                  \
          Mary_Vector_Push_Back(&v_output, &frag);                                                 \
        }                                                                                          \
        else if (top == QUES)                                                                      \
        {                                                                                          \
          Mary_Vector_Pop_Back(&v_output, &frag_a);                                                \
          IN_CREATE(frag.in, STATE_SPLIT, frag_a.in, 0);                                           \
          ppState = &(State *)frag.in->out_b;                                                      \
          frag_b.outs.data = &ppState;                                                             \
          frag_b.outs.bytes = sizeof(State **);                                                    \
          OUTS_CONCAT(frag.outs, frag_a.outs, frag_b.outs);                                        \
          OUTS_DELETE(frag_a.outs);                                                                \
          Mary_Vector_Push_Back(&v_output, &frag);                                                 \
        }                                                                                          \
        else if (top == AND)                                                                       \
        {                                                                                          \
          Mary_Vector_Pop_Back(&v_output, &frag_b);                                                \
          Mary_Vector_Pop_Back(&v_output, &frag_a);                                                \
          frag.in = frag_a.in;                                                                     \
          frag.outs = frag_b.outs;                                                                 \
          OUTS_PATCH(frag_a.outs, frag_b.in);                                                      \
          Mary_Vector_Push_Back(&v_output, &frag);                                                 \
        }                                                                                          \
        else if (top == BAR)                                                                       \
        {                                                                                          \
          Mary_Vector_Pop_Back(&v_output, &frag_b);                                                \
          Mary_Vector_Pop_Back(&v_output, &frag_a);                                                \
          IN_CREATE(frag.in, STATE_SPLIT, frag_a.in, frag_b.in);                                   \
          OUTS_CONCAT(frag.outs, frag_a.outs, frag_b.outs);                                        \
          OUTS_DELETE(frag_a.outs);                                                                \
          OUTS_DELETE(frag_b.outs);                                                                \
          Mary_Vector_Push_Back(&v_output, &frag);                                                 \
        }                                                                                          \
        else if (top == APOS)                                                                      \
        {                                                                                          \
          Mary_Vector_Pop_Back(&v_output, &frag_a);                                                \
          IN_CREATE(frag_b.in, STATE_MATCH, 0, 0);                                                 \
          OUTS_PATCH(frag_a.outs, frag_b.in);                                                      \
          OUTS_DELETE(frag_a.outs);                                                                \
          IN_CREATE(frag.in, STATE_AHEAD_POS, 0, frag_a.in);                                       \
          OUTS_CREATE(frag.outs, frag.in->out_a);                                                  \
          Mary_Vector_Push_Back(&v_output, &frag);                                                 \
        }                                                                                          \
        else if (top == ANEG)                                                                      \
        {                                                                                          \
          Mary_Vector_Pop_Back(&v_output, &frag_a);                                                \
          IN_CREATE(frag_b.in, STATE_MATCH, 0, 0);                                                 \
          OUTS_PATCH(frag_a.outs, frag_b.in);                                                      \
          OUTS_DELETE(frag_a.outs);                                                                \
          IN_CREATE(frag.in, STATE_AHEAD_NEG, 0, frag_a.in);                                       \
          OUTS_CREATE(frag.outs, frag.in->out_a);                                                  \
          Mary_Vector_Push_Back(&v_output, &frag);                                                 \
        }                                                                                          \
        else if (top == BPOS)                                                                      \
        {                                                                                          \
          Mary_Vector_Pop_Back(&v_output, &frag_a);                                                \
          IN_CREATE(frag_b.in, STATE_MATCH, 0, 0);                                                 \
          OUTS_PATCH(frag_a.outs, frag_b.in);                                                      \
          OUTS_DELETE(frag_a.outs);                                                                \
          IN_CREATE(frag.in, STATE_BEHIND_POS, 0, frag_a.in);                                      \
          OUTS_CREATE(frag.outs, frag.in->out_a);                                                  \
          Mary_Vector_Push_Back(&v_output, &frag);                                                 \
        }                                                                                          \
        else if (top == BNEG)                                                                      \
        {                                                                                          \
          Mary_Vector_Pop_Back(&v_output, &frag_a);                                                \
          IN_CREATE(frag_b.in, STATE_MATCH, 0, 0);                                                 \
          OUTS_PATCH(frag_a.outs, frag_b.in);                                                      \
          OUTS_DELETE(frag_a.outs);                                                                \
          IN_CREATE(frag.in, STATE_BEHIND_NEG, 0, frag_a.in);                                      \
          OUTS_CREATE(frag.outs, frag.in->out_a);                                                  \
          Mary_Vector_Push_Back(&v_output, &frag);                                                 \
        }                                                                                          \
        if (--v_stack.size == 0) break;                                                            \
        else Mary_Vector_At(&v_stack, v_stack.size - 1, &top);                                     \
      }                                                                                            \
    }                                                                                              \
  }

  MARY_Range(v_input.data, u32, 0, v_input.size)
  {
    // precedence 1: +, *, ? 2: () 3: & 4: |
    if (range.val == 0)
    {
      EVAL_WHILE(v_stack.size != 0);
      Mary_Vector_Pop_Back(&v_output, &frag_a);
      IN_CREATE(frag.in, STATE_MATCH, 0, 0);
      OUTS_PATCH(frag_a.outs, frag.in);
      mary_regex->machine = frag_a.in;
      break;
    }
    else if (range.val == PLUS || range.val == STAR || range.val == QUES)
    {
      EVAL_WHILE(top == PLUS || top == STAR || top == QUES);
      Mary_Vector_Push_Back(&v_stack, range.ptr);
    }
    else if (range.val == LPAR)
    {
      EVAL_WHILE(top == PLUS || top == STAR || top == QUES);
      Mary_Vector_Push_Back(&v_stack, range.ptr);
    }
    else if (range.val == RPAR)
    {
      EVAL_WHILE(top != LPAR);
      --v_stack.size;
    }
    else if (range.val == AND)
    {
      EVAL_WHILE(top == PLUS || top == STAR || top == QUES || top == AND);
      Mary_Vector_Push_Back(&v_stack, range.ptr);
    }
    else if (range.val == BAR)
    {
      EVAL_WHILE(top == PLUS || top == STAR || top == QUES || top == AND || top == BAR);
      Mary_Vector_Push_Back(&v_stack, range.ptr);
    }
    else if (range.val == APOS || range.val == ANEG || range.val == BPOS || range.val == BNEG)
    {
      Mary_Vector_Push_Back(&v_stack, range.ptr);
    }
    else if (range.val == LSQU)
    {
      MARY_Range_Advance(1);
      if (range.val == EXPO)
      {
        IN_CREATE(frag.in, STATE_NOR, 0, 0);
        MARY_Range_Advance(1);
      }
      else
      {
        IN_CREATE(frag.in, STATE_XOR, 0, 0);
      }
      while (range.val != RSQU)
      {
        Mary_Vector_Push_Back(&v_codepoints, &range.val);
        MARY_Range_Advance(1);
      }
      range.val = 0; Mary_Vector_Push_Back(&v_codepoints, &range.val);
      codepoints = Mary_Pool_Allocate(&mary_regex->pool, sizeof(32) * v_codepoints.size);
      memcpy(codepoints, v_codepoints.data, sizeof(32) * v_codepoints.size);
      Mary_Vector_Empty(&v_codepoints);
      frag.in->out_b = codepoints;
      OUTS_CREATE(frag.outs, frag.in->out_a);
      Mary_Vector_Push_Back(&v_output, &frag);
    }
    else if (range.val == DOT)
    {
      IN_CREATE(frag.in, STATE_DOT, 0, 0);
      OUTS_CREATE(frag.outs, frag.in->out_a);
      Mary_Vector_Push_Back(&v_output, &frag);
    }
    else
    {
      IN_CREATE(frag.in, range.val, 0, 0);
      OUTS_CREATE(frag.outs, frag.in->out_a);
      Mary_Vector_Push_Back(&v_output, &frag);
    }
  }

  #undef IN_CREATE
  #undef OUTS_CREATE
  #undef OUTS_CONCAT
  #undef OUTS_PATCH
  #undef OUTS_DELETE
  #undef EVAL_WHILE

  Mary_Pool_Destroy(&pool_compiler);
}

Mary_Vector_t Mary_Regex_Execute(Mary_Regex_t *mary_regex, char bit_format, void *search_string)
{
  if (bit_format == 8)
  {
    return Mary_Regex_8bit_Execute(mary_regex, search_string);
  }
  else if (bit_format == 16)
  {
    return Mary_Regex_16bit_Execute(mary_regex, search_string);
  }
  else
  {
    return Mary_Regex_32bit_Execute(mary_regex, search_string);
  }
}

Mary_Vector_t Mary_Regex_8bit_Execute(Mary_Regex_t *mary_regex, uint8_t *search_string)
{
  return (Mary_Vector_t){0, 0, 0, 0};
}

Mary_Vector_t Mary_Regex_16bit_Execute(Mary_Regex_t *mary_regex, uint16_t *search_string)
{
  return (Mary_Vector_t){ 0, 0, 0, 0 };
}

Mary_Vector_t Mary_Regex_32bit_Execute(Mary_Regex_t *mary_regex, uint32_t *search_string)
{
  Mary_String_t str;
  Mary_String_Create(&str, 32, search_string, 0);

  Candidate candidate, *p_candidate;
  Mary_Vector_t v_candidates_a, *v_old = &v_candidates_a; Candidate a_candidates_a[64];
  Mary_Pointer_t p_candidates_a = { a_candidates_a, sizeof(Candidate) * 64 };
  Mary_Vector_Create_With(v_old, sizeof(Candidate), p_candidates_a);

  Mary_Vector_t v_candidates_b, *v_new = &v_candidates_b; Candidate a_candidates_b[64];
  Mary_Pointer_t p_candidates_b = { a_candidates_b, sizeof(Candidate) * 64 };
  Mary_Vector_Create_With(v_new, sizeof(Candidate), p_candidates_b);

  State *state;
  Mary_Vector_t v_states; State *a_states[64];
  Mary_Pointer_t p_states = { a_states, sizeof(State *) * 64 };
  Mary_Vector_Create_With(&v_states, sizeof(State *), p_states);

  Match match;
  Mary_Vector_t v_matches;
  Mary_Vector_Create(&v_matches, sizeof(Match), 64 * sizeof(Match));

  Mary_Vector_t *v_swap;
  u32 *codepoints;

  MARY_Range(str.data, u32, 0, str.size)
  {
    // update old candidates
    for (u64 i = 0; i < v_old->size; ++i)
    {
      Mary_Vector_Point(v_old, i, &p_candidate);
      if (p_candidate->from > range.idx)
      {
        // waits to check valid spots found after a look behind.
        Mary_Vector_Push_Back(v_new, p_candidate); continue;
      }
      Mary_Vector_Push_Back(&v_states, &p_candidate->state->out_a);
      for (u64 j = 0; j < v_states.size; ++j)
      {
        Mary_Vector_At(&v_states, j, &state);
        if (state->flag == STATE_MATCH)
        {
          match.from = p_candidate->from;
          match.to_exclusive = range.idx;
          Mary_Vector_Push_Back(&v_matches, &match);
        }
        else if (state->flag == STATE_SPLIT)
        {
          Mary_Vector_Push_Back(&v_states, &state->out_a);
          Mary_Vector_Push_Back(&v_states, &state->out_b);
        }
        else if (state->flag == STATE_XOR)
        {
          codepoints = state->out_b;
          for (; *codepoints != 0; ++codepoints)
          {
            if (*(codepoints + 1) == HYPH)
            {
              if (range.val >= *codepoints && range.val <= *(codepoints += 2))
              {
                candidate = (Candidate) { state, p_candidate->from };
                Mary_Vector_Push_Back(v_new, &candidate); break;
              }
            }
            else if (range.val == *codepoints)
            {
              candidate = (Candidate) { state, p_candidate->from };
              Mary_Vector_Push_Back(v_new, &candidate); break;
            }
          }
        }
        else if (state->flag == STATE_NOR)
        {
          codepoints = state->out_b;
          for (; *codepoints != 0; ++codepoints)
          {
            if (*(codepoints + 1) == HYPH)
            {
              if (range.val >= *codepoints && range.val <= *(codepoints += 2)) break;
            }
            else if (range.val == *codepoints) break;
          }
          if (*codepoints == 0)
          {
            candidate = (Candidate) { state, p_candidate->from };
            Mary_Vector_Push_Back(v_new, &candidate);
          }
        }
        else if (state->flag == STATE_DOT)
        {
          if (range.val != '\n')
          {
            candidate = (Candidate) { state, p_candidate->from };
            Mary_Vector_Push_Back(v_new, &candidate);
          }
        }
        else if (state->flag == range.val)
        {
          candidate = (Candidate) { state, p_candidate->from };
          Mary_Vector_Push_Back(v_new, &candidate);
        }
      }
      Mary_Vector_Empty(&v_states);
    }
    Mary_Vector_Empty(v_old);

    // add any candidates from machine start
    if (v_matches.size == 0 || mary_regex->flags & FLAG_GLOBAL)
    {
      Mary_Vector_Push_Back(&v_states, &mary_regex->machine);
      for (u64 j = 0; j < v_states.size; ++j)
      {
        Mary_Vector_At(&v_states, j, &state);
        if (state->flag == STATE_MATCH)
        {
          // matches ""
          match.from = range.idx;
          match.to_exclusive = range.idx + 1;
          Mary_Vector_Push_Back(&v_matches, &match);
        }
        else if (state->flag == STATE_BEHIND_POS)
        {
          // I should put this in the candidates' check loop if a look_behind is in the middle of the string.
          // but it may not work as expected...?
          Mary_Regex_t look_behind = { mary_regex->pool, mary_regex->expression, 0, state->out_b };
          Mary_Vector_t matches = Mary_Regex_Execute(&look_behind, 32, range.ptr);
          u64 string_idx = range.idx;
          MARY_Range(matches.data, Mary_Slice_t, 0, matches.size)
          {
            candidate = (Candidate) { state, string_idx + range.val.to_exclusive };
            if (candidate.from - (range.val.to_exclusive - range.val.from) == string_idx) // perhaps just check last candidate to see if it has the same from.
            {
              Mary_Vector_Push_Back(v_new, &candidate);
            }
          }
          Mary_Vector_Destroy(&matches);
        }
        else if (state->flag == STATE_BEHIND_NEG)
        {
          Mary_Regex_t look_behind = { mary_regex->pool, mary_regex->expression, 0, state->out_b };
          Mary_Vector_t matches = Mary_Regex_Execute(&look_behind, 32, range.ptr);

          Mary_Vector_Destroy(&matches);
        }
        else if (state->flag == STATE_SPLIT)
        {
          Mary_Vector_Push_Back(&v_states, &state->out_a);
          Mary_Vector_Push_Back(&v_states, &state->out_b);
        }
        else if (state->flag == STATE_XOR)
        {
          codepoints = state->out_b;
          for (; *codepoints != 0; ++codepoints)
          {
            if (*(codepoints + 1) == HYPH)
            {
              if (range.val >= *codepoints && range.val <= *(codepoints += 2))
              {
                candidate = (Candidate) { state, range.idx };
                Mary_Vector_Push_Back(v_new, &candidate); break;
              }
            }
            else if (range.val == *codepoints)
            {
              candidate = (Candidate) { state, range.idx };
              Mary_Vector_Push_Back(v_new, &candidate); break;
            }
          }
        }
        else if (state->flag == STATE_NOR)
        {
          codepoints = state->out_b;
          for (; *codepoints != 0; ++codepoints)
          {
            if (*(codepoints + 1) == HYPH)
            {
              if (range.val >= *codepoints && range.val <= *(codepoints += 2)) break;
            }
            else if (range.val == *codepoints) break;
          }
          if (*codepoints == 0)
          {
            candidate = (Candidate) { state, range.idx };
            Mary_Vector_Push_Back(v_new, &candidate);
          }
        }
        else if (state->flag == STATE_DOT)
        {
          if (range.val != '\n')
          {
            candidate = (Candidate) { state, range.idx };
            Mary_Vector_Push_Back(v_new, &candidate);
          }
        }
        else if (state->flag == range.val)
        {
          candidate = (Candidate) { state, range.idx };
          Mary_Vector_Push_Back(v_new, &candidate);
        }
      }
      Mary_Vector_Empty(&v_states);
    }

    // swap buffers
    v_swap = v_old; v_old = v_new; v_new = v_swap;
  }
  Mary_String_Destroy(&str);

  return v_matches;
}

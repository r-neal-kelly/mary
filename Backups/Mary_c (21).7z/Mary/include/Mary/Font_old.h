#pragma once

#include <stdint.h>
#include <Mary/Hashmap.h>

typedef struct
{
  void *data;
  Mary_Hashmap_t tables;
  const uint16_t *name;
  const uint16_t *copyright;
  uint8_t long_loca;
  uint16_t units_per_em;
  int16_t ascent;
  int16_t descent;
  uint8_t *cmap;
  uint32_t (*Glyph_Index)(void *mary_font, uint32_t unicode); // could do a void *
}
Mary_Font_t;

void Mary_Font_Start();
void Mary_Font_Finish();
void Mary_Font_Create(Mary_Font_t *mary_font, char *file_path);
void Mary_Font_Destroy(Mary_Font_t *mary_font);

#pragma once

#include <stdint.h>

#define MARY_PRIMITIVES            \
  typedef uint8_t  u8;             \
  typedef uint16_t u16;            \
  typedef uint32_t u32;            \
  typedef uint64_t u64;            \
  typedef int8_t   s8;             \
  typedef int16_t  s16;            \
  typedef int32_t  s32;            \
  typedef int64_t  s64;            \
  typedef float    r32;            \
  typedef double   r64;            \
  typedef uint8_t  bool

#define MARY_SWAP_16(I)            \
(                                  \
  (I) >> 8 & 0x00FF |              \
  (I) << 8 & 0xFF00                \
)

#define MARY_SWAP_32(I)            \
(                                  \
  (I) >> 24 & 0x000000FF |         \
  (I) >> 8  & 0x0000FF00 |         \
  (I) << 8  & 0x00FF0000 |         \
  (I) << 24 & 0xFF000000           \
)

#define MARY_SWAP_64(I)            \
(                                  \
  (I) >> 56 & 0x00000000000000FF | \
  (I) >> 48 & 0x000000000000FF00 | \
  (I) >> 40 & 0x0000000000FF0000 | \
  (I) >> 32 & 0x00000000FF000000 | \
  (I) << 32 & 0x000000FF00000000 | \
  (I) << 40 & 0x0000FF0000000000 | \
  (i) << 48 & 0x00FF000000000000 | \
  (I) << 56 & 0xFF00000000000000   \
)

void Mary_Exit_Success();
void Mary_Exit_Failure(const char *error_string);
char Mary_Is_Big_Endian();
char Mary_Is_Little_Endian();

typedef struct
{
  void *data;
  size_t size;
}
Mary_File_t;
Mary_File_t Mary_File_Read(const char *file_path);
void Mary_File_Destroy(Mary_File_t *mary_file);

void Mary_Print_Binary(void *value, int size);

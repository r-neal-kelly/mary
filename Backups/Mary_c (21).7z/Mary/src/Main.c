﻿#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <Mary/Mary.h>

MARY_PRIMITIVES;

int main()
{
  //Mary_Start();

#if 0
  Mary_Vector_t test; u8 in = 101, out = 0;
  MARY_Vector_Create(test, u8, 8);
  MARY_Vector_Push_Back(test, in);
  MARY_Vector_At(test, 0, out);
  printf("%i\n", out);
  MARY_Vector_Destroy(test);
  MARY_Vector_Create(test, u16, 8);
  MARY_Vector_Destroy(test);
  Mary_Exit_Success();
#endif

#if 0
  Mary_Window_t window;
  Mary_Window_Create(&window);
  while (Mary_Window_Can_Render())
  {
    Mary_Window_Render();
  }
  Mary_Window_Destroy(&window);
#endif

#if 0
  Mary_String_t string;
  Mary_String_Create(&string, 16, u"Praise Yahweh!", 0);
  wprintf(u"%s\n", (wchar_t *)string.data);
  printf("size:%zu\n", string.size);
  Mary_String_Destroy(&string); puts("");

  Mary_String_Create(&string, 8, "Amen!!!", 0);
  Mary_String_Convert(&string, 32);
  Mary_String_Convert(&string, 16);
  Mary_String_Convert(&string, 8);
  printf("%s\n", (char *)string.data);
  printf("size:%zu\n", string.size);
  Mary_String_Convert(&string, 16);
  wprintf(u"%s\n", (wchar_t *)*(void **)&string);
  Mary_String_Destroy(&string); puts("");

  Mary_Exit_Success();
#endif

  u64 val = 345893427923479;
  Mary_Print_Binary(&val, 8);

  Mary_Font_Start();
  Mary_Font_t font; Mary_String_t string;
  Mary_Font_Create(&font, "SILEOTSR.ttf");
  Mary_String_Create(&string, 16, u"אהב", 0);
  Mary_Font_Layout(&font, &string, MARY_FONT_HEBREW);
  Mary_String_Destroy(&string);
  Mary_Font_Destroy(&font);
  Mary_Font_Finish();

  Mary_Exit_Success();

  //Mary_Finish();
}

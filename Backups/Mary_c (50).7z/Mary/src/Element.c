#include <string.h>
#include <Mary/Element.h>
#include <Mary/Window.h>
#include <Mary/Div.h>
#include <Mary/Text.h>

MARY_PRIMITIVES;

typedef void (*Render_f)(void *);

Mary_Hashmap_t type_sizes;
Mary_Hashmap_t render_funcs;

void Mary_Element_Start()
{
  #define ASSIGN_TYPE_SIZE(TYPE, TYPE_NAME)\
    type = TYPE, size = sizeof(TYPE_NAME), Mary_Hashmap_Assign(&type_sizes, &type, &size)

  #define ASSIGN_RENDER_FUNC(TYPE, RENDER_FUNC)\
    type = TYPE, Render = RENDER_FUNC, Mary_Hashmap_Assign(&render_funcs, &type, &Render)

  size_t type, size;
  Mary_Hashmap_Create(&type_sizes, sizeof(size_t), sizeof(size_t));
  ASSIGN_TYPE_SIZE(MARY_ELEMENT_WINDOW, Mary_Window_t);
  ASSIGN_TYPE_SIZE(MARY_ELEMENT_DIV, Mary_Div_t);
  ASSIGN_TYPE_SIZE(MARY_ELEMENT_TEXT, Mary_Text_t);

  Render_f Render;
  Mary_Hashmap_Create(&render_funcs, sizeof(size_t), sizeof(Render_f));
  ASSIGN_RENDER_FUNC(MARY_ELEMENT_WINDOW, Mary_Window_Render);
  ASSIGN_RENDER_FUNC(MARY_ELEMENT_DIV, Mary_Div_Render);
  ASSIGN_RENDER_FUNC(MARY_ELEMENT_TEXT, Mary_Text_Render);

  #undef ASSIGN_TYPE_SIZE
  #undef ASSIGN_RENDER_FUNC
}

void Mary_Element_Finish()
{
  Mary_Hashmap_Destroy(&type_sizes);
  Mary_Hashmap_Destroy(&render_funcs);
}

void Mary_Element_Create(void *mary_element, size_t type)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  size_t type_size; Mary_Hashmap_At(&type_sizes, &type, &type_size);
  memset(element, 0, type_size);
  element->type = type;
  if (type == MARY_ELEMENT_WINDOW) element->window = MARY_Window(element);
  Mary_Vector_Create(&element->children_s, sizeof(Mary_Element_t *), 0);
  Mary_Vector_Create(&element->children_z, sizeof(Mary_Element_t *), 0);
  Mary_Vector_Create(&element->events, sizeof(Mary_Event_t *), 0);
  Mary_Hashmap_Create(&element->listeners, sizeof(Mary_Element_t *), sizeof(u64));
  element->back_a = 1, element->fore_a = 1;
}

void Mary_Element_Destroy(void *mary_element)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  size_t type_size; Mary_Hashmap_At(&type_sizes, &element->type, &type_size);
  Mary_Vector_Destroy(&element->children_s);
  Mary_Vector_Destroy(&element->children_z);
  Mary_Vector_Destroy(&element->events);
  Mary_Hashmap_Destroy(&element->listeners);
  memset(element, 0, type_size); // may just want to memset the element size here?
}

void Mary_Element_Compute_Size(Mary_Element_t *element)
{
  // so here we need to run through each child and compare them
  // together to figure out where they will be placed on screen.
  // we cache the results in the element type so that they can
  // access the needed details in rendering func.

  // I think we need to recurse downwards to children to get the
  // width and height first, and then we can do the coords.
  // we'll set the parent's w and h directly, no need to return
  // that info from from.

  element->x1 = element->parent->x1 + element->parent->padding_l + element->margin_l;
  element->y1 = element->parent->y1 + element->parent->padding_t + element->margin_t;
  element->x2 = element->parent->x2 - element->parent->padding_r - element->margin_r;
  element->y2 = element->parent->y2 - element->parent->padding_b - element->margin_b;
}

void Mary_Element_Render_Children(Mary_Element_t *element)
{
  Render_f Render;
  MARY_Vector_Each(element->children_z, Mary_Element_t *)
  {
    Mary_Hashmap_At(&render_funcs, &range.val->type, &Render);
    Render(range.val);
    Mary_Element_Render_Children(range.val);
  }
}

static void Mary_Element_Window(Mary_Element_t *element, Mary_Window_t *window)
{
  element->window = window;
  MARY_Vector_Each(element->children_s, Mary_Element_t *)
  {
    Mary_Element_Window(range.val, window);
  }
}

void Mary_Element_Append_To(void *mary_element, void *mary_element_parent)
{
  #define LAST_CHILD_Z(PARENT_PTR)\
    (*(Mary_Element_t **)Mary_Vector_Point(&PARENT_PTR->children_z, PARENT_PTR->children_z.units - 1))

  Mary_Element_t *element = MARY_Element(mary_element);
  Mary_Element_t *parent = MARY_Element(mary_element_parent);

  ////// remove from old parent
  if (element->parent != 0)
  {
    MARY_Vector_Each(element->parent->children_s, Mary_Element_t *)
    {
      if (range.val == element)
      {
        Mary_Vector_Erase_At(&element->parent->children_s, range.idx); break;
      }
    }
    MARY_Vector_Each(element->parent->children_z, Mary_Element_t *)
    {
      if (range.val == element)
      {
        Mary_Vector_Erase_At(&element->parent->children_z, range.idx); break;
      }
    }
    Mary_Window_Flag_Dirty(element->window);
  }

  ////// add to new parent
  Mary_Vector_Push_Back(&parent->children_s, &element);
  if (parent->children_z.units == 0)
  {
    Mary_Vector_Push_Back(&parent->children_z, &element);
  }
  else if (LAST_CHILD_Z(parent)->z <= element->z)
  {
    Mary_Vector_Push_Back(&parent->children_z, &element);
  }
  else
  {
    MARY_Vector_Each(parent->children_z, Mary_Element_t *)
    {
      if (range.val->z > element->z)
      {
        Mary_Vector_Push_At(&parent->children_z, range.idx, &element);
      }
    }
  }
  Mary_Element_Window(element, parent->window);
  Mary_Window_Flag_Dirty(element->window);
  element->parent = parent;

  #undef LAST_CHILD_Z
}

void Mary_Element_Remove(void *mary_element)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  if (element->parent != 0)
  {
    MARY_Vector_Each(element->parent->children_s, Mary_Element_t *)
    {
      if (range.val == element)
      {
        Mary_Vector_Erase_At(&element->parent->children_s, range.idx); break;
      }
    }
    MARY_Vector_Each(element->parent->children_z, Mary_Element_t *)
    {
      if (range.val == element)
      {
        Mary_Vector_Erase_At(&element->parent->children_z, range.idx); break;
      }
    }
    Mary_Window_Flag_Dirty(element->window);
    Mary_Element_Window(element, 0);
    element->parent = 0;
  }
}

void Mary_Element_Position(void *mary_element, float x, float y, int z)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  element->x = x, element->y = y, element->z = z;
}

void Mary_Element_Size(void *mary_element, float w, float h)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  element->inner_w = w, element->inner_h = h; // I wonder if we should have a setting to make the one or the other default?
}

void Mary_Element_Back_Color(void *mary_element, float r, float g, float b, float a)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  element->back_r = r, element->back_g = g, element->back_b = b, element->back_a = a;
}

void Mary_Element_Fore_Color(void *mary_element, float r, float g, float b, float a)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  element->fore_r = r, element->fore_g = g, element->fore_b = b, element->fore_a = a;
}

void Mary_Element_Margin(void *mary_element, float l, float t, float r, float b)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  element->margin_l = l, element->margin_t = t, element->margin_r = r, element->margin_b = b;
}

void Mary_Element_Padding(void *mary_element, float l, float t, float r, float b)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  element->padding_l = l, element->padding_t = t, element->padding_r = r, element->padding_b = b;
}

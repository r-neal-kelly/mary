#pragma once

#include <Mary/Element.h>

#define MARY_EVENT_TYPES 3

enum
{
  MARY_EVENT_KEYDOWN,
  MARY_EVENT_MOUSECLICK,
  MARY_EVENT_MOUSEWHEEL
};

typedef struct Mary_Event_t Mary_Event_t;
typedef struct Mary_Event_Keydown_t Mary_Event_Keydown_t;
typedef struct Mary_Event_Mouseclick_t Mary_Event_Mouseclick_t;
typedef struct Mary_Event_Mousewheel_t Mary_Event_Mousewheel_t;

#define MARY_Event_t\
  uint32_t type;\
  Mary_Element_t *target, *current;\
  uint8_t skipped, stopped, defaulted

struct Mary_Event_t
{
  MARY_Event_t;
};

struct Mary_Event_Keydown_t
{
  MARY_Event_t;
  uint32_t key;
};

// mousedown then mouseup, then mouseclick after cycle is complete. but it has to happen on the same element
// to be a mouseclick. else one element has a mousedown and another has a mouseup.
struct Mary_Event_Mouseclick_t
{
  MARY_Event_t;
  uint8_t button;
};

struct Mary_Event_Mousewheel_t
{
  MARY_Event_t;
  int16_t delta, key, x, y;
};

typedef void (*Mary_Event_f)(Mary_Event_t *);
typedef struct Mary_Event_Listener_t Mary_Event_Listener_t;

struct Mary_Event_Listener_t
{
  // should we add event_type
  Mary_Element_t *subject;
  Mary_Event_f function;
  uint8_t capture, once;
};

void Mary_Event_Start();
void Mary_Event_Finish();
void *Mary_Event_Create(Mary_Window_t *window, int enum_mary_event);
void Mary_Event_Create_Listeners(Mary_Vector_t *listeners);
void Mary_Event_Destroy_Listeners(Mary_Vector_t *listeners);
void Mary_Event_Dispatch(void *mary_event, void *mary_element_target);
void Mary_Event_Skip_Current(void *mary_event);
void Mary_Event_Stop_Propagation(void *mary_event);
void Mary_Event_Enable_Default(void *mary_event);
void Mary_Event_Disable_Default(void *mary_event);
void Mary_Event_Add_Listener(void *mary_element, int enum_mary_event, Mary_Event_f func, char capture, char once);
void Mary_Event_Del_Listener(void *mary_element, int enum_mary_event, Mary_Event_f func, char capture, char once);
void Mary_Event_Empty_Listeners(void *mary_element, int enum_mary_event);
// may want to change the names, but we need a remove too. maybe Push and Pop?

#define MARY_Event(PTR) ((Mary_Event_t *)(PTR))

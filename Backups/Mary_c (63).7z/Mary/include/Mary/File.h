#pragma once

#include <Mary/Utils.h>

typedef struct
{
  MARY_Pointer_t;
}
Mary_File_t;

void Mary_File_Create(Mary_File_t *mary_file, const char *file_path, const char *mode);
void Mary_File_Destroy(Mary_File_t *mary_file);

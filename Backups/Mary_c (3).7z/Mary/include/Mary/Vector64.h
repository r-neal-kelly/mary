#pragma once

#include <stdint.h>

// make a Mary_Vector1_t too, for bools, bitwise! fun!

// we could do one with void *, but we would have to use
// pointer arthimetic to access elements I think.
// but could be useful and all encompassing.

typedef struct
{
  int64_t *data;
  size_t capacity;
  size_t length;
  //uint8_t unit; // indivual size, 64bit, etc.
}
Mary_Vector64_t;

typedef struct
{
  void    (*const Create)    (Mary_Vector64_t *vector);
  void    (*const Destroy)   (Mary_Vector64_t *vector);
  int64_t (*const At)        (Mary_Vector64_t *vector, size_t index);
  int8_t  (*const Has_At)    (Mary_Vector64_t *vector, size_t index);
  int64_t (*const Front)     (Mary_Vector64_t *vector);
  int64_t (*const Back)      (Mary_Vector64_t *vector);
  void    (*const Push_Back) (Mary_Vector64_t *vector, int64_t element);
  void    (*const Push_Front)(Mary_Vector64_t *vector, int64_t element);
  int64_t (*const Pop_Back)  (Mary_Vector64_t *vector);
  int64_t (*const Pop_Front) (Mary_Vector64_t *vector);
  void    (*const Insert)    (Mary_Vector64_t *vector, size_t index, int64_t element);
  int64_t (*const Remove)    (Mary_Vector64_t *vector, size_t index);
  int64_t (*const Replace)   (Mary_Vector64_t *vector, size_t index, int64_t element);
  int8_t  (*const Is_Empty)  (Mary_Vector64_t *vector);
  void    (*const Do_Empty)  (Mary_Vector64_t *vector);
  void    (*const Grow)      (Mary_Vector64_t *vector, size_t bytes);
  void    (*const Fit)       (Mary_Vector64_t *vector);
  void    (*const Print)     (Mary_Vector64_t *vector, uint8_t elements_per_line);
}
Mary_Vector64_i;

const Mary_Vector64_i Mary_Vector64();

#pragma once

#include <stddef.h>

typedef struct
{
  void *data;
  size_t capacity;
  size_t unit;
  size_t size;
}
Mary_Vector_t;

typedef struct
{
  void (*const Create)    (Mary_Vector_t *vector, size_t unit);
  void (*const Destroy)   (Mary_Vector_t *vector);
  void (*const Reserve)   (Mary_Vector_t *vector, size_t size);
  void (*const Fit)       (Mary_Vector_t *vector);
  void (*const Insert)    (Mary_Vector_t *vector, size_t index, void *elem_in);
  void (*const Extract)   (Mary_Vector_t *vector, size_t index, void *elem_out);
  void (*const Assign)    (Mary_Vector_t *vector, size_t index, void *elem_in);
  void (*const Exchange)  (Mary_Vector_t *vector, size_t index, void *elem_in, void *elem_out);
  void (*const Push_Back) (Mary_Vector_t *vector, void *elem_in);
  void (*const Push_Front)(Mary_Vector_t *vector, void *elem_in);
  void (*const Pop_Back)  (Mary_Vector_t *vector, void *elem_out);
  void (*const Pop_Front) (Mary_Vector_t *vector, void *elem_out);
  void (*const At)        (Mary_Vector_t *vector, size_t index, void *elem_out);
  char (*const Has_At)    (Mary_Vector_t *vector, size_t index);
  void (*const Back)      (Mary_Vector_t *vector, void *elem_out);
  void (*const Front)     (Mary_Vector_t *vector, void *elem_out);
  void (*const Empty)     (Mary_Vector_t *vector);
  char (*const Is_Empty)  (Mary_Vector_t *vector);
  void (*const Resize)    (Mary_Vector_t *vector, size_t size);
  void (*const Fill)      (Mary_Vector_t *vector, void *elem_in);
  void (*const Rotate)    (Mary_Vector_t *vector, void *elem_out);
  void (*const Reverse)   (Mary_Vector_t *vector);
  char (*const Contains)  (Mary_Vector_t *vector, void *elem);
}
Mary_Vector_i;

const Mary_Vector_i *Mary_Vector();

#include <Mary/Utils.h>
#include <Mary/Allocator.h>
#include <Mary/Arena.h>
#include <Mary/Hashmap.h>
#include <Mary/Regex.h>

MARY_Primitives;
MARY_Allocators;

#define UNICODE_LIMIT 0x10FFFF // not currently used, but a good reminder.
#define ESC '~' // I kinda want the user to be able to choose this, but will backslash work?

uint32_t MARY_Regex_Class_Space[]       = U" \n\r\t\f\x00A0\x2002-\x200B";
uint32_t MARY_Regex_Class_Latin[]       = U"\x0021-\x007E\x00A1-\x00AC\x00AE-\x024F";
uint32_t MARY_Regex_Class_Latin_Char[]  = U"";
uint32_t MARY_Regex_Class_Latin_Punc[]  = U"\x0020-\x002F\x003A-\x0040\x005B-\x0060\x007B-\x007E";
uint32_t MARY_Regex_Class_Latin_Numb[]  = U"";
uint32_t MARY_Regex_Class_Hebrew[]      = U"\x0590-\x05FF\xFB1D-\xFB4F";
uint32_t MARY_Regex_Class_Hebrew_Char[] = U"\x05D0-\x05F2\x05C6\xFB1F-\xFB28\xFB2A-\xFB4F\xFB1D";
uint32_t MARY_Regex_Class_Hebrew_Punc[] = U"";
uint32_t MARY_Regex_Class_Greek[]       = U"\x0370-\x03FF\x1F00-\x1FFF";
uint32_t MARY_Regex_Class_Greek_Char[]  = U"";
uint32_t MARY_Regex_Class_Greek_Punc[]  = U"";

static u32 Class_Phrase_Latin[6]        = U"Latin:";
static u32 Class_Phrase_Latin_Char[11]  = U"Latin Char:";
static u32 Class_Phrase_Latin_Punc[11]  = U"Latin Punc:";
static u32 Class_Phrase_Latin_Numb[11]  = U"Latin Numb:";
static u32 Class_Phrase_Hebrew[7]       = U"Hebrew:";
static u32 Class_Phrase_Hebrew_Char[12] = U"Hebrew Char:";
static u32 Class_Phrase_Hebrew_Punc[12] = U"Hebrew Punc:";
static u32 Class_Phrase_Greek[6]        = U"Greek:";
static u32 Class_Phrase_Greek_Char[11]  = U"Greek Char:";
static u32 Class_Phrase_Greek_Punc[11]  = U"Greek Punc:";

static u64 Class_Phrase_Latin_Units       = 6;
static u64 Class_Phrase_Latin_Char_Units  = 11;
static u64 Class_Phrase_Latin_Punc_Units  = 11;
static u64 Class_Phrase_Latin_Numb_Units  = 11;
static u64 Class_Phrase_Hebrew_Units      = 7;
static u64 Class_Phrase_Hebrew_Char_Units = 12;
static u64 Class_Phrase_Hebrew_Punc_Units = 12;
static u64 Class_Phrase_Greek_Units       = 6;
static u64 Class_Phrase_Greek_Char_Units  = 11;
static u64 Class_Phrase_Greek_Punc_Units  = 11;

static Mary_Bool_t is_started = MARY_FALSE;
static Mary_Hashmap_t enum_to_classes;

enum Mary_Regex_Flag_e
{
  FLAG_GLOBAL = 1,   // 'g'
  FLAG_MULTILINE     // 'm'
  // add one that disable /n check on .
};

enum Mary_Regex_Token_e
{
  TOKEN_DOT = 0xF0000000, // .
  TOKEN_BAR,              // |
  TOKEN_AND,              // & (implicit)
  TOKEN_QUES,             // ?
  TOKEN_STAR,             // *
  TOKEN_PLUS,             // +
  TOKEN_EXPO,             // ^
  TOKEN_CASH,             // $
  TOKEN_LPAR,             // (
  TOKEN_RPAR,             // )
  TOKEN_LSQU,             // [
  TOKEN_RSQU,             // ]
  TOKEN_BEHIND_POS,       // ?<
  TOKEN_BEHIND_NEG,       // ?<!
  TOKEN_AHEAD_POS,        // ?>
  TOKEN_AHEAD_NEG,        // ?>!
  TOKEN_BOUND_POS,        // ~b
  TOKEN_BOUND_NEG,        // ~B
  TOKEN_CLASS_POS,        // ~s, etc.
  TOKEN_CLASS_NEG         // ~S, etc.
};

enum Mary_Regex_Class_e
{
  CLASS_SPACE = 0xF0000000, // ~s ~S
  CLASS_LATIN,              // ~:Latin: ~:!Latin:
  CLASS_LATIN_CHAR,         // ~:Latin Char: ~:!Latin Char:
  CLASS_LATIN_PUNC,         // ~:Latin Punc: ~:!Latin Punc:
  CLASS_LATIN_NUMB,         // ~:Latin Numb: ~:!Latin Numb:
  CLASS_HEBREW,             // ~:Hebrew: ~:!Hebrew:
  CLASS_HEBREW_CHAR,        // ~:Hebrew Char: ~:!Hebrew Char:
  CLASS_HEBREW_PUNC,        // ~:Hebrew Punc: ~:!Hebrew Punc:
  CLASS_GREEK,              // ~:Greek: ~:!Greek:
  CLASS_GREEK_CHAR,         // ~:Greek Char: ~:!Greek Char:
  CLASS_GREEK_PUNC          // ~:Greek Punc: ~:!Greek Punc:
};

enum Mary_Regex_State_e
{
  STATE_MATCH,
  STATE_UNICODE,            // 0x0 - 0x10FFFF
  STATE_DOT,                // .
  STATE_CLASS_POS,          // [], ~s, etc.
  STATE_CLASS_NEG,          // [^], ~S, etc.
  STATE_BRANCH,             // *, +, ?, |
  STATE_BEHIND_POS,         // (?<)
  STATE_BEHIND_NEG,         // (?<!)
  STATE_AHEAD_POS,          // (?>)
  STATE_AHEAD_NEG,          // (?>!)
  STATE_BOUND_EXPO,         // ^
  STATE_BOUND_CASH,         // $
  STATE_BOUND_POS,          // ~b
  STATE_BOUND_NEG           // ~B
};

typedef struct System_t System_t;
typedef union Variable_u Variable_u;
typedef Mary_Index_t State_t;
typedef Mary_Vector_t Enum_v;
typedef Mary_Vector_t State_v;
typedef Mary_Vector_t Variable_v;

struct System_t // this should have its own type. but I'm not sure how I would init a variable amount of vectors.
{
  Enum_v flags;
  State_v outs;
  Variable_v vars;
};

union Variable_u
{
  State_t branch;
  State_t look;
  Mary_Char_32_t unicode;
  Mary_C_String_32_t class;
};

typedef struct Fragment_t Fragment_t;
typedef struct Candidate_t Candidate_t;
typedef Mary_Slice_t Match; // before we give matches back to user, I think we can sort the slices.

struct Fragment_t
{
  State_t in;
  State_v outs;
};

struct Candidate_t
{
  State_t state;
  Mary_Index_t from;
};

static void Mary_Regex_Tokenize(u32 *data, Mary_Size_t units, Mary_Vector_t *v_tokens);
static void Mary_Regex_Compile(Mary_Regex_t *this, Mary_Vector_t *v_tokens);
static void Mary_Regex_Evaluate(); // to be called from within Compile();

void Mary_Regex_Start()
{
  if (is_started == MARY_TRUE) return;

  Mary_Enum_t class_enum, *str; Mary_C_String_32_p class; // we may not need the units for class, since we test to 0 anyway.
  Mary_Hashmap_Create(&enum_to_classes, sizeof(class_enum), sizeof(class));

  #define HASH(ENUM, STR)                                        \
  MARY_M                                                         \
    class_enum = ENUM;                                           \
    class.data = STR;                                            \
    class.units = Mary_C_String_Count_Units(STR, 32, MARY_TRUE); \
    Mary_Hashmap_Assign(&enum_to_classes, &class_enum, &class);  \
  MARY_W

  HASH(CLASS_SPACE, MARY_Regex_Class_Space);
  HASH(CLASS_LATIN, MARY_Regex_Class_Latin);
  HASH(CLASS_LATIN_CHAR, MARY_Regex_Class_Latin_Char);
  HASH(CLASS_LATIN_PUNC, MARY_Regex_Class_Latin_Punc);
  HASH(CLASS_LATIN_NUMB, MARY_Regex_Class_Latin_Numb);
  HASH(CLASS_HEBREW, MARY_Regex_Class_Hebrew);
  HASH(CLASS_HEBREW_CHAR, MARY_Regex_Class_Hebrew_Char);
  HASH(CLASS_HEBREW_PUNC, MARY_Regex_Class_Hebrew_Punc);
  HASH(CLASS_GREEK, MARY_Regex_Class_Greek);
  HASH(CLASS_GREEK_CHAR, MARY_Regex_Class_Greek_Char);
  HASH(CLASS_GREEK_PUNC, MARY_Regex_Class_Greek_Punc);

  #undef HASH

  is_started = MARY_TRUE;
}

void Mary_Regex_Stop()
{
  if (is_started == MARY_FALSE) return;

  Mary_Hashmap_Destroy(&enum_to_classes);

  is_started = MARY_FALSE;
}

void Mary_Regex_Create(Mary_Regex_t *this, Mary_Allocator_t allocator, Mary_UTF_t utf, Mary_C_String_t expression, Mary_C_String_8_t flags)
{
  MARY_Arena_In;

#ifdef MARY_Debug
  MARY_Assert(is_started == MARY_TRUE, "Mary_Regex has not been started.");
#endif

  this->allocator = allocator; // may want a TRY.

  Mary_String_Create_From(&this->expression, this->allocator, 32, expression, utf);

#ifdef MARY_Debug
  MARY_Assert(*(u32 *)this->expression.data == 0, "Expression is an empty string.");
#endif

  Mary_Vector_Create(&this->classes, this->allocator, sizeof(Mary_C_String_32_t), 16); // make sure to use this->allocator when allocing a user_class in compile.

  System_t *system = this->system = Mary_Allocator_Alloc(this->allocator, sizeof(System_t));
  Mary_Vector_Create(&system->flags, this->allocator, sizeof(Mary_Enum_t), 64);
  Mary_Vector_Create(&system->outs, this->allocator, sizeof(State_t), 64);
  Mary_Vector_Create(&system->vars, this->allocator, sizeof(Variable_u), 64);

  this->flags = 0;
  if (flags)
    while (*flags != 0)
    {
      if (*flags == 'g' || *flags == 'G')
        MARY_Bit_Set(this->flags, FLAG_GLOBAL);
      else if (*flags == 'm' || *flags == 'M')
        MARY_Bit_Set(this->flags, FLAG_MULTILINE);
      ++flags;
    }

  MARY_Vector_Frame(v_tokens, u32, this->expression.units);
  Mary_Regex_Tokenize(this->expression.data, this->expression.units, &v_tokens);
  Mary_Regex_Compile(this, &v_tokens); // if we made each machine global, then we could check to see if we have the expression already compiled. might be a good idea.

  MARY_Arena_Out;
}

void Mary_Regex_Destroy(Mary_Regex_t *this)
{
  System_t *system = this->system;
  Mary_Vector_Destroy(&system->flags);
  Mary_Vector_Destroy(&system->outs);
  Mary_Vector_Destroy(&system->vars);
  Mary_Allocator_Dealloc(this->allocator, system);
  MARY_Vector_Each(&this->classes, Mary_C_String_32_t)
    Mary_Allocator_Dealloc(this->allocator, it.val);
  Mary_Vector_Destroy(&this->classes);
  Mary_String_Destroy(&this->expression);
}

static void Mary_Regex_Tokenize(u32 *data, Mary_Size_t units, Mary_Vector_t *v_tokens)
{
  MARY_Arena_In;

  u32 next;
  MARY_Vector_Frame(v_buffer, u32, 64);
  MARY_Vector_Frame(v_sub_tokens, u32, 64);

  #define ASSERT(THIS_IS_TRUE, ERR)\
    MARY_Assert(THIS_IS_TRUE, "Invalid regex: " ERR)

  #define PUSH(TOKEN)\
    MARY_Vector_Push(v_tokens, u32, TOKEN)

  #define IS_CLASS(CLASS_NAME)                      \
    Mary_Is_Same(it.ptr, Class_Phrase_##CLASS_NAME, \
                 sizeof(Class_Phrase_##CLASS_NAME))

  #define CLASS_UNITS(CLASS_NAME)\
    Class_Phrase_##CLASS_NAME##_Units

  #define TRY_CONCAT               \
  (                                \
    next = it.val == '\0' ?        \
      '*' : *(it.ptr + 1),         \
    next != '*'  && next != '+' && \
    next != '?'  && next != '{' && \
    next != ')'  && next != '|' && \
    next != '\0' ?                 \
      PUSH(TOKEN_AND), 0 : 0       \
  )

  MARY_Range(data, u32, 0, units)
  {
    if (it.val == '.')
      PUSH(TOKEN_DOT),
      TRY_CONCAT;
    else if (it.val == '|')
      PUSH(TOKEN_BAR);
    else if (it.val == '*')
      PUSH(TOKEN_STAR),
      TRY_CONCAT;
    else if (it.val == '+')
      PUSH(TOKEN_PLUS),
      TRY_CONCAT;
    else if (it.val == '^')
      PUSH(TOKEN_EXPO),
      TRY_CONCAT;
    else if (it.val == '$')
      PUSH(TOKEN_CASH),
      TRY_CONCAT;
    else if (it.val == '(')
      PUSH(TOKEN_LPAR);
    else if (it.val == ')')
      PUSH(TOKEN_RPAR),
      TRY_CONCAT;
    else if (it.val == '[')
    {
      PUSH(TOKEN_LSQU);
      MARY_Range_Advance(1);
      if (it.val == '^')
        PUSH(TOKEN_EXPO),
        MARY_Range_Advance(1);
      while (it.val != ']' && it.val != 0)
      {
        if (it.val == ESC)
          PUSH(*(it.ptr + 1)),
          MARY_Range_Advance(2);
        else
          PUSH(it.val),
          MARY_Range_Advance(1);
      }
      ASSERT(it.val == ']', "Missing ].");
      PUSH(TOKEN_RSQU);
      TRY_CONCAT;
    }
    else if (it.val == ESC)
    {
      MARY_Range_Advance(1);
      if (it.val == 's')
        PUSH(TOKEN_CLASS_POS),
        PUSH(CLASS_SPACE);
      else if (it.val == 'S')
        PUSH(TOKEN_CLASS_NEG),
        PUSH(CLASS_SPACE);
      else if (it.val == 'b' || it.val == 'B')
      {
        if (it.val == 'b')
          PUSH(TOKEN_BOUND_POS);
        else
          PUSH(TOKEN_BOUND_NEG);
        if (*(it.ptr + 1) == ':')
        {
          MARY_Range_Advance(2);
          if (IS_CLASS(Latin))
            PUSH(CLASS_LATIN_PUNC),
            MARY_Range_Advance(CLASS_UNITS(Latin));
          else if (IS_CLASS(Greek))
            PUSH(CLASS_GREEK_PUNC),
            MARY_Range_Advance(CLASS_UNITS(Greek));
          else if (IS_CLASS(Hebrew))
            PUSH(CLASS_HEBREW_PUNC),
            MARY_Range_Advance(CLASS_UNITS(Hebrew));
        }
        else
          PUSH(CLASS_LATIN_PUNC);
      }
      else if (it.val == ':')
      {
        MARY_Range_Advance(1);
        if (it.val == '!')
          PUSH(TOKEN_CLASS_NEG),
          MARY_Range_Advance(1);
        else
          PUSH(TOKEN_CLASS_POS);
        if (it.val == 'L')
        {
          if (IS_CLASS(Latin))
            PUSH(CLASS_LATIN),
            MARY_Range_Advance(CLASS_UNITS(Latin));
          else if (IS_CLASS(Latin_Char))
            PUSH(CLASS_LATIN_CHAR),
            MARY_Range_Advance(CLASS_UNITS(Latin_Char));
          else if (IS_CLASS(Latin_Punc))
            PUSH(CLASS_LATIN_PUNC),
            MARY_Range_Advance(CLASS_UNITS(Latin_Punc));
          else if (IS_CLASS(Latin_Numb))
            PUSH(CLASS_LATIN_NUMB),
            MARY_Range_Advance(CLASS_UNITS(Latin_Numb));
        }
        else if (it.val == 'H')
        {
          if (IS_CLASS(Hebrew))
            PUSH(CLASS_HEBREW),
            MARY_Range_Advance(CLASS_UNITS(Hebrew));
          else if (IS_CLASS(Hebrew_Char))
            PUSH(CLASS_HEBREW_CHAR),
            MARY_Range_Advance(CLASS_UNITS(Hebrew_Char));
          else if (IS_CLASS(Hebrew_Punc))
            PUSH(CLASS_HEBREW_PUNC),
            MARY_Range_Advance(CLASS_UNITS(Hebrew_Punc));
        }
        else if (it.val == 'G')
        {
          if (IS_CLASS(Greek))
            PUSH(CLASS_GREEK),
            MARY_Range_Advance(CLASS_UNITS(Greek));
          else if (IS_CLASS(Greek_Char))
            PUSH(CLASS_GREEK_CHAR),
            MARY_Range_Advance(CLASS_UNITS(Greek_Char));
          else if (IS_CLASS(Greek_Punc))
            PUSH(CLASS_GREEK_PUNC),
            MARY_Range_Advance(CLASS_UNITS(Greek_Punc));
        }
      }
      else
      {
        PUSH(it.val);
      }
      TRY_CONCAT;
    }
    else if (it.val == '?')
    {
      if (*(it.ptr + 1) == '<')
      {
        MARY_Range_Advance(2);
        if (it.val == '!')
          PUSH(TOKEN_BEHIND_NEG),
          MARY_Range_Advance(1);
        else
          PUSH(TOKEN_BEHIND_POS);
        // tokenize the look behind
        u32 *ptr = it.ptr;
        u64 balance = 1, units = 0;
        while (balance != 0 && it.val != '\0')
        {
          if (it.val == ESC)
            units += 2,
            MARY_Range_Advance(2);
          else
          {
            if (it.val == '(')
              ++balance;
            else if (it.val == ')')
              --balance;
            ++units;
            MARY_Range_Advance(1);
          }
        }
        ASSERT(balance == 0, "Missing ).");
        ASSERT(it.val == ')', "Missing ).");
        MARY_Vector_Empty(&v_sub_tokens);
        Mary_Regex_Tokenize(ptr, --units, &v_sub_tokens);
        // reverse TOKEN_AND clusters
        MARY_Vector_Empty(&v_buffer);
        MARY_Vector_Each_Reverse(&v_sub_tokens, u32)
        {
          if (it.val != TOKEN_AND)
            MARY_Vector_Push(&v_buffer, u32, it.val);
          else
          {
            while (v_buffer.units != 0)
              PUSH(MARY_Vector_Pop(&v_buffer, u32)),
              PUSH(TOKEN_AND);
          }
        }
        while (v_buffer.units != 0)
          PUSH(MARY_Vector_Pop(&v_buffer, u32));
        PUSH(TOKEN_RPAR);
        TRY_CONCAT;
      }
      else if (*(it.ptr + 1) == '>')
      {
        MARY_Range_Advance(2);
        if (it.val == '!')
          PUSH(TOKEN_AHEAD_NEG),
          MARY_Range_Advance(1);
        else
          PUSH(TOKEN_AHEAD_POS);
      }
      else
        PUSH(TOKEN_QUES),
        TRY_CONCAT;
    }
    else if (it.val == '{')
    {
      // read {m,n}
      MARY_Range_Advance(1);
      MARY_Vector_Stack(v_m, u32, 3);
      MARY_Vector_Stack(v_n, u32, 3);
      while (it.val != ',' && it.val != '}' && it.val != '\0')
        ASSERT(v_m.units < 3, "{m} is too big."),
        ASSERT(it.val >= '0' && it.val <= '9', "{m} is not a number."),
        MARY_Vector_Push(&v_m, u32, it.val),
        MARY_Range_Advance(1);
      ASSERT(it.val == ',' || it.val == '}', "Missing }.");
      while (it.val != '}' && it.val != '\0')
        ASSERT(v_n.units < 3, "{,n} is too big."),
        ASSERT(it.val >= '0' && it.val <= '9', "{,n} is not a number."),
        MARY_Vector_Push(&v_n, u32, it.val),
        MARY_Range_Advance(1);
      ASSERT(it.val == '}', "Missing }.");
      // convert to numbers
      s64 m = v_m.units ? 0 : -1;
      s64 n = v_n.units ? 0 : -1;
      for (u64 exp = 1; v_m.units; exp *= 10)
        m += (MARY_Vector_Pop(&v_m, u32) - '0') * exp;
      for (u64 exp = 1; v_n.units; exp *= 10)
        n += (MARY_Vector_Pop(&v_n, u32) - '0') * exp;
      ASSERT(m != -1, "{} is missing m.");
      ASSERT(n != 0, "{,0} is invalid.");
      ASSERT(n == -1 || n >= m, "{} n is less than m.");
      ASSERT(v_tokens->units != 0, "Dangling {}.");
      // add tokens
      if (m == 0 && n == 1)
        PUSH(TOKEN_QUES);
      else if (m == 0 && n == -1)
        PUSH(TOKEN_STAR);
      else if (m == 1 && n == -1)
        PUSH(TOKEN_PLUS);
      else if (!(m == 1 && n == 1))
      {
        // copy previous cluster
        MARY_Vector_Empty(&v_buffer);
        u32 *prev1 = MARY_Vector_Point_Back(v_tokens);
        u32 *prev2 = v_tokens->units > 1 ? prev1 - 1 : 0;
        if (prev2 && *prev1 == TOKEN_RPAR) // (.){}
        {
          u32 balance = 1;
          for (; balance != 0; --prev2)
          {
            if (*prev2 == TOKEN_RPAR)
              ++balance;
            else if (*prev2 == TOKEN_LPAR)
              --balance;
          }
          for (; prev2 <= prev1; ++prev2)
            MARY_Vector_Push(&v_buffer, u32, *prev2);
        }
        else if (prev2 && *prev1 == TOKEN_RSQU) // [.]{}
        {
          for (; *prev2 != TOKEN_LSQU; --prev2);
          for (; prev2 <= prev1; ++prev2)
            MARY_Vector_Push(&v_buffer, u32, *prev2);
        }
        else if (prev2 && (*prev2 == TOKEN_CLASS_POS ||
                           *prev2 == TOKEN_CLASS_NEG ||
                           *prev2 == TOKEN_BOUND_POS ||
                           *prev2 == TOKEN_BOUND_NEG)) // ~.{}, ~.:.:{}, ~:.:{}
          MARY_Vector_Push(&v_buffer, u32, *prev2),
          MARY_Vector_Push(&v_buffer, u32, *prev1);
        else // .{}
          MARY_Vector_Push(&v_buffer, u32, *prev1);
        // add m
        if (m == 0)
          PUSH(TOKEN_QUES);
        else
          for (I i_m = m; i_m > 1; --i_m)
          {
            PUSH(TOKEN_AND);
            for (I i = 0; i < v_buffer.units; ++i)
              PUSH(MARY_Vector_At(&v_buffer, u32, i));
          }
        // add n
        if (n == -1)
        {
          PUSH(TOKEN_AND);
          for (I i = 0; i < v_buffer.units; ++i)
            PUSH(MARY_Vector_At(&v_buffer, u32, i));
          PUSH(TOKEN_STAR);
        }
        else
          for (I i_n = n - m; i_n > 0; --i_n)
          {
            PUSH(TOKEN_AND);
            for (I i = 0; i < v_buffer.units; ++i)
              PUSH(MARY_Vector_At(&v_buffer, u32, i));
            PUSH(TOKEN_QUES);
          }
      }
      TRY_CONCAT;
    }
    else
      PUSH(it.val),
      TRY_CONCAT;
  }

  #undef ASSERT
  #undef PUSH
  #undef IS_CLASS
  #undef CLASS_UNITS
  #undef TRY_CONCAT

  MARY_Arena_Out;
}

static void Mary_Regex_Compile(Mary_Regex_t *this, Mary_Vector_t *v_tokens)
{
  MARY_Arena_In;

  MARY_Vector_Frame(v_frags, Fragment_t, 64);
  MARY_Vector_Frame(v_stack, u32, 64);

  System_t *system = this->system;
  Fragment_t *frag;

  MARY_Vector_Each(v_tokens, u32)
  {
    // precedence 1: +, *, ? 2: () 3: & 4: |
    switch (it.val)
    {
      case '\0':
        break;
      default:
        MARY_Vector_Push(&system->flags, Mary_Enum_t, STATE_UNICODE);
        MARY_Vector_Push(&system->outs, State_t, 0);
        MARY_Vector_Push(&system->vars, Mary_Char_32_t, it.val);

        frag = MARY_Vector_Point_Push(&v_frags);
        Mary_Vector_Create(&frag->outs, FRAME, sizeof(State_t), 4);
        frag->in = system->flags.units - 1;
        MARY_Vector_Push(&frag->outs, State_t, frag->in);

        break;
    }
  }

  MARY_Arena_Out;
}

/*
static void Mary_Regex_Compile(Mary_Regex_t *this)
{
  MARY_Arena_In;

  MARY_Vector_Frame(v_tokens, u32, 64);
  Mary_Regex_Tokenize(this->expression.data,
                      this->expression.units,
                      &v_tokens);

  MARY_Vector_Stack(v_stack, u32, 64);
  MARY_Vector_Stack(v_output, Fragment, 64);
  MARY_Vector_Stack(v_codepoints, u32, 64); // prob. don't need this.

  u32 top, *codepoints, flag; Shortcut *shortcut; Fragment frag, frag_a, frag_b; State **ppState;

  #define IN_CREATE(IN, FLAG, OUT_PTR_A, OUT_PTR_B)                                                \
  {                                                                                                \
    (IN) = Mary_Pool_Alloc(mary_regex->pool, sizeof(State));                                       \
    (IN)->flag = (FLAG);                                                                           \
    (IN)->out_a = (OUT_PTR_A);                                                                     \
    (IN)->out_b = (OUT_PTR_B);                                                                     \
  }

  #define OUTS_CREATE(OUTS, OUT_PTR)                                                               \
  {                                                                                                \
    (OUTS).bytes = sizeof(State **);                                                               \
    (OUTS).data = Mary_Pool_Alloc(compiler_pool, (OUTS).bytes);                                    \
    ppState = &(State *)(OUT_PTR);                                                                 \
    memcpy((OUTS).data, &ppState, (OUTS).bytes);                                                   \
  }

  #define OUTS_CONCAT(OUTS, OUTS_A, OUTS_B)                                                        \
  {                                                                                                \
    (OUTS).bytes = (OUTS_A).bytes + (OUTS_B).bytes;                                                \
    (OUTS).data = Mary_Pool_Alloc(compiler_pool, (OUTS).bytes);                                    \
    memcpy((OUTS).data, (OUTS_A).data, (OUTS_A).bytes);                                            \
    memcpy((u8 *)(OUTS).data + (OUTS_A).bytes, (OUTS_B).data, (OUTS_B).bytes);                     \
  }

  #define OUTS_PATCH(OUTS, IN)                                                                     \
  {                                                                                                \
    MARY_Range((OUTS).data, State **, 0, (OUTS).bytes / sizeof(State **)) *it.val = IN;            \
  }

  #define OUTS_DELETE(OUTS)                                                                        \
  {                                                                                                \
    Mary_Pool_Dealloc(compiler_pool, (OUTS).data);                                                 \
  }

  #define EVAL_WHILE(CONDITION)                                                                    \
  {                                                                                                \
    if (v_stack.units)                                                                             \
    {                                                                                              \
      top = MARY_Vector_At_Back(&v_stack, u32);                                                    \
      while ((CONDITION))                                                                          \
      {                                                                                            \
        if (top == PLUS)                                                                           \
        {                                                                                          \
          frag_a = MARY_Vector_Pop(&v_output, Fragment);                                           \
          IN_CREATE(frag.in, STATE_SPLIT, frag_a.in, 0);                                           \
          OUTS_PATCH(frag_a.outs, frag.in);                                                        \
          OUTS_DELETE(frag_a.outs);                                                                \
          OUTS_CREATE(frag.outs, frag.in->out_b);                                                  \
          frag.in = frag_a.in;                                                                     \
          MARY_Vector_Push(&v_output, Fragment, frag);                                             \
        }                                                                                          \
        else if (top == STAR)                                                                      \
        {                                                                                          \
          frag_a = MARY_Vector_Pop(&v_output, Fragment);                                           \
          IN_CREATE(frag.in, STATE_SPLIT, frag_a.in, 0);                                           \
          OUTS_PATCH(frag_a.outs, frag.in);                                                        \
          OUTS_DELETE(frag_a.outs);                                                                \
          OUTS_CREATE(frag.outs, frag.in->out_b);                                                  \
          MARY_Vector_Push(&v_output, Fragment, frag);                                             \
        }                                                                                          \
        else if (top == QUES)                                                                      \
        {                                                                                          \
          frag_a = MARY_Vector_Pop(&v_output, Fragment);                                           \
          IN_CREATE(frag.in, STATE_SPLIT, frag_a.in, 0);                                           \
          ppState = &(State *)frag.in->out_b;                                                      \
          frag_b.outs.data = &ppState;                                                             \
          frag_b.outs.bytes = sizeof(State **);                                                    \
          OUTS_CONCAT(frag.outs, frag_a.outs, frag_b.outs);                                        \
          OUTS_DELETE(frag_a.outs);                                                                \
          MARY_Vector_Push(&v_output, Fragment, frag);                                             \
        }                                                                                          \
        else if (top == AND)                                                                       \
        {                                                                                          \
          frag_b = MARY_Vector_Pop(&v_output, Fragment);                                           \
          frag_a = MARY_Vector_Pop(&v_output, Fragment);                                           \
          frag.in = frag_a.in;                                                                     \
          frag.outs = frag_b.outs;                                                                 \
          OUTS_PATCH(frag_a.outs, frag_b.in);                                                      \
          MARY_Vector_Push(&v_output, Fragment, frag);                                             \
        }                                                                                          \
        else if (top == BAR)                                                                       \
        {                                                                                          \
          frag_b = MARY_Vector_Pop(&v_output, Fragment);                                           \
          frag_a = MARY_Vector_Pop(&v_output, Fragment);                                           \
          IN_CREATE(frag.in, STATE_SPLIT, frag_a.in, frag_b.in);                                   \
          OUTS_CONCAT(frag.outs, frag_a.outs, frag_b.outs);                                        \
          OUTS_DELETE(frag_a.outs);                                                                \
          OUTS_DELETE(frag_b.outs);                                                                \
          MARY_Vector_Push(&v_output, Fragment, frag);                                             \
        }                                                                                          \
        else if (top == AHEAD_POS)                                                                 \
        {                                                                                          \
          frag_a = MARY_Vector_Pop(&v_output, Fragment);                                           \
          IN_CREATE(frag_b.in, STATE_MATCH, 0, 0);                                                 \
          OUTS_PATCH(frag_a.outs, frag_b.in);                                                      \
          OUTS_DELETE(frag_a.outs);                                                                \
          IN_CREATE(frag.in, STATE_AHEAD_POS, 0, frag_a.in);                                       \
          OUTS_CREATE(frag.outs, frag.in->out_a);                                                  \
          MARY_Vector_Push(&v_output, Fragment, frag);                                             \
        }                                                                                          \
        else if (top == AHEAD_NEG)                                                                 \
        {                                                                                          \
          frag_a = MARY_Vector_Pop(&v_output, Fragment);                                           \
          IN_CREATE(frag_b.in, STATE_MATCH, 0, 0);                                                 \
          OUTS_PATCH(frag_a.outs, frag_b.in);                                                      \
          OUTS_DELETE(frag_a.outs);                                                                \
          IN_CREATE(frag.in, STATE_AHEAD_NEG, 0, frag_a.in);                                       \
          OUTS_CREATE(frag.outs, frag.in->out_a);                                                  \
          MARY_Vector_Push(&v_output, Fragment, frag);                                             \
        }                                                                                          \
        else if (top == BEHIND_POS)                                                                \
        {                                                                                          \
          frag_a = MARY_Vector_Pop(&v_output, Fragment);                                           \
          IN_CREATE(frag_b.in, STATE_MATCH, 0, 0);                                                 \
          OUTS_PATCH(frag_a.outs, frag_b.in);                                                      \
          OUTS_DELETE(frag_a.outs);                                                                \
          IN_CREATE(frag.in, STATE_BEHIND_POS, 0, frag_a.in);                                      \
          OUTS_CREATE(frag.outs, frag.in->out_a);                                                  \
          MARY_Vector_Push(&v_output, Fragment, frag);                                             \
        }                                                                                          \
        else if (top == BEHIND_NEG)                                                                \
        {                                                                                          \
          frag_a = MARY_Vector_Pop(&v_output, Fragment);                                           \
          IN_CREATE(frag_b.in, STATE_MATCH, 0, 0);                                                 \
          OUTS_PATCH(frag_a.outs, frag_b.in);                                                      \
          OUTS_DELETE(frag_a.outs);                                                                \
          IN_CREATE(frag.in, STATE_BEHIND_NEG, 0, frag_a.in);                                      \
          OUTS_CREATE(frag.outs, frag.in->out_a);                                                  \
          MARY_Vector_Push(&v_output, Fragment, frag);                                             \
        }                                                                                          \
        if (--v_stack.units == 0) break;                                                           \
        else top = MARY_Vector_At_Back(&v_stack, u32);                                             \
      }                                                                                            \
    }                                                                                              \
  }

  MARY_Range(v_tokens.data, u32, 0, v_tokens.units)
  {
    // precedence 1: +, *, ? 2: () 3: & 4: |
    if (it.val == 0)
    {
      EVAL_WHILE(v_stack.units != 0);
      frag_a = MARY_Vector_Pop(&v_output, Fragment);
      IN_CREATE(frag.in, STATE_MATCH, 0, 0);
      OUTS_PATCH(frag_a.outs, frag.in);
      mary_regex->machine = frag_a.in;
      break;
    }
    else if (it.val == PLUS || it.val == STAR || it.val == QUES)
    {
      EVAL_WHILE(top == PLUS || top == STAR || top == QUES);
      MARY_Vector_Push(&v_stack, u32, it.val);
    }
    else if (it.val == LPAR)
    {
      EVAL_WHILE(top == PLUS || top == STAR || top == QUES);
      MARY_Vector_Push(&v_stack, u32, it.val);
    }
    else if (it.val == RPAR)
    {
      EVAL_WHILE(top != LPAR);
      --v_stack.units;
    }
    else if (it.val == AND)
    {
      EVAL_WHILE(top == PLUS || top == STAR || top == QUES || top == AND);
      MARY_Vector_Push(&v_stack, u32, it.val);
    }
    else if (it.val == BAR)
    {
      EVAL_WHILE(top == PLUS || top == STAR || top == QUES || top == AND || top == BAR);
      MARY_Vector_Push(&v_stack, u32, it.val);
    }
    else if (it.val >= BEHIND_POS && it.val <= AHEAD_NEG)
    {
      MARY_Vector_Push(&v_stack, u32, it.val);
    }
    else if (it.val == EXPO || it.val == CASH)
    {
      flag = (it.val == EXPO) ? STATE_BOUND_EXPO : STATE_BOUND_CASH;
      IN_CREATE(frag.in, flag, 0, 0);
      OUTS_CREATE(frag.outs, frag.in->out_a);
      MARY_Vector_Push(&v_output, Fragment, frag);
    }
    else if (it.val == BOUND_POS || it.val == BOUND_NEG)
    {
      flag = (it.val == BOUND_POS) ? STATE_BOUND_POS : STATE_BOUND_NEG; MARY_Range_Advance(1);
      shortcut = Mary_Hashmap_Point(&hm_shortcuts, &it.val);
      IN_CREATE(frag.in, flag, 0, shortcut->str);
      OUTS_CREATE(frag.outs, frag.in->out_a);
      MARY_Vector_Push(&v_output, Fragment, frag);
    }
    else if (it.val == CLASS_POS || it.val == CLASS_NEG)
    {
      flag = (it.val == CLASS_POS) ? STATE_CLASS_POS : STATE_CLASS_NEG; MARY_Range_Advance(1);
      shortcut = Mary_Hashmap_Point(&hm_shortcuts, &it.val);
      IN_CREATE(frag.in, flag, 0, shortcut->str);
      OUTS_CREATE(frag.outs, frag.in->out_a);
      MARY_Vector_Push(&v_output, Fragment, frag);
    }
    else if (it.val == LSQU)
    {
      MARY_Range_Advance(1);
      if (it.val == EXPO)
      {
        IN_CREATE(frag.in, STATE_CLASS_NEG, 0, 0); MARY_Range_Advance(1);
      }
      else
      {
        IN_CREATE(frag.in, STATE_CLASS_POS, 0, 0);
      }
      // instead of copying into vector, why not just memcpy from input string into pool?
      // or how about we just store a ptr to the start of the class in expression on Regex_t? it should always be u32, so what's the problem?
      // I think it's because we're relying on a null ptr to terminate class string. should be fine, these class strings are not too big anyway
      while (it.val != RSQU)
      {
        MARY_Vector_Push(&v_codepoints, u32, it.val); MARY_Range_Advance(1);
      }
      it.val = 0; MARY_Vector_Push(&v_codepoints, u32, it.val);
      codepoints = Mary_Pool_Alloc(mary_regex->pool, sizeof(32) * v_codepoints.units);
      memcpy(codepoints, v_codepoints.data, sizeof(32) * v_codepoints.units);
      MARY_Vector_Empty(&v_codepoints);
      frag.in->out_b = codepoints;
      OUTS_CREATE(frag.outs, frag.in->out_a);
      MARY_Vector_Push(&v_output, Fragment, frag);
    }
    else if (it.val == DOT)
    {
      IN_CREATE(frag.in, STATE_DOT, 0, 0);
      OUTS_CREATE(frag.outs, frag.in->out_a);
      MARY_Vector_Push(&v_output, Fragment, frag);
    }
    else
    {
      IN_CREATE(frag.in, it.val, 0, 0);
      OUTS_CREATE(frag.outs, frag.in->out_a);
      MARY_Vector_Push(&v_output, Fragment, frag);
    }
  }

  Mary_Pool_Empty(compiler_pool);

  #undef IN_CREATE
  #undef OUTS_CREATE
  #undef OUTS_CONCAT
  #undef OUTS_PATCH
  #undef OUTS_DELETE
  #undef EVAL_WHILE

  MARY_Arena_Out;
}

// we should be able to use String_Each's in here to help!
Mary_Vector_t Mary_Regex_Execute(Mary_Regex_t *mary_regex, char bit_format, void *search_string)
{
  if (bit_format == 8)
  {
    return Mary_Regex_8bit_Execute(mary_regex, search_string);
  }
  else if (bit_format == 16)
  {
    return Mary_Regex_16bit_Execute(mary_regex, search_string);
  }
  else
  {
    return Mary_Regex_32bit_Execute(mary_regex, search_string);
  }
}

Mary_Vector_t Mary_Regex_8bit_Execute(Mary_Regex_t *mary_regex, uint8_t *search_string)
{
  return (Mary_Vector_t) {0, 0, 0, 0};
}

Mary_Vector_t Mary_Regex_16bit_Execute(Mary_Regex_t *mary_regex, uint16_t *search_string)
{
  return (Mary_Vector_t) { 0, 0, 0, 0 };
}

// both of the following funcs are nearly identical.
void Add_Candidates(size_t flags,
                    State *machine,
                    Mary_Vector_t *v_new,
                    Mary_Vector_t *v_states,
                    Mary_Vector_t *v_matches,
                    u64 codepoint_idx,
                    u32 *codepoint_ptr,
                    u32 codepoint_val);
void Update_Candidates(size_t flags,
                       Mary_Vector_t *v_old,
                       Mary_Vector_t *v_new,
                       Mary_Vector_t *v_states,
                       Mary_Vector_t *v_matches,
                       u64 codepoint_idx,
                       u32 *codepoint_ptr,
                       u32 codepoint_val);
char Execute_Behind(size_t flags, State *machine, u64 codepoint_idx, u32 *codepoint_ptr); // these two functions are so similar.
char Execute_Ahead(size_t flags, State *machine, u64 codepoint_idx, u32 *codepoint_ptr);

char Class_Contains(u32 *class_codepoints, u32 codepoint)
{
  for (; *class_codepoints != 0; ++class_codepoints)
  {
    if (*(class_codepoints + 1) == HYPH)
    {
      if (codepoint >= *class_codepoints && codepoint <= *(class_codepoints += 2)) return 1;
    }
    else if (codepoint == *class_codepoints) return 1;
  }
  return 0;
}

void Add_Candidates(size_t flags,
                    State *machine,
                    Mary_Vector_t *v_new,
                    Mary_Vector_t *v_states,
                    Mary_Vector_t *v_matches,
                    u64 codepoint_idx,
                    u32 *codepoint_ptr,
                    u32 codepoint_val)
{
  Candidate candidate; State *p_state; Match match;
  if (v_matches->units == 0 || flags & FLAG_GLOBAL) // can add this check into main execute loop instead.
  {
    MARY_Vector_Push(v_states, State *, machine);
    for (u64 j = 0; j < v_states->units; ++j)
    {
      p_state = MARY_Vector_At(v_states, State *, j);
      if (p_state->flag == STATE_MATCH)
      {
        match.from = codepoint_idx;
        match.to_exclusive = codepoint_idx + 1;
        MARY_Vector_Push(v_matches, Match, match);
      }
      else if (p_state->flag == STATE_SPLIT)
      {
        MARY_Vector_Push(v_states, State *, p_state->out_a);
        MARY_Vector_Push(v_states, State *, p_state->out_b);
      }
      else if (p_state->flag == STATE_BEHIND_POS)
      {
        if (codepoint_idx)
        {
          if (Execute_Behind(flags, p_state->out_b, codepoint_idx, codepoint_ptr))
          {
            MARY_Vector_Push(v_states, State *, p_state->out_a);
          }
        }
      }
      else if (p_state->flag == STATE_BEHIND_NEG)
      {
        if (codepoint_idx)
        {
          if (!Execute_Behind(flags, p_state->out_b, codepoint_idx, codepoint_ptr))
          {
            MARY_Vector_Push(v_states, State *, p_state->out_a);
          }
        }
        else
        {
          MARY_Vector_Push(v_states, State *, p_state->out_a);
        }
      }
      else if (p_state->flag == STATE_AHEAD_POS)
      {
        if (codepoint_val)
        {
          if (Execute_Ahead(flags, p_state->out_b, codepoint_idx, codepoint_ptr))
          {
            MARY_Vector_Push(v_states, State *, p_state->out_a);
          }
        }
      }
      else if (p_state->flag == STATE_AHEAD_NEG)
      {
        if (codepoint_val)
        {
          if (!Execute_Ahead(flags, p_state->out_b, codepoint_idx, codepoint_ptr))
          {
            MARY_Vector_Push(v_states, State *, p_state->out_a);
          }
        }
        else
        {
          MARY_Vector_Push(v_states, State *, p_state->out_a);
        }
      }
      else if (p_state->flag == STATE_BOUND_EXPO)
      {
        if (codepoint_idx == 0)
        {
          MARY_Vector_Push(v_states, State *, p_state->out_a);
        }
        else if (flags & FLAG_MULTILINE)
        {
          u32 prev = *(codepoint_ptr - 1);
          if (prev == '\n' || prev == '\r')
          {
            MARY_Vector_Push(v_states, State *, p_state->out_a);
          }
        }
      }
      else if (p_state->flag == STATE_BOUND_CASH)
      {
        if (codepoint_val == 0)
        {
          MARY_Vector_Push(v_states, State *, p_state->out_a);
        }
        else if (flags & FLAG_MULTILINE)
        {
          if (codepoint_val == '\n' || codepoint_val == '\r')
          {
            MARY_Vector_Push(v_states, State *, p_state->out_a);
          }
        }
      }
      else if (p_state->flag == STATE_BOUND_POS)
      {
        u64 prev_exists = codepoint_idx != 0; u64 curr_exists = codepoint_val != 0;
        u64 prev_is_bound = (prev_exists) ? Class_Contains(p_state->out_b, *(codepoint_ptr - 1)) : 0;
        u64 curr_is_bound = (curr_exists) ? Class_Contains(p_state->out_b, codepoint_val) : 0;
        if (!prev_exists && curr_exists && !curr_is_bound)
        {
          MARY_Vector_Push(v_states, State *, p_state->out_a);
        }
        else if (!curr_exists && prev_exists && !prev_is_bound)
        {
          MARY_Vector_Push(v_states, State *, p_state->out_a);
        }
        else if (prev_exists && curr_exists && prev_is_bound && !curr_is_bound)
        {
          MARY_Vector_Push(v_states, State *, p_state->out_a);
        }
        else if (prev_exists && curr_exists && !prev_is_bound && curr_is_bound)
        {
          MARY_Vector_Push(v_states, State *, p_state->out_a);
        }
      }
      else if (p_state->flag == STATE_BOUND_NEG)
      {
        u64 prev_exists = codepoint_idx != 0; u64 curr_exists = codepoint_val != 0;
        u64 prev_is_bound = (prev_exists) ? Class_Contains(p_state->out_b, *(codepoint_ptr - 1)) : 0;
        u64 curr_is_bound = (curr_exists) ? Class_Contains(p_state->out_b, codepoint_val) : 0;
        if (!prev_exists && curr_exists && curr_is_bound)
        {
          MARY_Vector_Push(v_states, State *, p_state->out_a);
        }
        else if (!curr_exists && prev_exists && prev_is_bound)
        {
          MARY_Vector_Push(v_states, State *, p_state->out_a);
        }
        else if (prev_exists && curr_exists && prev_is_bound && curr_is_bound)
        {
          MARY_Vector_Push(v_states, State *, p_state->out_a);
        }
        else if (prev_exists && curr_exists && !prev_is_bound && !curr_is_bound)
        {
          MARY_Vector_Push(v_states, State *, p_state->out_a);
        }
      }
      else if (p_state->flag == STATE_CLASS_POS)
      {
        if (Class_Contains(p_state->out_b, codepoint_val))
        {
          candidate = (Candidate) { p_state, codepoint_idx };
          MARY_Vector_Push(v_new, Candidate, candidate);
        }
      }
      else if (p_state->flag == STATE_CLASS_NEG)
      {
        if (!Class_Contains(p_state->out_b, codepoint_val))
        {
          candidate = (Candidate) { p_state, codepoint_idx };
          MARY_Vector_Push(v_new, Candidate, candidate);
        }
      }
      else if (p_state->flag == STATE_DOT)
      {
        if (codepoint_val != '\n')
        {
          candidate = (Candidate) { p_state, codepoint_idx };
          MARY_Vector_Push(v_new, Candidate, candidate);
        }
      }
      else if (p_state->flag == codepoint_val)
      {
        candidate = (Candidate) { p_state, codepoint_idx };
        MARY_Vector_Push(v_new, Candidate, candidate);
      }
    }
    MARY_Vector_Empty(v_states);
  }
}

void Update_Candidates(size_t flags,
                       Mary_Vector_t *v_old,
                       Mary_Vector_t *v_new,
                       Mary_Vector_t *v_states,
                       Mary_Vector_t *v_matches,
                       u64 codepoint_idx,
                       u32 *codepoint_ptr,
                       u32 codepoint_val)
{
  Candidate candidate, *p_candidate; State *p_state; Match match;
  for (u64 i = 0; i < v_old->units; ++i)
  {
    p_candidate = MARY_Vector_Point(v_old, i);
    MARY_Vector_Push(v_states, State *, p_candidate->state->out_a);
    for (u64 j = 0; j < v_states->units; ++j)
    {
      p_state = MARY_Vector_At(v_states, State *, j);
      if (p_state->flag == STATE_MATCH)
      {
        match.from = p_candidate->from;
        match.to_exclusive = codepoint_idx;
        MARY_Vector_Push(v_matches, Match, match);
      }
      else if (p_state->flag == STATE_SPLIT)
      {
        MARY_Vector_Push(v_states, State *, p_state->out_a);
        MARY_Vector_Push(v_states, State *, p_state->out_b);
      }
      else if (p_state->flag == STATE_BEHIND_POS)
      {
        if (codepoint_idx)
        {
          if (Execute_Behind(flags, p_state->out_b, codepoint_idx, codepoint_ptr))
          {
            MARY_Vector_Push(v_states, State *, p_state->out_a);
          }
        }
      }
      else if (p_state->flag == STATE_BEHIND_NEG)
      {
        if (codepoint_idx)
        {
          if (!Execute_Behind(flags, p_state->out_b, codepoint_idx, codepoint_ptr))
          {
            MARY_Vector_Push(v_states, State *, p_state->out_a);
          }
        }
        else
        {
          MARY_Vector_Push(v_states, State *, p_state->out_a);
        }
      }
      else if (p_state->flag == STATE_AHEAD_POS)
      {
        if (codepoint_val)
        {
          if (Execute_Ahead(flags, p_state->out_b, codepoint_idx, codepoint_ptr))
          {
            MARY_Vector_Push(v_states, State *, p_state->out_a);
          }
        }
      }
      else if (p_state->flag == STATE_AHEAD_NEG)
      {
        if (codepoint_val)
        {
          if (!Execute_Ahead(flags, p_state->out_b, codepoint_idx, codepoint_ptr))
          {
            MARY_Vector_Push(v_states, State *, p_state->out_a);
          }
        }
        else
        {
          MARY_Vector_Push(v_states, State *, p_state->out_a);
        }
      }
      else if (p_state->flag == STATE_BOUND_EXPO)
      {
        if (codepoint_idx == 0)
        {
          MARY_Vector_Push(v_states, State *, p_state->out_a);
        }
        else if (flags & FLAG_MULTILINE)
        {
          u32 prev = *(codepoint_ptr - 1);
          if (prev == '\n' || prev == '\r')
          {
            MARY_Vector_Push(v_states, State *, p_state->out_a);
          }
        }
      }
      else if (p_state->flag == STATE_BOUND_CASH)
      {
        if (codepoint_val == 0)
        {
          MARY_Vector_Push(v_states, State *, p_state->out_a);
        }
        else if (flags & FLAG_MULTILINE)
        {
          if (codepoint_val == '\n' || codepoint_val == '\r')
          {
            MARY_Vector_Push(v_states, State *, p_state->out_a);
          }
        }
      }
      else if (p_state->flag == STATE_BOUND_POS)
      {
        u64 prev_exists = codepoint_idx != 0; u64 curr_exists = codepoint_val != 0;
        u64 prev_is_bound = (prev_exists) ? Class_Contains(p_state->out_b, *(codepoint_ptr - 1)) : 0;
        u64 curr_is_bound = (curr_exists) ? Class_Contains(p_state->out_b, codepoint_val) : 0;
        if (!prev_exists && curr_exists && !curr_is_bound)
        {
          MARY_Vector_Push(v_states, State *, p_state->out_a);
        }
        else if (!curr_exists && prev_exists && !prev_is_bound)
        {
          MARY_Vector_Push(v_states, State *, p_state->out_a);
        }
        else if (prev_exists && curr_exists && prev_is_bound && !curr_is_bound)
        {
          MARY_Vector_Push(v_states, State *, p_state->out_a);
        }
        else if (prev_exists && curr_exists && !prev_is_bound && curr_is_bound)
        {
          MARY_Vector_Push(v_states, State *, p_state->out_a);
        }
      }
      else if (p_state->flag == STATE_BOUND_NEG)
      {
        u64 prev_exists = codepoint_idx != 0; u64 curr_exists = codepoint_val != 0;
        u64 prev_is_bound = (prev_exists) ? Class_Contains(p_state->out_b, *(codepoint_ptr - 1)) : 0;
        u64 curr_is_bound = (curr_exists) ? Class_Contains(p_state->out_b, codepoint_val) : 0;
        if (!prev_exists && curr_exists && curr_is_bound)
        {
          MARY_Vector_Push(v_states, State *, p_state->out_a);
        }
        else if (!curr_exists && prev_exists && prev_is_bound)
        {
          MARY_Vector_Push(v_states, State *, p_state->out_a);
        }
        else if (prev_exists && curr_exists && prev_is_bound && curr_is_bound)
        {
          MARY_Vector_Push(v_states, State *, p_state->out_a);
        }
        else if (prev_exists && curr_exists && !prev_is_bound && !curr_is_bound)
        {
          MARY_Vector_Push(v_states, State *, p_state->out_a);
        }
      }
      else if (p_state->flag == STATE_CLASS_POS)
      {
        if (Class_Contains(p_state->out_b, codepoint_val))
        {
          candidate = (Candidate) { p_state, p_candidate->from };
          MARY_Vector_Push(v_new, Candidate, candidate);
        }
      }
      else if (p_state->flag == STATE_CLASS_NEG)
      {
        if (!Class_Contains(p_state->out_b, codepoint_val))
        {
          candidate = (Candidate) { p_state, p_candidate->from };
          MARY_Vector_Push(v_new, Candidate, candidate);
        }
      }
      else if (p_state->flag == STATE_DOT)
      {
        if (codepoint_val != '\n')
        {
          candidate = (Candidate) { p_state, p_candidate->from };
          MARY_Vector_Push(v_new, Candidate, candidate);
        }
      }
      else if (p_state->flag == codepoint_val)
      {
        candidate = (Candidate) { p_state, p_candidate->from };
        MARY_Vector_Push(v_new, Candidate, candidate);
      }
    }
    MARY_Vector_Empty(v_states);
  }
  MARY_Vector_Empty(v_old);
}

Mary_Vector_t Mary_Regex_32bit_Execute(Mary_Regex_t *mary_regex, uint32_t *search_string)
{
  MARY_String_Heap(str, 32, search_string); // does this need to be on the heap?
  MARY_Vector_Stack(v_candidates_old, Candidate, 64);
  MARY_Vector_Stack(v_candidates_new, Candidate, 64);
  MARY_Vector_Stack(v_states, State *, 64);
  MARY_Vector(v_matches, HEAP, Match, 64); // maybe should have a param allocator
  Mary_Vector_t *v_old = &v_candidates_old, *v_new = &v_candidates_new, *v_swap;
  MARY_Range(str.data, u32, 0, str.units)
  {
    Add_Candidates(mary_regex->flags, mary_regex->machine, v_new, &v_states, &v_matches, it.idx, it.ptr, it.val);
    Update_Candidates(mary_regex->flags, v_old, v_new, &v_states, &v_matches, it.idx, it.ptr, it.val);
    v_swap = v_old; v_old = v_new; v_new = v_swap;
  }
  Mary_String_Destroy(&str);
  return v_matches;
}

char Execute_Behind(size_t flags, State *machine, u64 codepoint_idx, u32 *codepoint_ptr)
{
  MARY_Vector_Stack(v_candidates_old, Candidate, 64);
  MARY_Vector_Stack(v_candidates_new, Candidate, 64);
  MARY_Vector_Stack(v_states, State *, 64);
  MARY_Vector_Stack(v_matches, Match, 64);
  Mary_Vector_t *v_old = &v_candidates_old, *v_new = &v_candidates_new, *v_swap;
  u64 idx = codepoint_idx - 1; u32 *ptr = codepoint_ptr - 1;
  Add_Candidates(flags, machine, v_new, &v_states, &v_matches, idx, ptr, *ptr);
  MARY_Range_Reverse(codepoint_ptr - codepoint_idx, u32, idx, 0)
  {
    Update_Candidates(flags, v_old, v_new, &v_states, &v_matches, it.idx, it.ptr, it.val);
    if (v_matches.units) return 1;
    else if (!v_new->units) return 0;
    v_swap = v_old; v_old = v_new; v_new = v_swap;
  }
  return 0;
}

char Execute_Ahead(size_t flags, State *machine, u64 codepoint_idx, u32 *codepoint_ptr)
{
  MARY_Vector_Stack(v_candidates_old, Candidate, 64);
  MARY_Vector_Stack(v_candidates_new, Candidate, 64);
  MARY_Vector_Stack(v_states, State *, 64);
  MARY_Vector_Stack(v_matches, Match, 64);
  Mary_Vector_t *v_old = &v_candidates_old, *v_new = &v_candidates_new, *v_swap;
  u64 idx = codepoint_idx; u32 *ptr = codepoint_ptr, last_codepoint = 1;
  Add_Candidates(flags, machine, v_new, &v_states, &v_matches, idx, ptr, *ptr);
  MARY_Range(ptr, u32, 0, ~(u64)0)
  {
    if (last_codepoint == 0) break;
    else last_codepoint = it.val;
    Update_Candidates(flags, v_old, v_new, &v_states, &v_matches, it.idx, it.ptr, it.val);
    if (v_matches.units) return 1;
    else if (!v_new->units) return 0;
    v_swap = v_old; v_old = v_new; v_new = v_swap;
  }
  return 0;
}
*/
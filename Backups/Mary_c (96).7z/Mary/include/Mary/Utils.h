﻿#pragma once

#include <stdint.h>

#define MARY_Debug

#ifdef MARY_Debug
  #define MARY_Assert(THIS_IS_TRUE, FAILURE_MESSAGE)\
    ( !(THIS_IS_TRUE) ? (Mary_Exit_Assert(#THIS_IS_TRUE, FAILURE_MESSAGE, __func__, __FILE__, __LINE__), 0) : 1 )

  #define MARY_In_Debug(CODE) CODE
#else
  #define MARY_Assert(ITS_NOT_MY_PROBLEM, NOPE_DONT_CARE) 1

  #define MARY_In_Debug(LA_LA_LA_I_CANT_HEAR_YOU)
#endif

#define MARY_M\
  do {

#define MARY_W\
  } while (0)

enum
{
  MARY_FALSE,
  MARY_TRUE
};

#define MARY_True(VALUE)\
  ( (VALUE) == MARY_TRUE )

#define MARY_False(VALUE)\
  ( (VALUE) == MARY_FALSE )

#define MARY_Truthy(VALUE)\
  ( (VALUE) > 0 ? MARY_TRUE : MARY_FALSE )

#define MARY_Falsey(VALUE)\
  ( (VALUE) < 1 ? MARY_TRUE : MARY_FALSE )

#define MARY_Comma ,

// u = unsigned, s = signed, r = real, b = bool, e = enum, I = iter, U = unsigned, S = signed;
#define MARY_Primitives                                                                            \
  typedef uint8_t  u8;                                                                             \
  typedef uint16_t u16;                                                                            \
  typedef uint32_t u32;                                                                            \
  typedef uint64_t u64;                                                                            \
  typedef int8_t   s8;                                                                             \
  typedef int16_t  s16;                                                                            \
  typedef int32_t  s32;                                                                            \
  typedef int64_t  s64;                                                                            \
  typedef float    r32;                                                                            \
  typedef double   r64;                                                                            \
  typedef uint32_t b32;                                                                            \
  typedef uint64_t b64;                                                                            \
  typedef uint32_t e32;                                                                            \
  typedef uint64_t e64;                                                                            \
  typedef uint64_t I;                                                                              \
  typedef uint64_t U;                                                                              \
  typedef int64_t  S

#define MARY_Swap_16(X)                                                                            \
(                                                                                                  \
  (X) >> 8 & 0x00FF |                                                                              \
  (X) << 8 & 0xFF00                                                                                \
)

#define MARY_Swap_32(X)                                                                            \
(                                                                                                  \
  (X) >> 24 & 0x000000FF |                                                                         \
  (X) >> 8  & 0x0000FF00 |                                                                         \
  (X) << 8  & 0x00FF0000 |                                                                         \
  (X) << 24 & 0xFF000000                                                                           \
)

#define MARY_Swap_64(X)                                                                            \
(                                                                                                  \
  (X) >> 56 & 0x00000000000000FF |                                                                 \
  (X) >> 48 & 0x000000000000FF00 |                                                                 \
  (X) >> 40 & 0x0000000000FF0000 |                                                                 \
  (X) >> 32 & 0x00000000FF000000 |                                                                 \
  (X) << 32 & 0x000000FF00000000 |                                                                 \
  (X) << 40 & 0x0000FF0000000000 |                                                                 \
  (X) << 48 & 0x00FF000000000000 |                                                                 \
  (X) << 56 & 0xFF00000000000000                                                                   \
)

#define MARY_Bit_Set(BITS, BIT_IDX)\
  ( (BITS) |=  ( (1llu) << (BIT_IDX) ) )

#define MARY_Bit_Unset(BITS, BIT_IDX)\
  ( (BITS) &= ~( (1llu) << (BIT_IDX) ) )

#define MARY_Bit_Is_Set(BITS, BIT_IDX)\
  ( (1llu) &   ( (BITS) >> (BIT_IDX) ) )

#define MARY_Bit_Toggle(BITS, BIT_IDX)\
  ( (BITS) ^=  ( (1llu) << (BIT_IDX) ) )

#define MARY_Bit_Clear(BITS)\
  ( (BITS) = 0 )

#define MARY_Swap_Unit(PTR1, PTR2, TEMP, UNIT) \
(                                              \
  Mary_Copy(PTR1, TEMP, UNIT),                 \
  Mary_Copy(PTR2, PTR1, UNIT),                 \
  Mary_Copy(TEMP, PTR2, UNIT)                  \
)

#define MARY_Cast(PTR, TYPE)\
  ( (TYPE *)(PTR) )

#define MARY_Point(PTR, TYPE, IDX)\
  ( MARY_Cast(PTR, TYPE) + IDX )

#define MARY_At(PTR, TYPE, IDX)\
  ( *MARY_Point(PTR, TYPE, IDX) )

#define MARY_Point_Unit(PTR, UNIT, IDX)\
  MARY_Cast( (uint8_t *)(PTR) + (IDX) * (UNIT), void )

// MARY_Point_To_Byte?
#define MARY_Index_Byte(PTR, BYTES)\
  MARY_Cast( MARY_Cast( PTR, uint8_t ) + (BYTES), void )

// MARY_Point_To_Unit?
#define MARY_Index_Unit(PTR, TYPE, UNITS)\
  ( MARY_Cast((PTR), TYPE) + (UNITS) )

#define MARY_Range(PTR, TYPE, FROM, TO_EXCLUSIVE)                                                  \
  for                                                                                              \
  (                                                                                                \
    struct { size_t idx, start, finish, finish_exclusive; TYPE *ptr; TYPE val; }                   \
    it =                                                                                           \
    {                                                                                              \
      (FROM), (FROM), (TO_EXCLUSIVE) - 1, (TO_EXCLUSIVE),                                          \
      MARY_Cast(PTR, TYPE) + (FROM),                                                               \
      *(MARY_Cast(PTR, TYPE) + (FROM))                                                             \
    };                                                                                             \
    it.idx < it.finish_exclusive;                                                                  \
    ++it.idx, ++it.ptr, it.val = *it.ptr                                                           \
  )

#define MARY_Range_Reverse(PTR, TYPE, FROM, TO)                                                    \
  for                                                                                              \
  (                                                                                                \
    struct { size_t idx, start, finish; TYPE *ptr; TYPE val; }                                     \
    it =                                                                                           \
    {                                                                                              \
      (FROM), (FROM), (TO),                                                                        \
      MARY_Cast(PTR, TYPE) + (FROM),                                                               \
      *(MARY_Cast(PTR, TYPE) + (FROM))                                                             \
    };                                                                                             \
    it.idx + 1 > it.finish;                                                                        \
    --it.idx, --it.ptr, it.val = *it.ptr                                                           \
  )

#define MARY_Range_Advance(INDICES)\
  ( it.idx += (INDICES), it.ptr += (INDICES), it.val = *it.ptr )

#define MARY_Range_Regress(INDICES)\
  ( it.idx -= (INDICES), it.ptr -= (INDICES), it.val = *it.ptr )

#define MARY_Clip_Number(NUMBER, FROM, TO)\
  ( (NUMBER) < (FROM) ? (FROM) : (NUMBER) > (TO) ? (TO) : (NUMBER) );

#define MARY_Round_to_64bit(BYTES)\
  ( (BYTES) + 7 & -8 )

#define MARY_Is_Power_2(NUMBER)\
  ( (NUMBER) != 0 && ((NUMBER) & (NUMBER) - 1) == 0 )

typedef uint64_t Mary_Bool_t;
typedef uint64_t Mary_Enum_t;
typedef uint64_t Mary_Size_t;
typedef uint64_t Mary_Index_t, Mary_Idx_t;
typedef uint64_t Mary_ID_t;
typedef uint64_t Mary_Allocator_t;

typedef uint8_t Mary_Enum_8_t;
typedef uint16_t Mary_Enum_16_t;
typedef uint32_t Mary_Enum_32_t;
typedef uint64_t Mary_Enum_64_t;

#define MARY_Pointer_t\
  void *data;\
  Mary_Size_t bytes;\
  Mary_Allocator_t allocator

typedef struct
{
  MARY_Pointer_t;
}
Mary_Pointer_t, Mary_Ptr_t, Mary_p;

#define MARY_Pointer(NAME, DATA, BYTES, ALLOCATOR)\
  Mary_p NAME = { DATA, BYTES, ALLOCATOR }

#define MARY_p(DATA, BYTES, ALLOCATOR)\
  MARY_Pointer(DATA, BYTES, ALLOCATOR)

#define MARY_Pointer_Cast(PTR)\
  MARY_Cast(PTR, Mary_p)

typedef struct
{
  uint64_t id;
  uint64_t info;
}
Mary_Error_t; // this needs to go in it's own file, where others can inherit from it, I think.




typedef uint64_t Mary_UTF_t;

#define MARY_UTF_To_Unit(UTF)\
  ( (UTF) >> 3 )

#define MARY_Unit_To_UTF(UNIT)\
  ( (UNIT) << 3 )

#define MARY_UTF_To_Max_Units(UTF)\
  ( (UTF) == 8 ? 4 : (UTF) == 16 ? 2 : 1 )

typedef struct
{
  uint8_t a, b, c, d;
  uint32_t code;
  Mary_Size_t units;
}
Mary_UTF_8_t;

typedef struct
{
  uint16_t a, b;
  uint32_t code;
  Mary_Size_t units;
}
Mary_UTF_16_t;

typedef uint32_t Mary_UTF_32_t;

typedef uint8_t Mary_Char_8_t;
typedef uint16_t Mary_Char_16_t;
typedef uint32_t Mary_Char_32_t;
typedef void *Mary_C_String_t;
typedef uint8_t *Mary_C_String_8_t;
typedef uint16_t *Mary_C_String_16_t;
typedef uint32_t *Mary_C_String_32_t;
typedef struct { Mary_C_String_t data; Mary_Size_t bytes; } Mary_C_String_p; // I'm really not sure if these should have allocator field or not.
typedef struct { Mary_C_String_8_t data; Mary_Size_t units; } Mary_C_String_8_p;
typedef struct { Mary_C_String_16_t data; Mary_Size_t units; } Mary_C_String_16_p;
typedef struct { Mary_C_String_32_t data; Mary_Size_t units; } Mary_C_String_32_p;
typedef struct { Mary_Size_t bytes, units, codes; } Mary_C_String_Size_t;

#define MARY_C_String(UTF, C_STR) \
(                                 \
  UTF == 8  ? (void *)u8##C_STR : \
  UTF == 16 ? (void *) u##C_STR : \
  UTF == 32 ? (void *) U##C_STR : \
              (void *) ""         \
)

#define MARY_C_String_p(NAME, DATA, BYTES)\
  Mary_C_String_p NAME = { DATA, BYTES }

#define MARY_C_String_8_p(NAME, DATA, BYTES)\
  Mary_C_String_8_p NAME = { DATA, BYTES }

#define MARY_C_String_16_p(NAME, DATA, BYTES)\
  Mary_C_String_16_p NAME = { DATA, BYTES }

#define MARY_C_String_32_p(NAME, DATA, BYTES)\
  Mary_C_String_32_p NAME = { DATA, BYTES }

Mary_Size_t Mary_C_String_Count_Bytes(Mary_C_String_t c_string, Mary_UTF_t utf, Mary_Bool_t with_null);
Mary_Size_t Mary_C_String_Count_Units(Mary_C_String_t c_string, Mary_UTF_t utf, Mary_Bool_t with_null);
Mary_Size_t Mary_C_String_Count_Codes(Mary_C_String_t c_string, Mary_UTF_t utf, Mary_Bool_t with_null);
void Mary_C_String_Count(Mary_C_String_t c_string, Mary_UTF_t utf, Mary_Bool_t with_null, Mary_C_String_Size_t *out_size);
void Mary_C_String_Copy(Mary_C_String_p *from, Mary_UTF_t from_utf, Mary_C_String_p *to, Mary_UTF_t to_utf, Mary_Bool_t with_null);



typedef struct
{
  Mary_Index_t from;
  Mary_Index_t to_exclusive;
}
Mary_Slice_t;

typedef struct
{
  Mary_Size_t width, height;
}
Mary_Size_2D_t;

typedef struct
{
  Mary_Size_t width, height, depth;
}
Mary_Size_3D_t;

void Mary_Exit_Success();
void Mary_Exit_Success_Message(char *message);
void Mary_Exit_Failure(char *error_string);
void Mary_Exit_Assert(char *assertion, char *message, char *func, char *file, int line); // we might want to get a stack trace in this func.
Mary_Bool_t Mary_Is_Little_Endian();
Mary_Bool_t Mary_Is_Big_Endian();
void Mary_Print_Bits(void *value, Mary_Size_t size, Mary_Bool_t little_endian); // I really want to have a hex to decimal func. Will be a fun func!
void *Mary_Alloc(Mary_Size_t bytes);
void *Mary_Calloc(Mary_Size_t unit, Mary_Size_t units);
void *Mary_Realloc(void *data, Mary_Size_t bytes);
void Mary_Dealloc(void *data);
void Mary_Zero(void *data, Mary_Size_t bytes);
void *Mary_Copy(void *from, void *to, Mary_Size_t bytes);
void *Mary_Move(void *from, void *to, Mary_Size_t bytes);
void Mary_Swap(void *one, void *two, Mary_Size_t bytes);
void Mary_Set(void *data, void *val, Mary_Size_t val_unit, Mary_Size_t val_units); // should I add data_bytes as a param to help bound_check?
Mary_Bool_t Mary_Is_Same(void *one, void *two, Mary_Size_t bytes);
int64_t Mary_Compare(void *one, void *two, Mary_Size_t bytes); // should have its own return type, maybe Mary_Compare_t

// planned types
// Mary_Biarray_t, quickly extendable on either side. Mary_Queue_t? Deque?
// Mary_Map_t, essentially just a hashmap with vector index pointer to buckets.

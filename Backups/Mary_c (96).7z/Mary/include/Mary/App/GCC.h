#pragma once

#include <Mary/File.h>

void Mary_GCC_Create_Bat();

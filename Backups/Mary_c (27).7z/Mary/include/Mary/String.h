#pragma once

typedef struct
{
  void *data;
  size_t capacity;
  size_t unit;
  size_t size; // maybe add a codepoint count as well. this is units
}
Mary_String_t;

void Mary_String_Create(Mary_String_t *mary_string, size_t bit_format, void *string, size_t opt_size);
void Mary_String_Destroy(Mary_String_t *mary_string);
void Mary_String_Format(Mary_String_t *mary_string, char bit_format);
char Mary_String_Get_Format(Mary_String_t *mary_string);
void Mary_String_8bit_to_16bit(Mary_String_t *s_8bit);
void Mary_String_8bit_to_32bit(Mary_String_t *s_8bit);
void Mary_String_16bit_to_8bit(Mary_String_t *s_16bit);
void Mary_String_16bit_to_32bit(Mary_String_t *s_16bit);
void Mary_String_32bit_to_8bit(Mary_String_t *s_32bit);
void Mary_String_32bit_to_16bit(Mary_String_t *s_32bit);

#include <stdlib.h>
#include <stdio.h>
#include <Mary/Utils.h>
#include <Mary/Vector.h>

MARY_PRIMITIVES;

void Mary_Exit_Success()
{
  puts("\npress enter to exit...");
  getc(stdin); exit(EXIT_SUCCESS);
}

void Mary_Exit_Failure(const char *error_string)
{
  printf("MARY FATAL ERROR: %s\n", error_string);
  puts("\npress enter to exit...");
  getc(stdin); exit(EXIT_FAILURE);
}

void Mary_Exit_Assert(const char *assertion, const char *file, int line)
{
  printf("MARY ASSERT: ( %s ) is not true!\n", assertion);
  printf("    in file: %s\n", file);
  printf("    on line: %i\n", line);
  printf("\npress enter to exit\n");
  getc(stdin); exit(EXIT_FAILURE);
}

char Mary_Is_Little_Endian()
{
  volatile u16 i = 0x0001;
  if (*(u8 *)&i == 1)
    return 1;
  else
    return 0;
}

char Mary_Is_Big_Endian()
{
  volatile u16 i = 0x0001;
  if (*(u8 *)&i == 0)
    return 1;
  else
    return 0;
}

void Mary_Print_Little_Endian(void *value, int size)
{
  char *binary_digits[16] =
  {
    "0000", "0001", "0010", "0011",
    "0100", "0101", "0110", "0111",
    "1000", "1001", "1010", "1011",
    "1100", "1101", "1110", "1111"
  };
  u8 byte = 0, *p = value;
  printf("bin: ");
  for (int i = size - 1; i > -1; --i)
  {
    byte = *(p + i);
    printf("%s", binary_digits[(byte & 0xF0) >> 4]);
    printf("%s ", binary_digits[byte & 0x0F]);
  } printf("\n");
  printf("hex: ");
  for (int i = size - 1; i > -1; --i)
  {
    byte = *(p + i);
    printf("%4X", (byte & 0xF0) >> 4);
    printf("%4X ", byte & 0x0F);
  } printf("\n");
}

void Mary_Print_Big_Endian(void *value, int size)
{
  char *binary_digits[16] =
  {
    "0000", "0001", "0010", "0011",
    "0100", "0101", "0110", "0111",
    "1000", "1001", "1010", "1011",
    "1100", "1101", "1110", "1111"
  };
  u8 byte = 0, *p = value;
  printf("bin: ");
  for (int i = 0; i < size; ++i)
  {
    byte = *(p + i);
    printf("%s", binary_digits[(byte & 0xF0) >> 4]);
    printf("%s ", binary_digits[byte & 0x0F]);
  } printf("\n");
  printf("hex: ");
  for (int i = 0; i < size; ++i)
  {
    byte = *(p + i);
    printf("%4X", (byte & 0xF0) >> 4);
    printf("%4X ", byte & 0x0F);
  } printf("\n");
}

void Mary_File_Read(Mary_File_t *mary_file, const char *file_path)
{
  FILE *file = fopen(file_path, "r");
  if (file == 0)
  {
    Mary_Exit_Failure("File_Read: could not open.");
  }

  if (fseek(file, 0, SEEK_END))
  {
    Mary_Exit_Failure("File_Read: could not read.");
  }

  int size = ftell(file);
  if (size == -1)
  {
    Mary_Exit_Failure("File_Read: could not find end.");
  }

  char *data = calloc(size, sizeof(char));
  if (data == 0)
  {
    Mary_Exit_Failure("File_Read: could not allocate buffer.");
  }

  rewind(file); fread(data, sizeof(char), size, file);
  if (ferror(file))
  {
    Mary_Exit_Failure("File_Read: could not read into buffer.");
  }

  if (fclose(file) == EOF)
  {
    Mary_Exit_Failure("File_Read: could not close.");
  }

  mary_file->data = data;
  mary_file->size = size;
}

void Mary_File_Destroy(Mary_File_t *mary_file)
{
  free(mary_file->data);
}

#define intern static
#include <stdio.h>
#include <stdint.h>
#include <Mary/Vector.h>
#include <Mary/Window.h>

void Mary_Window_Start();
void Mary_Window_Finish();

const Mary_Window_i *Mary_Window();
intern void Create(Mary_Window_t *window);
intern void Destroy(Mary_Window_t *window);
intern void Show(Mary_Window_t *window);
intern void Hide(Mary_Window_t *window);
intern int64_t __stdcall Win32_Wnd_Proc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp);

intern const Mary_Vector_i *vector_i;
intern Mary_Vector_t v_windows;
intern const uint16_t win32_class_name[] = u"Mary_Win32_Class";

// make a Mary_Win32_t interface for use in here an else where. static
void Mary_Window_Start()
{
  vector_i = Mary_Vector();
  vector_i->Create(&v_windows, sizeof(Mary_Window_t *));

  WNDCLASSEX win32_class;
  memset(&win32_class, 0, sizeof(win32_class));
  win32_class.cbSize = sizeof(win32_class);
  win32_class.lpfnWndProc = Win32_Wnd_Proc;
  win32_class.hCursor = LoadCursor(0, IDC_ARROW);
  win32_class.hbrBackground = (HBRUSH)8;
  win32_class.lpszClassName = win32_class_name;
  win32_class.style = CS_OWNDC;
  RegisterClassEx(&win32_class);
}

void Mary_Window_Finish()
{
  return;
}

const Mary_Window_i *Mary_Window()
{
  static const Mary_Window_i interface =
    { Create, Destroy
    , Show, Hide
    };

  return &interface;
}

intern void Create(Mary_Window_t *window)
{
  memset(window, 0, sizeof(window));
  vector_i->Push_Back(&v_windows, &window);

  HWND win32_hwnd = CreateWindowEx
    ( WS_EX_CLIENTEDGE
    , win32_class_name
    , L"Praise Yahweh!"
    , WS_OVERLAPPEDWINDOW
    , 100, 100
    , 800, 600
    , 0, 0, 0, 0
    );
  window->win32_hwnd = win32_hwnd;
  
  HDC win32_hdc = GetDC(win32_hwnd);
  window->win32_hdc = win32_hdc;

  Show(window);
}

intern void Destroy(Mary_Window_t *window)
{
  HWND win32_hwnd = window->win32_hwnd;
  HDC win32_hdc = window->win32_hdc;
  ReleaseDC(win32_hwnd, win32_hdc);
  DestroyWindow(win32_hwnd);
  memset(window, 0, sizeof(window));
}

intern int64_t __stdcall Win32_Wnd_Proc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
{
  Mary_Window_t *window = 0;
  size_t size = v_windows.size;
  size_t i = 0; // put in loop. it's out for testing.
  for (; i < size; ++i)
  {
    vector_i->At(&v_windows, i, &window);
    if (window->win32_hwnd == hwnd) break;
  }

  if (!window)
  {
    return DefWindowProc(hwnd, msg, wp, lp);
  }
  else if (msg == WM_SIZE)
  {
    printf("%zu:s ", i);
    return 0;
  }
  else if (msg == WM_MOVE)
  {
    printf("%zu:m ", i);
    return 0;
  }
  else
  {
    return DefWindowProc(hwnd, msg, wp, lp);
  }
}

intern void Show(Mary_Window_t *window)
{
  HWND win32_hwnd = window->win32_hwnd;
  ShowWindow(win32_hwnd, SW_NORMAL);
  UpdateWindow(win32_hwnd);
}

intern void Hide(Mary_Window_t *window)
{
  ShowWindow(window->win32_hwnd, SW_HIDE);
}

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <limits.h>
#include <Mary/Mary.h>

int main()
{
  Mary_Hashmap_t hashmap;
  const Mary_Hashmap_i *hashmap_i = Mary_Hashmap();
  int key, val, out_val = 0;

  hashmap_i->Create(&hashmap, sizeof(key), sizeof(val));
  for (size_t i = 0; i < 1440000; ++i)
  {
    key = (int)i, val = rand(); hashmap_i->Insert(&hashmap, &key, &val);
    hashmap_i->At(&hashmap, &key, &out_val);
    printf("%i: %i\n", key, out_val);
  }
  printf("%zu\n", hashmap.buckets_occupied);
  hashmap_i->Destroy(&hashmap);
  
  Mary_Exit_Success();
  //////

  Mary_Start();

  const Mary_Window_i *window_i = Mary_Window();
  Mary_Window_t window;
  Mary_Window_t window2;
  window_i->Create(&window);
  window_i->Create(&window2);

  ////// temp.
  MSG msg;
  while (IsWindow(window.win32_hwnd) || IsWindow(window2.win32_hwnd))
  {
    while (PeekMessage(&msg, window.win32_hwnd, 0, 0, PM_REMOVE))
    {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
    }
    while (PeekMessage(&msg, window2.win32_hwnd, 0, 0, PM_REMOVE))
    {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
    }
    Sleep(1);
  }
  //////

  window_i->Destroy(&window);
  window_i->Destroy(&window2);

  Mary_Finish();

  puts("\nThank you for using the C programming language!");
  Mary_Exit_Success();
}

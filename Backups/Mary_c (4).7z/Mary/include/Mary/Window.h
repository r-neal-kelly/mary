#pragma once

#define WIN32_LEAN_AND_MEAN
#define UNICODE
#include <Windows.h>

// maybe we can design a tree type that holds nodes.
// each node can be a variable node type, as long as they are the same size.
// we can build a variable size vector too if required.

// I want these two to be more private.
void Mary_Window_Start(); // Begin
void Mary_Window_Finish(); // End

typedef struct
{
  HWND win32_hwnd;
  HDC win32_hdc;
}
Mary_Window_t;

typedef struct
{
  void (*const Create) (Mary_Window_t *window);
  void (*const Destroy)(Mary_Window_t *window);
  void (*const Show)   (Mary_Window_t *window);
  void (*const Hide)   (Mary_Window_t *window);
}
Mary_Window_i;

const Mary_Window_i *Mary_Window();

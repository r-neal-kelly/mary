#pragma once

#include <Mary/Utils.h>
#include <Mary/Vector.h>
#include <Mary/Bitbool.h>
#include <Mary/Hashmap.h>
#include <Mary/Window.h>

void Mary_Start();
void Mary_Finish();

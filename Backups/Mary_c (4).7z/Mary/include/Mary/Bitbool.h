#pragma once

#include <stddef.h>

typedef struct
{
  void (*const Assign)(void *bitbool, size_t bitbool_size, size_t bit_index, char boolean);
  char (*const At)    (void *bitbool, size_t bitbool_size, size_t bit_index);
  void (*const Fill)  (void *bitbool, size_t bitbool_size, char boolean);
  void (*const Print) (void *bitbool, size_t bitbool_size);
}
Mary_Bitbool_i;

const Mary_Bitbool_i *Mary_Bitbool();

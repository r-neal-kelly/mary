#pragma once

#include <stddef.h>

// I think 12 buckets with six places for each unit is 
// a good start. it can dynamically grow whenever
// one of the buckets becomes full. perhaps to
// twice as many buckets, and twice as many places.

// I want there to be very few cache misses. so the entire
// structure will be malloc'd together. no liked lists!!!

// might use bitbool to keep track of buckets!

typedef struct
{
  void *buckets_data;
  void *buckets_bitbool;
  size_t buckets_total;
  size_t buckets_occupied;
  size_t size_key;
  size_t size_value;
}
Mary_Hashmap_t;

typedef struct
{
  void (*const Create) (Mary_Hashmap_t *hashmap, size_t size_key, size_t size_value);
  void (*const Destroy)(Mary_Hashmap_t *hashmap);
  void (*const Insert) (Mary_Hashmap_t *hashmap, void *key, void *value); // Set
  char (*const At)     (Mary_Hashmap_t *hashmap, void *in_key, void *out_value); // Get
}
Mary_Hashmap_i;

const Mary_Hashmap_i *Mary_Hashmap();

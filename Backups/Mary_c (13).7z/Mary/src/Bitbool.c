#define intern static
#include <string.h>
#include <stdio.h>
#include <Mary/Bitbool.h>
typedef char byte_t;

const Mary_Bitbool_i *Mary_Bitbool();
intern void Assign(void *bitbool, size_t bitbool_size, size_t bit_index, char boolean);
intern char At    (void *bitbool, size_t bitbool_size, size_t bit_index);
intern void Fill  (void *bitbool, size_t bitbool_size, char boolean);
intern void Print (void *bitbool, size_t bitbool_size);

const Mary_Bitbool_i *Mary_Bitbool()
{
  static const Mary_Bitbool_i interface =
    { Assign
    , At
    , Fill
    , Print
    };

  return &interface;
}

intern void Assign(void *bitbool, size_t bitbool_size, size_t bit_index, char boolean)
{
  size_t byte_index = bit_index / 8;
  if (byte_index <= bitbool_size)
  {
    byte_t *p = (byte_t *)bitbool + byte_index;
    bit_index %= 8;
    boolean = (boolean > 0) ? 1 : 0;
    byte_t byte = (boolean) ? (*p | (1 << bit_index)) : (*p & ~(1 << bit_index));
    memmove(p, &byte, 1);
  }
}

intern char At(void *bitbool, size_t bitbool_size, size_t bit_index)
{
  char result = 0;
  size_t byte_index = bit_index / 8;
  if (byte_index <= bitbool_size)
  {
    byte_t *p = (byte_t *)bitbool + byte_index;
    bit_index %= 8;
    result = (*p & (1 << bit_index)) ? 1 : 0;
  }
  return result;
}

intern void Fill(void *bitbool, size_t bitbool_size, char boolean)
{
  byte_t *p = (byte_t *)bitbool;
  byte_t value = (boolean > 0) ? ~0 : 0;
  for (size_t z = 0; z < bitbool_size; ++z, p += 1)
  {
    memset(p, value, 1);
  }
}

intern void Print(void *bitbool, size_t bitbool_size)
{
  size_t total_bits = bitbool_size * 8;
  for (size_t i = 0; i < total_bits; ++i)
  {
    printf("%zu: %i\n", i, At(bitbool, bitbool_size, i));
  }
}

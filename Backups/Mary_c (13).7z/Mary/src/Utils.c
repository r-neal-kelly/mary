#include <stdlib.h>
#include <stdio.h>
#include <Mary/Utils.h>
#include <Mary/Vector.h>

void Mary_Exit_Success()
{
  puts("press enter to exit...");
  getc(stdin);
  exit(EXIT_SUCCESS);
}

void Mary_Exit_Failure(const char *error_string)
{
  printf("MARY FATAL ERROR: %s\n", error_string);
  puts("press enter to exit...");
  getc(stdin);
  exit(EXIT_FAILURE);
}

char *Mary_Read_File(const char *file_path)
{
  FILE *file = fopen(file_path, "r");
  if (file == 0)
  {
    Mary_Exit_Failure("Read_File: could not open.");
  }

  if (fseek(file, 0, SEEK_END))
  {
    Mary_Exit_Failure("Read_File: could not read.");
  }

  int length = ftell(file);
  if (length == -1)
  {
    Mary_Exit_Failure("Read_File: could not find end.");
  }

  char *data = malloc(sizeof(char) * (length + 1)); // adding '\0'
  if (data == 0)
  {
    Mary_Exit_Failure("Read_File: could not allocate buffer.");
  }

  rewind(file);
  fread(data, sizeof(char), length, file);
  if (ferror(file))
  {
    Mary_Exit_Failure("Read_File: could not read into buffer.");
  }
  data[length] = '\0'; // do this only if it's not already there?

  if (fclose(file) == EOF)
  {
    Mary_Exit_Failure("Read_File: could not close.");
  }

  return data;
}

uint32_t *Mary_UTF8_Decode(uint8_t *text)
{
  Mary_Vector_t v_text;
  Mary_Vector_Create(&v_text, 4);
  Mary_Vector_Reserve(&v_text, 4 * 1024); // size_estimate param?
  uint8_t *p = text, v = *p; uint32_t a, b, c, d;
  while (1)
  {
    if (v == 0)
    { // last byte
      a = v;
      Mary_Vector_Push_Back(&v_text, &a);
      break;
    }
    else if (v >> 7 == 0)
    { // 1 byte
      a = v; ++p, v = *p;
      Mary_Vector_Push_Back(&v_text, &a);
    }
    else if (v >> 5 == 6)
    { // 2 bytes
      a = (v ^ 192) << 6; ++p, v = *p;
      b = (v ^ 128)     ; ++p, v = *p;
      a = a | b;
      Mary_Vector_Push_Back(&v_text, &a);
    }
    else if (v >> 4 == 14)
    { // 3 bytes
      a = (v ^ 224) << 12; ++p, v = *p;
      b = (v ^ 128) <<  6; ++p, v = *p;
      c = (v ^ 128)      ; ++p, v = *p;
      a = a | b | c;
      Mary_Vector_Push_Back(&v_text, &a);
    }
    else
    { // 4 bytes
      a = (v ^ 240) << 18; ++p, v = *p;
      b = (v ^ 128) << 12; ++p, v = *p;
      c = (v ^ 128) <<  6; ++p, v = *p;
      d = (v ^ 128)      ; ++p, v = *p;
      a = a | b | c | d;
      Mary_Vector_Push_Back(&v_text, &a);
    }
  }
  Mary_Vector_Fit(&v_text);
  return v_text.data;
}

uint16_t *Mary_UTF16_Encode(uint32_t *text)
{
  Mary_Vector_t v_text;
  Mary_Vector_Create(&v_text, 2);
  Mary_Vector_Reserve(&v_text, 2 * 1024);
  uint32_t *p = text, v = *p; uint16_t a, b;
  uint32_t hi_clear = ~0 << 10;
  while (1)
  {
    if (v == 0)
    { // last char
      a = v;
      Mary_Vector_Push_Back(&v_text, &a);
      break;
    }
    else if (v < 0x10000)
    { // bmp short
      a = v; ++p, v = *p;
      Mary_Vector_Push_Back(&v_text, &a);
    }
    else
    { // surrogate pair
      v -= 0x10000;
      a = (v >> 10) + 0xD800;
      b = (v & ~(~0 << 10)) + 0xDC00;
      ++p, v = *p;
      Mary_Vector_Push_Back(&v_text, &a);
      Mary_Vector_Push_Back(&v_text, &b);
    }
  }
  Mary_Vector_Fit(&v_text);
  return v_text.data;
}

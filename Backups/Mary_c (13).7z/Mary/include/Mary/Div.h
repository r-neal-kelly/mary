#pragma once

#include <stdint.h>

typedef struct
{
  float w, h;
  float x, y; int16_t z;
  uint8_t r, g, b, a;
}
Mary_Div_t;

typedef struct
{
  void (*const Create) (Mary_Div_t *div);
  void (*const Destroy)(Mary_Div_t *div);
}
Mary_Div_i;

const Mary_Div_i *Mary_Hashmap();

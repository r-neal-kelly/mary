#pragma once

#include <stdint.h>

void Mary_Exit_Success();
void Mary_Exit_Failure(const char *error_string);
char *Mary_Read_File(const char *file_path);
uint8_t *Mary_UTF8_Encode(uint32_t *text);
uint32_t *Mary_UTF8_Decode(uint8_t *text);
uint16_t *Mary_UTF16_Encode(uint32_t *text);
uint32_t *Mary_UTF16_Decode(uint16_t *text);
uint16_t *Mary_UTF8_To_UTF16(uint8_t *text);

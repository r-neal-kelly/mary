#pragma once

#include <Mary/UTF.h>

#undef MARY_UTF_Code_32_To_Units_8
#undef MARY_UTF_Code_32_To_Units_16
#undef MARY_UTF_Ptr_8_To_Units_8
#undef MARY_UTF_Ptr_16_To_Units_16
#undef MARY_UTF_Encode_8
#undef MARY_UTF_Decode_8
#undef MARY_UTF_Decode_8_Reverse
#undef MARY_UTF_Encode_16
#undef MARY_UTF_Decode_16
#undef MARY_UTF_Decode_16_Reverse
#undef MARY_UTF_Encode_32
#undef MARY_UTF_Decode_32
#undef MARY_UTF_Decode_32_Reverse

////// Sizing //////

#define MARY_UTF_Code_32_To_Units_8(CODE)   \
(                                           \
    (CODE) < 0x000080 ? 1 :                 \
    (CODE) < 0x000800 ? 2 :                 \
    (CODE) < 0x010000 ? 3 :                 \
    (CODE) < 0x110000 ? 4 : 0               \
)

#define MARY_UTF_Code_32_To_Units_16(CODE)  \
(                                           \
    (CODE) < 0x10000 ? 1 : 2                \
)

#define MARY_UTF_Ptr_8_To_Units_8(PTR)  \
(                                       \
    *(PTR) >> 7 == 0x00 ? 1 :           \
    *(PTR) >> 5 == 0x06 ? 2 :           \
    *(PTR) >> 4 == 0x0E ? 3 :           \
    *(PTR) >> 3 == 0x1E ? 4 : 0         \
)

#define MARY_UTF_Ptr_16_To_Units_16(PTR)        \
(                                               \
    *(PTR) < 0xD800 || *(PTR) > 0xDFFF ? 1 : 2  \
)

////// Encoding / Decoding //////

#define MARY_UTF_Encode_8(CODE, OUT, CASE_A, CASE_B, CASE_C, CASE_D)    \
(                                                                       \
    OUT.code = CODE,                                                    \
    OUT.code < 0x000080 ? (                                             \
        OUT.a = OUT.code,                                               \
        OUT.units = 1,                                                  \
        (CASE_A),                                                       \
        OUT                                                             \
    ) : OUT.code < 0x000800 ? (                                         \
        OUT.a = 0xC0 | OUT.code >> 6,                                   \
        OUT.b = 0x80 | OUT.code & 0x3F,                                 \
        OUT.units = 2,                                                  \
        (CASE_B),                                                       \
        OUT                                                             \
    ) : OUT.code < 0x010000 ? (                                         \
        OUT.a = 0xE0 | OUT.code >> 12,                                  \
        OUT.b = 0x80 | OUT.code >> 6 & 0x3F,                            \
        OUT.c = 0x80 | OUT.code & 0x3F,                                 \
        OUT.units = 3,                                                  \
        (CASE_C),                                                       \
        OUT                                                             \
    ) : OUT.code < 0x110000 ? (                                         \
        OUT.a = 0xF0 | OUT.code >> 18,                                  \
        OUT.b = 0x80 | OUT.code >> 12 & 0x3F,                           \
        OUT.c = 0x80 | OUT.code >> 6 & 0x3F,                            \
        OUT.d = 0x80 | OUT.code & 0x3F,                                 \
        OUT.units = 4,                                                  \
        (CASE_D),                                                       \
        OUT                                                             \
    ) : (                                                               \
        OUT                                                             \
    )                                                                   \
)

#define MARY_UTF_Decode_8(PTR, OUT)                 \
(                                                   \
    *PTR >> 7 == 0x00 ? (                           \
        OUT.code =                                  \
            OUT.a = *PTR,                           \
        OUT.units = 1,                              \
        PTR += 1,                                   \
        OUT                                         \
    ) : *PTR >> 5 == 0x06 ? (                       \
        OUT.code =                                  \
            ((OUT.a = *PTR) ^ 0xC0) << 6 |          \
            (OUT.b = *(PTR + 1)) ^ 0x80,            \
        OUT.units = 2,                              \
        PTR += 2,                                   \
        OUT                                         \
    ) : *PTR >> 4 == 0x0E ? (                       \
        OUT.code =                                  \
            ((OUT.a = *PTR) ^ 0xE0) << 12 |         \
            ((OUT.b = *(PTR + 1)) ^ 0x80) << 6 |    \
            (OUT.c = *(PTR + 2)) ^ 0x80,            \
        OUT.units = 3,                              \
        PTR += 3,                                   \
        OUT                                         \
    ) : *PTR >> 3 == 0x1E ? (                       \
        OUT.code =                                  \
            ((OUT.a = *PTR) ^ 0xF0) << 18 |         \
            ((OUT.b = *(PTR + 1)) ^ 0x80) << 12 |   \
            ((OUT.c = *(PTR + 2)) ^ 0x80) << 6 |    \
            (OUT.d = *(PTR + 3)) ^ 0x80,            \
        OUT.units = 4,                              \
        PTR += 4,                                   \
        OUT                                         \
    ) : (                                           \
        OUT                                         \
    )                                               \
)

#define MARY_UTF_Decode_8_Reverse(PTR, OUT)         \
(                                                   \
    *--PTR >> 6 != 0x2 ? (                          \
        PTR                                         \
    ) : *--PTR >> 6 != 0x2 ? (                      \
        PTR                                         \
    ) : *--PTR >> 6 != 0x2 ? (                      \
        PTR                                         \
    ) : (                                           \
        --PTR                                       \
    ),                                              \
    *PTR >> 7 == 0x00 ? (                           \
        OUT.code =                                  \
            OUT.a = *PTR,                           \
        OUT.units = 1,                              \
        OUT                                         \
    ) : *PTR >> 5 == 0x06 ? (                       \
        OUT.code =                                  \
            ((OUT.a = *PTR) ^ 0xC0) << 6 |          \
            (OUT.b = *(PTR + 1)) ^ 0x80,            \
        OUT.units = 2,                              \
        OUT                                         \
    ) : *PTR >> 4 == 0x0E ? (                       \
        OUT.code =                                  \
            ((OUT.a = *PTR) ^ 0xE0) << 12 |         \
            ((OUT.b = *(PTR + 1)) ^ 0x80) << 6 |    \
            (OUT.c = *(PTR + 2)) ^ 0x80,            \
        OUT.units = 3,                              \
        OUT                                         \
    ) : *PTR >> 3 == 0x1E ? (                       \
        OUT.code =                                  \
            ((OUT.a = *PTR) ^ 0xF0) << 18 |         \
            ((OUT.b = *(PTR + 1)) ^ 0x80) << 12 |   \
            ((OUT.c = *(PTR + 2)) ^ 0x80) << 6 |    \
            (OUT.d = *(PTR + 3)) ^ 0x80,            \
        OUT.units = 4,                              \
        OUT                                         \
    ) : (                                           \
        OUT                                         \
    )                                               \
)

#define MARY_UTF_Encode_16(CODE, OUT, CASE_A, CASE_B)   \
(                                                       \
    OUT.code = CODE,                                    \
    OUT.code < 0x10000 ? (                              \
        OUT.a = OUT.code,                               \
        OUT.units = 1,                                  \
        (CASE_A),                                       \
        OUT                                             \
    ) : (                                               \
        OUT.a = (OUT.code - 0x10000 >> 10) + 0xD800,    \
        OUT.b = (OUT.code - 0x10000 & 0x3FF) + 0xDC00,  \
        OUT.units = 2,                                  \
        (CASE_B),                                       \
        OUT                                             \
    )                                                   \
)

#define MARY_UTF_Decode_16(UTF_16, PTR)         \
(                                               \
    (*PTR < 0xD800 || 0xDBFF < *PTR) ? (        \
        UTF_16.units = 1,                       \
        UTF_16.a = *PTR++,                      \
        UTF_16.code = UTF_16.a,                 \
        UTF_16                                  \
    ) : (                                       \
        UTF_16.a = *PTR++,                      \
                                                \
        (*PTR < 0xDC00 || 0xDFFF < *PTR) ? (    \
            UTF_16.units = 1,                   \
            UTF_16.code = UTF_16.a,             \
            ++PTR,                              \
            UTF_16                              \
        ) : (                                   \
            UTF_16.units = 2,                   \
            UTF_16.b = *PTR++,                  \
            UTF_16.code =                       \
                (UTF_16.a - 0xD800 << 10) +     \
                (UTF_16.b - 0xDC00) +           \
                0x10000,                        \
            UTF_16                              \
        )                                       \
    )                                           \
)

#define MARY_UTF_Decode_16_Reverse(PTR, OUT)        \
(                                                   \
    PTR -= 1,                                       \
    *PTR < 0xDC00 || 0xDFFF < *PTR ? (              \
        OUT.code =                                  \
            OUT.a = *PTR,                           \
        OUT.units = 1,                              \
        OUT                                         \
    ) : (                                           \
        OUT.code =                                  \
            ((OUT.a = *(PTR - 1)) - 0xD800 << 10) + \
            ((OUT.b = *PTR) - 0xDC00) +             \
            0x10000,                                \
        OUT.units = 2,                              \
        PTR -= 1,                                   \
        OUT                                         \
    )                                               \
)

#define MARY_UTF_Encode_32(CODE, OUT, CASE_A)   \
(                                               \
    OUT = CODE,                                 \
    CASE_A,                                     \
    OUT                                         \
)

#define MARY_UTF_Decode_32(PTR, OUT)    \
(                                       \
    OUT = *PTR++                        \
)

#define MARY_UTF_Decode_32_Reverse(PTR, OUT)    \
(                                               \
    OUT = *--PTR                                \
)

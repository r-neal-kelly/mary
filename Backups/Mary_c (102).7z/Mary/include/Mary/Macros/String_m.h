#pragma once

#include <Mary/String.h>

#undef MARY_String_Static
#undef MARY_String_Stack
#undef MARY_String_Heap
#undef MARY_String_Pool
#undef MARY_String_Frame
#undef MARY_String_Chain
#undef MARY_String_Heap_p
#undef MARY_String_Pool_p
#undef MARY_String_Frame_p
#undef MARY_String_Chain_p
#undef MARY_String_Get_UTF
#undef MARY_String_Point_Front
#undef MARY_String_Point_Back
#undef MARY_String_Point_End
#undef MARY_String_Assign
#undef MARY_String_Append_Front
#undef MARY_String_Append_Back
#undef MARY_String_Each_8
#undef MARY_String_Each_8_To_16
#undef MARY_String_Each_8_To_32
#undef MARY_String_Each_16
#undef MARY_String_Each_16_To_8
#undef MARY_String_Each_16_To_32
#undef MARY_String_Each_32
#undef MARY_String_Each_32_To_8
#undef MARY_String_Each_32_To_16

////// Creation //////

#define MARY_String_Static(NAME, UTF, C_STR)\
    Mary_String_t NAME; Mary_String_Create_With(&NAME, C_STR, 0, MARY_Allocator_Static, UTF)

#define MARY_String_Stack(NAME, UTF, C_STR)\
    Mary_String_t NAME; uint##UTF##_t NAME##_stack[] = C_STR;\
    Mary_String_Create_With(&NAME, NAME##_stack, 0, MARY_Allocator_Stack, UTF)

#define MARY_String_Heap(NAME, UTF, C_STR)\
    Mary_String_t NAME; Mary_String_Create_From(&NAME, MARY_Allocator_Heap, UTF, C_STR, UTF)

#define MARY_String_Pool(NAME, POOL, UTF, C_STR)\
    Mary_String_t NAME; Mary_String_Create_From(&NAME, MARY_Allocator_Pool((POOL)->id), UTF, C_STR, UTF)

#define MARY_String_Frame(NAME, UTF, C_STR)\
    Mary_String_t NAME; Mary_String_Create_From(&NAME, MARY_Allocator_Frame, UTF, C_STR, UTF)

#define MARY_String_Chain(NAME, UTF, C_STR)\
    Mary_String_t NAME; Mary_String_Create_From(&NAME, MARY_Allocator_Chain, UTF, C_STR, UTF)

#define MARY_String_Heap_p(THIS, UTF, C_STR)\
    Mary_String_Create_From(THIS, MARY_Allocator_Heap, UTF, C_STR, UTF)

#define MARY_String_Pool_p(THIS, POOL, UTF, C_STR)\
    Mary_String_Create_From(THIS, MARY_Allocator_Pool((POOL)->id), UTF, C_STR, UTF)

#define MARY_String_Frame_p(THIS, UTF, C_STR)\
    Mary_String_Create_From(THIS, MARY_Allocator_Frame, UTF, C_STR, UTF)

#define MARY_String_Chain_p(THIS, UTF, C_STR)\
    Mary_String_Create_From(THIS, MARY_Allocator_Chain, UTF, C_STR, UTF)

////// Accessing //////

#define MARY_String_Get_UTF(THIS)\
    MARY_Unit_To_UTF((THIS)->unit)

#define MARY_String_Point_Front(THIS)\
    MARY_Vector_Point_Front(THIS)

#define MARY_String_Point_Back(THIS)\
    MARY_Vector_Point_Back(THIS)

#define MARY_String_Point_End(THIS)\
    MARY_Vector_Point_End(THIS)

////// Altering //////

#define MARY_String_Assign(THIS, UTF, C_STR)    \
MARY_M                                          \
    MARY_String_Static(static_str, UTF, C_STR); \
    Mary_String_Assign(THIS, &static_str);      \
MARY_W

#define MARY_String_Append_Front(THIS, UTF, C_STR) \
MARY_M                                             \
    MARY_String_Static(static_str, UTF, C_STR);    \
    Mary_String_Append_Front(THIS, &static_str);   \
MARY_W

#define MARY_String_Append_Back(THIS, UTF, C_STR) \
MARY_M                                            \
    MARY_String_Static(static_str, UTF, C_STR);   \
    Mary_String_Append_Back(THIS, &static_str);   \
MARY_W

////// Loops //////

#define MARY_String_Each(THIS)\
for (\
    struct {\
        Mary_String_t *this;\
        Mary_Index_t code_idx;\
        Mary_Index_t unit_idx;\
        Mary_Byte_t *ptr;\
        Mary_Byte_t *next;\
        Mary_UTF_8_t utf_8;\
        Mary_UTF_16_t utf_16;\
        Mary_UTF_32_t utf_32;\
    } it = {\
        THIS\
        0,\
        0,\
        it.string->data,\
        it.ptr,\
        MARY_UTF_Decode_8(it.next, it.utf_8),\
        MARY_UTF_Encode_16(it.utf_8.code, it.utf_16, 0, 0)\
    };\
    it.code_idx < it.this->codes;\
    (\
        ++it.code_idx, it.unit_idx += it.utf_8.units, it.ptr = it.next,\
        MARY_UTF_Decode_8(it.next, it.utf_8),\
        MARY_UTF_Encode_16(it.utf_8.code, it.utf_16, 0, 0)\
    )\
)

#define MARY_String_Each_8(THIS)                                                                  \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx, unit_idx;                                                            \
      Mary_Size_t codes;                                                                          \
      uint8_t *ptr, *next;                                                                        \
      Mary_UTF_8_t utf_8;                                                                         \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(MARY_String_Get_UTF(THIS) == 8, 0), THIS ),                                   \
        0, 0, it.string->codes, it.string->data, it.ptr,                                          \
        MARY_UTF_Decode_8(it.next, it.utf_8)                                                   \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, it.unit_idx += it.utf_8.units, it.ptr = it.next,                               \
    MARY_UTF_Decode_8(it.next, it.utf_8)                                                       \
  )

#define MARY_String_Each_8_To_16(THIS)                                                            \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx, unit_idx;                                                            \
      Mary_Size_t codes;                                                                          \
      uint8_t *ptr, *next;                                                                        \
      Mary_UTF_8_t utf_8;                                                                         \
      Mary_UTF_16_t utf_16;                                                                       \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(MARY_String_Get_UTF(THIS) == 8, 0), THIS ),                                   \
        0, 0, it.string->codes, it.string->data, it.ptr,                                          \
        MARY_UTF_Decode_8(it.next, it.utf_8),                                                  \
        MARY_UTF_Encode_16(it.utf_8.code, it.utf_16, 0, 0)                                     \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, it.unit_idx += it.utf_8.units, it.ptr = it.next,                               \
    MARY_UTF_Decode_8(it.next, it.utf_8),                                                      \
    MARY_UTF_Encode_16(it.utf_8.code, it.utf_16, 0, 0)                                         \
  )

#define MARY_String_Each_8_To_32(THIS)                                                            \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx, unit_idx;                                                            \
      Mary_Size_t codes;                                                                          \
      uint8_t *ptr, *next;                                                                        \
      Mary_UTF_8_t utf_8;                                                                         \
      Mary_UTF_32_t utf_32;                                                                       \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(MARY_String_Get_UTF(THIS) == 8, 0), THIS ),                                   \
        0, 0, it.string->codes, it.string->data, it.ptr,                                          \
        MARY_UTF_Decode_8(it.next, it.utf_8),                                                  \
        it.utf_8.code                                                                             \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, it.unit_idx += it.utf_8.units, it.ptr = it.next,                               \
    MARY_UTF_Decode_8(it.next, it.utf_8),                                                      \
    it.utf_32 = it.utf_8.code                                                                     \
  )

#define MARY_String_Each_16(THIS)                                                                 \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx, unit_idx;                                                            \
      Mary_Size_t codes;                                                                          \
      uint16_t *ptr, *next;                                                                       \
      Mary_UTF_16_t utf_16;                                                                       \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(MARY_String_Get_UTF(THIS) == 16, 0), THIS ),                                  \
        0, 0, it.string->codes, it.string->data, it.ptr,                                          \
        MARY_UTF_Decode_16(it.utf_16, it.next)                                                 \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, it.unit_idx += it.utf_16.units, it.ptr = it.next,                              \
    MARY_UTF_Decode_16(it.utf_16, it.next)                                                     \
  )

#define MARY_String_Each_16_To_8(THIS)                                                            \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx, unit_idx;                                                            \
      Mary_Size_t codes;                                                                          \
      uint16_t *ptr, *next;                                                                       \
      Mary_UTF_16_t utf_16;                                                                       \
      Mary_UTF_8_t utf_8;                                                                         \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(MARY_String_Get_UTF(THIS) == 16, 0), THIS ),                                  \
        0, 0, it.string->codes, it.string->data, it.ptr,                                          \
        MARY_UTF_Decode_16(it.utf_16, it.next),                                                \
        MARY_UTF_Encode_8(it.utf_16.code, it.utf_8, 0, 0, 0, 0)                                \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, it.unit_idx += it.utf_16.units, it.ptr = it.next,                              \
    MARY_UTF_Decode_16(it.utf_16, it.next),                                                    \
    MARY_UTF_Encode_8(it.utf_16.code, it.utf_8, 0, 0, 0, 0)                                    \
  )

#define MARY_String_Each_16_To_32(THIS)                                                           \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx, unit_idx;                                                            \
      Mary_Size_t codes;                                                                          \
      uint16_t *ptr, *next;                                                                       \
      Mary_UTF_16_t utf_16;                                                                       \
      Mary_UTF_32_t utf_32;                                                                       \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(MARY_String_Get_UTF(THIS) == 16, 0), THIS ),                                  \
        0, 0, it.string->codes, it.string->data, it.ptr,                                          \
        MARY_UTF_Decode_16(it.utf_16, it.next),                                                \
        it.utf_16.code                                                                            \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, it.unit_idx += it.utf_16.units, it.ptr = it.next,                              \
    MARY_UTF_Decode_16(it.utf_16, it.next),                                                    \
    it.utf_32 = it.utf_16.code                                                                    \
  )

#define MARY_String_Each_32(THIS)                                                                 \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx;                                                                      \
      Mary_Size_t codes;                                                                          \
      uint32_t *ptr;                                                                              \
      Mary_UTF_32_t utf_32;                                                                       \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(MARY_String_Get_UTF(THIS) == 32, 0), THIS ),                                  \
        0, it.string->codes, it.string->data, *it.ptr                                             \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, ++it.ptr, it.utf_32 = *it.ptr                                                  \
  )

#define MARY_String_Each_32_To_8(THIS)                                                            \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx;                                                                      \
      Mary_Size_t codes;                                                                          \
      uint32_t *ptr;                                                                              \
      Mary_UTF_32_t utf_32;                                                                       \
      Mary_UTF_8_t utf_8;                                                                         \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(MARY_String_Get_UTF(THIS) == 32, 0), THIS ),                                  \
        0, it.string->codes, it.string->data, *it.ptr,                                            \
        MARY_UTF_Encode_8(it.utf_32, it.utf_8, 0, 0, 0, 0)                                     \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, ++it.ptr, it.utf_32 = *it.ptr,                                                 \
    MARY_UTF_Encode_8(it.utf_32, it.utf_8, 0, 0, 0, 0)                                         \
  )

#define MARY_String_Each_32_To_16(THIS)                                                           \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx;                                                                      \
      Mary_Size_t codes;                                                                          \
      uint32_t *ptr;                                                                              \
      Mary_UTF_32_t utf_32;                                                                       \
      Mary_UTF_16_t utf_16;                                                                       \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(MARY_String_Get_UTF(THIS) == 32, 0), THIS ),                                  \
        0, it.string->codes, it.string->data, *it.ptr,                                            \
        MARY_UTF_Encode_16(it.utf_32, it.utf_16, 0, 0)                                         \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, ++it.ptr, it.utf_32 = *it.ptr,                                                 \
    MARY_UTF_Encode_16(it.utf_32, it.utf_16, 0, 0)                                             \
  )

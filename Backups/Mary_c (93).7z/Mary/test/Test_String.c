﻿#include <Mary/Utils.h>
#include <Mary/Arena.h>
#include <Mary/String.h>
#include <Mary/Test/Test.h> // this should prob. be one level up.

MARY_Primitives;
MARY_Allocators;

static void Test_String_Create();
static void Test_String_Recode();
static void Test_String_Loops();

void Test_String()
{
  Mary_Arena_Start();

  MARY_Arena_In;

  Test_String_Create();
  Test_String_Recode();
  Test_String_Loops();

  MARY_Arena_Out;

  Mary_Arena_Stop();
}

static void Test_String_Create()
{
  MARY_Arena_In;

  Mary_Pool_t *pool = Mary_Pool_Create(256);

  TEST_START(Test_String_Create);

  MARY_String_Static(static_str, 8, u8"aϑ☱𗷱");
  MARY_Assert(static_str.data != 0, 0);
  MARY_Assert(static_str.bytes == 11, 0);
  MARY_Assert(static_str.allocator == STATIC, 0);
  MARY_Assert(static_str.unit == sizeof(u8), 0);
  MARY_Assert(static_str.units == 11, 0);
  MARY_Assert(static_str.codes == 5, 0);

  MARY_String_Stack(stack_str, 16, u"aϑ☱𗷱");
  MARY_Assert(stack_str.data != 0, 0);
  MARY_Assert(stack_str.bytes == 12, 0);
  MARY_Assert(stack_str.allocator == STACK, 0);
  MARY_Assert(stack_str.unit == sizeof(u16), 0);
  MARY_Assert(stack_str.units == 6, 0);
  MARY_Assert(stack_str.codes == 5, 0);

  MARY_String_Heap(heap_str, 32, U"aϑ☱𗷱");
  MARY_Assert(heap_str.data != 0, 0);
  MARY_Assert(heap_str.bytes == 20, 0);
  MARY_Assert(heap_str.allocator == HEAP, 0);
  MARY_Assert(heap_str.unit == sizeof(u32), 0);
  MARY_Assert(heap_str.units == 5, 0);
  MARY_Assert(heap_str.codes == 5, 0);
  Mary_String_Destroy(&heap_str);

  MARY_String_Pool(pool_str, pool, 8, u8"aϑ☱𗷱");
  MARY_Assert(pool_str.data != 0, 0);
  MARY_Assert(pool_str.bytes == 11, 0);
  MARY_Assert(pool_str.allocator == pool->id, 0);
  MARY_Assert(pool_str.unit == sizeof(u8), 0);
  MARY_Assert(pool_str.units == 11, 0);
  MARY_Assert(pool_str.codes == 5, 0);
  Mary_String_Destroy(&pool_str);

  MARY_String_Frame(frame_str, 16, u"aϑ☱𗷱");
  MARY_Assert(frame_str.data != 0, 0);
  MARY_Assert(frame_str.bytes == 12, 0);
  MARY_Assert(frame_str.allocator == FRAME, 0);
  MARY_Assert(frame_str.unit == sizeof(u16), 0);
  MARY_Assert(frame_str.units == 6, 0);
  MARY_Assert(frame_str.codes == 5, 0);

  MARY_String_Chain(chain_str, 32, U"aϑ☱𗷱");
  MARY_Assert(chain_str.data != 0, 0);
  MARY_Assert(chain_str.bytes == 20, 0);
  MARY_Assert(chain_str.allocator == CHAIN, 0);
  MARY_Assert(chain_str.unit == sizeof(u32), 0);
  MARY_Assert(chain_str.units == 5, 0);
  MARY_Assert(chain_str.codes == 5, 0);

  TEST_STOP;

  Mary_Pool_Destroy(pool);

  MARY_Arena_Out;
}

static void Test_String_Recode()
{
  MARY_Arena_In;

  Mary_C_String_8_t c_str_8 = MARY_C_String(8, "aϑ☱𗷱");
  Mary_C_String_16_t c_str_16 = MARY_C_String(16, "aϑ☱𗷱");
  Mary_C_String_32_t c_str_32 = MARY_C_String(32, "aϑ☱𗷱");

  MARY_String_Frame(str, 32, c_str_32);

  TEST_START(Test_String_Recode);

  Mary_String_Recode(&str, 32);
  //printf("\n"); MARY_String_Each_UTF_32(&str) printf("%u ", it.utf_32);
  MARY_Assert(Mary_Is_Same(str.data, c_str_32, str.unit * str.units), 0);

  Mary_String_Recode(&str, 8);
  //printf("\n"); MARY_String_Each_UTF_8(&str) printf("%u ", it.utf_8.code);
  MARY_Assert(Mary_Is_Same(str.data, c_str_8, str.unit * str.units), 0);

  Mary_String_Recode(&str, 32);
  //printf("\n"); MARY_String_Each_UTF_32(&str) printf("%u ", it.utf_32);
  MARY_Assert(Mary_Is_Same(str.data, c_str_32, str.unit * str.units), 0);

  Mary_String_Recode(&str, 16);
  //printf("\n"); MARY_String_Each_UTF_16(&str) printf("%u ", it.utf_16.code);
  MARY_Assert(Mary_Is_Same(str.data, c_str_16, str.unit * str.units), 0);

  Mary_String_Recode(&str, 8);
  //printf("\n"); MARY_String_Each_UTF_8(&str) printf("%u ", it.utf_8.code);
  MARY_Assert(Mary_Is_Same(str.data, c_str_8, str.unit * str.units), 0);

  Mary_String_Recode(&str, 16);
  //printf("\n"); MARY_String_Each_UTF_16(&str) printf("%u ", it.utf_16.code);
  MARY_Assert(Mary_Is_Same(str.data, c_str_16, str.unit * str.units), 0);

  Mary_String_Recode(&str, 32);
  //printf("\n"); MARY_String_Each_UTF_32(&str) printf("%u ", it.utf_32);
  MARY_Assert(Mary_Is_Same(str.data, c_str_32, str.unit * str.units), 0);

  TEST_STOP;

  MARY_Arena_Out;
}

static void Test_String_Loops()
{
  #define CODE_0 97
  #define CODE_1 977
  #define CODE_2 9777
  #define CODE_3 97777
  #define CODE_4 0

  #define UTF_8_0                             \
    MARY_Assert(it.utf_8.code == CODE_0, 0);  \
    MARY_Assert(it.utf_8.units == 1, 0);      \
    MARY_Assert(it.utf_8.a == 97, 0)

  #define UTF_8_1                             \
    MARY_Assert(it.utf_8.code == CODE_1, 0);  \
    MARY_Assert(it.utf_8.units == 2, 0);      \
    MARY_Assert(it.utf_8.a == 207, 0);        \
    MARY_Assert(it.utf_8.b == 145, 0)

  #define UTF_8_2                             \
    MARY_Assert(it.utf_8.code == CODE_2, 0);  \
    MARY_Assert(it.utf_8.units == 3, 0);      \
    MARY_Assert(it.utf_8.a == 226, 0);        \
    MARY_Assert(it.utf_8.b == 152, 0);        \
    MARY_Assert(it.utf_8.c == 177, 0)

  #define UTF_8_3                             \
    MARY_Assert(it.utf_8.code == CODE_3, 0);  \
    MARY_Assert(it.utf_8.units == 4, 0);      \
    MARY_Assert(it.utf_8.a == 240, 0);        \
    MARY_Assert(it.utf_8.b == 151, 0);        \
    MARY_Assert(it.utf_8.c == 183, 0);        \
    MARY_Assert(it.utf_8.d == 177, 0)

  #define UTF_8_4                             \
    MARY_Assert(it.utf_8.code == CODE_4, 0);  \
    MARY_Assert(it.utf_8.units == 1, 0);      \
    MARY_Assert(it.utf_8.a == 0, 0)

  #define UTF_16_0                            \
    MARY_Assert(it.utf_16.code == CODE_0, 0); \
    MARY_Assert(it.utf_16.units == 1, 0);     \
    MARY_Assert(it.utf_16.a == 97, 0)

  #define UTF_16_1                            \
    MARY_Assert(it.utf_16.code == CODE_1, 0); \
    MARY_Assert(it.utf_16.units == 1, 0);     \
    MARY_Assert(it.utf_16.a == 977, 0)

  #define UTF_16_2                            \
    MARY_Assert(it.utf_16.code == CODE_2, 0); \
    MARY_Assert(it.utf_16.units == 1, 0);     \
    MARY_Assert(it.utf_16.a == 9777, 0)

  #define UTF_16_3                            \
    MARY_Assert(it.utf_16.code == CODE_3, 0); \
    MARY_Assert(it.utf_16.units == 2, 0);     \
    MARY_Assert(it.utf_16.a == 0xD81F, 0);    \
    MARY_Assert(it.utf_16.b == 0xDDF1, 0)

  #define UTF_16_4                            \
    MARY_Assert(it.utf_16.code == CODE_4, 0); \
    MARY_Assert(it.utf_16.units == 1, 0);     \
    MARY_Assert(it.utf_16.a == 0, 0)

  #define UTF_32_0\
    MARY_Assert(it.utf_32 == CODE_0, 0)

  #define UTF_32_1\
    MARY_Assert(it.utf_32 == CODE_1, 0)

  #define UTF_32_2\
    MARY_Assert(it.utf_32 == CODE_2, 0)

  #define UTF_32_3\
    MARY_Assert(it.utf_32 == CODE_3, 0)

  #define UTF_32_4\
    MARY_Assert(it.utf_32 == CODE_4, 0)

  MARY_Arena_In;

  MARY_String_Frame(str, 8, u8"aϑ☱𗷱");

  TEST_START(Test_String_Loops);

  Mary_String_Recode(&str, 8);

  MARY_String_Each_UTF_8(&str)
  {
    MARY_Assert(it.string == &str, 0);
    MARY_Assert(it.string->units == 11, 0);
    MARY_Assert(it.codes == 5, 0);
    if (it.code_idx == 0)
    {
      MARY_Assert(it.unit_idx == 0, 0);
      UTF_8_0;
    }
    else if (it.code_idx == 1)
    {
      MARY_Assert(it.unit_idx == 1, 0);
      UTF_8_1;
    }
    else if (it.code_idx == 2)
    {
      MARY_Assert(it.unit_idx == 3, 0);
      UTF_8_2;
    }
    else if (it.code_idx == 3)
    {
      MARY_Assert(it.unit_idx == 6, 0);
      UTF_8_3;
    }
    else
    {
      MARY_Assert(it.unit_idx == 10, 0);
      UTF_8_4;
    }
  }

  MARY_String_Each_UTF_8_To_16(&str)
  {
    MARY_Assert(it.string == &str, 0);
    MARY_Assert(it.string->units == 11, 0);
    MARY_Assert(it.codes == 5, 0);
    if (it.code_idx == 0)
    {
      MARY_Assert(it.unit_idx == 0, 0);
      UTF_8_0;
      UTF_16_0;
    }
    else if (it.code_idx == 1)
    {
      MARY_Assert(it.unit_idx == 1, 0);
      UTF_8_1;
      UTF_16_1;
    }
    else if (it.code_idx == 2)
    {
      MARY_Assert(it.unit_idx == 3, 0);
      UTF_8_2;
      UTF_16_2;
    }
    else if (it.code_idx == 3)
    {
      MARY_Assert(it.unit_idx == 6, 0);
      UTF_8_3;
      UTF_16_3;
    }
    else
    {
      MARY_Assert(it.unit_idx == 10, 0);
      UTF_8_4;
      UTF_16_4;
    }
  }

  MARY_String_Each_UTF_8_To_32(&str)
  {
    MARY_Assert(it.string == &str, 0);
    MARY_Assert(it.string->units == 11, 0);
    MARY_Assert(it.codes == 5, 0);
    if (it.code_idx == 0)
    {
      MARY_Assert(it.unit_idx == 0, 0);
      UTF_8_0;
      UTF_32_0;
    }
    else if (it.code_idx == 1)
    {
      MARY_Assert(it.unit_idx == 1, 0);
      UTF_8_1;
      UTF_32_1;
    }
    else if (it.code_idx == 2)
    {
      MARY_Assert(it.unit_idx == 3, 0);
      UTF_8_2;
      UTF_32_2;
    }
    else if (it.code_idx == 3)
    {
      MARY_Assert(it.unit_idx == 6, 0);
      UTF_8_3;
      UTF_32_3;
    }
    else
    {
      MARY_Assert(it.unit_idx == 10, 0);
      UTF_8_4;
      UTF_32_4;
    }
  }

  Mary_String_Recode(&str, 16);

  MARY_String_Each_UTF_16(&str)
  {
    MARY_Assert(it.string == &str, 0);
    MARY_Assert(it.string->units == 6, 0);
    MARY_Assert(it.codes == 5, 0);
    if (it.code_idx == 0)
    {
      MARY_Assert(it.unit_idx == 0, 0);
      UTF_16_0;
    }
    else if (it.code_idx == 1)
    {
      MARY_Assert(it.unit_idx == 1, 0);
      UTF_16_1;
    }
    else if (it.code_idx == 2)
    {
      MARY_Assert(it.unit_idx == 2, 0);
      UTF_16_2;
    }
    else if (it.code_idx == 3)
    {
      MARY_Assert(it.unit_idx == 3, 0);
      UTF_16_3;
    }
    else
    {
      MARY_Assert(it.unit_idx == 5, 0);
      UTF_16_4;
    }
  }

  MARY_String_Each_UTF_16_To_8(&str)
  {
    MARY_Assert(it.string == &str, 0);
    MARY_Assert(it.string->units == 6, 0);
    MARY_Assert(it.codes == 5, 0);
    if (it.code_idx == 0)
    {
      MARY_Assert(it.unit_idx == 0, 0);
      UTF_16_0;
      UTF_8_0;
    }
    else if (it.code_idx == 1)
    {
      MARY_Assert(it.unit_idx == 1, 0);
      UTF_16_1;
      UTF_8_1;
    }
    else if (it.code_idx == 2)
    {
      MARY_Assert(it.unit_idx == 2, 0);
      UTF_16_2;
      UTF_8_2;
    }
    else if (it.code_idx == 3)
    {
      MARY_Assert(it.unit_idx == 3, 0);
      UTF_16_3;
      UTF_8_3;
    }
    else
    {
      MARY_Assert(it.unit_idx == 5, 0);
      UTF_16_4;
      UTF_8_4;
    }
  }

  MARY_String_Each_UTF_16_To_32(&str)
  {
    MARY_Assert(it.string == &str, 0);
    MARY_Assert(it.string->units == 6, 0);
    MARY_Assert(it.codes == 5, 0);
    if (it.code_idx == 0)
    {
      MARY_Assert(it.unit_idx == 0, 0);
      UTF_16_0;
      UTF_32_0;
    }
    else if (it.code_idx == 1)
    {
      MARY_Assert(it.unit_idx == 1, 0);
      UTF_16_1;
      UTF_32_1;
    }
    else if (it.code_idx == 2)
    {
      MARY_Assert(it.unit_idx == 2, 0);
      UTF_16_2;
      UTF_32_2;
    }
    else if (it.code_idx == 3)
    {
      MARY_Assert(it.unit_idx == 3, 0);
      UTF_16_3;
      UTF_32_3;
    }
    else
    {
      MARY_Assert(it.unit_idx == 5, 0);
      UTF_16_4;
      UTF_32_4;
    }
  }

  Mary_String_Recode(&str, 32);

  MARY_String_Each_UTF_32(&str)
  {
    MARY_Assert(it.string == &str, 0);
    MARY_Assert(it.string->units == 5, 0);
    MARY_Assert(it.codes == 5, 0);
    if (it.code_idx == 0)
    {
      UTF_32_0;
    }
    else if (it.code_idx == 1)
    {
      UTF_32_1;
    }
    else if (it.code_idx == 2)
    {
      UTF_32_2;
    }
    else if (it.code_idx == 3)
    {
      UTF_32_3;
    }
    else
    {
      UTF_32_4;
    }
  }

  MARY_String_Each_UTF_32_To_8(&str)
  {
    MARY_Assert(it.string == &str, 0);
    MARY_Assert(it.string->units == 5, 0);
    MARY_Assert(it.codes == 5, 0);
    if (it.code_idx == 0)
    {
      UTF_32_0;
      UTF_8_0;
    }
    else if (it.code_idx == 1)
    {
      UTF_32_1;
      UTF_8_1;
    }
    else if (it.code_idx == 2)
    {
      UTF_32_2;
      UTF_8_2;
    }
    else if (it.code_idx == 3)
    {
      UTF_32_3;
      UTF_8_3;
    }
    else
    {
      UTF_32_4;
      UTF_8_4;
    }
  }

  MARY_String_Each_UTF_32_To_16(&str)
  {
    MARY_Assert(it.string == &str, 0);
    MARY_Assert(it.string->units == 5, 0);
    MARY_Assert(it.codes == 5, 0);
    if (it.code_idx == 0)
    {
      UTF_32_0;
      UTF_16_0;
    }
    else if (it.code_idx == 1)
    {
      UTF_32_1;
      UTF_16_1;
    }
    else if (it.code_idx == 2)
    {
      UTF_32_2;
      UTF_16_2;
    }
    else if (it.code_idx == 3)
    {
      UTF_32_3;
      UTF_16_3;
    }
    else
    {
      UTF_32_4;
      UTF_16_4;
    }
  }

  TEST_STOP;

  MARY_Arena_Out;

  #undef CODE_0
  #undef CODE_1
  #undef CODE_2
  #undef CODE_3
  #undef CODE_4

  #undef UTF_8_0
  #undef UTF_8_1
  #undef UTF_8_2
  #undef UTF_8_3
  #undef UTF_8_4

  #undef UTF_16_0
  #undef UTF_16_1
  #undef UTF_16_2
  #undef UTF_16_3
  #undef UTF_16_4

  #undef UTF_32_0
  #undef UTF_32_1
  #undef UTF_32_2
  #undef UTF_32_3
  #undef UTF_32_4
}

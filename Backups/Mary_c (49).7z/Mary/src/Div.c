#include <Mary/Utils.h>
#include <Mary/Vector.h>
#include <Mary/Div.h>

Mary_Vector_t v_divs;

void Mary_Div_Create(Mary_Div_t *mary_div)
{
  Mary_Element_Create(mary_div, MARY_ELEMENT_DIV);
}

void Mary_Div_Destroy(Mary_Div_t *mary_div)
{
  Mary_Element_Destroy(mary_div);
}

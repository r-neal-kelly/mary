﻿#include <stdio.h>
#include <stdlib.h>
#include <Mary/Mary.h>

MARY_PRIMITIVES;

int main()
{
#if 1
  Mary_Start();

  Mary_Window_t window; Mary_Window_Create(&window);
  Mary_Text_t text; Mary_Text_Create_With_File(&text, 8, "test2.txt");
  Mary_Element_Append_To(&text, &window);
  Mary_Text_Position(&text, 0, 0);
  Mary_Text_Size(&text, 500, 500);
  Mary_Text_Color(&text, 1.0f, 1.0f, 1.0f, 1.0f);

  while (Mary_Window_Can_Render())
  {
    Mary_Window_Render_All();
    Mary_OS_Sleep(1);
  }

  Mary_Finish();
#endif

#if 0
  Mary_Regex_Start();

  #define PRINT_MATCHES(MATCHES)                                                         \
    MARY_Range(MATCHES.data, Mary_Slice_t, 0, MATCHES.units)                             \
      printf("from: %llu to_exclusive: %llu\n", range.val.from, range.val.to_exclusive);

  if (0)
  {
    Mary_Regex_t regex; Mary_Vector_t matches;

    //MARY_Benchmark(Mary_Regex_Create(&regex, 32, U"(?<[1-9]+z+)a", "g"), 1);
    //MARY_Benchmark(matches = Mary_Regex_Execute(&regex, 32, U"a12zzzza 5zza a"), 12);

    //MARY_Benchmark(Mary_Regex_Create(&regex, 32, U"b(?>12+3?)", "g"), 1);
    //MARY_Benchmark(matches = Mary_Regex_Execute(&regex, 32, U"b122222bdb123ba"), 12);

    //MARY_Benchmark(Mary_Regex_Create(&regex, 32, U"~:Hebrew Char:", "g"), 1);
    //MARY_Benchmark(matches = Mary_Regex_Execute(&regex, 32, U"Ἄνθρωπος בְּרֵאשִׁ֖ית בָּרָ֣א πρὸς πάντα"), 12);

    //MARY_Benchmark(Mary_Regex_Create(&regex, 32, U"^a$", "gm"), 1);
    //MARY_Benchmark(matches = Mary_Regex_Execute(&regex, 32, U"a\na"), 12);

    //MARY_Benchmark(Mary_Regex_Create(&regex, 32, U"a{3,2}", "g"), 1);
    //MARY_Benchmark(matches = Mary_Regex_Execute(&regex, 32, U"aaaaa"), 12);

    MARY_Benchmark(Mary_Regex_Create(&regex, 32, U"~:Latin:+", "g"), 1);
    MARY_Benchmark(matches = Mary_Regex_Execute(&regex, 32, U"abc"), 12);

    PRINT_MATCHES(matches);

    Mary_Vector_Destroy(&matches); Mary_Regex_Destroy(&regex);
  }

  if (1)
  {
    Mary_Regex_t _1, _2, _3, _4; Mary_Vector_t v_1, v_2, v_3, v_4;
    u32 *bound_test = U"This is a misty island.";
                       "01234567891111111111222";
                       "          0123456789012";
    MARY_Benchmark(Mary_Regex_Create(&_1, 32, U"~bis~b", "g"), 1);
    MARY_Benchmark(Mary_Regex_Create(&_2, 32, U"~bis~B", "g"), 1);
    MARY_Benchmark(Mary_Regex_Create(&_3, 32, U"~Bis~b", "g"), 1);
    MARY_Benchmark(Mary_Regex_Create(&_4, 32, U"~Bis~B", "g"), 1); printf("\n");
    MARY_Benchmark(v_1 = Mary_Regex_Execute(&_1, 32, bound_test), 12);
    MARY_Benchmark(v_2 = Mary_Regex_Execute(&_2, 32, bound_test), 12);
    MARY_Benchmark(v_3 = Mary_Regex_Execute(&_3, 32, bound_test), 12);
    MARY_Benchmark(v_4 = Mary_Regex_Execute(&_4, 32, bound_test), 12); printf("\n");
    PRINT_MATCHES(v_1); PRINT_MATCHES(v_2); PRINT_MATCHES(v_3); PRINT_MATCHES(v_4);
    MARY_Vector_Destroy(v_1); MARY_Vector_Destroy(v_2); MARY_Vector_Destroy(v_3); MARY_Vector_Destroy(v_4);
    Mary_Regex_Destroy(&_1); Mary_Regex_Destroy(&_2); Mary_Regex_Destroy(&_3); Mary_Regex_Destroy(&_4);
  }

  #undef PRINT_MATCHES

  Mary_Regex_Finish();
#endif

  //Mary_Exit_Success();
}

#include <Mary/Element.h>
#include <Mary/Window.h>
#include <Mary/Text.h>

MARY_PRIMITIVES;

typedef void (*Render_f)(void *);

Mary_Hashmap_t render_funcs;

void Mary_Element_Start()
{
  size_t type; Render_f Render;
  Mary_Hashmap_Create(&render_funcs, sizeof(size_t), sizeof(Render_f));
  type = MARY_ELEMENT_WINDOW; Render = Mary_Window_Render;
  Mary_Hashmap_Assign(&render_funcs, &type, &Render);
  type = MARY_ELEMENT_TEXT;  Render = Mary_Text_Render;
  Mary_Hashmap_Assign(&render_funcs, &type, &Render);
}

void Mary_Element_Finish()
{
  Mary_Hashmap_Destroy(&render_funcs);
}

void Mary_Element_Create(void *mary_element, size_t type)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  element->type = type;
  element->window = type == MARY_ELEMENT_WINDOW ? MARY_Window(element) : 0;
  element->parent = 0;
  element->z = 0;
  Mary_Vector_Create(&element->children_s, sizeof(Mary_Element_t *), 0);
  Mary_Vector_Create(&element->children_z, sizeof(Mary_Element_t *), 0);
  Mary_Vector_Create(&element->events, sizeof(Mary_Event_t *), 0);
  Mary_Hashmap_Create(&element->listeners, sizeof(Mary_Element_t *), sizeof(u64));
}

void Mary_Element_Destroy(void *mary_element)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  element->type = 0;
  element->window = 0;
  element->parent = 0;
  Mary_Vector_Destroy(&element->children_s);
  Mary_Vector_Destroy(&element->children_z);
  Mary_Vector_Destroy(&element->events);
  Mary_Hashmap_Destroy(&element->listeners);
}

static void Mary_Element_Window(Mary_Element_t *element, Mary_Window_t *window)
{
  element->window = window;
  MARY_Vector_Each(element->children_s, Mary_Element_t *)
  {
    Mary_Element_Window(range.val, window);
  }
}

void Mary_Element_Append_To(void *mary_element, void *mary_element_parent)
{
  #define LAST_CHILD_Z(PARENT_PTR)\
    (*(Mary_Element_t **)Mary_Vector_Point(&PARENT_PTR->children_z, PARENT_PTR->children_z.units - 1))

  Mary_Element_t *element = MARY_Element(mary_element);
  Mary_Element_t *parent = MARY_Element(mary_element_parent);

  ////// remove from old parent
  if (element->parent != 0)
  {
    MARY_Vector_Each(element->parent->children_s, Mary_Element_t *)
    {
      if (range.val == element)
      {
        Mary_Vector_Erase_At(&element->parent->children_s, range.idx); break;
      }
    }
    MARY_Vector_Each(element->parent->children_z, Mary_Element_t *)
    {
      if (range.val == element)
      {
        Mary_Vector_Erase_At(&element->parent->children_z, range.idx); break;
      }
    }
    Mary_Window_Flag_Dirty(element->window);
  }

  ////// add to new parent
  Mary_Vector_Push_Back(&parent->children_s, &element);
  if (parent->children_z.units == 0)
  {
    Mary_Vector_Push_Back(&parent->children_z, &element);
  }
  else if (LAST_CHILD_Z(parent)->z <= element->z)
  {
    Mary_Vector_Push_Back(&parent->children_z, &element);
  }
  else
  {
    MARY_Vector_Each(parent->children_z, Mary_Element_t *)
    {
      if (range.val->z > element->z)
      {
        Mary_Vector_Push_At(&parent->children_z, range.idx, &element);
      }
    }
  }
  Mary_Element_Window(element, parent->window);
  Mary_Window_Flag_Dirty(element->window);
  element->parent = parent;

  #undef LAST_CHILD_Z
}

void Mary_Element_Remove(void *mary_element)
{
  Mary_Element_t *element = MARY_Element(mary_element);
  if (element->parent != 0)
  {
    MARY_Vector_Each(element->parent->children_s, Mary_Element_t *)
    {
      if (range.val == element)
      {
        Mary_Vector_Erase_At(&element->parent->children_s, range.idx); break;
      }
    }
    MARY_Vector_Each(element->parent->children_z, Mary_Element_t *)
    {
      if (range.val == element)
      {
        Mary_Vector_Erase_At(&element->parent->children_z, range.idx); break;
      }
    }
    Mary_Window_Flag_Dirty(element->window);
    Mary_Element_Window(element, 0);
    element->parent = 0;
  }
}

void Mary_Element_Render(Mary_Element_t *element)
{
  Render_f Render; Mary_Hashmap_At(&render_funcs, &element->type, &Render); Render(element);
  MARY_Vector_Each(element->children_z, Mary_Element_t *)
  {
    Mary_Element_Render(range.val);
  }
}

void Mary_Element_Render_Children(Mary_Element_t *element)
{
  Render_f Render;
  MARY_Vector_Each(element->children_z, Mary_Element_t *)
  {
    Mary_Hashmap_At(&render_funcs, &range.val->type, &Render);
    Render(range.val);
    Mary_Element_Render_Children(range.val);
  }
}

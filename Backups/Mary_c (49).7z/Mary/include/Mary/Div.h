#pragma once

#include <Mary/Element.h>

typedef struct Mary_Div_t Mary_Div_t;

struct Mary_Div_t
{
  MARY_Element_t;
};

void Mary_Div_Create(Mary_Div_t *mary_div);
void Mary_Div_Destroy(Mary_Div_t *mary_div);

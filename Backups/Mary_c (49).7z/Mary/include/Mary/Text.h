#pragma once

#include <Mary/String.h>
#include <Mary/Element.h>

typedef struct
{
  MARY_Element_t;
  Mary_String_t string;
  Mary_Wordmap_v lines;
  unsigned int texture;
  // will prob need a height to know how far to move vertically.
  // maybe want to attach font details here. we could let fonts be inlined instead, like html.
}
Mary_Text_t;

void Mary_Text_Start();
void Mary_Text_Finish();
void Mary_Text_Create(Mary_Text_t *mary_text, char bit_format, void *text, size_t opt_units);
void Mary_Text_Create_With_File(Mary_Text_t *elem, char bit_format, const char *file_path);
//void Mary_Text_Create_With_String(Mary_Text_t *mary_text, Mary_String_t *mary_string);
void Mary_Text_Destroy(Mary_Text_t *mary_text);
//void Mary_Text_Change(Mary_Text_t *mary_text, uint16_t *text);
void Mary_Text_Render(void *mary_text);
void Mary_Text_Position(Mary_Text_t *mary_text, float x, float y);
void Mary_Text_Size(Mary_Text_t *mary_text, float w, float h);
void Mary_Text_Color(Mary_Text_t *mary_text, float r, float g, float b, float a);

#define MARY_Text(VOID_PTR) ((Mary_Text_t *)(VOID_PTR))

#pragma once

#include <stdint.h>
#include <Mary/Vector.h>

#if defined(_WIN32)

#define WIN32_LEAN_AND_MEAN
#define UNICODE
#include <Windows.h>
#define MARY_CALL WINAPI

#elif defined(__linux__)

#define to_be_done

#endif

void Mary_OS_Start();
void Mary_OS_Finish();
void *Mary_OS_Global_Window();
void *Mary_OS_Global_Window_Context();
void *Mary_OS_Global_OpenGl_Context();
void Mary_OS_Window_Create(void *mary_window);
void Mary_OS_Window_Destroy(void *mary_window);
void Mary_OS_Window_Show(void *mary_window);
void Mary_OS_Window_Hide(void *mary_window);
void Mary_OS_Window_Measure(void *mary_window);
void Mary_OS_Window_Handle_Messages(void *mary_window);
void Mary_OS_Window_Make_Current(void *mary_window);
void Mary_OS_Window_Swap_Buffers(void *mary_window);
void Mary_OS_Sleep(size_t milliseconds);

// all of the following needs to be made a lot better.
typedef struct
{
  Mary_Bitmap_t line;
  Mary_Vector_t widths;
}
Mary_Wordmap_t;

typedef Mary_Vector_t Mary_Wordmap_v; // maybe we should make this use a pool to keep it all in one area.

Mary_Wordmap_t Mary_OS_Text_To_Bitmap(uint16_t *text, int units);

#pragma once

#include <Mary/Vector.h>

enum
{
  MARY_STRING_8 = 8,
  MARY_STRING_16 = 16,
  MARY_STRING_32 = 32
};

typedef struct
{
  MARY_Vector_t;
  size_t codes;
}
Mary_String_t;

void Mary_String_Create(Mary_String_t *mary_string, char bit_format, void *string, size_t opt_units);
void Mary_String_Create_At(Mary_String_t *mary_string, char bit_format, Mary_p mary_ptr);
void Mary_String_8_Create_At(Mary_String_t *mary_string, Mary_p mary_ptr);
void Mary_String_16_Create_At(Mary_String_t *mary_string, Mary_p mary_ptr);
void Mary_String_32_Create_At(Mary_String_t *mary_string, Mary_p mary_ptr);
void Mary_String_Create_With(Mary_String_t *mary_string, char bit_format, Mary_p mary_ptr);
void Mary_String_8_Create_With(Mary_String_t *mary_string, Mary_p mary_ptr);
void Mary_String_16_Create_With(Mary_String_t *mary_string, Mary_p mary_ptr);
void Mary_String_32_Create_With(Mary_String_t *mary_string, Mary_p mary_ptr);
void Mary_String_Destroy(Mary_String_t *mary_string);
size_t Mary_String_Count_Bytes(char bit_format, void *string, char want_null);
size_t Mary_String_Count_Codes(Mary_String_t *mary_string);
void Mary_String_Edit(Mary_String_t *mary_string, void *string);
char Mary_String_Get_Format(Mary_String_t *mary_string);
void Mary_String_Format(Mary_String_t *mary_string, char bit_format);
void Mary_String_Format_8_To_16(Mary_String_t *string);
void Mary_String_Format_8_To_32(Mary_String_t *string);
void Mary_String_Format_16_To_8(Mary_String_t *string);
void Mary_String_Format_16_To_32(Mary_String_t *string);
void Mary_String_Format_32_To_8(Mary_String_t *string);
void Mary_String_Format_32_To_16(Mary_String_t *string);
// Cluster() should group the clusters in the string together
// Alphabet() should return whatever lang it is, see Lang.h

#define MARY_String_8_Encode(CODE, OUT_A, OUT_B, OUT_C, OUT_D, CASE_A, CASE_B, CASE_C, CASE_D)    \
(                                                                                                 \
  (CODE) < 0x000080 ?                                                                             \
      ( OUT_A = (CODE)                        , (CASE_A), 0 ) :                                   \
  (CODE) < 0x000800 ?                                                                             \
      ( OUT_A = ( 0xC0 | (CODE) >> 6         ),                                                   \
        OUT_B = ( 0x80 | (CODE)       & 0x3F ), (CASE_B), 0 ) :                                   \
  (CODE) < 0x010000 ?                                                                             \
      ( OUT_A = ( 0xE0 | (CODE) >> 12        ),                                                   \
        OUT_B = ( 0x80 | (CODE) >> 6  & 0x3F ),                                                   \
        OUT_C = ( 0x80 | (CODE)       & 0x3F ), (CASE_C), 0 ) :                                   \
  (CODE) < 0x110000 ?                                                                             \
      ( OUT_A = ( 0xF0 | (CODE) >> 18        ),                                                   \
        OUT_B = ( 0x80 | (CODE) >> 12 & 0x3F ),                                                   \
        OUT_C = ( 0x80 | (CODE) >> 6  & 0x3F ),                                                   \
        OUT_D = ( 0x80 | (CODE)       & 0x3F ), (CASE_D), 0 ) : 0                                 \
)

#define MARY_String_8_Decode(PTR, OUT_CODE, CASE_A, CASE_B, CASE_C, CASE_D)    \
(                                                                              \
  *(PTR) >> 7 == 0x00 ?                                                        \
      ( OUT_CODE = ( * (PTR)             )       , (CASE_A), 0 ) :             \
  *(PTR) >> 5 == 0x06 ?                                                        \
      ( OUT_CODE = ( * (PTR)      ^ 0xC0 ) << 6  |                             \
                   ( *((PTR) + 1) ^ 0x80 )       , (CASE_B), 0 ) :             \
  *(PTR) >> 4 == 0x0E ?                                                        \
      ( OUT_CODE = ( * (PTR)      ^ 0xE0 ) << 12 |                             \
                   ( *((PTR) + 1) ^ 0x80 ) << 6  |                             \
                   ( *((PTR) + 2) ^ 0x80 )       , (CASE_C), 0 ) :             \
  *(PTR) >> 3 == 0x1E ?                                                        \
      ( OUT_CODE = ( * (PTR)      ^ 0xF0 ) << 18 |                             \
                   ( *((PTR) + 1) ^ 0x80 ) << 12 |                             \
                   ( *((PTR) + 2) ^ 0x80 ) << 6  |                             \
                   ( *((PTR) + 3) ^ 0x80 )       , (CASE_D), 0 ) : 0           \
)

#define MARY_String_8_Code_To_Units(CODE)    \
(                                            \
  (CODE) < 0x000080 ? 1 :                    \
  (CODE) < 0x000800 ? 2 :                    \
  (CODE) < 0x010000 ? 3 :                    \
  (CODE) < 0x110000 ? 4 : 0                  \
)

#define MARY_String_8_Ptr_To_Units(PTR)    \
(                                          \
  *(PTR) >> 7 == 0x00 ? 1 :                \
  *(PTR) >> 5 == 0x06 ? 2 :                \
  *(PTR) >> 4 == 0x0E ? 3 :                \
  *(PTR) >> 3 == 0x1E ? 4 : 0              \
)

#define MARY_String_16_Encode(CODE, OUT_A, OUT_B, CASE_A, CASE_B)           \
(                                                                           \
  (CODE) < 0x10000 ?                                                        \
      ( OUT_A = (CODE)                                    , (CASE_A), 0 ) : \
      ( OUT_A = ( ( (CODE) - 0x10000 >> 10    ) + 0xD800 ),                 \
        OUT_B = ( ( (CODE) - 0x10000 &  0x3FF ) + 0xDC00 ), (CASE_B), 0 )   \
)

#define MARY_String_16_Decode(PTR, OUT_CODE, CASE_A, CASE_B)                                    \
(                                                                                               \
  *(PTR) < 0xD800 || *(PTR) > 0xDFFF ?                                                          \
      ( OUT_CODE = *(PTR)                                                     , (CASE_A), 0 ) : \
      ( OUT_CODE = (*(PTR) - 0xD800 << 10) + (*((PTR) + 1) - 0xDC00) + 0x10000, (CASE_B), 0 )   \
)

#define MARY_String_16_Code_To_Units(CODE)    \
(                                             \
  (CODE) < 0x10000 ? 1 : 2                    \
)

#define MARY_String_16_Ptr_To_Units(PTR)        \
(                                               \
  *(PTR) < 0xD800 || *(PTR) > 0xDFFF ? 2 : 1    \
)

#define MARY_String_8_Each(S)                                                                    \
  for                                                                                            \
  (                                                                                              \
    struct { u64 idx_codes, idx_units, ptr_units, finish_exclusive, finish; u32 code; u8 *ptr; } \
    it =                                                                                         \
    {                                                                                            \
      ( MARY_Assert(Mary_String_Get_Format(S) == MARY_STRING_8),                                 \
        0 ), 0, 0, (S)->codes, (S)->codes - 1, 0,                                                \
      ( MARY_String_8_Decode( (u8 *)(S)->data, it.code,                                          \
                                it.ptr_units = 1,                                                \
                                it.ptr_units = 2,                                                \
                                it.ptr_units = 3,                                                \
                                it.ptr_units = 4 ),                                              \
        (S)->data )                                                                              \
    };                                                                                           \
    it.idx_codes < it.finish_exclusive;                                                          \
    ++it.idx_codes, it.idx_units += it.ptr_units, it.ptr += it.ptr_units,                        \
    MARY_String_8_Decode( it.ptr, it.code,                                                       \
                             it.ptr_units = 1,                                                   \
                             it.ptr_units = 2,                                                   \
                             it.ptr_units = 3,                                                   \
                             it.ptr_units = 4 )                                                  \
  )

#define MARY_String_16_Each(S)                                                                    \
  for                                                                                             \
  (                                                                                               \
    struct { u64 idx_codes, idx_units, ptr_units, finish_exclusive, finish; u32 code; u16 *ptr; } \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(Mary_String_Get_Format(S) == MARY_STRING_16),                                 \
        0 ), 0, 0, (S)->codes, (S)->codes - 1, 0,                                                 \
      ( MARY_String_16_Decode( (u16 *)(S)->data, it.code,                                         \
                                  it.ptr_units = 1,                                               \
                                  it.ptr_units = 2 ),                                             \
        (S)->data )                                                                               \
    };                                                                                            \
    it.idx_codes < it.finish_exclusive;                                                           \
    ++it.idx_codes, it.idx_units += it.ptr_units, it.ptr += it.ptr_units,                         \
    MARY_String_16_Decode( it.ptr, it.code,                                                       \
                              it.ptr_units = 1,                                                   \
                              it.ptr_units = 2 )                                                  \
  )

#define MARY_String_32_Each(S)                                                         \
  for                                                                                  \
  (                                                                                    \
    struct { u64 idx_codes, idx_units, finish_exclusive, finish; u32 *ptr; u32 code; } \
    it =                                                                               \
    {                                                                                  \
      ( MARY_Assert(Mary_String_Get_Format(S) == MARY_STRING_32),                      \
        0 ), 0, (S)->codes, (S)->codes - 1, (S)->data, *(u32 *)(S)->data               \
    };                                                                                 \
    it.idx_codes < it.finish_exclusive;                                                \
    ++it.idx_codes, ++it.idx_units, ++it.ptr, it.code = *it.ptr                        \
  )

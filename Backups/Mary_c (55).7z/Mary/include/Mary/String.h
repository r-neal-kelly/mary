#pragma once

#include <Mary/Vector.h>

typedef struct
{
  MARY_Vector_t;
  size_t codes;
}
Mary_String_t;

void Mary_String_Create(Mary_String_t *mary_string, char bit_format, void *string, size_t opt_units);
void Mary_String_Create_With_Data(Mary_String_t *mary_string, char bit_format, Mary_p mary_ptr);
void Mary_String_8bit_Create_With_Data(Mary_String_t *mary_string, Mary_p mary_ptr);
void Mary_String_16bit_Create_With_Data(Mary_String_t *mary_string, Mary_p mary_ptr);
void Mary_String_32bit_Create_With_Data(Mary_String_t *mary_string, Mary_p mary_ptr);
void Mary_String_Destroy(Mary_String_t *mary_string);
size_t Mary_String_Count_Bytes(char bit_format, void *string, char want_null);
size_t Mary_String_Count_Codes(Mary_String_t *mary_string);
void Mary_String_Edit(Mary_String_t *mary_string, void *string);
void Mary_String_Format(Mary_String_t *mary_string, char bit_format);
char Mary_String_Get_Format(Mary_String_t *mary_string);
void Mary_String_8bit_to_16bit(Mary_String_t *s_8bit);
void Mary_String_8bit_to_32bit(Mary_String_t *s_8bit);
void Mary_String_16bit_to_8bit(Mary_String_t *s_16bit);
void Mary_String_16bit_to_32bit(Mary_String_t *s_16bit);
void Mary_String_32bit_to_8bit(Mary_String_t *s_32bit);
void Mary_String_32bit_to_16bit(Mary_String_t *s_32bit);

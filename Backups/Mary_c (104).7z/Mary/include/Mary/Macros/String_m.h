#pragma once

#include <Mary/String.h>

#undef MARY_String_Static
#undef MARY_String_Stack
#undef MARY_String_Heap
#undef MARY_String_Pool
#undef MARY_String_Frame
#undef MARY_String_Chain
#undef MARY_String_Heap_p
#undef MARY_String_Pool_p
#undef MARY_String_Frame_p
#undef MARY_String_Chain_p
#undef MARY_String_Get_UTF
#undef MARY_String_Point_Front
#undef MARY_String_Point_Back
#undef MARY_String_Point_End
#undef MARY_String_Assign
#undef MARY_String_Append_Front
#undef MARY_String_Append_Back
#undef MARY_String_Each_8
#undef MARY_String_Each_16
#undef MARY_String_Each_32

////// Creation //////

#define MARY_String_Static(NAME, UTF, C_STR)\
    Mary_String_t NAME; Mary_String_Create_With(&NAME, C_STR, 0, MARY_Allocator_Static, UTF)

#define MARY_String_Stack(NAME, UTF, C_STR)\
    Mary_String_t NAME; uint##UTF##_t NAME##_stack[] = C_STR;\
    Mary_String_Create_With(&NAME, NAME##_stack, 0, MARY_Allocator_Stack, UTF)

#define MARY_String_Heap(NAME, UTF, C_STR)\
    Mary_String_t NAME; Mary_String_Create_From(&NAME, MARY_Allocator_Heap, UTF, C_STR, UTF)

#define MARY_String_Pool(NAME, POOL, UTF, C_STR)\
    Mary_String_t NAME; Mary_String_Create_From(&NAME, MARY_Allocator_Pool((POOL)->id), UTF, C_STR, UTF)

#define MARY_String_Frame(NAME, UTF, C_STR)\
    Mary_String_t NAME; Mary_String_Create_From(&NAME, MARY_Allocator_Frame, UTF, C_STR, UTF)

#define MARY_String_Chain(NAME, UTF, C_STR)\
    Mary_String_t NAME; Mary_String_Create_From(&NAME, MARY_Allocator_Chain, UTF, C_STR, UTF)

#define MARY_String_Heap_p(THIS, UTF, C_STR)\
    Mary_String_Create_From(THIS, MARY_Allocator_Heap, UTF, C_STR, UTF)

#define MARY_String_Pool_p(THIS, POOL, UTF, C_STR)\
    Mary_String_Create_From(THIS, MARY_Allocator_Pool((POOL)->id), UTF, C_STR, UTF)

#define MARY_String_Frame_p(THIS, UTF, C_STR)\
    Mary_String_Create_From(THIS, MARY_Allocator_Frame, UTF, C_STR, UTF)

#define MARY_String_Chain_p(THIS, UTF, C_STR)\
    Mary_String_Create_From(THIS, MARY_Allocator_Chain, UTF, C_STR, UTF)

////// Accessing //////

#define MARY_String_Get_UTF(THIS)\
    MARY_Unit_To_UTF((THIS)->unit)

#define MARY_String_Point_Front(THIS)\
    MARY_Vector_Point_Front(THIS)

#define MARY_String_Point_Back(THIS)\
    MARY_Vector_Point_Back(THIS)

#define MARY_String_Point_End(THIS)\
    MARY_Vector_Point_End(THIS)

////// Altering //////

#define MARY_String_Assign(THIS, UTF, C_STR)    \
MARY_M                                          \
    MARY_String_Static(static_str, UTF, C_STR); \
    Mary_String_Assign(THIS, &static_str);      \
MARY_W

#define MARY_String_Append_Front(THIS, UTF, C_STR) \
MARY_M                                             \
    MARY_String_Static(static_str, UTF, C_STR);    \
    Mary_String_Append_Front(THIS, &static_str);   \
MARY_W

#define MARY_String_Append_Back(THIS, UTF, C_STR) \
MARY_M                                            \
    MARY_String_Static(static_str, UTF, C_STR);   \
    Mary_String_Append_Back(THIS, &static_str);   \
MARY_W

////// Loops //////

#define MARY_String_Each(THIS)                          \
for (                                                   \
    struct {                                            \
        Mary_String_t *this;                            \
        Mary_Index_t code_idx;                          \
        Mary_Index_t unit_idx;                          \
        Mary_Size_t idx_units;                          \
        Mary_Void_t *ptr;                               \
        Mary_Char_8_t *ptr_8;                           \
        Mary_Char_16_t *ptr_16;                         \
        Mary_Char_32_t *ptr_32;                         \
        Mary_UTF_t utf;                                 \
        Mary_UTF_8_t utf_8;                             \
        Mary_UTF_16_t utf_16;                           \
        Mary_UTF_32_t utf_32;                           \
        Mary_Char_32_t char_32;                         \
    } it = {                                            \
        (                                               \
            MARY_Assert((THIS)->data != 0 &&            \
                        (THIS)->codes > 0,              \
                        "String is uncreated."),        \
            THIS                                        \
        ),                                              \
        0,                                              \
        0,                                              \
        0,                                              \
        it.this->data,                                  \
        it.ptr,                                         \
        it.ptr,                                         \
        it.ptr,                                         \
        MARY_String_Get_UTF(it.this),                   \
        { 0, 0, 0, 0, 0, 0 },                           \
        { 0, 0, 0, 0 },                                 \
        { 0, 0 },                                       \
        (it.utf == 8) ? (                               \
            Mary_UTF_Decode_8(&it.utf_8, it.ptr_8),     \
            it.idx_units = it.utf_8.units,              \
            it.utf_8.char_32                            \
        ) : (it.utf == 16) ? (                          \
            Mary_UTF_Decode_16(&it.utf_16, it.ptr_16),  \
            it.idx_units = it.utf_16.units,             \
            it.utf_16.char_32                           \
        ) : (                                           \
            MARY_UTF_Decode_32(it.utf_32, it.ptr_32),   \
            it.idx_units = it.utf_32.units,             \
            it.utf_32.char_32                           \
        )                                               \
    };                                                  \
    it.code_idx < it.this->codes;                       \
    (                                                   \
        ++it.code_idx,                                  \
        (it.utf == 8) ? (                               \
            it.unit_idx += it.utf_8.units,              \
            it.ptr_8 += it.utf_8.units,                 \
            MARY_UTF_Decode_8(it.utf_8, it.ptr_8),      \
            it.idx_units = it.utf_8.units,              \
            it.ptr = it.ptr_8,                          \
            it.char_32 = it.utf_8.char_32               \
        ) : (it.utf == 16) ? (                          \
            it.unit_idx += it.utf_16.units,             \
            it.ptr_16 += it.utf_16.units,               \
            MARY_UTF_Decode_16(it.utf_16, it.ptr_16),   \
            it.idx_units = it.utf_16.units,             \
            it.ptr = it.ptr_16,                         \
            it.char_32 = it.utf_16.char_32              \
        ) : (                                           \
            it.unit_idx += it.utf_32.units,             \
            it.ptr_32 += it.utf_32.units,               \
            MARY_UTF_Decode_32(it.utf_32, it.ptr_32),   \
            it.idx_units = it.utf_32.units,             \
            it.ptr = it.ptr_32,                         \
            it.char_32 = it.utf_32.char_32              \
        )                                               \
    )                                                   \
)

#define MARY_String_Each_Reverse(THIS)                          \
for (                                                           \
    struct {                                                    \
        Mary_String_t *this;                                    \
        Mary_Index_t code_idx;                                  \
        Mary_Index_t unit_idx;                                  \
        Mary_Size_t idx_units;                                  \
        Mary_Void_t *ptr;                                       \
        Mary_Char_8_t *ptr_8;                                   \
        Mary_Char_16_t *ptr_16;                                 \
        Mary_Char_32_t *ptr_32;                                 \
        Mary_UTF_t utf;                                         \
        Mary_UTF_8_t utf_8;                                     \
        Mary_UTF_16_t utf_16;                                   \
        Mary_UTF_32_t utf_32;                                   \
        Mary_Char_32_t char_32;                                 \
    } it = {                                                    \
        (                                                       \
            MARY_Assert((THIS)->data != 0 &&                    \
                        (THIS)->codes > 0,                      \
                        "String is uncreated."),                \
            THIS                                                \
        ),                                                      \
        it.this->codes - 1,                                     \
        it.this->units - 1,                                     \
        0,                                                      \
        MARY_String_Point_End(it.this),                         \
        it.ptr,                                                 \
        it.ptr,                                                 \
        it.ptr,                                                 \
        MARY_String_Get_UTF(it.this),                           \
        { 0, 0, 0, 0, 0, 0 },                                   \
        { 0, 0, 0, 0 },                                         \
        { 0, 0 },                                               \
        (it.utf == 8) ? (                                       \
            Mary_UTF_Decode_8_Reverse(&it.utf_8, it.ptr_8),     \
            it.idx_units = it.utf_8.units,                      \
            it.ptr = it.ptr_8 - it.idx_units,                   \
            it.utf_8.char_32                                    \
        ) : (it.utf == 16) ? (                                  \
            Mary_UTF_Decode_16_Reverse(&it.utf_16, it.ptr_16),  \
            it.idx_units = it.utf_16.units,                     \
            it.ptr = it.ptr_16 - it.idx_units,                  \
            it.utf_16.char_32                                   \
        ) : (                                                   \
            MARY_UTF_Decode_32_Reverse(it.utf_32, it.ptr_32),   \
            it.idx_units = it.utf_32.units,                     \
            it.ptr = it.ptr_32 - it.idx_units,                  \
            it.utf_32.char_32                                   \
        )                                                       \
    };                                                          \
    it.code_idx + 1 > 0;                                        \
    (it.code_idx != 0) ? (                                      \
        --it.code_idx,                                          \
        (it.utf == 8) ? (                                       \
            it.unit_idx -= it.utf_8.units,                      \
            it.ptr_8 -= it.utf_8.units,                         \
            MARY_UTF_Decode_8_Reverse(it.utf_8, it.ptr_8),      \
            it.idx_units = it.utf_8.units,                      \
            it.ptr = it.ptr_8 - it.idx_units,                   \
            it.char_32 = it.utf_8.char_32                       \
        ) : (it.utf == 16) ? (                                  \
            it.unit_idx -= it.utf_16.units,                     \
            it.ptr_16 -= it.utf_16.units,                       \
            MARY_UTF_Decode_16_Reverse(it.utf_16, it.ptr_16),   \
            it.idx_units = it.utf_16.units,                     \
            it.ptr = it.ptr_16 - it.idx_units,                  \
            it.char_32 = it.utf_16.char_32                      \
        ) : (                                                   \
            it.unit_idx -= it.utf_32.units,                     \
            it.ptr_32 -= it.utf_32.units,                       \
            MARY_UTF_Decode_32_Reverse(it.utf_32, it.ptr_32),   \
            it.idx_units = it.utf_32.units,                     \
            it.ptr = it.ptr_32 - it.idx_units,                  \
            it.char_32 = it.utf_32.char_32                      \
        )                                                       \
    ) : (                                                       \
        --it.code_idx,                                          \
        it.char_32                                              \
    )                                                           \
)

#define MARY_String_Each_8(THIS)                \
for (                                           \
    struct {                                    \
        Mary_String_t *this;                    \
        Mary_Index_t code_idx;                  \
        Mary_Index_t unit_idx;                  \
        Mary_Char_8_t *ptr;                     \
        Mary_UTF_8_t utf_8;                     \
    } it = {                                    \
        THIS,                                   \
        0,                                      \
        0,                                      \
        it.this->data,                          \
        MARY_UTF_Decode_8(it.utf_8, it.ptr)     \
    };                                          \
    it.code_idx < it.this->codes;               \
    (                                           \
        ++it.code_idx,                          \
        it.unit_idx += it.utf_8.units,          \
        it.ptr += it.utf_8.units,               \
        MARY_UTF_Decode_8(it.utf_8, it.ptr)     \
    )                                           \
)

#define MARY_String_Each_8_Reverse(THIS)                    \
for (                                                       \
    struct {                                                \
        Mary_String_t *this;                                \
        Mary_Index_t code_idx;                              \
        Mary_Index_t unit_idx;                              \
        Mary_Char_8_t *ptr;                                 \
        Mary_UTF_8_t utf_8;                                 \
    } it = {                                                \
        THIS,                                               \
        it.this->codes - 1,                                 \
        it.this->units - 1,                                 \
        MARY_String_Point_End(it.this),                     \
        (                                                   \
            MARY_UTF_Decode_16_Reverse(it.utf_8, it.ptr),   \
            it.ptr -= it.utf_8.units,                       \
            it.utf_8                                        \
        )                                                   \
    };                                                      \
    it.code_idx + 1 > 0;                                    \
    (it.code_idx != 0) ? (                                  \
        --it.code_idx,                                      \
        it.unit_idx -= it.utf_8.units,                      \
        MARY_UTF_Decode_8_Reverse(it.utf_8, it.ptr),        \
        it.ptr -= it.utf_8.units                            \
    ) : (                                                   \
        --it.code_idx,                                      \
        0                                                   \
    )                                                       \
)

#define MARY_String_Each_16(THIS)               \
for (                                           \
    struct {                                    \
        Mary_String_t *this;                    \
        Mary_Index_t code_idx;                  \
        Mary_Index_t unit_idx;                  \
        Mary_Char_16_t *ptr;                    \
        Mary_UTF_16_t utf_16;                   \
    } it = {                                    \
        THIS,                                   \
        0,                                      \
        0,                                      \
        it.this->data,                          \
        MARY_UTF_Decode_16(it.utf_16, it.ptr)   \
    };                                          \
    it.code_idx < it.this->codes;               \
    (                                           \
        ++it.code_idx,                          \
        it.unit_idx += it.utf_16.units,         \
        it.ptr += it.utf_16.units,              \
        MARY_UTF_Decode_16(it.utf_16, it.ptr)   \
    )                                           \
)

#define MARY_String_Each_16_Reverse(THIS)                   \
for (                                                       \
    struct {                                                \
        Mary_String_t *this;                                \
        Mary_Index_t code_idx;                              \
        Mary_Index_t unit_idx;                              \
        Mary_Char_16_t *ptr;                                \
        Mary_UTF_16_t utf_16;                               \
    } it = {                                                \
        THIS,                                               \
        it.this->codes - 1,                                 \
        it.this->units - 1,                                 \
        MARY_String_Point_End(it.this),                     \
        (                                                   \
            MARY_UTF_Decode_16_Reverse(it.utf_16, it.ptr),  \
            it.ptr -= it.utf_16.units,                      \
            it.utf_16                                       \
        )                                                   \
    };                                                      \
    it.code_idx + 1 > 0;                                    \
    (it.code_idx != 0) ? (                                  \
        --it.code_idx,                                      \
        it.unit_idx -= it.utf_16.units,                     \
        MARY_UTF_Decode_16_Reverse(it.utf_16, it.ptr),      \
        it.ptr -= it.utf_16.units                           \
    ) : (                                                   \
        --it.code_idx,                                      \
        0                                                   \
    )                                                       \
)

#define MARY_String_Each_32(THIS)               \
for (                                           \
    struct {                                    \
        Mary_String_t *this;                    \
        Mary_Index_t code_idx;                  \
        Mary_Index_t unit_idx;                  \
        Mary_Char_32_t *ptr;                    \
        Mary_UTF_32_t utf_32;                   \
    } it = {                                    \
        THIS,                                   \
        0,                                      \
        0,                                      \
        it.this->data,                          \
        MARY_UTF_Decode_32(it.utf_32, it.ptr)   \
    };                                          \
    it.code_idx < it.this->codes;               \
    (                                           \
        ++it.code_idx,                          \
        it.unit_idx += it.utf_32.units,         \
        it.ptr += it.utf_32.units,              \
        MARY_UTF_Decode_32(it.utf_32, it.ptr)   \
    )                                           \
)

#define MARY_String_Each_32_Reverse(THIS)                   \
for (                                                       \
    struct {                                                \
        Mary_String_t *this;                                \
        Mary_Index_t code_idx;                              \
        Mary_Index_t unit_idx;                              \
        Mary_Char_32_t *ptr;                                \
        Mary_UTF_16_t utf_32;                               \
    } it = {                                                \
        THIS,                                               \
        it.this->codes - 1,                                 \
        it.this->units - 1,                                 \
        MARY_String_Point_End(it.this),                     \
        (                                                   \
            MARY_UTF_Decode_32_Reverse(it.utf_32, it.ptr),  \
            it.ptr -= it.utf_32.units,                      \
            it.utf_32                                       \
        )                                                   \
    };                                                      \
    it.code_idx + 1 > 0;                                    \
    (it.code_idx != 0) ? (                                  \
        --it.code_idx,                                      \
        it.unit_idx -= it.utf_32.units,                     \
        MARY_UTF_Decode_32_Reverse(it.utf_32, it.ptr),      \
        it.ptr -= it.utf_32.units                           \
    ) : (                                                   \
        --it.code_idx,                                      \
        0                                                   \
    )                                                       \
)

////// Program //////

#define MARY_String_Program(THIS, MACRO)                \
MARY_M                                                  \
    Mary_UTF_t this_utf = MARY_String_Get_UTF(THIS);    \
    if (this_utf == 8) {                                \
        Mary_Char_8_t *this_data = (THIS)->data;        \
        MACRO(Mary_Char_8_t,                            \
             Mary_UTF_8_t,                              \
             MARY_UTF_Encode_8,                         \
             MARY_UTF_Decode_8,                         \
             MARY_UTF_Decode_8_Reverse,                 \
             MARY_String_Each_8,                        \
             MARY_String_Each_8_Reverse,                \
             it.utf_8);                                 \
    } else if (this_utf == 16) {                        \
        Mary_Char_16_t *this_data = (THIS)->data;       \
        MACRO(Mary_Char_16_t,                           \
             Mary_UTF_16_t,                             \
             MARY_UTF_Encode_16,                        \
             MARY_UTF_Decode_16,                        \
             MARY_UTF_Decode_16_Reverse,                \
             MARY_String_Each_16,                       \
             MARY_String_Each_16_Reverse,               \
             it.utf_16);                                \
    } else {                                            \
        Mary_Char_32_t *this_data = (THIS)->data;       \
        MACRO(Mary_Char_32_t,                           \
             Mary_UTF_32_t,                             \
             MARY_UTF_Encode_32,                        \
             MARY_UTF_Decode_32,                        \
             MARY_UTF_Decode_32_Reverse,                \
             MARY_String_Each_32,                       \
             MARY_String_Each_32_Reverse,               \
             it.utf_32);                                \
    }                                                   \
MARY_W

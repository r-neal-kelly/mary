#include <stdio.h>
#include <Mary/Utils.h>
#include <Mary/Pool.h>
#include <Mary/Regex.h>

// pretty sure that Mary_Pool_t is going to play a huge role in this
// to make mallocing automatons extremely fast. but should it be global or not?

MARY_PRIMITIVES;

void Mary_Regex_Create(Mary_Regex_t *mary_regex, Mary_String_t *expression)
{
  // should we just get a void * for string and utf type?
}

void Mary_Regex_Destroy(Mary_Regex_t *mary_regex)
{

}

void Mary_Regex_Compile(Mary_Regex_t *mary_regex)
{

}

void Mary_Regex_Match()
{

}

void Mary_Regex_To_Postfix(Mary_String_t *regex)
{
  MARY_Assert(regex->size <= 64);
  // can put the three following into a pool type eventually.
  Mary_Vector_t v_stack; u8 a_stack[64];
  Mary_Vector_Create_With(&v_stack, 1, a_stack, 64);
  Mary_Vector_t v_input; u8 a_input[64];
  Mary_Vector_Create_With(&v_input, 1, a_input, 64);
  Mary_Vector_t v_output; u8 a_output[64];
  Mary_Vector_Create_With(&v_output, 1, a_output, 64);
  u8 concat_symbol = '&', top;
  MARY_Range(regex->data, u8, 0, regex->size)
  {
    Mary_Vector_Push_Back(&v_input, range.ptr);
    if (range.val != '(' && range.val != '|' && range.val != '\0')
    {
      u8 next = *(range.ptr + 1);
      if (next != '*' && next != ')' && next != '|' && next != '\0')
      {
        Mary_Vector_Push_Back(&v_input, &concat_symbol);
      }
    }
  }
  MARY_Range(v_input.data, u8, 0, v_input.size)
  {
    // this is ascii only at the moment
    // precedence 1: *, (); 2: &; 3: |; is parens right? prob not.
    // it may be because * is a unary.
    if (range.val == 0)
    {
      while (v_stack.size)
      {
        Mary_Vector_Pop_Back(&v_stack, &top);
        Mary_Vector_Push_Back(&v_output, &top);
      }
      break;
    }
    else if (range.val == '|')
    {
      if (v_stack.size)
      {
        Mary_Vector_At(&v_stack, v_stack.size - 1, &top);
        if (top == '*' || top == '&' || top == '|')
        {
          Mary_Vector_Pop_Back(&v_stack, &top);
          Mary_Vector_Push_Back(&v_output, &top);
        }
      }
      Mary_Vector_Push_Back(&v_stack, &range.val);
    }
    else if (range.val == '&')
    {
      if (v_stack.size)
      {
        Mary_Vector_At(&v_stack, v_stack.size - 1, &top);
        if (top == '*' || top == '&')
        {
          Mary_Vector_Pop_Back(&v_stack, &top);
          Mary_Vector_Push_Back(&v_output, &top);
        }
      }
      top = '&'; Mary_Vector_Push_Back(&v_stack, &top);
    }
    else if (range.val == '*')
    {
      if (v_stack.size)
      {
        Mary_Vector_At(&v_stack, v_stack.size - 1, &top);
        if (top == '*')
        {
          Mary_Vector_Pop_Back(&v_stack, &top);
          Mary_Vector_Push_Back(&v_output, &top);
        }
      }
      Mary_Vector_Push_Back(&v_stack, &range.val);
    }
    else if (range.val == '(')
    {
      if (v_stack.size)
      {
        Mary_Vector_At(&v_stack, v_stack.size - 1, &top);
        if (top == '*')
        {
          Mary_Vector_Pop_Back(&v_stack, &top);
          Mary_Vector_Push_Back(&v_output, &top);
        }
      }
      Mary_Vector_Push_Back(&v_stack, &range.val);
    }
    else if (range.val == ')')
    {
      Mary_Vector_Pop_Back(&v_stack, &top);
      while (top != '(')
      {
        Mary_Vector_Push_Back(&v_output, &top);
        Mary_Vector_Pop_Back(&v_stack, &top);
      }
    }
    else
    {
      Mary_Vector_Push_Back(&v_output, &range.val);
    }
    printf("%c", range.val);
  } puts("");
  MARY_Range(v_output.data, u8, 0, v_output.size)
  {
    printf("%c", range.val);
  }
}

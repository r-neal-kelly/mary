#pragma once

#include <stdint.h>
#include <Mary/String.h>

// when parsing a regex string, you build up automatons for
// the simplest parts and combine them together into more complex
// machines. You then run a search string through the final machine
// and it should return results. shouldn't be TOO hard, but a new challenge!

// just some idea, obviously not final.
typedef struct
{
  Mary_String_t string;
  uint8_t matched;
  void *results;
}
Mary_Regex_t;

void Mary_Regex_Create(Mary_Regex_t *mary_regex, Mary_String_t *expression);
void Mary_Regex_Destroy(Mary_Regex_t *mary_regex);
void Mary_Regex_To_Postfix(Mary_String_t *regex); // need to update proto
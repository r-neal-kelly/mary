#include <stdio.h>
#include <Mary/Vector.h>
#include <Mary/Hashmap.h>
#include <Mary/GL_Texture.h>

MARY_Primitives;
MARY_Allocator_Enum;

typedef struct
{
  GLuint slot;
  GLenum target;
}
Location;

typedef struct
{
  Mary_Vector_t *free, *used;
}
Slots;

Mary_Vector_t
  free_1d, free_2d, free_3d, free_1d_a, free_2d_a, free_rect, free_cube, free_buffer, free_2d_m, free_2d_ma,
  used_1d, used_2d, used_3d, used_1d_a, used_2d_a, used_rect, used_cube, used_buffer, used_2d_m, used_2d_ma;
Mary_Hashmap_t
  targets_to_slots, locations_to_textures;

static void Mary_GL_Texture_Slot(Mary_GL_Texture_t *texture);
static void Mary_GL_Texture_Unslot(Mary_GL_Texture_t *texture);

void Mary_GL_Texture_Start()
{
  // should prob. put all these vectors on a pool to make sure they are near each other.
  GLuint max_slots = MARY_GL_MAX_TEXTURES;
  Mary_Vector_Create(&free_1d, HEAP, sizeof(GLuint), max_slots);
  Mary_Vector_Create(&free_2d, HEAP, sizeof(GLuint), max_slots);
  Mary_Vector_Create(&free_3d, HEAP, sizeof(GLuint), max_slots);
  Mary_Vector_Create(&free_1d_a, HEAP, sizeof(GLuint), max_slots);
  Mary_Vector_Create(&free_2d_a, HEAP, sizeof(GLuint), max_slots);
  Mary_Vector_Create(&free_rect, HEAP, sizeof(GLuint), max_slots);
  Mary_Vector_Create(&free_cube, HEAP, sizeof(GLuint), max_slots);
  Mary_Vector_Create(&free_buffer, HEAP, sizeof(GLuint), max_slots);
  Mary_Vector_Create(&free_2d_m, HEAP, sizeof(GLuint), max_slots);
  Mary_Vector_Create(&free_2d_ma, HEAP, sizeof(GLuint), max_slots);
  for (GLuint i = 0; i < max_slots; ++i)
  {
    Mary_Vector_Push_Back(&free_1d, &i);
    Mary_Vector_Push_Back(&free_2d, &i);
    Mary_Vector_Push_Back(&free_3d, &i);
    Mary_Vector_Push_Back(&free_1d_a, &i);
    Mary_Vector_Push_Back(&free_2d_a, &i);
    Mary_Vector_Push_Back(&free_rect, &i);
    Mary_Vector_Push_Back(&free_cube, &i);
    Mary_Vector_Push_Back(&free_buffer, &i);
    Mary_Vector_Push_Back(&free_2d_m, &i);
    Mary_Vector_Push_Back(&free_2d_ma, &i);
  }

  Mary_Vector_Create(&used_1d, HEAP, sizeof(GLuint), max_slots);
  Mary_Vector_Create(&used_2d, HEAP, sizeof(GLuint), max_slots);
  Mary_Vector_Create(&used_3d, HEAP, sizeof(GLuint), max_slots);
  Mary_Vector_Create(&used_1d_a, HEAP, sizeof(GLuint), max_slots);
  Mary_Vector_Create(&used_2d_a, HEAP, sizeof(GLuint), max_slots);
  Mary_Vector_Create(&used_rect, HEAP, sizeof(GLuint), max_slots);
  Mary_Vector_Create(&used_cube, HEAP, sizeof(GLuint), max_slots);
  Mary_Vector_Create(&used_buffer, HEAP, sizeof(GLuint), max_slots);
  Mary_Vector_Create(&used_2d_m, HEAP, sizeof(GLuint), max_slots);
  Mary_Vector_Create(&used_2d_ma, HEAP, sizeof(GLuint), max_slots);

  GLenum target; Slots slots;
  Mary_Hashmap_Create(&targets_to_slots, sizeof(GLenum), sizeof(Slots));
  target = GL_TEXTURE_1D, slots = (Slots) { &free_1d, &used_1d }, 
    Mary_Hashmap_Assign(&targets_to_slots, &target, &slots);
  target = GL_TEXTURE_2D, slots = (Slots) { &free_2d, &used_2d },
    Mary_Hashmap_Assign(&targets_to_slots, &target, &slots);
  target = GL_TEXTURE_3D, slots = (Slots) { &free_3d, &used_3d },
    Mary_Hashmap_Assign(&targets_to_slots, &target, &slots);
  target = GL_TEXTURE_1D_ARRAY, slots = (Slots) { &free_1d_a, &used_1d_a },
    Mary_Hashmap_Assign(&targets_to_slots, &target, &slots);
  target = GL_TEXTURE_2D_ARRAY, slots = (Slots) { &free_2d_a, &used_2d_a },
    Mary_Hashmap_Assign(&targets_to_slots, &target, &slots);
  target = GL_TEXTURE_RECTANGLE, slots = (Slots) { &free_rect, &used_rect },
    Mary_Hashmap_Assign(&targets_to_slots, &target, &slots);
  target = GL_TEXTURE_CUBE_MAP, slots = (Slots) { &free_cube, &used_cube },
    Mary_Hashmap_Assign(&targets_to_slots, &target, &slots);
  target = GL_TEXTURE_BUFFER, slots = (Slots) { &free_buffer, &used_buffer },
    Mary_Hashmap_Assign(&targets_to_slots, &target, &slots);
  target = GL_TEXTURE_2D_MULTISAMPLE, slots = (Slots) { &free_2d_m, &used_2d_m },
    Mary_Hashmap_Assign(&targets_to_slots, &target, &slots);
  target = GL_TEXTURE_2D_MULTISAMPLE_ARRAY, slots = (Slots) { &free_2d_ma, &used_2d_ma },
    Mary_Hashmap_Assign(&targets_to_slots, &target, &slots);

  Mary_Hashmap_Create(&locations_to_textures, sizeof(Location), sizeof(Mary_GL_Texture_t *));
}

void Mary_GL_Texture_Finish()
{
  Mary_Vector_Destroy(&free_1d);
  Mary_Vector_Destroy(&free_2d);
  Mary_Vector_Destroy(&free_3d);
  Mary_Vector_Destroy(&used_1d);
  Mary_Vector_Destroy(&used_2d);
  Mary_Vector_Destroy(&used_3d);
  Mary_Hashmap_Destroy(&locations_to_textures);
  Mary_Hashmap_Destroy(&targets_to_slots);
}

void Mary_GL_Texture_Create(Mary_GL_Texture_t *texture, GLenum target)
{
  texture->target = target;
  texture->slot = -1;
  glGenTextures(1, &texture->id);
  Mary_GL_Texture_Slot(texture);
  glActiveTexture(GL_TEXTURE0 + texture->slot);
  glBindTexture(texture->target, texture->id);
}

void Mary_GL_Texture_Destroy(Mary_GL_Texture_t *texture)
{
  if (texture->slot != -1)
  {
    Mary_GL_Texture_Unslot(texture);
  }
  glDeleteTextures(1, &texture->id);
  texture->id = 0;
}

void Mary_GL_Texture_Activate(Mary_GL_Texture_t *texture)
{
  if (texture->slot == -1)
  {
    Mary_GL_Texture_Slot(texture);
    glActiveTexture(GL_TEXTURE0 + texture->slot);
    glBindTexture(texture->target, texture->id);
  }
  else
  {
    glActiveTexture(GL_TEXTURE0 + texture->slot);
  }
}

static void Mary_GL_Texture_Slot(Mary_GL_Texture_t *texture)
{
  Slots slots; Mary_Hashmap_At(&targets_to_slots, &texture->target, &slots);
  if (slots.free->units == 0)
  {
    GLuint used_slot; Mary_Vector_Pop_Front(slots.used, &used_slot);
    Location loc = { used_slot, texture->target };
    Mary_GL_Texture_t *old_texture;
    Mary_Hashmap_At(&locations_to_textures, &loc, &old_texture);
    old_texture->slot = -1;
    Mary_Vector_Push_Back(slots.used, &used_slot);
    Mary_Hashmap_Assign(&locations_to_textures, &loc, &texture);
    texture->slot = used_slot;
  }
  else
  {
    GLuint free_slot; Mary_Vector_Pop_Back(slots.free, &free_slot);
    Location loc = { free_slot, texture->target };
    Mary_Vector_Push_Back(slots.used, &free_slot);
    Mary_Hashmap_Assign(&locations_to_textures, &loc, &texture);
    texture->slot = free_slot;
  }
}

static void Mary_GL_Texture_Unslot(Mary_GL_Texture_t *texture)
{
  Slots slots; Mary_Hashmap_At(&targets_to_slots, &texture->target, &slots);
  GLuint slot = texture->slot;
  Mary_Vector_Erase(slots.used, &slot);
  Mary_Vector_Push_Back(slots.free, &slot);
  Location loc = { slot, texture->target };
  Mary_Hashmap_Erase(&locations_to_textures, &loc);
  texture->slot = -1;
}

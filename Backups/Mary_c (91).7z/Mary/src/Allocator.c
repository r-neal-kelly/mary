#include <stdlib.h>
#include <Mary/Allocator.h>
#include <Mary/Pool.h>
#include <Mary/Arena.h>

MARY_Primitives;
MARY_Allocators;

const Mary_Pool_t *MARY_ALLOCATOR_POOLS;

void *Mary_Allocator_Alloc(Mary_Allocator_t allocator, Mary_Size_t bytes)
{
  if (allocator == FRAME || allocator == CHAIN || allocator == ERROR)
  {
    return Mary_Arena_Alloc(allocator, bytes);
  }
  else if (allocator < STACK)
  {
    return Mary_Pool_Alloc(&((Mary_Pool_t *)MARY_ALLOCATOR_POOLS)[allocator], bytes);
  }
  else if (allocator == MARY_HEAP)
  {
    return Mary_Alloc(bytes);
  }
  else if (allocator == MARY_STACK)
  {
    MARY_Assert(0, "Cannot alloc on the stack."); return 0;
  }
  else
  {
    MARY_Assert(0, "Invalid alloc."); return 0;
  }
}

void *Mary_Allocator_Calloc(Mary_Allocator_t allocator, Mary_Size_t unit, Mary_Size_t units)
{
  if (allocator == FRAME || allocator == CHAIN || allocator == ERROR)
  {
    //return Mary_Arena_Calloc(allocator, unit, units);
    return 0;
  }
  else if (allocator < STACK)
  {
    //return Mary_Pool_Calloc(&((Mary_Pool_t *)MARY_ALLOCATOR_POOLS)[allocator], unit, units);
    return 0;
  }
  else if (allocator == MARY_HEAP)
  {
    return Mary_Calloc(unit, units);
  }
  else if (allocator == MARY_STACK)
  {
    MARY_Assert(0, "Cannot calloc on the stack."); return 0;
  }
  else
  {
    MARY_Assert(0, "Invalid calloc."); return 0;
  }
}

void *Mary_Allocator_Realloc(Mary_Allocator_t allocator, void *data, Mary_Size_t bytes)
{
  // eventually what I would like is some way to tell the user when the realloc failed
  // other than returning 0. Because I do not want to lose the original pointer, and
  // it will give the caller the chance to free some memory. so, if it does fail,
  // it simply returns the same pointer and an error by other means.

  // in vector Reserve, Fit, and Grow, we are not even checking the data ptr. we want to check
  // for an error separately! We can use the arena system in this function in particular
  // because it is not meant to be used by anyone but the library.

  // also, instead of the exception like system, we could also send a union instead,
  // which would be more like the option system, it either is something or isn't. either
  // would probably be okay...

  if (allocator == FRAME || allocator == CHAIN || allocator == ERROR)
  {
    //return Mary_Arena_Realloc(allocator, data, bytes);
    return 0;
  }
  else if (allocator < STACK)
  {
    return Mary_Pool_Realloc(&((Mary_Pool_t *)MARY_ALLOCATOR_POOLS)[allocator], data, bytes);
  }
  else if (allocator == MARY_HEAP)
  {
    return Mary_Realloc(data, bytes);
  }
  else if (allocator == MARY_STACK)
  {
    MARY_Assert(0, "Cannot realloc on the stack."); return 0;
  }
  else
  {
    MARY_Assert(0, "Invalid realloc."); return 0;
  }
}

void Mary_Allocator_Dealloc(Mary_Allocator_t allocator, void *data)
{
  if (allocator == FRAME || allocator == CHAIN || allocator == ERROR)
  {
    Mary_Arena_Dealloc(allocator, data);
  }
  else if (allocator < STACK)
  {
    Mary_Pool_Dealloc(&((Mary_Pool_t *)MARY_ALLOCATOR_POOLS)[allocator], data);
  }
  else if (allocator == MARY_HEAP)
  {
    Mary_Dealloc(data);
  }
  else if (allocator == MARY_STACK)
  {
    MARY_Assert(0, "Cannot dealloc on the stack.");
  }
  else
  {
    MARY_Assert(0, "Invalid dealloc.");
  }
}

#ifdef MARY_Debug
void Mary_Allocator_Validate(Mary_Allocator_t allocator, char *func_name)
{
  if (allocator == FRAME || allocator == CHAIN || allocator == ERROR)
  {
    Mary_Arena_Validate_Frame(func_name);
  }
}
#endif

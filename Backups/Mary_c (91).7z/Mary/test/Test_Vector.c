#include <stdio.h>
#include <Mary/Utils.h>
#include <Mary/Vector.h>
#include <Mary/Arena.h>
#include <Mary/Test/Test.h>
#include <Mary/Test/Test_Vector.h> // maybe we won't need separate headers for each type, if we just wrap all sub funcs in one func that is declared in Test.h, eg.g Test_Vector()
#include MARY_Vector_Namespace

MARY_Primitives;
MARY_Allocators;

void Test_Vector()
{
  Test_Vector_Create();
  Test_Vector_Loops();
}

void Test_Vector_Create()
{
  // still need to do other create types, and chain allocation, perhaps more, but focus on Vector creation. but we might end up testing destroy in this same func.

  Mary_Pool_Start();
  Mary_Pool_t *pool = Mary_Pool_Create(8);

  TEST_START(Test_Vector_Create);

  //VECTOR(fail, STACK, U, 0); // assert, STACK is invalid in this context
  VECTOR(vec0, HEAP, U, 0); // ok, *DO* need to destroy
  VECTOR(vec1, pool->id, U, 0); // ok, *DO* need to destroy

  //VECTOR(fail, FRAME, U, 0); // assert, arena not started
  //VECTOR(fail, CHAIN, U, 0); // assert, arena not started
  //VECTOR(fail, ERROR, U, 0); // assert, arena not started

  Mary_Arena_Start();

  //VECTOR(fail, FRAME, U, 0); // assert, no frame available
  //VECTOR(fail, CHAIN, U, 0); // assert, no chain available (we are getting no frame available on this cause validation only checks for frame. we could make multiple funcs.
  //VECTOR(fail, ERROR, U, 0); // assert, no chain available

  //MARY_Arena_In; Mary_Arena_Stop(); // assert, still frames unpopped

  //MARY_Arena_Out; // error, uses variable defined in MARY_Arena_In;

  MARY_Arena_In; // ok

  VECTOR(vec2, FRAME, U, 0); // ok, *DON'T* need to destroy
  //VECTOR(fail, CHAIN, U, 0); // assert, no chain available
  //VECTOR(fail, ERROR, U, 0); // assert, no chain available

  MARY_Arena_Out; // ok

  Mary_Arena_Stop();

  TEST_STOP;

  Vector_Destroy(&vec0);
  Vector_Destroy(&vec1);
  Mary_Pool_Destroy(pool);

  Mary_Pool_Stop();
}

void Test_Vector_Loops()
{
  TEST_START(Test_Vector_Loops);

  VECTOR_Stack(nums, u8, 256);

  for (I i = 0; i < 256; ++i)
  {
    VECTOR_Push(&nums, u8, (u8)i);
  }

  I independant = 0;

  VECTOR_Each(&nums, u8)
  {
    MARY_Assert(it.v = &nums, 0);
    MARY_Assert(it.idx == independant, 0);
    MARY_Assert(it.end == 255, 0);
    MARY_Assert(it.ptr == &nums_array[it.idx], 0);
    MARY_Assert(it.val == nums_array[it.val], 0);
    ++independant;
  }

  MARY_Assert(independant == 256, 0);

  independant = 255;

  VECTOR_Each_Reverse(&nums, u8)
  {
    MARY_Assert(it.v = &nums, 0);
    MARY_Assert(it.idx == independant, 0);
    MARY_Assert(it.end == 0, 0);
    MARY_Assert(it.ptr == &nums_array[it.idx], 0);
    MARY_Assert(it.val == nums_array[it.val], 0);
    --independant;
  }

  MARY_Assert(independant + 1 == 0, 0);

  TEST_STOP;

  // I think we should be able to handle a it.v.units of ~0llu
  // in Vector_Each, but in Each_Reverse, it won't even start,
  // because of the it.idx + 1 trick. in order to fix it, we would
  // have to store a separate variable for units. It's such an edge case
  // though. About 16,777,216 terrabytes for an array with ~0llu u8's!
}

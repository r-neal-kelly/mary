#pragma once

#include <stdio.h>
#include <stdint.h>

#define WIN32_LEAN_AND_MEAN
#define UNICODE
#include <Windows.h>

typedef struct
{
  HWND win32_hwnd;
  HDC win32_hdc;
} Mary_Window_t;

// I would like to keep instances pointers on the heap.
// might want to make a simple vector struct!

// Mary_Window_Finish will Mary_Window_Destroy all remaining
// windows in our vector. user should never worry about it.

void Mary_Window_Start();
void Mary_Window_Finish();
void Mary_Window_Create(Mary_Window_t *window);
void Mary_Window_Destroy(Mary_Window_t *window);
void Mary_Window_Show(Mary_Window_t *window);
void Mary_Window_Hide(Mary_Window_t *window);

#include <stdio.h>
#include <stdlib.h>
#include <Mary/Mary.h>

int main()
{
  Mary_Vector_i veci = Mary_Vector();
  Mary_Vector_t vect;
  Mary_Vector_t var;
  
  veci.Create(&vect, sizeof(var));

  for (int i = 0; i <= 2550; ++i)
  {
    var.size = i;
    veci.Push_Front(&vect, &var);
  }

  for (size_t i = 0u; i < vect.size; ++i)
  {
    veci.At(&vect, i, &var);
    printf("%zu ", var.size);
  } printf("\n");

  while (vect.size)
  {
    veci.Pop_Back(&vect, &var);
    printf("%zu ", var.size);
  } printf("\n");

  veci.Destroy(&vect);

  char num = 12;
  veci.Create(&vect, sizeof(char));
  veci.Resize(&vect, 200);
  veci.Fill(&vect, &num);

  char test = 0;
  for (size_t i = 0; i < vect.size; ++i)
  {
    veci.At(&vect, i, &test);
    printf("%i ", (int)test);
  } printf("\n");

  veci.Destroy(&vect);

  Mary_Exit_Success();

  //////
  printf("%llu\n", (uint64_t)~0);
  printf("%lli\n", (int64_t)~0 & ~((int64_t)1 << 63));
  //////

  Mary_Start();

  Mary_Window_t window;
  Mary_Window_Create(&window);

  // temp.
  MSG msg;
  while (IsWindow(window.win32_hwnd))
  {
    while (PeekMessage(&msg, window.win32_hwnd, 0, 0, PM_REMOVE))
    {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
    }
    Sleep(1);
  }

  Mary_Finish();
  Mary_Window_Destroy(&window); // will go in Mary_Finish();
  puts("Thank you for using C programming language!");
  Mary_Exit_Success();
}

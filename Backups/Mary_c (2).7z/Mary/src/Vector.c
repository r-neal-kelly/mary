#define intern static
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <Mary/Utils.h>
#include <Mary/Vector.h>
typedef char byte_t;

const Mary_Vector_i Mary_Vector();
intern void Create    (Mary_Vector_t *vector, size_t unit);
intern void Destroy   (Mary_Vector_t *vector);
intern void Reserve   (Mary_Vector_t *vector, size_t size);
intern void Fit       (Mary_Vector_t *vector);
intern void Insert    (Mary_Vector_t *vector, size_t index, void *elem_in);
intern void Extract   (Mary_Vector_t *vector, size_t index, void *elem_out);
intern void Replace   (Mary_Vector_t *vector, size_t index, void *elem_in);
intern void Exchange  (Mary_Vector_t *vector, size_t index, void *elem_in, void *elem_out);
intern void Push_Back (Mary_Vector_t *vector, void *elem_in);
intern void Push_Front(Mary_Vector_t *vector, void *elem_in);
intern void Pop_Back  (Mary_Vector_t *vector, void *elem_out);
intern void Pop_Front (Mary_Vector_t *vector, void *elem_out);
intern void At        (Mary_Vector_t *vector, size_t index, void *elem_out);
intern char Has_At    (Mary_Vector_t *vector, size_t index);
intern void Back      (Mary_Vector_t *vector, void *elem_out);
intern void Front     (Mary_Vector_t *vector, void *elem_out);
intern void Empty     (Mary_Vector_t *vector);
intern char Is_Empty  (Mary_Vector_t *vector);
intern void Resize    (Mary_Vector_t *vector, size_t size);
intern void Fill      (Mary_Vector_t *vector, void *elem_in);

const Mary_Vector_i Mary_Vector()
{
  const Mary_Vector_i interface =
    { Create, Destroy
    , Reserve, Fit
    , Insert, Extract
    , Replace, Exchange
    , Push_Back, Push_Front
    , Pop_Back, Pop_Front
    , At, Has_At
    , Back, Front
    , Empty, Is_Empty
    , Resize, Fill
    };

  return interface;
}

intern void Create(Mary_Vector_t *vector, size_t unit)
{
  void *data = calloc(1, unit);
  if (data)
  {
    vector->data = data;
    vector->capacity = unit;
    vector->unit = unit;
    vector->size = 0;
  }
}

intern void Destroy(Mary_Vector_t *vector)
{
  free(vector->data);
}

intern void Reserve(Mary_Vector_t *vector, size_t size)
{
  size_t old_capacity = vector->capacity;
  size_t new_capacity = size * vector->unit;
  if (new_capacity > old_capacity)
  {
    void *data = vector->data;
    data = realloc(data, new_capacity);
    if (data)
    {
      vector->data = data;
      vector->capacity = new_capacity;
    }
  }
}

intern void Fit(Mary_Vector_t *vector)
{
  size_t capacity = vector->capacity;
  size_t unit = vector->unit;
  size_t size = vector->size;
  size_t fit_capacity = (size) ? (size * unit) : unit;
  if (capacity != fit_capacity)
  {
    void *data = vector->data;
    data = realloc(data, fit_capacity);
    if (data)
    {
      vector->data = data;
      vector->capacity = fit_capacity;
    }
  }
}

intern void Insert(Mary_Vector_t *vector, size_t index, void *elem_in)
{
  size_t capacity = vector->capacity;
  size_t unit = vector->unit;
  size_t size = vector->size + 1;
  if (size * unit > capacity)
  {
    Reserve(vector, size * 2);
  }

  void *data = vector->data;
  size_t i = size - 1;
  byte_t *p = (byte_t *)data + (i * unit);
  for (; i > index; --i, p -= unit)
  {
    memmove(p, p - unit, unit);
  }
  memcpy(p, elem_in, unit);

  vector->size = size;
}

intern void Extract(Mary_Vector_t *vector, size_t index, void *elem_out)
{
  size_t unit = vector->unit;
  size_t size = vector->size - 1;
  void *data = vector->data;
  byte_t *p = (byte_t *)data + (index * unit);
  memcpy(elem_out, p, unit);
  for (; index < size; ++index, p += unit)
  {
    memmove(p, p + unit, unit);
  }

  vector->size = size;
}

intern void Replace(Mary_Vector_t *vector, size_t index, void *elem_in)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  byte_t *p = (byte_t *)data + (index * unit);
  memcpy(p, elem_in, unit);
}

intern void Exchange(Mary_Vector_t *vector, size_t index, void *elem_in, void *elem_out)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  byte_t *p = (byte_t *)data + (index * unit);
  memcpy(elem_out, p, unit);
  memcpy(p, elem_in, unit);
}

intern void Push_Back(Mary_Vector_t *vector, void *elem_in)
{
  Insert(vector, vector->size, elem_in);
}

intern void Push_Front(Mary_Vector_t *vector, void *elem_in)
{
  Insert(vector, 0, elem_in);
}

intern void Pop_Back(Mary_Vector_t *vector, void *elem_out)
{
  size_t size = vector->size;
  Extract(vector, (size) ? size - 1 : 0, elem_out);
}

intern void Pop_Front(Mary_Vector_t *vector, void *elem_out)
{
  Extract(vector, 0, elem_out);
}

intern void At(Mary_Vector_t *vector, size_t index, void *elem_out)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  byte_t *p = (byte_t *)data + (index * unit);
  memcpy(elem_out, p, unit);
}

intern char Has_At(Mary_Vector_t *vector, size_t index)
{
  return index < vector->size;
}

intern void Back(Mary_Vector_t *vector, void *elem_out)
{
  size_t size = vector->size;
  At(vector, (size) ? size - 1 : 0, elem_out);
}

intern void Front(Mary_Vector_t *vector, void *elem_out)
{
  At(vector, 0, elem_out);
}

intern void Empty(Mary_Vector_t *vector)
{
  size_t unit = vector->unit;
  Destroy(vector);
  Create(vector, unit);
}

intern char Is_Empty(Mary_Vector_t *vector)
{
  return vector->size != 0;
}

intern void Resize(Mary_Vector_t *vector, size_t size)
{
  vector->size = size;
  Fit(vector);
}

intern void Fill(Mary_Vector_t *vector, void *elem_in)
{
  void *data = vector->data;
  size_t unit = vector->unit;
  size_t size = vector->size;
  byte_t *p = (byte_t *)data;
  for (size_t i = 0; i < size; ++i, p += unit)
  {
    memcpy(p, elem_in, unit);
  }
}

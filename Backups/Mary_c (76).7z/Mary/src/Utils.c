#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <Mary/Utils.h>
#include <Mary/String.h>

MARY_Primitives;

void Mary_Exit_Success()
{
  puts("\npress enter to exit...");
  getc(stdin); exit(EXIT_SUCCESS);
}

void Mary_Exit_Failure(char *error_string)
{
  printf("MARY FATAL ERROR: %s\n", error_string);
  puts("\npress enter to exit...");
  getc(stdin); exit(EXIT_FAILURE);
}

void Mary_Exit_Assert(char *assertion, char *file, int line)
{
  printf("MARY ASSERT: %s is not true!\n", assertion);
  printf("    in file: %s\n", file);
  printf("    on line: %i\n", line);
  printf("\npress enter to exit\n");
  getc(stdin); exit(EXIT_FAILURE);
}

Mary_Bool_t Mary_Is_Little_Endian()
{
  volatile u16 i = 0x0001;
  return *(u8 *)&i == 1;
}

Mary_Bool_t Mary_Is_Big_Endian()
{
  volatile u16 i = 0x0001;
  return *(u8 *)&i == 0;
}

void Mary_Print_Bits(void *value, Mary_Size_t size, Mary_Bool_t little_endian)
{
  char *binary_digits[16] =
  {
    "0000", "0001", "0010", "0011",
    "0100", "0101", "0110", "0111",
    "1000", "1001", "1010", "1011",
    "1100", "1101", "1110", "1111"
  };
  u8 byte = 0, *p = little_endian ? (u8 *)value + size - 1 : value;
  for (int i = 0; i < 76; ++i) printf("-"); printf("\n");
  for (size_t i = 0; i < size; i += 8)
  {
    if (!i)
      printf("bin: ");
    else if (i % 8 == 0)
      printf("     ");
    for (int j = 0; j < 8; ++j)
    {
      if (i + j == size) break;
      byte = little_endian ? *(p - (i + j)) : *(p + i + j);
      printf("%s", binary_digits[(byte & 0xF0) >> 4]);
      printf("%s ", binary_digits[byte & 0x0F]);
    } printf("\n");

    if (!i)
      printf("hex: ");
    else if (i % 8 == 0)
      printf("     ");
    for (int j = 0; j < 8; ++j)
    {
      if (i + j == size) break;
      byte = little_endian ? *(p - (i + j)) : *(p + i + j);
      printf("%4X", (byte & 0xF0) >> 4);
      printf("%4X ", byte & 0x0F);
    } printf("\n");
  }
  for (int i = 0; i < 76; ++i) printf("-"); printf("\n");
}

Mary_Size_t Mary_C_String_Count_Bytes(void *c_string, Mary_Size_t unit, Mary_Bool_t with_null)
{
  size_t bytes = 0; u64 zero = 0;
  for (u8 *b = c_string; ; b += unit, bytes += unit)
  {
    if (memcmp(b, &zero, unit) == 0) break;
  }
  if (with_null > 0) bytes += unit;
  return bytes;
}

Mary_Size_t Mary_C_String_Count_Units(void *c_string, Mary_Size_t unit, Mary_Bool_t with_null)
{
  size_t units = 0; u64 zero = 0;
  for (u8 *b = c_string; ; b += unit, ++units)
  {
    if (memcmp(b, &zero, unit) == 0) break;
  }
  if (with_null > 0) ++units;
  return units;
}

Mary_Size_t Mary_C_String_Count_Codes(void *c_string, Mary_UTF_t utf, Mary_Bool_t with_null)
{
  u64 codes = 0, zero = 0;
  if (utf == MARY_UTF_8)
  {
    u64 code_units;
    for (u8 *p = c_string; ; ++codes)
    {
      if (memcmp(p, &zero, sizeof(u8)) == 0) break;
      code_units = MARY_String_UTF_8_Ptr_To_Units(p);
      p += code_units;
    }
  }
  else if (utf == MARY_UTF_16)
  {
    u64 code_units;
    for (u16 *p = c_string; ; ++codes)
    {
      if (memcmp(p, &zero, sizeof(u16)) == 0) break;
      code_units = MARY_String_UTF_16_Ptr_To_Units(p);
      p += code_units;
    }
  }
  else
  {
    for (u32 *p = c_string; ; ++p, ++codes)
    {
      if (memcmp(p, &zero, sizeof(u32)) == 0) break;
    }
  }
  if (with_null > 0) ++codes;
  return codes;
}

void Mary_Zero(void *ptr, Mary_Size_t bytes)
{
  if (bytes >= sizeof(u64))
  {
    u64 u64s = bytes / sizeof(u64);
    u64 *ptr_64 = MARY_Cast(ptr, u64);
    MARY_Range(ptr_64, u64, 0, u64s) *it.ptr = 0;
    u64 u8s = bytes - u64s * sizeof(u64);
    u8 *ptr_8 = MARY_Cast(ptr_64 + u64s, u8);
    MARY_Range(ptr_8, u8, 0, u8s) *it.ptr = 0;
  }
  else
  {
    MARY_Range(ptr, u8, 0, bytes) *it.ptr = 0;
  }
}

void *Mary_Copy(void *from, void *to, Mary_Size_t bytes)
{
  if (bytes >= sizeof(u64))
  {
    u64 u64s = bytes / sizeof(u64);
    u64 *to_64 = MARY_Cast(to, u64);
    u64 *from_64 = MARY_Cast(from, u64);
    MARY_Range(to_64, u64, 0, u64s) *it.ptr = *(from_64 + it.idx);
    u64 u8s = bytes - u64s * sizeof(u64);
    u8 *to_8 = MARY_Cast(to_64 + u64s, u8);
    u8 *from_8 = MARY_Cast(from_64 + u64s, u8);
    MARY_Range(to_8, u8, 0, u8s) *it.ptr = *(from_8 + it.idx);
  }
  else
  {
    u8 *to_8 = MARY_Cast(to, u8);
    u8 *from_8 = MARY_Cast(from, u8);
    MARY_Range(to_8, u8, 0, bytes) *it.ptr = *(from_8 + it.idx);
  }
  return to;
}

Mary_Bool_t Mary_Is_Same(void *one, void *two, Mary_Size_t bytes)
{
  if (bytes >= sizeof(u64))
  {
    u64 u64s = bytes / sizeof(u64);
    u64 *one_64 = MARY_Cast(one, u64);
    u64 *two_64 = MARY_Cast(two, u64);
    MARY_Range(one_64, u64, 0, u64s)
    {
      if (it.val != *(two_64 + it.idx))
      {
        return MARY_FALSE;
      }
    }
    u64 u8s = bytes - u64s * sizeof(u64);
    u8 *one_8 = MARY_Cast(one_64 + u64s, u8);
    u8 *two_8 = MARY_Cast(two_64 + u64s, u8);
    MARY_Range(one_8, u8, 0, u8s)
    {
      if (it.val != *(two_8 + it.idx))
      {
        return MARY_FALSE;
      }
    }
  }
  else
  {
    u8 *one_8 = MARY_Cast(one, u8);
    u8 *two_8 = MARY_Cast(two, u8);
    MARY_Range(one_8, u8, 0, bytes)
    {
      if (it.val != *(two_8 + it.idx))
      {
        return MARY_FALSE;
      }
    }
  }
  return MARY_TRUE;
}

int64_t Mary_Compare(void *one, void *two, Mary_Size_t bytes)
{

  return 0;
}

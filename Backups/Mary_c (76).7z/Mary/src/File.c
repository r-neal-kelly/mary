#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <Mary/File.h>

MARY_Primitives;

const u8 modes_8[6][4] =
{
  "rb", "r+b", "wb", "w+b", "ab", "a+b"
};

const u16 modes_16[6][4] =
{
  u"rb", u"r+b", u"wb", u"w+b", u"ab", u"a+b"
};

static void File_Error(Mary_File_t *mary_file);

// these two creation funcs may be put together able
void Mary_File_String_Create(Mary_File_t *mary_file, Mary_String_t *path, Mary_Enum_t mode, Mary_Size_t unit)
{
  mary_file->unit = unit;
  mary_file->flags = 0 | MARY_FILE_STRING;

  mary_file->stream = fopen(path->data, &modes_8[mode][0]);
  //_wfopen, we need to check the utf of the string and recode and choose the right function.
  // I'm having a hell of a time deciding what to do. I don't want to call out to heap on each
  // file open just to copy the string in this manner. Maybe we can set up a memory pool in the type.
  // my preferred option is hands down to keep in on the stack, these are just path names.
  // but I will need some helper fuctions in String_t to get it right.
  // I think we will use a macro call to handle this. a Mary_String_Each_8_To_16

  if (mary_file->stream == 0)
  {
    File_Error(mary_file);
  }
  else
  {
    if (mode == MARY_FILE_WRITE ||
        mode == MARY_FILE_WRITE_READ)
    {
      mary_file->units = 0;
    }
    else
    {
      u64 bytes = 0;
      while (fgetc(mary_file->stream),
             feof(mary_file->stream) == 0)
      {
        ++bytes;
      }
      rewind(mary_file->stream);
      mary_file->units = bytes / unit;
    }
  }
}

void Mary_File_Bytes_Create(Mary_File_t *mary_file, Mary_String_t *path, Mary_Enum_t mode, Mary_Size_t unit)
{
  mary_file->unit = unit;
  mary_file->flags = 0 | MARY_FILE_BYTES;
  mary_file->stream = fopen(path->data, &modes_8[mode][0]);

  if (mary_file->stream == 0)
  {
    File_Error(mary_file);
  }
  else
  {
    if (mode == MARY_FILE_WRITE ||
        mode == MARY_FILE_WRITE_READ)
    {
      mary_file->units = 0;
    }
    else
    {
      u64 bytes = 0;
      while (fgetc(mary_file->stream),
             feof(mary_file->stream) == 0)
      {
        ++bytes;
      }
      rewind(mary_file->stream);
      mary_file->units = bytes / unit;
    }
  }
}

void Mary_File_Destroy(Mary_File_t *mary_file)
{
  if (fclose(mary_file->stream) == EOF)
  {
    File_Error(mary_file);
  }
  else
  {
    mary_file->flags |= MARY_FILE_ENDED;
  }
}

static void File_Error(Mary_File_t *mary_file)
{
  mary_file->units = 0;
  mary_file->flags |= MARY_FILE_ERROR;
  MARY_Assert(mary_file->flags & MARY_FILE_ERROR);
}

uint64_t Mary_File_Has_Error(Mary_File_t *mary_file)
{
  return mary_file->flags & MARY_FILE_ERROR ? MARY_TRUE : MARY_FALSE;
}

uint64_t Mary_File_Has_Bytes(Mary_File_t *mary_file)
{
  return mary_file->flags & MARY_FILE_BYTES ? MARY_TRUE : MARY_FALSE;
}

uint64_t Mary_File_Has_Text(Mary_File_t *mary_file)
{
  return mary_file->flags & MARY_FILE_STRING ? MARY_TRUE : MARY_FALSE;
}

uint64_t Mary_File_Has_Ended(Mary_File_t *mary_file)
{
  if (MARY_Truthy(feof(mary_file->stream)))
  {
    mary_file->flags |= MARY_FILE_ENDED;
    return MARY_TRUE;
  }
  else
  {
    return MARY_FALSE;
  }
}

uint64_t Mary_File_Read_Unit(Mary_File_t *mary_file, void *out_unit)
{
  if (mary_file->flags & MARY_FILE_ENDED)
  {
    return MARY_FALSE;
  }
  else if (mary_file->flags & MARY_FILE_STRING)
  {
    u64 cr = '\r', lf = '\n';
    fread(out_unit, mary_file->unit, 1, mary_file->stream);
    if (MARY_Truthy(feof(mary_file->stream)))
    {
      mary_file->flags |= MARY_FILE_ENDED;
      return MARY_FALSE;
    }
    else
    {
      if (memcmp(out_unit, &cr, mary_file->unit) == 0)
      {
        fpos_t pos; fgetpos(mary_file->stream, &pos);
        fread(out_unit, mary_file->unit, 1, mary_file->stream);
        if (MARY_Truthy(feof(mary_file->stream)))
        {
          Mary_Copy(&lf, out_unit, mary_file->unit);
          mary_file->flags |= MARY_FILE_ENDED;
        }
        else if (memcmp(out_unit, &lf, mary_file->unit) != 0)
        {
          fsetpos(mary_file->stream, &pos);
          Mary_Copy(&lf, out_unit, mary_file->unit);
        }
      }
    }
  }
  else
  {
    fread(out_unit, mary_file->unit, 1, mary_file->stream);
    if (MARY_Truthy(feof(mary_file->stream)))
    {
      mary_file->flags |= MARY_FILE_ENDED;
      return MARY_FALSE;
    }
  }
  return MARY_TRUE;
}

// I think it might actually be better to just go ahead and malloc space for each line separately, so there is not confusion.
Mary_Bool_t Mary_File_Read_Line(Mary_File_t *mary_file, Mary_Vector_t *out_buffer, Mary_Bool_t is_created)
{
  if ((mary_file->flags & MARY_FILE_BYTES) || (mary_file->flags & MARY_FILE_ENDED))
  {
    return MARY_FALSE;
  }

  if (MARY_Falsey(is_created))
  {
    Mary_Vector_Create(out_buffer, mary_file->unit, 0);
  }

  u64 code = 0, units = 0;
  while (Mary_File_Read_Unit(mary_file, &code) && code == '\n');
  if (code != 0)
  {
    ++units, Mary_Vector_Push_Back(out_buffer, &code);
  }

  while (Mary_File_Read_Unit(mary_file, &code) && code != '\n')
  {
    ++units, Mary_Vector_Push_Back(out_buffer, &code);
  }

  if (units == 0)
  {
    return MARY_FALSE;
  }
  else
  {
    if (code != 0)
    {
      code = 0; Mary_Vector_Push_Back(out_buffer, &code);
    }
    return MARY_TRUE;
  }
}

void Mary_File_String_Read_All(Mary_File_t *mary_file, Mary_String_t *out_string, Mary_Bool_t is_created)
{
  Mary_Vector_t *out_vector = MARY_Vector(out_string);

  rewind(mary_file->stream);

  if (MARY_Truthy(is_created))
  {
    MARY_Assert(out_string->unit == mary_file->unit);
    Mary_Vector_Reserve(out_vector, out_string->units + mary_file->units + 1);
  }
  else
  {
    Mary_Vector_Create(out_vector, mary_file->unit, mary_file->units + 1);
  }

  u64 buffer_idx = out_vector->units;
  u8 *buffer_ptr = MARY_Vector_Point(out_vector, buffer_idx), *buffer_start = buffer_ptr;
  while (Mary_File_Read_Unit(mary_file, buffer_ptr))
  {
    ++out_vector->units, buffer_ptr += out_vector->unit;
  }
  u64 null = '\0'; Mary_Vector_Push_Back(out_vector, &null);
  out_string->codes += Mary_C_String_Count_Codes(buffer_start, out_string->unit * 8, 1);
}

void Mary_File_Bytes_Read_All(Mary_File_t *mary_file, Mary_Vector_t *out_buffer, Mary_Bool_t is_created)
{
  rewind(mary_file->stream);

  if (MARY_Truthy(is_created))
  {
    MARY_Assert(out_buffer->unit == mary_file->unit);
    Mary_Vector_Reserve(out_buffer, out_buffer->units + mary_file->units);
  }
  else
  {
    Mary_Vector_Create(out_buffer, mary_file->unit, mary_file->units);
  }

  u8 *buffer_ptr = MARY_Vector_Point(out_buffer, out_buffer->units);
  u64 units_read = fread(buffer_ptr, mary_file->unit, mary_file->units, mary_file->stream);
  if (MARY_Truthy(ferror(mary_file->stream)) || units_read != mary_file->units)
  {
    File_Error(mary_file);
  }
  else
  {
    out_buffer->units += units_read;
  }
}

void Mary_File_String_Write_All(Mary_File_t *mary_file, Mary_String_t *in_string)
{
  u64 written_units = fwrite(in_string->data, in_string->unit,
                             in_string->units - 1, mary_file->stream);
  if (written_units != in_string->units)
  {
    File_Error(mary_file);
  }
}

void Mary_File_Bytes_Write_All(Mary_File_t *mary_file, Mary_Vector_t *in_buffer)
{
  u64 written_units = fwrite(in_buffer->data, in_buffer->unit,
                             in_buffer->units, mary_file->stream);
  if (written_units != in_buffer->units)
  {
    File_Error(mary_file);
  }
}

void Mary_File_Front(Mary_File_t *mary_file)
{
  rewind(mary_file->stream);
}

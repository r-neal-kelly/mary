#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <Mary/Utils.h>
#include <Mary/Pool.h>

MARY_Primitives;

#define IDX_RESERVE 16

typedef struct
{
  u32 from;
  u32 to_exclusive;
}
Used_Space;

void Mary_Pool_Create(Mary_Pool_t *pool, size_t bytes)
{
  MARY_Assert(bytes > 0 && bytes <= 0x800000000); // 32 gig max, because a u32 in index can only hold so much.
  u64 size_8bit_data = bytes + 7 & -8; // rounded to 8 bytes, 64 bit
  u8 *data = malloc(size_8bit_data + 8);
  if (data)
  {
    pool->data = data + 8; // avoids accidental deallocation of entire pool.
    pool->bytes = size_8bit_data;
    pool->free = size_8bit_data;
    MARY_Vector_Create(pool->index, Used_Space, IDX_RESERVE);
  }
  else
  {
    Mary_Exit_Failure("out of memory");
  }
}

void Mary_Pool_Create_At(Mary_Pool_t *pool, Mary_p at_ptr, Mary_p at_idx)
{
  at_ptr.bytes = (at_ptr.bytes - 8 & -8) + 8; // need to round down
  at_idx.bytes = (at_idx.bytes - 8 & -8) + 8;
  pool->data = at_ptr.data;
  pool->bytes = at_ptr.bytes;
  pool->free = at_ptr.bytes;
  Mary_Vector_Create_At(&pool->index, sizeof(Used_Space), at_idx);
}

void Mary_Pool_Destroy(Mary_Pool_t *pool)
{
  Mary_Vector_Destroy(&pool->index);
  free((u8 *)pool->data - 8);
}

void *Mary_Pool_Allocate(Mary_Pool_t *pool, size_t bytes)
{
  MARY_Assert(bytes > 0 && bytes <= pool->free);
  u64 size_8bit_alloc = bytes + 7 & -8;
  u32 size_64bit_alloc = (u32)(size_8bit_alloc >> 3);
  Used_Space index_new = { 0, 0 };
  if (!pool->index.units)
  {
    index_new.to_exclusive = size_64bit_alloc;
    Mary_Vector_Push_Back(&pool->index, &index_new);
  }
  else
  {
    Used_Space index_last = *((Used_Space *)pool->index.data + pool->index.units - 1);
    Used_Space index_first = *(Used_Space *)pool->index.data;
    if (size_64bit_alloc <= (pool->bytes >> 3) - index_last.to_exclusive)
    {
      index_new.from = index_last.to_exclusive;
      index_new.to_exclusive = index_new.from + size_64bit_alloc;
      Mary_Vector_Push_Back(&pool->index, &index_new);
    }
    else if (size_64bit_alloc <= index_first.from)
    {
      index_new.from = 0;
      index_new.to_exclusive = index_new.from + size_64bit_alloc;
      Mary_Vector_Push_At(&pool->index, 0, &index_new);
    }
    else
    {
      MARY_Range(pool->index.data, Used_Space, 0, pool->index.units - 1)
      {
        if (size_64bit_alloc <= (it.ptr + 1)->from - it.val.to_exclusive)
        {
          index_new.from = it.val.to_exclusive;
          index_new.to_exclusive = index_new.from + size_64bit_alloc;
          Mary_Vector_Push_At(&pool->index, it.idx + 1, &index_new);
          break;
        }
      }
    }
  }
  if (index_new.to_exclusive != 0)
  {
    pool->free -= size_8bit_alloc;
    return (u64 *)pool->data + index_new.from;
  }
  else
  {
    Mary_Exit_Failure("out of memory");
    return 0;
  }
}

void Mary_Pool_Deallocate(Mary_Pool_t *pool, void *ptr)
{
  // should add a check to do a linear seach if it's beneath a certain threshold.
  u64 from_target = (u64 *)ptr - (u64 *)pool->data;
  u64 from_left = 0, from_right = pool->index.units - 1, from_middle;
  Used_Space index;
  while (from_left <= from_right)
  {
    from_middle = from_left + from_right >> 1;
    Mary_Vector_At(&pool->index, from_middle, &index);
    if (index.from < from_target)
    {
      from_left = from_middle + 1;
    }
    else if (index.from > from_target)
    {
      from_right = from_middle - 1;
    }
    else
    {
      pool->free += index.to_exclusive - index.from << 3;
      Mary_Vector_Erase_At(&pool->index, from_middle); return;
    }
  }
  Mary_Exit_Failure("invalid pointer");
}

void Mary_Pool_Empty(Mary_Pool_t *pool)
{
  Mary_Vector_Empty(&pool->index);
  pool->free = pool->bytes;
}

#pragma once

#include <Mary/Utils.h>
#include <Mary/Vector.h>

typedef struct
{
  MARY_Vector_t;
  Mary_Size_t codes;
}
Mary_String_t;

// change bit_format to utf

void Mary_String_Create(Mary_String_t *mary_string, Mary_UTF_t utf, void *text, Mary_Size_t opt_units);
void Mary_String_Create_At(Mary_String_t *mary_string, Mary_UTF_t utf, Mary_p mary_ptr);
void Mary_String_Create_With(Mary_String_t *mary_string, Mary_UTF_t utf, Mary_p mary_ptr);
void Mary_String_Create_With_Stack(Mary_String_t *mary_string, Mary_UTF_t utf, void *c_string);
void Mary_String_Destroy(Mary_String_t *mary_string);
// prob should have a change and concat with String_t too.
void Mary_String_Change(Mary_String_t *mary_string, void *c_string, Mary_UTF_t opt_utf_c_string);
void Mary_String_Concat(Mary_String_t *mary_string, void *c_string, Mary_UTF_t opt_utf_c_string);
void Mary_String_Copy(Mary_String_t *string, Mary_String_t *out_copy, Mary_UTF_t opt_new_utf);
Mary_UTF_t Mary_String_Get_UTF(Mary_String_t *mary_string);
void Mary_String_Recode(Mary_String_t *mary_string, Mary_UTF_t new_utf);
// Cluster() should group the clusters in the string together
// Alphabet() should return whatever lang it is, see Lang.h

// we could have a function version of these macros, that takes a call back.
// I think I want to have UTF_ on all of these.
#define MARY_String_8_Encode(CODE, OUT_A, OUT_B, OUT_C, OUT_D, CASE_A, CASE_B, CASE_C, CASE_D)    \
(                                                                                                 \
  (CODE) < 0x000080 ?                                                                             \
      ( OUT_A =          (CODE)               , (CASE_A), 0 ) :                                   \
  (CODE) < 0x000800 ?                                                                             \
      ( OUT_A = ( 0xC0 | (CODE) >> 6         ),                                                   \
        OUT_B = ( 0x80 | (CODE)       & 0x3F ), (CASE_B), 0 ) :                                   \
  (CODE) < 0x010000 ?                                                                             \
      ( OUT_A = ( 0xE0 | (CODE) >> 12        ),                                                   \
        OUT_B = ( 0x80 | (CODE) >> 6  & 0x3F ),                                                   \
        OUT_C = ( 0x80 | (CODE)       & 0x3F ), (CASE_C), 0 ) :                                   \
  (CODE) < 0x110000 ?                                                                             \
      ( OUT_A = ( 0xF0 | (CODE) >> 18        ),                                                   \
        OUT_B = ( 0x80 | (CODE) >> 12 & 0x3F ),                                                   \
        OUT_C = ( 0x80 | (CODE) >> 6  & 0x3F ),                                                   \
        OUT_D = ( 0x80 | (CODE)       & 0x3F ), (CASE_D), 0 ) : 0                                 \
)

#define MARY_String_8_Decode(PTR, OUT_CODE, CASE_A, CASE_B, CASE_C, CASE_D)    \
(                                                                              \
  *(PTR) >> 7 == 0x00 ?                                                        \
      ( OUT_CODE = ( * (PTR)             )       , (CASE_A), 0 ) :             \
  *(PTR) >> 5 == 0x06 ?                                                        \
      ( OUT_CODE = ( * (PTR)      ^ 0xC0 ) << 6  |                             \
                   ( *((PTR) + 1) ^ 0x80 )       , (CASE_B), 0 ) :             \
  *(PTR) >> 4 == 0x0E ?                                                        \
      ( OUT_CODE = ( * (PTR)      ^ 0xE0 ) << 12 |                             \
                   ( *((PTR) + 1) ^ 0x80 ) << 6  |                             \
                   ( *((PTR) + 2) ^ 0x80 )       , (CASE_C), 0 ) :             \
  *(PTR) >> 3 == 0x1E ?                                                        \
      ( OUT_CODE = ( * (PTR)      ^ 0xF0 ) << 18 |                             \
                   ( *((PTR) + 1) ^ 0x80 ) << 12 |                             \
                   ( *((PTR) + 2) ^ 0x80 ) << 6  |                             \
                   ( *((PTR) + 3) ^ 0x80 )       , (CASE_D), 0 ) : 0           \
)

#define MARY_String_UTF_8_Code_To_Units(CODE) \
(                                             \
  (CODE) < 0x000080 ? 1 :                     \
  (CODE) < 0x000800 ? 2 :                     \
  (CODE) < 0x010000 ? 3 :                     \
  (CODE) < 0x110000 ? 4 : 0                   \
)

#define MARY_String_UTF_8_Ptr_To_Units(PTR) \
(                                           \
  *(PTR) >> 7 == 0x00 ? 1 :                 \
  *(PTR) >> 5 == 0x06 ? 2 :                 \
  *(PTR) >> 4 == 0x0E ? 3 :                 \
  *(PTR) >> 3 == 0x1E ? 4 : 0               \
)

#define MARY_String_16_Encode(CODE, OUT_A, OUT_B, CASE_A, CASE_B)           \
(                                                                           \
  (CODE) < 0x10000 ?                                                        \
      ( OUT_A =     (CODE)                                , (CASE_A), 0 ) : \
      ( OUT_A = ( ( (CODE) - 0x10000 >> 10    ) + 0xD800 ),                 \
        OUT_B = ( ( (CODE) - 0x10000 &  0x3FF ) + 0xDC00 ), (CASE_B), 0 )   \
)

#define MARY_String_16_Decode(PTR, OUT_CODE, CASE_A, CASE_B)                                    \
(                                                                                               \
  *(PTR) < 0xD800 || *(PTR) > 0xDFFF ?                                                          \
      ( OUT_CODE =  *(PTR)                                                    , (CASE_A), 0 ) : \
      ( OUT_CODE = (*(PTR) - 0xD800 << 10) + (*((PTR) + 1) - 0xDC00) + 0x10000, (CASE_B), 0 )   \
)

#define MARY_String_UTF_16_Code_To_Units(CODE) \
(                                              \
  (CODE) < 0x10000 ? 1 : 2                     \
)

#define MARY_String_UTF_16_Ptr_To_Units(PTR) \
(                                            \
  *(PTR) < 0xD800 || *(PTR) > 0xDFFF ? 2 : 1 \
)

#define MARY_String_Each_8_To_32(S)                                                               \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx, unit_idx;                                                            \
      Mary_Size_t codes, utf_8_units;                                                             \
      u8 *ptr; u32 utf_32;                                                                        \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(Mary_String_Get_UTF(S) == MARY_UTF_8), (S) ),                                 \
        0, 0, it.string->codes, 0, it.string->data,                                               \
      ( MARY_String_8_Decode(it.ptr, it.utf_32,                                                   \
                             it.utf_8_units = 1,                                                  \
                             it.utf_8_units = 2,                                                  \
                             it.utf_8_units = 3,                                                  \
                             it.utf_8_units = 4), it.utf_32 )                                     \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, it.unit_idx += it.utf_8_units, it.ptr += it.utf_8_units,                       \
    MARY_String_8_Decode(it.ptr, it.utf_32,                                                       \
                         it.utf_8_units = 1,                                                      \
                         it.utf_8_units = 2,                                                      \
                         it.utf_8_units = 3,                                                      \
                         it.utf_8_units = 4)                                                      \
  )

#define MARY_String_Each_8_To_16(S)                                                               \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx, unit_idx;                                                            \
      Mary_Size_t codes, utf_8_units, utf_16_units;                                               \
      u8 *ptr; u32 utf_32; struct { u16 a, b; } utf_16;                                           \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(Mary_String_Get_UTF(S) == MARY_UTF_8), (S) ),                                 \
        0, 0, it.string->codes, 0, 0, it.string->data,                                            \
      ( MARY_String_8_Decode(it.ptr, it.utf_32,                                                   \
                             it.utf_8_units = 1,                                                  \
                             it.utf_8_units = 2,                                                  \
                             it.utf_8_units = 3,                                                  \
                             it.utf_8_units = 4), it.utf_32 ),                                    \
      ( MARY_String_16_Encode(it.utf_32,                                                          \
                              it.utf_16.a,                                                        \
                              it.utf_16.b,                                                        \
                              it.utf_16_units = 1,                                                \
                              it.utf_16_units = 2), it.utf_16 )                                   \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, it.unit_idx += it.utf_8_units, it.ptr += it.utf_8_units,                       \
    MARY_String_8_Decode(it.ptr, it.utf_32,                                                       \
                         it.utf_8_units = 1,                                                      \
                         it.utf_8_units = 2,                                                      \
                         it.utf_8_units = 3,                                                      \
                         it.utf_8_units = 4),                                                     \
    MARY_String_16_Encode(it.utf_32,                                                              \
                          it.utf_16.a,                                                            \
                          it.utf_16.b,                                                            \
                          it.utf_16_units = 1,                                                    \
                          it.utf_16_units = 2)                                                    \
  )

#define MARY_String_Each_16_To_32(S)                                                              \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx, unit_idx;                                                            \
      Mary_Size_t codes, utf_16_units;                                                            \
      u16 *ptr; u32 utf_32;                                                                       \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(Mary_String_Get_UTF(S) == MARY_UTF_16), (S) ),                                \
        0, 0, it.string->codes, 0, it.string->data,                                               \
      ( MARY_String_16_Decode(it.ptr, it.utf_32,                                                  \
                              it.utf_16_units = 1,                                                \
                              it.utf_16_units = 2), it.utf_32 )                                   \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, it.unit_idx += it.utf_16_units, it.ptr += it.utf_16_units,                     \
    MARY_String_16_Decode(it.ptr, it.utf_32,                                                      \
                          it.utf_16_units = 1,                                                    \
                          it.utf_16_units = 2)                                                    \
  )

#define MARY_String_Each_16_To_8(S)                                                               \
  for                                                                                             \
  (                                                                                               \
    struct                                                                                        \
    {                                                                                             \
      Mary_String_t *string;                                                                      \
      Mary_Index_t code_idx, unit_idx;                                                            \
      Mary_Size_t codes, utf_16_units, utf_8_units;                                               \
      u16 *ptr; u32 utf_32; struct { u8 a, b, c, d; } utf_8;                                      \
    }                                                                                             \
    it =                                                                                          \
    {                                                                                             \
      ( MARY_Assert(Mary_String_Get_UTF(S) == MARY_UTF_16), (S) ),                                \
        0, 0, it.string->codes, 0, 0, it.string->data,                                            \
      ( MARY_String_16_Decode(it.ptr, it.utf_32,                                                  \
                              it.utf_16_units = 1,                                                \
                              it.utf_16_units = 2), it.utf_32 ),                                  \
      ( MARY_String_8_Encode(it.utf_32,                                                           \
                             it.utf_8.a, it.utf_8.b,                                              \
                             it.utf_8.c, it.utf_8.d,                                              \
                             it.utf_8_units = 1, it.utf_8_units = 2,                              \
                             it.utf_8_units = 3, it.utf_8_units = 4), it.utf_8 )                  \
    };                                                                                            \
    it.code_idx < it.codes;                                                                       \
    ++it.code_idx, it.unit_idx += it.utf_16_units, it.ptr += it.utf_16_units,                     \
    MARY_String_16_Decode(it.ptr, it.utf_32,                                                      \
                          it.utf_16_units = 1,                                                    \
                          it.utf_16_units = 2),                                                   \
    MARY_String_8_Encode(it.utf_32,                                                               \
                         it.utf_8.a, it.utf_8.b,                                                  \
                         it.utf_8.c, it.utf_8.d,                                                  \
                         it.utf_8_units = 1, it.utf_8_units = 2,                                  \
                         it.utf_8_units = 3, it.utf_8_units = 4)                                  \
  )

#define MARY_String_32_Each(S)                                                         \
  for                                                                                  \
  (                                                                                    \
    struct { u64 idx_codes, idx_units, finish_exclusive, finish; u32 *ptr; u32 code; } \
    it =                                                                               \
    {                                                                                  \
      ( MARY_Assert(Mary_String_Get_UTF(S) == MARY_UTF_32),                            \
        0 ), 0, (S)->codes, (S)->codes - 1, (S)->data, *(u32 *)(S)->data               \
    };                                                                                 \
    it.idx_codes < it.finish_exclusive;                                                \
    ++it.idx_codes, ++it.idx_units, ++it.ptr, it.code = *it.ptr                        \
  )

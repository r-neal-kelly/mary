﻿#include <stdio.h>
#include <Mary/Mary.h>
#include <Mary/App/Test.h>

MARY_Primitives;

void Test_String_Recode()
{
  Mary_String_t str; Mary_String_Create(&str, MARY_UTF_32, MARY_C_String(u32, "aγፈ𐙖"), 0);

  MARY_String_32_Each(&str) printf("%u\n", it.code);
  Mary_String_Recode(&str, MARY_UTF_8); printf("\n");
  MARY_String_Each_8_To_32(&str) printf("%u\n", it.utf_32);
  Mary_String_Recode(&str, MARY_UTF_32); printf("\n");
  MARY_String_32_Each(&str) printf("%u\n", it.code);
  Mary_String_Recode(&str, MARY_UTF_16); printf("\n");
  MARY_String_Each_16_To_32(&str) printf("%u\n", it.utf_32);
  Mary_String_Recode(&str, MARY_UTF_8); printf("\n");
  MARY_String_Each_8_To_32(&str) printf("%u\n", it.utf_32);
  Mary_String_Recode(&str, MARY_UTF_16); printf("\n");
  MARY_String_Each_16_To_32(&str) printf("%u\n", it.utf_32);
  Mary_String_Recode(&str, MARY_UTF_32); printf("\n");
  MARY_String_32_Each(&str) printf("%u\n", it.code);

  Mary_String_Recode(&str, MARY_UTF_8); printf("\n");
  MARY_String_Each_8_To_16(&str)
  {
    if (it.utf_16_units == 1)
    {
      printf("32: %u 16: %u, 8_units: %llu\n",
             it.utf_32, it.utf_16.a, it.utf_8_units);
    }
    else
    {
      printf("32: %u 16: %X, %X, 8_units: %llu\n",
             it.utf_32, it.utf_16.a, it.utf_16.b, it.utf_8_units);
    }
  }

  Mary_String_Recode(&str, MARY_UTF_16); printf("\n");
  MARY_String_Each_16_To_8(&str)
  {
    if (it.utf_8_units == 1)
    {
      printf("32: %u 8: %u, 16_units: %llu\n",
             it.utf_32, it.utf_8.a, it.utf_16_units);
    }
    else if (it.utf_8_units == 2)
    {
      printf("32: %u 8: %u, %u, 16_units: %llu\n",
             it.utf_32, it.utf_8.a, it.utf_8.b, it.utf_16_units);
    }
    else if (it.utf_8_units == 3)
    {
      printf("32: %u 8: %u, %u, %u, 16_units: %llu\n",
             it.utf_32, it.utf_8.a, it.utf_8.b, it.utf_8.c, it.utf_16_units);
    }
    else
    {
      printf("32: %u 8: %u, %u, %u, %u, 16_units: %llu\n",
             it.utf_32, it.utf_8.a, it.utf_8.b, it.utf_8.c, it.utf_8.d, it.utf_16_units);
    }
  }

  Mary_Exit_Success();
}

#include <stdio.h>
#include <Mary/Utils.h>
#include <Mary/Regex.h>
#include <Mary/OS.h>
#include <Mary/App/GCC.h>

// will need to have a func in OS that gives me a directory list
// also, this might be a good time to try out Regex, even though it's not perfect.
// it will be useful in getting the ranges we need to work in our mmake file.

void Mary_GCC_Create_Bat()
{
  printf("hopefully will work soon!");
  Mary_Exit_Success();
}

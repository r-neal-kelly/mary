#pragma once

#include <stdint.h>

enum
{
  MARY_FALSE,
  MARY_TRUE
};

#define MARY_True(VALUE)\
  ((VALUE) == MARY_TRUE)

#define MARY_False(VALUE)\
  ((VALUE) == MARY_FALSE)

#define MARY_Truthy(VALUE)\
  ((VALUE) > 0 ? MARY_TRUE : MARY_FALSE)

#define MARY_Falsey(VALUE)\
  ((VALUE) < 1 ? MARY_TRUE : MARY_FALSE)

#define MARY_Primitives                                                                            \
  typedef uint8_t  u8;                                                                             \
  typedef uint16_t u16;                                                                            \
  typedef uint32_t u32;                                                                            \
  typedef uint64_t u64;                                                                            \
  typedef int8_t   s8;                                                                             \
  typedef int16_t  s16;                                                                            \
  typedef int32_t  s32;                                                                            \
  typedef int64_t  s64;                                                                            \
  typedef float    r32;                                                                            \
  typedef double   r64;                                                                            \
  typedef uint32_t b32;                                                                            \
  typedef uint64_t b64

#define MARY_Swap_16(I)                                                                            \
(                                                                                                  \
  (I) >> 8 & 0x00FF |                                                                              \
  (I) << 8 & 0xFF00                                                                                \
)

#define MARY_Swap_32(I)                                                                            \
(                                                                                                  \
  (I) >> 24 & 0x000000FF |                                                                         \
  (I) >> 8  & 0x0000FF00 |                                                                         \
  (I) << 8  & 0x00FF0000 |                                                                         \
  (I) << 24 & 0xFF000000                                                                           \
)

#define MARY_Swap_64(I)                                                                            \
(                                                                                                  \
  (I) >> 56 & 0x00000000000000FF |                                                                 \
  (I) >> 48 & 0x000000000000FF00 |                                                                 \
  (I) >> 40 & 0x0000000000FF0000 |                                                                 \
  (I) >> 32 & 0x00000000FF000000 |                                                                 \
  (I) << 32 & 0x000000FF00000000 |                                                                 \
  (I) << 40 & 0x0000FF0000000000 |                                                                 \
  (I) << 48 & 0x00FF000000000000 |                                                                 \
  (I) << 56 & 0xFF00000000000000                                                                   \
)

#define MARY_Assert(THIS_IS_TRUE)                                                                  \
  if (!(THIS_IS_TRUE))                                                                             \
  {                                                                                                \
    Mary_Exit_Assert(#THIS_IS_TRUE, __FILE__, __LINE__);                                           \
  }

#define MARY_Cast(PTR, TYPE)\
  ((TYPE *)(PTR))

#define MARY_Range(PTR, TYPE, FROM, TO_EXCLUSIVE)                                                  \
  for                                                                                              \
  (                                                                                                \
    struct { size_t idx, start, finish, finish_exclusive; TYPE *ptr; TYPE val; }                   \
    it =                                                                                           \
    {                                                                                              \
      (FROM), (FROM), (TO_EXCLUSIVE) - 1, (TO_EXCLUSIVE),                                          \
      MARY_Cast(PTR, TYPE) + (FROM),                                                               \
      *(MARY_Cast(PTR, TYPE) + (FROM))                                                             \
    };                                                                                             \
    it.idx < it.finish_exclusive;                                                                  \
    ++it.idx, ++it.ptr, it.val = *it.ptr                                                           \
  )

#define MARY_Range_Reverse(PTR, TYPE, FROM, TO)                                                    \
  for                                                                                              \
  (                                                                                                \
    struct { size_t idx, start, finish; TYPE *ptr; TYPE val; }                                     \
    it =                                                                                           \
    {                                                                                              \
      (FROM), (FROM), (TO),                                                                        \
      MARY_Cast(PTR, TYPE) + (FROM),                                                               \
      *(MARY_Cast(PTR, TYPE) + (FROM))                                                             \
    };                                                                                             \
    it.idx + 1 > it.finish;                                                                        \
    --it.idx, --it.ptr, it.val = *it.ptr                                                           \
  )

#define MARY_Range_Advance(INDICES)\
  it.idx += (INDICES), it.ptr += (INDICES), it.val = *it.ptr

#define MARY_Range_Regress(INDICES)\
  it.idx -= (INDICES), it.ptr -= (INDICES), it.val = *it.ptr

#define MARY_Zero(PTR, BYTES)                                                                      \
{                                                                                                  \
  u8 *ptr = MARY_Cast(PTR, u8);                                                                    \
  u64 bytes = BYTES;                                                                               \
  u64 u64s = bytes / sizeof(u64);                                                                  \
  MARY_Range(ptr, u64, 0, u64s) *it.ptr = 0;                                                       \
  u64 u8s = bytes - u64s * sizeof(u64);                                                            \
  MARY_Range(ptr + bytes - u8s, u8, 0, u8s) *it.ptr = 0;                                           \
}

#define MARY_Clip_Number(NUMBER, FROM, TO)\
  ((NUMBER) < (FROM) ? (FROM) : (NUMBER) > (TO) ? (TO) : (NUMBER));

#define MARY_Round_to_64bit(BYTES)\
  ((BYTES) + 7 & -8)

#define MARY_Pointer_t\
  void *data;\
  size_t bytes

typedef struct
{
  MARY_Pointer_t;
}
Mary_Pointer_t, Mary_p;

#define MARY_Pointer(PTR) ((Mary_Pointer_t *)(PTR))

typedef struct
{
  size_t from;
  size_t to_exclusive;
}
Mary_Slice_t;

typedef struct
{
  void *data;
  size_t bytes;
  size_t offset;
}
Mary_Index_t;

typedef struct
{
  size_t width;
  size_t height;
}
Mary_Size_t, Mary_sz;

typedef struct
{
  MARY_Pointer_t;
  short width;
  short height;
  short depth;
}
Mary_Bitmap_t;

// typedef Mary_Vector_t Mary_Bitmap_v; I can't define this here without a forward declare for vector.

void Mary_Exit_Success();
void Mary_Exit_Failure(const char *error_string);
void Mary_Exit_Assert(const char *assertion, const char *file, int line);
char Mary_Is_Little_Endian();
char Mary_Is_Big_Endian();
void Mary_Print_Bits(void *value, size_t size, char little_endian);
size_t Mary_C_String_Bytes(void *string, size_t unit, uint8_t count_zero);
size_t Mary_C_String_Units(void *string, size_t unit, uint8_t count_zero);
size_t Mary_C_String_Codes(void *string, char bit_format, uint8_t count_zero); // need utf macros.

// planned types
// Mary_Biarray_t, quickly extendable on either side. Mary_Queue_t? Deque?

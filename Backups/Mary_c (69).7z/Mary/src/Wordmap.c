#include <stdlib.h>
#include <Mary/Wordmap.h>

MARY_Primitives;

#define MAX_PAGE_WIDTH MARY_GL_MAX_TEXTURE_SIZE
#define MAX_PAGE_HEIGHT 1024

void Mary_Wordmap_Create(Mary_Wordmap_t *wordmap, Mary_OS_Font_Info_t *font_info, uint32_t opt_pages)
{
  u32 pages = opt_pages > 0 ? opt_pages : 1;
  Mary_Vector_Create(&wordmap->pages, sizeof(Mary_Wordmap_Page_t), pages); wordmap->pages.units = pages;
  Mary_Hashmap_Create(&wordmap->words, sizeof(u16) * 32, sizeof(Mary_Wordmap_Word_t));

  memcpy(&wordmap->font_info, font_info, sizeof(Mary_OS_Font_Info_t));
  Mary_OS_Font_Change(&wordmap->font_info);
  wordmap->line_px = Mary_OS_Font_Get_Real_Px();

  size_t full_page_bytes = MAX_PAGE_WIDTH * MAX_PAGE_HEIGHT * 4;
  size_t empty_page_bytes = MAX_PAGE_WIDTH * wordmap->line_px * 4;
  MARY_Vector_Each(&wordmap->pages, Mary_Wordmap_Page_t)
  {
    Mary_Wordmap_Page_t *page = it.ptr;
    if (it.idx != it.finish)
    {
      page->bitmap.data = malloc(full_page_bytes);
      page->bitmap.bytes = full_page_bytes;
      page->bitmap.width = MAX_PAGE_WIDTH;
      page->bitmap.height = MAX_PAGE_HEIGHT;
      page->bitmap.depth = 32;
    }
    else
    {
      page->bitmap.data = malloc(empty_page_bytes);
      page->bitmap.bytes = empty_page_bytes;
      page->bitmap.width = MAX_PAGE_WIDTH;
      page->bitmap.height = wordmap->line_px;
      page->bitmap.depth = 32;
    }
    Mary_GL_Texture_Create(&page->gl_texture, GL_TEXTURE_2D);
  }

  wordmap->free_page_idx = 0;
  wordmap->free_x = 0;
  wordmap->free_y = 0;
}

void Mary_Wordmap_Destroy(Mary_Wordmap_t *wordmap)
{
  MARY_Vector_Each(&wordmap->pages, Mary_Wordmap_Page_t)
  {
    Mary_Wordmap_Page_t *page = it.ptr;
    free(page->bitmap.data);
    Mary_GL_Texture_Destroy(&page->gl_texture);
  }
  Mary_Hashmap_Destroy(&wordmap->words);
  Mary_Vector_Destroy(&wordmap->pages);
}

void Mary_Wordmap_Add(Mary_Wordmap_t *wordmap, uint16_t *word_data, uint8_t opt_word_units)
{
  u32 word_units = MARY_Truthy(opt_word_units) ?
    opt_word_units : (u32)Mary_C_String_Units(word_data, sizeof(u16), 0);
  Mary_OS_Textmap2_Info_t textmap_info;
  MARY_Zero(&textmap_info, sizeof(textmap_info));
  textmap_info.text_data = word_data;
  textmap_info.text_units = word_units;
  textmap_info.align = MARY_OS_TEXTMAP_ALIGN_LEFT;
  textmap_info.max_alpha = MARY_TRUE; // maybe make false
  Mary_OS_Textmap2_t textmap;
  Mary_OS_Textmap2_Create(&textmap, &textmap_info);

  // copy bitmap into page at free location
  // update free location, create new page if you have to
  // add word to hashmap. has to have normalized values.
  // which means we need to get a list of all words from hash when we remap the page
  // I think we might also have to store the x_px and y_px
  // so much work for the computer. but if we don't make it dynamic, the gpu has to upload
  // a potentially almost empty texture (page)
  // I think it's probably worth the tradeoff in memory for speed in this case. think of the
  // the dynamic text box, it needs something like this.

  Mary_OS_Textmap2_Destroy(&textmap);
}

void Mary_Wordmap_Empty(Mary_Wordmap_t *wordmap)
{
  Mary_Hashmap_Empty(&wordmap->words);
  wordmap->free_page_idx = 0;
  wordmap->free_x = 0;
  wordmap->free_y = 0;
}

﻿#include <stdio.h>
#include <stdlib.h>
#include <Mary/Mary.h>

MARY_PRIMITIVES;

int main()
{
#if 0
  // broken
  Mary_Start();

  Mary_Window_t window;
  Mary_Window_Create(&window);
  while (Mary_Window_Can_Render())
  {
    Mary_Window_Render();
  }
  Mary_Window_Destroy(&window);

  Mary_Finish();
  Mary_Exit_Success();
#endif

#if 0
  Mary_Font_Start();
  Mary_Font_t font; Mary_String_t string;
  Mary_Font_Create(&font, "SILEOTSR.ttf");
  Mary_String_Create(&string, 32, U"\u05D0\u200D\u05DC", 0); // mid is turned to zero. check cmap
  Mary_Font_Layout(&font, &string, MARY_FONT_HEBREW);
  Mary_String_Destroy(&string);
  Mary_Font_Destroy(&font);
  Mary_Font_Finish();
#endif

#if 1
  Mary_Regex_t regex; MARY_Benchmark(Mary_Regex_Create(&regex, 32, U"[a-zA-Z]"), 1);
  Mary_Vector_t matches; MARY_Benchmark(matches = Mary_Regex_Execute(&regex, 32, U"abcABC"), 12);
  MARY_Range(matches.data, Mary_Index_t, 0, matches.size)
   printf("from: %llu to_exclusive: %llu\n", range.val.from, range.val.to_exclusive);
  Mary_Vector_Destroy(&matches);
  Mary_Regex_Destroy(&regex);
#endif

  Mary_Exit_Success();
}

#include <stdlib.h>
#include <string.h>
#include <Mary/Utils.h>
#include <Mary/Vector.h>
#include <Mary/String.h>

MARY_PRIMITIVES;

void Mary_String_Create(Mary_String_t *mary_string, char bit_format, void *string, size_t opt_size)
{
  Mary_Vector_t *mary_vector = (Mary_Vector_t *)mary_string;
  if (bit_format == 8)
  {
    Mary_Vector_Create(mary_vector, 1, opt_size || 64);
    u8 *p = string; u8 code = *p;
    for (; code; ++p, code = *p)
    {
      Mary_Vector_Push_Back(mary_vector, &code);
    }
    code = 0; Mary_Vector_Push_Back(mary_vector, &code);
    if (!opt_size)
    {
      Mary_Vector_Fit(mary_vector);
    }
  }
  else if (bit_format == 16)
  {
    Mary_Vector_Create(mary_vector, 2, opt_size || 64);
    u16 *p = string; u16 code = *p;
    for (; code; ++p, code = *p)
    {
      Mary_Vector_Push_Back(mary_vector, &code);
    }
    code = 0; Mary_Vector_Push_Back(mary_vector, &code);
    if (!opt_size)
    {
      Mary_Vector_Fit(mary_vector);
    }
  }
  else if (bit_format == 32)
  {
    Mary_Vector_Create(mary_vector, 4, opt_size || 64);
    u32 *p = string; u32 code = *p;
    for (; code; ++p, code = *p)
    {
      Mary_Vector_Push_Back(mary_vector, &code);
    }
    code = 0; Mary_Vector_Push_Back(mary_vector, &code);
    if (!opt_size)
    {
      Mary_Vector_Fit(mary_vector);
    }
  }
  mary_string->codes = Mary_String_Count_Codes(mary_string);
}

void Mary_String_Create_With(Mary_String_t *mary_string, char bit_format, void *string, size_t opt_size, Mary_Pointer_t mary_ptr)
{
  if (bit_format == 8)
  {
    Mary_String_8bit_Create_With(mary_string, string, opt_size, mary_ptr);
  }
  else if (bit_format == 16)
  {

  }
  else if (bit_format == 32)
  {
    Mary_String_32bit_Create_With(mary_string, string, opt_size, mary_ptr);
  }
}

void Mary_String_8bit_Create_With(Mary_String_t *mary_string, uint8_t *string, size_t opt_size, Mary_Pointer_t mary_ptr)
{
  Mary_Vector_t *mary_vector = (Mary_Vector_t *)mary_string;
  Mary_Vector_Create_With(mary_vector, sizeof(u8), mary_ptr);
  u8 *ptr = string;
  for (u32 i = 0; !opt_size; ++i, ++ptr)
  {
    if (*ptr == 0) opt_size = i + 1;
  }
  MARY_Assert(mary_vector->capacity >= opt_size * sizeof(u8));
  memcpy(mary_string->data, string, opt_size * sizeof(u8));
  mary_vector->size = opt_size;
  // still need to do codepoint count.
  // can prob turn these into a macro.
}

void Mary_String_32bit_Create_With(Mary_String_t *mary_string, uint32_t *string, size_t opt_size, Mary_Pointer_t mary_ptr)
{
  Mary_Vector_t *mary_vector = (Mary_Vector_t *)mary_string;
  Mary_Vector_Create_With(mary_vector, sizeof(u32), mary_ptr);
  u32 *ptr = string;
  for (u32 i = 0; !opt_size; ++i, ++ptr)
  {
    if (*ptr == 0) opt_size = i + 1;
  }
  MARY_Assert(mary_vector->capacity >= opt_size * sizeof(u32));
  memcpy(mary_string->data, string, opt_size * sizeof(u32));
  mary_vector->size = opt_size;
  mary_string->codes = opt_size - 1;
}

void Mary_String_Destroy(Mary_String_t *mary_string)
{
  free(mary_string->data);
}

size_t Mary_String_Count_Codes(Mary_String_t *mary_string)
{
  // should combine this with the string update loop for efficiency.
  u64 count = 0;
  if (mary_string->unit == 1)
  { // 8bit
    u64 i = 0, size = mary_string->size - 1;
    u8 *p = mary_string->data, v = *p;
    while (i < size)
    {
      if (v >> 7 == 0x00)
      {
        i += 1, p += 1, v = *p;
      }
      else if (v >> 5 == 0x06)
      {
        i += 2, p += 2, v = *p;
      }
      else if (v >> 4 == 0x0E)
      {
        i += 3, p += 3, v = *p;
      }
      else if (v >> 3 == 0x1E)
      {
        i += 4, p += 4, v = *p;
      }
      ++count;
    }
  }
  else if (mary_string->unit == 2)
  { // 16bit
    u64 i = 0, size = mary_string->size - 1;
    u8 *p = mary_string->data, v = *p;
    while (i < size)
    {
      if (v < 0xD800 || v > 0xDFFF)
      {
        i += 1, p += 1, v = *p;
      }
      else
      {
        i += 2, p += 2, v = *p;
      }
      ++count;
    }
  }
  else if (mary_string->unit == 4)
  { // 32bit
    count = mary_string->size;
  }
  return count;
}

void Mary_String_Format(Mary_String_t *mary_string, char new_bit_format)
{
  u8 old_bit_format = (u8)mary_string->unit * 8;
  if (old_bit_format == 8 && new_bit_format == 16)
  {
    Mary_String_8bit_to_16bit(mary_string);
  }
  else if (old_bit_format == 8 && new_bit_format == 32)
  {
    Mary_String_8bit_to_32bit(mary_string);
  }
  else if (old_bit_format == 16 && new_bit_format == 8)
  {
    Mary_String_16bit_to_8bit(mary_string);
  }
  else if (old_bit_format == 16 && new_bit_format == 32)
  {
    Mary_String_16bit_to_32bit(mary_string);
  }
  else if (old_bit_format == 32 && new_bit_format == 8)
  {
    Mary_String_32bit_to_8bit(mary_string);
  }
  else if (old_bit_format == 32 && new_bit_format == 16)
  {
    Mary_String_32bit_to_16bit(mary_string);
  }
}

char Mary_String_Get_Format(Mary_String_t *mary_string)
{
  return (char)(mary_string->unit * 8);
}

void Mary_String_8bit_to_16bit(Mary_String_t *s_8bit)
{
  Mary_Vector_t v_temp, *v_16bit = &v_temp;
  Mary_Vector_Create(v_16bit, 2, s_8bit->size);
  u8 *p = s_8bit->data, v = *p;
  u16 u16, hi, lo; u32 u32;
  while (1)
  {
    if (v == 0x00)
    { // null -> null
      u16 = 0;
      Mary_Vector_Push_Back(v_16bit, &u16);
      break;
    }
    else if (v >> 7 == 0x00)
    { // 1 byte -> bmp
      u16 = v; ++p, v = *p;
      Mary_Vector_Push_Back(v_16bit, &u16);
    }
    else if (v >> 5 == 0x06)
    { // 2 byte -> bmp
      u16  = (v ^ 0xC0) << 6; ++p, v = *p;
      u16 |= (v ^ 0x80)     ; ++p, v = *p;
      Mary_Vector_Push_Back(v_16bit, &u16);
    }
    else if (v >> 4 == 0x0E)
    { // 3 byte -> bmp
      u16  = (v ^ 0xE0) << 12; ++p, v = *p;
      u16 |= (v ^ 0x80) << 6 ; ++p, v = *p;
      u16 |= (v ^ 0x80)      ; ++p, v = *p;
      Mary_Vector_Push_Back(v_16bit, &u16);
    }
    else if (v >> 3 == 0x1E)
    { // 4 byte -> surrogates
      u32  = (v ^ 0xF0) << 18; ++p, v = *p;
      u32 |= (v ^ 0x80) << 12; ++p, v = *p;
      u32 |= (v ^ 0x80) << 6 ; ++p, v = *p;
      u32 |= (v ^ 0x80)      ; ++p, v = *p;
      u32 -= 0x10000;
      hi = (u32 >> 10)   + 0xD800;
      lo = (u32 & 0x3FF) + 0xDC00;
      Mary_Vector_Push_Back(v_16bit, &hi);
      Mary_Vector_Push_Back(v_16bit, &lo);
    }
  }
  s_8bit->size = 0; s_8bit->unit = v_16bit->unit;
  Mary_Vector_Add_Slice((Mary_Vector_t *)s_8bit, 0, v_16bit->size);
  memcpy(s_8bit->data, v_16bit->data, v_16bit->size * v_16bit->unit);
  Mary_Vector_Destroy(v_16bit);
}

void Mary_String_8bit_to_32bit(Mary_String_t *s_8bit)
{
  Mary_Vector_t v_temp, *v_32bit = &v_temp;
  Mary_Vector_Create(v_32bit, 4, s_8bit->size);
  u8 *p = s_8bit->data, v = *p;
  u32 u32;
  while (1)
  {
    if (v == 0x00)
    { // null
      u32 = 0;
      Mary_Vector_Push_Back(v_32bit, &u32);
      break;
    }
    else if (v >> 7 == 0x00)
    { // 1 byte
      u32 = v; ++p, v = *p;
      Mary_Vector_Push_Back(v_32bit, &u32);
    }
    else if (v >> 5 == 0x06)
    { // 2 bytes
      u32  = (v ^ 0xC0) << 6; ++p, v = *p;
      u32 |= (v ^ 0x80)     ; ++p, v = *p;
      Mary_Vector_Push_Back(v_32bit, &u32);
    }
    else if (v >> 4 == 0x0E)
    { // 3 bytes
      u32  = (v ^ 0xE0) << 12; ++p, v = *p;
      u32 |= (v ^ 0x80) << 6 ; ++p, v = *p;
      u32 |= (v ^ 0x80)      ; ++p, v = *p;
      Mary_Vector_Push_Back(v_32bit, &u32);
    }
    else if (v >> 3 == 0x1E)
    { // 4 bytes
      u32  = (v ^ 0xF0) << 18; ++p, v = *p;
      u32 |= (v ^ 0x80) << 12; ++p, v = *p;
      u32 |= (v ^ 0x80) << 6 ; ++p, v = *p;
      u32 |= (v ^ 0x80)      ; ++p, v = *p;
      Mary_Vector_Push_Back(v_32bit, &u32);
    }
  }
  s_8bit->size = 0; s_8bit->unit = v_32bit->unit;
  Mary_Vector_Add_Slice((Mary_Vector_t *)s_8bit, 0, v_32bit->size);
  memcpy(s_8bit->data, v_32bit->data, v_32bit->size * v_32bit->unit);
  Mary_Vector_Destroy(v_32bit);
}

void Mary_String_16bit_to_8bit(Mary_String_t *s_16bit)
{
  Mary_Vector_t v_temp, *v_8bit = &v_temp;
  Mary_Vector_Create(v_8bit, 1, s_16bit->size);
  u16 *p = s_16bit->data, v = *p;
  u8 a, b, c, d; u32 u32, hi, lo;
  while (1)
  {
    if (v == 0x0)
    {
      a = 0;
      Mary_Vector_Push_Back(v_8bit, &a);
      break;
    }
    else if (v < 0x0080)
    { // bmp -> 1 byte
      a = (u8)v;
      ++p, v = *p;
      Mary_Vector_Push_Back(v_8bit, &a);
    }
    else if (v < 0x0800)
    { // bmp -> 2 byte
      a = 0xC0 | v >> 6;
      b = 0x80 | v & 0x3F;
      ++p, v = *p;
      Mary_Vector_Push_Back(v_8bit, &a);
      Mary_Vector_Push_Back(v_8bit, &b);
    }
    else if (v < 0xD800 || v > 0xDFFF)
    { // bmp -> 3 byte
      a = 0xE0 | v >> 12;
      b = 0x80 | v >> 6 & 0x3F;
      c = 0x80 | v & 0x3F;
      ++p, v = *p;
      Mary_Vector_Push_Back(v_8bit, &a);
      Mary_Vector_Push_Back(v_8bit, &b);
      Mary_Vector_Push_Back(v_8bit, &c);
    }
    else
    { // surrogates -> 4 byte
      hi = v - 0xD800 << 10; ++p, v = *p;
      lo = v - 0xDC00      ; ++p, v = *p;
      u32 = hi + lo + 0x10000;
      a = 0xF0 | u32 >> 18;
      b = 0x80 | u32 >> 12 & 0x3F;
      c = 0x80 | u32 >> 6 & 0x3F;
      d = 0x80 | u32 & 0x3F;
      Mary_Vector_Push_Back(v_8bit, &a);
      Mary_Vector_Push_Back(v_8bit, &b);
      Mary_Vector_Push_Back(v_8bit, &c);
      Mary_Vector_Push_Back(v_8bit, &d);
    }
  }
  s_16bit->size = 0; s_16bit->unit = v_8bit->unit;
  Mary_Vector_Add_Slice((Mary_Vector_t *)s_16bit, 0, v_8bit->size);
  memcpy(s_16bit->data, v_8bit->data, v_8bit->size * v_8bit->unit);
  Mary_Vector_Destroy(v_8bit);
}

void Mary_String_16bit_to_32bit(Mary_String_t *s_16bit)
{
  Mary_Vector_t v_temp, *v_32bit = &v_temp;
  Mary_Vector_Create(v_32bit, 4, s_16bit->size);
  u16 *p = s_16bit->data, v = *p;
  u32 u32; u16 hi, lo;
  while (1)
  {
    if (v == 0x00)
    { // null
      u32 = 0;
      Mary_Vector_Push_Back(v_32bit, &u32);
      break;
    }
    else if (v < 0xD800 || v > 0xDFFF)
    { // bmp
      u32 = v;
      ++p, v = *p;
      Mary_Vector_Push_Back(v_32bit, &u32);
    }
    else
    { // surrogates
      hi = v - 0xD800 << 10; ++p, v = *p;
      lo = v - 0xDC00      ; ++p, v = *p;
      u32 = hi + lo + 0x10000;
      Mary_Vector_Push_Back(v_32bit, &u32);
    }
  }
  s_16bit->size = 0; s_16bit->unit = v_32bit->unit;
  Mary_Vector_Add_Slice((Mary_Vector_t *)s_16bit, 0, v_32bit->size);
  memcpy(s_16bit->data, v_32bit->data, v_32bit->size * v_32bit->unit);
  Mary_Vector_Destroy(v_32bit);
}

void Mary_String_32bit_to_8bit(Mary_String_t *s_32bit)
{
  Mary_Vector_t v_temp, *v_8bit = &v_temp;
  Mary_Vector_Create(v_8bit, 1, s_32bit->size);
  u32 *p = s_32bit->data, v = *p;
  u8 a, b, c, d;
  while (1)
  {
    if (v == 0x0)
    {
      a = 0;
      Mary_Vector_Push_Back(v_8bit, &a);
      break;
    }
    else if (v < 0x0080)
    { // 1 byte
      a = v;
      ++p, v = *p;
      Mary_Vector_Push_Back(v_8bit, &a);
    }
    else if (v < 0x0800)
    { // 2 byte
      a = 0xC0 | v >> 6;
      b = 0x80 | v & 0x3F;
      ++p, v = *p;
      Mary_Vector_Push_Back(v_8bit, &a);
      Mary_Vector_Push_Back(v_8bit, &b);
    }
    else if (v < 0x10000)
    { // 3 byte
      a = 0xE0 | v >> 12;
      b = 0x80 | v >> 6 & 0x3F;
      c = 0x80 | v & 0x3F;
      ++p, v = *p;
      Mary_Vector_Push_Back(v_8bit, &a);
      Mary_Vector_Push_Back(v_8bit, &b);
      Mary_Vector_Push_Back(v_8bit, &c);
    }
    else if (v < 0x110000)
    { // 4 byte
      a = 0xF0 | v >> 18;
      b = 0x80 | v >> 12 & 0x3F;
      c = 0x80 | v >> 6 & 0x3F;
      d = 0x80 | v & 0x3F;
      ++p, v = *p;
      Mary_Vector_Push_Back(v_8bit, &a);
      Mary_Vector_Push_Back(v_8bit, &b);
      Mary_Vector_Push_Back(v_8bit, &c);
      Mary_Vector_Push_Back(v_8bit, &d);
    }
  }
  s_32bit->size = 0; s_32bit->unit = v_8bit->unit;
  Mary_Vector_Add_Slice((Mary_Vector_t *)s_32bit, 0, v_8bit->size);
  memcpy(s_32bit->data, v_8bit->data, v_8bit->size * v_8bit->unit);
  Mary_Vector_Destroy(v_8bit);
}

void Mary_String_32bit_to_16bit(Mary_String_t *s_32bit)
{
  Mary_Vector_t v_temp, *v_16bit = &v_temp;
  Mary_Vector_Create(v_16bit, 2, s_32bit->size);
  u32 *p = s_32bit->data, v = *p;
  u16 a, b;
  while (1)
  {
    if (v == 0)
    { // null
      a = v;
      Mary_Vector_Push_Back(v_16bit, &a);
      break;
    }
    else if (v < 0x10000)
    { // bmp
      a = v;
      ++p, v = *p;
      Mary_Vector_Push_Back(v_16bit, &a);
    }
    else
    { // surrogates
      v -= 0x10000;
      a = (v >> 10)   + 0xD800;
      b = (v & 0x3FF) + 0xDC00;
      ++p, v = *p;
      Mary_Vector_Push_Back(v_16bit, &a);
      Mary_Vector_Push_Back(v_16bit, &b);
    }
  }
  s_32bit->size = 0; s_32bit->unit = v_16bit->unit;
  Mary_Vector_Add_Slice((Mary_Vector_t *)s_32bit, 0, v_16bit->size);
  memcpy(s_32bit->data, v_16bit->data, v_16bit->size * v_16bit->unit);
  Mary_Vector_Destroy(v_16bit);
}

void Mary_String_8bit_Match(Mary_String_t *mary_string, Mary_String_t *regex)
{
  // needs to return an object. Mary_Regex_t?
  MARY_Range(regex->data, u8, 0, regex->size)
  {

  }
}

void Mary_String_8bit_Replace(Mary_String_t *mary_string, u8 *regex, u8 *replacement)
{

}

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <Mary/Utils.h>
#include <Mary/Vector.h>
#include <Mary/Bitbool.h>
#include <Mary/Font_old.h>

#define intern static

#define UNICODE_PLAT 0
#define UNICODE_SPEC_DEF 0
#define UNICODE_SPEC_1 1
#define UNICODE_SPEC_BMP 3
#define UNICODE_SPEC_2 4
#define UNICODE_SPEC_VAR 5
#define UNICODE_SPEC_FULL 6
#define UNICODE_LANG_DEF 0

#define MICROSOFT_PLAT 3
#define MICROSOFT_SPEC_BMP 1
#define MICROSOFT_LANG_EN_US 0x0409

#define RASTER_TRUETYPE 0x74727565
#define RASTER_POSTSCRIPT 0x74797031
#define RASTER_OPENTYPE_TTF 0x00010000
#define RASTER_OPENTYPE_CFF 0x4F54544F

#define NAME_COPYRIGHT 0
#define NAME_FAMILY 1
#define NAME_SUB 3
#define NAME_UNIQUE 3
#define NAME_FULL 4

#define GLYF_ON_CURVE 0x01
#define GLYF_X_IS_BYTE 0x02
#define GLYF_Y_IS_BYTE 0x04
#define GLYF_REPEAT_FLAG 0x08
#define GLYF_X_IS_PSTV 0x10
#define GLYF_Y_IS_PSTV 0x20
#define GLYF_X_IS_SAME 0x10
#define GLYF_Y_IS_SAME 0x20

void Mary_Font_Start();
void Mary_Font_Finish();
void Mary_Font_Create(Mary_Font_t *mary_font, char *file_path);
void Mary_Font_Destroy(Mary_Font_t *mary_font);
intern uint32_t Cmap_Format_12(Mary_Font_t *mary_font, uint32_t unicode);
intern void Glyph(Mary_Font_t *mary_font, uint32_t unicode);

intern uint8_t should_swap = 1;
#define GET_U16(P) (should_swap ? MARY_SWAP_16(*(uint16_t *)(P)) : *(uint16_t *)(P))
#define GET_U32(P) (should_swap ? MARY_SWAP_32(*(uint32_t *)(P)) : *(uint32_t *)(P))
#define GET_S16(P) (should_swap ? MARY_SWAP_16(*( int16_t *)(P)) : *( int16_t *)(P))
#define GET_S32(P) (should_swap ? MARY_SWAP_32(*( int32_t *)(P)) : *( int32_t *)(P))

void Mary_Font_Start()
{
  // ttf and otf are always big endian, so we match it
  volatile uint16_t i = 0x0001; // volatile = always check from main memory
  if (*(uint8_t *)&i == 1)
  {
    should_swap = 1;
  }
  else
  {
    should_swap = 0;
  }
}

void Mary_Font_Finish()
{

}

void Mary_Font_Create(Mary_Font_t *mary_font, char *file_path)
{
  Mary_File_t mary_file = Mary_File_Read(file_path);
  uint8_t *beginning = mary_file.data;
  mary_font->data = beginning;

  ////// Beginning
  {
    uint8_t *p = beginning;
    uint32_t rasterizer = GET_U32(p); p += 4;
    char should_stop =
      rasterizer != RASTER_TRUETYPE &&
      rasterizer != RASTER_POSTSCRIPT &&
      rasterizer != RASTER_OPENTYPE_TTF &&
      rasterizer != RASTER_OPENTYPE_CFF;
    if (should_stop)
    {
      Mary_Exit_Failure("Mary_Font_Create: I don't think this is a ttf or otf file.");
    }

    uint16_t num_tables = GET_U16(p); p += 8;
    Mary_Hashmap_t *tables = &mary_font->tables;
    Mary_Hashmap_Create(tables, 5, sizeof(p));
    char tag[5]; memset(tag, 0, 5);
    for (int i = 0; i < num_tables; ++i)
    {
      memcpy(tag, p, 4); p += 8;
      uint32_t offset = GET_U32(p); p += 8;
      uint8_t *table_start = beginning + offset;
      Mary_Hashmap_Insert(tables, tag, &table_start);
      printf("%s: %p\n", tag, table_start); // temp
    }

    // we should also do a general check for what tables exist.
    // Mary_Hashmap_Contains_Key will be useful, and fast!
  }

  ////// 'name' Table
  {
    uint8_t *p; Mary_Hashmap_At(&mary_font->tables, "name", &p);
    uint8_t *beginning = p; p += 2;
    uint16_t strings_count = GET_U16(p); p += 2;
    uint16_t strings_offset = GET_U16(p); p += 2;
    char has_name = 0; char has_copyright = 0;
    for (int i = 0; i < strings_count; ++i)
    {
      uint16_t plat = GET_U16(p); p += 2;
      uint16_t spec = GET_U16(p); p += 2;
      uint16_t lang = GET_U16(p); p += 2;
      uint16_t name = GET_U16(p); p += 2;
      uint16_t length = GET_U16(p); p += 2;
      uint16_t offset = GET_U16(p); p += 2;
      //printf("p:%i s:%i l:%i n:%i l:%i o:%i\n", plat, spec, lang, name, length, offset); //
      char is_unicode =
        plat == UNICODE_PLAT &&
        spec == UNICODE_SPEC_DEF &&
        lang == UNICODE_LANG_DEF;
      char is_microsoft =
        plat == MICROSOFT_PLAT &&
        spec == MICROSOFT_SPEC_BMP &&
        lang == MICROSOFT_LANG_EN_US;
      if (is_unicode || is_microsoft)
      {
        if (!has_name && name == NAME_FULL || !has_copyright && name == NAME_COPYRIGHT)
        {
          Mary_Vector_t v_string;
          Mary_Vector_Create(&v_string, 2, 32);
          uint8_t *p2 = beginning + strings_offset + offset;
          uint16_t codepoint;
          for (int j = 0; j < length; j +=2)
          {
            codepoint = GET_U16(p2); p2 += 2;
            Mary_Vector_Push_Back(&v_string, &codepoint);
          }
          codepoint = 0; Mary_Vector_Push_Back(&v_string, &codepoint);
          Mary_Vector_Fit(&v_string);
          if (name == NAME_FULL)
          {
            has_name = 1;
            mary_font->name = v_string.data;
          }
          else
          {
            has_copyright = 1;
            mary_font->copyright = v_string.data;
          }
        }
      }
    }
  }

  ////// 'head' table
  {
    // this table may not exist for some kinds of fonts
    uint8_t *p; Mary_Hashmap_At(&mary_font->tables, "head", &p);
    uint8_t *beginning = p; p += 16;
    uint16_t flags = GET_U16(p); p += 2;
    uint16_t units_per_em = GET_U16(p); p += 18;
    int16_t x_min = GET_S16(p); p += 2;
    int16_t y_min = GET_S16(p); p += 2;
    int16_t x_max = GET_S16(p); p += 2;
    int16_t y_max = GET_S16(p); p += 2;
    uint16_t mac_style = GET_U16(p); p += 2;
    uint16_t lowest_pix_size = GET_U16(p); p += 2;
    int16_t direction_hint = GET_S16(p); p += 2;
    int16_t long_loca = GET_S16(p); p += 2;
    int16_t data_format = GET_S16(p); p += 2;
    mary_font->long_loca = (uint8_t)long_loca;
    mary_font->units_per_em = units_per_em;
  }

  ////// 'hhea' table
  {
    uint8_t *p; Mary_Hashmap_At(&mary_font->tables, "hhea", &p); p += 4;
    int16_t ascent = GET_S16(p); p += 2;
    int16_t descent = GET_S16(p); p += 2;
    int16_t line_gap = GET_S16(p); p += 2;
    mary_font->ascent = ascent;
    mary_font->descent = descent;
  }

  ////// 'cmap' table
  {
    uint8_t *p; Mary_Hashmap_At(&mary_font->tables, "cmap", &p);
    uint8_t *beginning = p;
    uint16_t version = GET_U16(p); p += 2;
    uint16_t num_tables = GET_U16(p); p += 2;
    uint8_t *cmap = 0;
    for (int i = 0; i < num_tables; ++i)
    {
      uint16_t platform = GET_U16(p); p += 2;
      uint16_t encoding = GET_U16(p); p += 2;
      uint32_t offset = GET_U32(p); p += 4;
      //printf("platform:%i, encoding:%i, offset:%i\n", platform, encoding, offset);
      if (platform == UNICODE_PLAT && encoding == UNICODE_SPEC_2)
      {
        cmap = beginning + offset;
        uint16_t format = GET_U16(cmap);
        if (format == 12)
        {
          mary_font->cmap = cmap;
          mary_font->Glyph_Index = Cmap_Format_12;
        }
        // add more
        break;
      }
      // add more types.
    }
    if (!cmap)
    {
      Mary_Exit_Failure("Mary_Font_Create: couldn't find a good cmap.");
    }
  }

  Glyph(mary_font, '-');
}

void Mary_Font_Destroy(Mary_Font_t *mary_font)
{
  free(mary_font->data);
  Mary_Hashmap_Destroy(&mary_font->tables);
  free((void *)mary_font->name);
  free((void *)mary_font->copyright);
}

intern uint32_t Cmap_Format_12(Mary_Font_t *mary_font, uint32_t unicode)
{
  // this should do a string of unicodes at a time
  uint8_t *cmap = mary_font->cmap;
  uint8_t *p = cmap; p += 4;
  uint32_t length = GET_U32(p); p += 8;
  uint32_t num_groups = GET_U32(p); p += 4;
  uint32_t glyph_code = 0;
  for (size_t i = 0; i < num_groups; ++i)
  {
    uint32_t char_start_code = GET_U32(p); p += 4;
    uint32_t char_end_code = GET_U32(p); p += 4;
    uint32_t glyph_start_code = GET_U32(p); p += 4;
    //printf("start:%i...end:%i\n", char_start_code, char_end_code);
    if (unicode < char_start_code)
    {
      break;
    }
    else if (unicode > char_end_code)
    {
      continue;
    }
    else if (unicode == char_start_code)
    {
      glyph_code = glyph_start_code;
      break;
    }
    else if (unicode == char_end_code)
    {
      glyph_code = char_end_code - char_start_code + glyph_start_code;
      break;
    }
    else
    {
      uint32_t char_mid_code = char_start_code + 1;
      while (unicode != char_mid_code) ++char_mid_code;
      glyph_code = char_mid_code - char_start_code + glyph_start_code;
      break;
    }
  }
  return glyph_code;
}

typedef struct
{
  int16_t x_coord;
  int16_t y_coord;
}
Point;

intern void Glyph(Mary_Font_t *mary_font, uint32_t unicode)
{
  // will want to switch unicode to glyph index in the future
  uint8_t loca_unit = (mary_font->long_loca) ? 4 : 2;
  uint32_t index = mary_font->Glyph_Index(mary_font, unicode);
  uint8_t *p; Mary_Hashmap_At(&mary_font->tables, "loca", &p); p += index * loca_unit;
  uint32_t offset = (loca_unit == 4) ? GET_U32(p) : (uint32_t)GET_U16(p); p += loca_unit;
  uint32_t next_offset = (loca_unit == 4) ? GET_U32(p) : (uint32_t)GET_U16(p);

  Mary_Hashmap_At(&mary_font->tables, "glyf", &p);
  int8_t *glyf_table = p; p += offset;
  int16_t num_contours = GET_S16(p); p += 2;
  int16_t x_min = GET_S16(p); p += 2;
  int16_t y_min = GET_S16(p); p += 2;
  int16_t x_max = GET_S16(p); p += 2;
  int16_t y_max = GET_S16(p); p += 2;

  if (num_contours > 0)
  {
    ////// Simple Glyph
    uint16_t *end_pts_of_contours = (uint16_t *)p; p += 2 * num_contours;
    uint16_t num_points = (GET_U16(end_pts_of_contours + num_contours - 1)) + 1;

    uint16_t instruction_length = GET_U16(p); p += 2;
    uint8_t *instructions = 0;
    if (instruction_length)
    {
      instructions = p; p += 1 * instruction_length;
    }

    uint8_t *flags = malloc(sizeof(uint8_t) * num_points);
    for (int i = 0; i < num_points;)
    {
      uint8_t point_flags = *p; p += 1;
      memcpy(flags + i, &point_flags, 1); i += 1;
      if (point_flags & GLYF_REPEAT_FLAG)
      {
        uint8_t times = *p; p += 1;
        for (int t = 0; t < times; ++t)
        {
          memcpy(flags + i, &point_flags, 1); i += 1;
        }
      }
    }

    int16_t *x_coords = malloc(sizeof(int16_t) * num_points);
    for (int i = 0; i < num_points; ++i)
    {
      uint8_t fs = flags[i]; int16_t x_coord;
      if (fs & GLYF_X_IS_BYTE)
      {
        if (fs & GLYF_X_IS_PSTV)
          x_coord = *p, p += 1;
        else
          x_coord = -*p, p += 1;
      }
      else
      {
        if (fs & GLYF_X_IS_SAME)
          x_coord = 0;
        else
          x_coord = GET_S16(p), p += 2;
      }
      memcpy(x_coords + i, &x_coord, 2);
    }

    int16_t *y_coords = malloc(sizeof(int16_t) * num_points);
    for (int i = 0; i < num_points; ++i)
    {
      uint8_t fs = flags[i]; int16_t y_coord;
      if (fs & GLYF_Y_IS_BYTE)
      {
        if (fs & GLYF_Y_IS_PSTV)
          y_coord = *p, p += 1;
        else
          y_coord = -*p, p += 1;
      }
      else
      {
        if (fs & GLYF_Y_IS_SAME)
          y_coord = 0;
        else
          y_coord = GET_S16(p), p += 2;
      }
      memcpy(y_coords + i, &y_coord, 2);
    }
    // we now how the master outline deltas

    int x = 0, y = 0;
    for (int i = 0; i < num_points; ++i)
    {
      x += x_coords[i];
      y += y_coords[i];
      printf("[x:%6i, y:%6i, on: %i]\n", x, y, flags[i] & GLYF_ON_CURVE);
    }

    float pixels = 16.0f;
    float scale = pixels / (mary_font->ascent - mary_font->descent);
    printf("%fpx scale:%f\n", pixels, scale);

    float fx = 0.0f, fy = 0.0f;
    for (int i = 0; i < num_points; ++i)
    {
      fx += x_coords[i] * scale;
      fy += y_coords[i] * scale;
      printf("[x:%10f, y:%10f, on: %i]\n", fx, fy, flags[i] & GLYF_ON_CURVE);
    }

    // remember, you have to close contours yourself,
    // it doesn't add an extra point for you.

    free(y_coords);
    free(x_coords);
    free(flags);
  }
  else
  {
    ////// Composite Glyph
  }
}

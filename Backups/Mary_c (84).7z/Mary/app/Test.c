﻿#include <stdio.h>
#include <stdlib.h>
#include <Mary/Mary.h>
#include <Mary/App/Test.h>

MARY_Primitives;

#define TEST_START(FUNC_NAME)\
  printf("Running '%s'...", #FUNC_NAME)
#define TEST_FINISH\
  printf(" Ok!\n")

////// Pool_t //////

void Test_Mary_Pool_Reallocate()
{
  // this could be a lot more thorough!
  TEST_START(Test_Mary_Pool_Reallocate);

  U bytes = 1024;
  Mary_Pool_t *pool = Mary_Pool_Create(bytes);
  void *p1, *p2, *p3; U free;

  free = bytes;
  p1 = Mary_Pool_Alloc(pool, 8); free -= 8;
  p2 = Mary_Pool_Realloc(pool, p1, 8);
  MARY_Assert(free = pool->free && p1 == p2, 0);
  Mary_Pool_Empty(pool);

  free = bytes;
  p1 = Mary_Pool_Alloc(pool, 8); free -= 8;
  p2 = Mary_Pool_Realloc(pool, p1, 9); free -= 8;
  MARY_Assert(free = pool->free && p1 == p2, 0);
  Mary_Pool_Empty(pool);

  free = bytes;
  p1 = Mary_Pool_Alloc(pool, 8); free -= 8;
  p2 = Mary_Pool_Realloc(pool, p1, 16); free -= 8;
  MARY_Assert(free = pool->free && p1 == p2, 0);
  Mary_Pool_Empty(pool);

  free = bytes;
  p1 = Mary_Pool_Alloc(pool, 8); free -= 8;
  p2 = Mary_Pool_Realloc(pool, p1, 7);
  MARY_Assert(free = pool->free && p1 == p2, 0);
  Mary_Pool_Empty(pool);

  free = bytes;
  p1 = Mary_Pool_Alloc(pool, 8); free -= 8;
  p2 = Mary_Pool_Realloc(pool, p1, 1);
  MARY_Assert(free = pool->free && p1 == p2, 0);
  Mary_Pool_Empty(pool);

  free = bytes;
  p1 = Mary_Pool_Alloc(pool, 8); free -= 8;
  p2 = Mary_Pool_Alloc(pool, 8); free -= 8;
  p3 = Mary_Pool_Realloc(pool, p1, 8);
  MARY_Assert(free = pool->free && p1 == p3 && p1 != p2, 0);
  Mary_Pool_Empty(pool);

  free = bytes;
  p1 = Mary_Pool_Alloc(pool, 8); free -= 8;
  p2 = Mary_Pool_Alloc(pool, 8); free -= 8;
  p3 = Mary_Pool_Realloc(pool, p1, 12); free -= 8;
  MARY_Assert(free = pool->free && p1 != p3 && p3 != p2, 0);
  Mary_Pool_Empty(pool);

  TEST_FINISH;
}

////// String_t //////

void Test_MARY_String()
{
  Mary_String_t empt = { 0, 0, 0, 0, 0, 0 };
  MARY_String(test, MARY_HEAP, u8, "test");
  printf("bytes: %llu, unit: %llu, units: %llu, codes: %llu, flags: %llu, %s\n",
         test.bytes, test.unit, test.units, test.codes, test.flags, (char *)test.data);
}

void Test_String_Create()
{
  TEST_START(Test_String_Create);

  Mary_String_t str;
  Mary_String_Create(&str, MARY_UTF_8, 8);
  MARY_Assert(str.data != 0, 0);
  MARY_Assert(str.bytes == 8, 0);
  MARY_Assert(str.unit == 1, 0);
  MARY_Assert(str.units == 1, 0);
  MARY_Assert(str.codes == 1, 0);
  Mary_String_Destroy(&str);
  Mary_String_Create(&str, MARY_UTF_16, 4);
  MARY_Assert(str.data != 0, 0);
  MARY_Assert(str.bytes == 8, 0);
  MARY_Assert(str.unit == 2, 0);
  MARY_Assert(str.units == 1, 0);
  MARY_Assert(str.codes == 1, 0);
  Mary_String_Destroy(&str);
  Mary_String_Create(&str, MARY_UTF_32, 2);
  MARY_Assert(str.data != 0, 0);
  MARY_Assert(str.bytes == 8, 0);
  MARY_Assert(str.unit == 4, 0);
  MARY_Assert(str.units == 1, 0);
  MARY_Assert(str.codes == 1, 0);
  Mary_String_Destroy(&str);

  TEST_FINISH;
}

void Test_String_Recode()
{
  #define CODE_0 97
  #define CODE_1 977
  #define CODE_2 9777
  #define CODE_3 97777
  #define CODE_4 0

  TEST_START(Test_String_Recode);

  Mary_C_String_t c_str = MARY_C_String(u32, "aϑ☱𗷱");
  Mary_String_t str;

  Mary_String_Create_With_C_String(&str, MARY_UTF_32, c_str, 0);
  MARY_String_Each_UTF_32(&str)
  {
    if      (it.code_idx == 0) MARY_Assert(it.utf_32 == CODE_0, 0);
    else if (it.code_idx == 1) MARY_Assert(it.utf_32 == CODE_1, 0);
    else if (it.code_idx == 2) MARY_Assert(it.utf_32 == CODE_2, 0);
    else if (it.code_idx == 3) MARY_Assert(it.utf_32 == CODE_3, 0);
    else                       MARY_Assert(it.utf_32 == CODE_4, 0);
  }
  Mary_String_Recode(&str, MARY_UTF_8);
  MARY_String_Each_UTF_8_To_32(&str)
  {
    if      (it.code_idx == 0) MARY_Assert(it.utf_32 == CODE_0, 0);
    else if (it.code_idx == 1) MARY_Assert(it.utf_32 == CODE_1, 0);
    else if (it.code_idx == 2) MARY_Assert(it.utf_32 == CODE_2, 0);
    else if (it.code_idx == 3) MARY_Assert(it.utf_32 == CODE_3, 0);
    else                       MARY_Assert(it.utf_32 == CODE_4, 0);
  }
  Mary_String_Recode(&str, MARY_UTF_32);
  MARY_String_Each_UTF_32(&str)
  {
    if      (it.code_idx == 0) MARY_Assert(it.utf_32 == CODE_0, 0);
    else if (it.code_idx == 1) MARY_Assert(it.utf_32 == CODE_1, 0);
    else if (it.code_idx == 2) MARY_Assert(it.utf_32 == CODE_2, 0);
    else if (it.code_idx == 3) MARY_Assert(it.utf_32 == CODE_3, 0);
    else                       MARY_Assert(it.utf_32 == CODE_4, 0);
  }
  Mary_String_Recode(&str, MARY_UTF_16);
  MARY_String_Each_UTF_16_To_32(&str)
  {
    if      (it.code_idx == 0) MARY_Assert(it.utf_32 == CODE_0, 0);
    else if (it.code_idx == 1) MARY_Assert(it.utf_32 == CODE_1, 0);
    else if (it.code_idx == 2) MARY_Assert(it.utf_32 == CODE_2, 0);
    else if (it.code_idx == 3) MARY_Assert(it.utf_32 == CODE_3, 0);
    else                       MARY_Assert(it.utf_32 == CODE_4, 0);
  }
  Mary_String_Recode(&str, MARY_UTF_8);
  MARY_String_Each_UTF_8_To_32(&str)
  {
    if      (it.code_idx == 0) MARY_Assert(it.utf_32 == CODE_0, 0);
    else if (it.code_idx == 1) MARY_Assert(it.utf_32 == CODE_1, 0);
    else if (it.code_idx == 2) MARY_Assert(it.utf_32 == CODE_2, 0);
    else if (it.code_idx == 3) MARY_Assert(it.utf_32 == CODE_3, 0);
    else                       MARY_Assert(it.utf_32 == CODE_4, 0);
  }
  Mary_String_Recode(&str, MARY_UTF_16);
  MARY_String_Each_UTF_16_To_32(&str)
  {
    if      (it.code_idx == 0) MARY_Assert(it.utf_32 == CODE_0, 0);
    else if (it.code_idx == 1) MARY_Assert(it.utf_32 == CODE_1, 0);
    else if (it.code_idx == 2) MARY_Assert(it.utf_32 == CODE_2, 0);
    else if (it.code_idx == 3) MARY_Assert(it.utf_32 == CODE_3, 0);
    else                       MARY_Assert(it.utf_32 == CODE_4, 0);
  }
  Mary_String_Recode(&str, MARY_UTF_32);
  MARY_String_Each_UTF_32(&str)
  {
    if      (it.code_idx == 0) MARY_Assert(it.utf_32 == CODE_0, 0);
    else if (it.code_idx == 1) MARY_Assert(it.utf_32 == CODE_1, 0);
    else if (it.code_idx == 2) MARY_Assert(it.utf_32 == CODE_2, 0);
    else if (it.code_idx == 3) MARY_Assert(it.utf_32 == CODE_3, 0);
    else                       MARY_Assert(it.utf_32 == CODE_4, 0);
  }

  TEST_FINISH;

  #undef CODE_0
  #undef CODE_1
  #undef CODE_2
  #undef CODE_3
  #undef CODE_4
}

void Test_String_Loops()
{
  TEST_START(Test_String_Loops);

  Mary_C_String_8_t c_str = MARY_C_String(u8, "aϑ☱𗷱");
  Mary_String_t str;

  #define CODE_0 97
  #define CODE_1 977
  #define CODE_2 9777
  #define CODE_3 97777
  #define CODE_4 0

  #define UTF_8_0                          \
    MARY_Assert(it.utf_8.code == CODE_0, 0);  \
    MARY_Assert(it.utf_8.units == 1, 0);      \
    MARY_Assert(it.utf_8.a == 97, 0)

  #define UTF_8_1                          \
    MARY_Assert(it.utf_8.code == CODE_1, 0);  \
    MARY_Assert(it.utf_8.units == 2, 0);      \
    MARY_Assert(it.utf_8.a == 207, 0);        \
    MARY_Assert(it.utf_8.b == 145, 0)

  #define UTF_8_2                          \
    MARY_Assert(it.utf_8.code == CODE_2, 0);  \
    MARY_Assert(it.utf_8.units == 3, 0);      \
    MARY_Assert(it.utf_8.a == 226, 0);        \
    MARY_Assert(it.utf_8.b == 152, 0);        \
    MARY_Assert(it.utf_8.c == 177, 0)

  #define UTF_8_3                          \
    MARY_Assert(it.utf_8.code == CODE_3, 0);  \
    MARY_Assert(it.utf_8.units == 4, 0);      \
    MARY_Assert(it.utf_8.a == 240, 0);        \
    MARY_Assert(it.utf_8.b == 151, 0);        \
    MARY_Assert(it.utf_8.c == 183, 0);        \
    MARY_Assert(it.utf_8.d == 177, 0)

  #define UTF_8_4                          \
    MARY_Assert(it.utf_8.code == CODE_4, 0);  \
    MARY_Assert(it.utf_8.units == 1, 0);      \
    MARY_Assert(it.utf_8.a == 0, 0)

  #define UTF_16_0                         \
    MARY_Assert(it.utf_16.code == CODE_0, 0); \
    MARY_Assert(it.utf_16.units == 1, 0);     \
    MARY_Assert(it.utf_16.a == 97, 0)

  #define UTF_16_1                         \
    MARY_Assert(it.utf_16.code == CODE_1, 0); \
    MARY_Assert(it.utf_16.units == 1, 0);     \
    MARY_Assert(it.utf_16.a == 977, 0)

  #define UTF_16_2                         \
    MARY_Assert(it.utf_16.code == CODE_2, 0); \
    MARY_Assert(it.utf_16.units == 1, 0);     \
    MARY_Assert(it.utf_16.a == 9777, 0)

  #define UTF_16_3                         \
    MARY_Assert(it.utf_16.code == CODE_3, 0); \
    MARY_Assert(it.utf_16.units == 2, 0);     \
    MARY_Assert(it.utf_16.a == 0xD81F, 0);    \
    MARY_Assert(it.utf_16.b == 0xDDF1, 0)

  #define UTF_16_4                         \
    MARY_Assert(it.utf_16.code == CODE_4, 0); \
    MARY_Assert(it.utf_16.units == 1, 0);     \
    MARY_Assert(it.utf_16.a == 0, 0)

  #define UTF_32_0                         \
    MARY_Assert(it.utf_32 == CODE_0, 0)

  #define UTF_32_1                         \
    MARY_Assert(it.utf_32 == CODE_1, 0)

  #define UTF_32_2                         \
    MARY_Assert(it.utf_32 == CODE_2, 0)

  #define UTF_32_3                         \
    MARY_Assert(it.utf_32 == CODE_3, 0)

  #define UTF_32_4                         \
    MARY_Assert(it.utf_32 == CODE_4, 0)

  Mary_String_Create_With_C_String(&str, MARY_UTF_8, c_str, 0);

  MARY_String_Each_UTF_8(&str)
  {
    MARY_Assert(it.string == &str, 0);
    MARY_Assert(it.string->units == 11, 0);
    MARY_Assert(it.codes == 5, 0);
    if (it.code_idx == 0)
    {
      MARY_Assert(it.unit_idx == 0, 0);
      UTF_8_0;
    }
    else if (it.code_idx == 1)
    {
      MARY_Assert(it.unit_idx == 1, 0);
      UTF_8_1;
    }
    else if (it.code_idx == 2)
    {
      MARY_Assert(it.unit_idx == 3, 0);
      UTF_8_2;
    }
    else if (it.code_idx == 3)
    {
      MARY_Assert(it.unit_idx == 6, 0);
      UTF_8_3;
    }
    else
    {
      MARY_Assert(it.unit_idx == 10, 0);
      UTF_8_4;
    }
  }

  MARY_String_Each_UTF_8_To_16(&str)
  {
    MARY_Assert(it.string == &str, 0);
    MARY_Assert(it.string->units == 11, 0);
    MARY_Assert(it.codes == 5, 0);
    if (it.code_idx == 0)
    {
      MARY_Assert(it.unit_idx == 0, 0);
      UTF_8_0;
      UTF_16_0;
    }
    else if (it.code_idx == 1)
    {
      MARY_Assert(it.unit_idx == 1, 0);
      UTF_8_1;
      UTF_16_1;
    }
    else if (it.code_idx == 2)
    {
      MARY_Assert(it.unit_idx == 3, 0);
      UTF_8_2;
      UTF_16_2;
    }
    else if (it.code_idx == 3)
    {
      MARY_Assert(it.unit_idx == 6, 0);
      UTF_8_3;
      UTF_16_3;
    }
    else
    {
      MARY_Assert(it.unit_idx == 10, 0);
      UTF_8_4;
      UTF_16_4;
    }
  }

  MARY_String_Each_UTF_8_To_32(&str)
  {
    MARY_Assert(it.string == &str, 0);
    MARY_Assert(it.string->units == 11, 0);
    MARY_Assert(it.codes == 5, 0);
    if (it.code_idx == 0)
    {
      MARY_Assert(it.unit_idx == 0, 0);
      UTF_8_0;
      UTF_32_0;
    }
    else if (it.code_idx == 1)
    {
      MARY_Assert(it.unit_idx == 1, 0);
      UTF_8_1;
      UTF_32_1;
    }
    else if (it.code_idx == 2)
    {
      MARY_Assert(it.unit_idx == 3, 0);
      UTF_8_2;
      UTF_32_2;
    }
    else if (it.code_idx == 3)
    {
      MARY_Assert(it.unit_idx == 6, 0);
      UTF_8_3;
      UTF_32_3;
    }
    else
    {
      MARY_Assert(it.unit_idx == 10, 0);
      UTF_8_4;
      UTF_32_4;
    }
  }

  Mary_String_Recode(&str, MARY_UTF_16);

  MARY_String_Each_UTF_16(&str)
  {
    MARY_Assert(it.string == &str, 0);
    MARY_Assert(it.string->units == 6, 0);
    MARY_Assert(it.codes == 5, 0);
    if (it.code_idx == 0)
    {
      MARY_Assert(it.unit_idx == 0, 0);
      UTF_16_0;
    }
    else if (it.code_idx == 1)
    {
      MARY_Assert(it.unit_idx == 1, 0);
      UTF_16_1;
    }
    else if (it.code_idx == 2)
    {
      MARY_Assert(it.unit_idx == 2, 0);
      UTF_16_2;
    }
    else if (it.code_idx == 3)
    {
      MARY_Assert(it.unit_idx == 3, 0);
      UTF_16_3;
    }
    else
    {
      MARY_Assert(it.unit_idx == 5, 0);
      UTF_16_4;
    }
  }

  MARY_String_Each_UTF_16_To_8(&str)
  {
    MARY_Assert(it.string == &str, 0);
    MARY_Assert(it.string->units == 6, 0);
    MARY_Assert(it.codes == 5, 0);
    if (it.code_idx == 0)
    {
      MARY_Assert(it.unit_idx == 0, 0);
      UTF_16_0;
      UTF_8_0;
    }
    else if (it.code_idx == 1)
    {
      MARY_Assert(it.unit_idx == 1, 0);
      UTF_16_1;
      UTF_8_1;
    }
    else if (it.code_idx == 2)
    {
      MARY_Assert(it.unit_idx == 2, 0);
      UTF_16_2;
      UTF_8_2;
    }
    else if (it.code_idx == 3)
    {
      MARY_Assert(it.unit_idx == 3, 0);
      UTF_16_3;
      UTF_8_3;
    }
    else
    {
      MARY_Assert(it.unit_idx == 5, 0);
      UTF_16_4;
      UTF_8_4;
    }
  }

  MARY_String_Each_UTF_16_To_32(&str)
  {
    MARY_Assert(it.string == &str, 0);
    MARY_Assert(it.string->units == 6, 0);
    MARY_Assert(it.codes == 5, 0);
    if (it.code_idx == 0)
    {
      MARY_Assert(it.unit_idx == 0, 0);
      UTF_16_0;
      UTF_32_0;
    }
    else if (it.code_idx == 1)
    {
      MARY_Assert(it.unit_idx == 1, 0);
      UTF_16_1;
      UTF_32_1;
    }
    else if (it.code_idx == 2)
    {
      MARY_Assert(it.unit_idx == 2, 0);
      UTF_16_2;
      UTF_32_2;
    }
    else if (it.code_idx == 3)
    {
      MARY_Assert(it.unit_idx == 3, 0);
      UTF_16_3;
      UTF_32_3;
    }
    else
    {
      MARY_Assert(it.unit_idx == 5, 0);
      UTF_16_4;
      UTF_32_4;
    }
  }

  Mary_String_Recode(&str, MARY_UTF_32);

  MARY_String_Each_UTF_32(&str)
  {
    MARY_Assert(it.string == &str, 0);
    MARY_Assert(it.string->units == 5, 0);
    MARY_Assert(it.codes == 5, 0);
    if (it.code_idx == 0)
    {
      UTF_32_0;
    }
    else if (it.code_idx == 1)
    {
      UTF_32_1;
    }
    else if (it.code_idx == 2)
    {
      UTF_32_2;
    }
    else if (it.code_idx == 3)
    {
      UTF_32_3;
    }
    else
    {
      UTF_32_4;
    }
  }

  MARY_String_Each_UTF_32_To_8(&str)
  {
    MARY_Assert(it.string == &str, 0);
    MARY_Assert(it.string->units == 5, 0);
    MARY_Assert(it.codes == 5, 0);
    if (it.code_idx == 0)
    {
      UTF_32_0;
      UTF_8_0;
    }
    else if (it.code_idx == 1)
    {
      UTF_32_1;
      UTF_8_1;
    }
    else if (it.code_idx == 2)
    {
      UTF_32_2;
      UTF_8_2;
    }
    else if (it.code_idx == 3)
    {
      UTF_32_3;
      UTF_8_3;
    }
    else
    {
      UTF_32_4;
      UTF_8_4;
    }
  }

  MARY_String_Each_UTF_32_To_16(&str)
  {
    MARY_Assert(it.string == &str, 0);
    MARY_Assert(it.string->units == 5, 0);
    MARY_Assert(it.codes == 5, 0);
    if (it.code_idx == 0)
    {
      UTF_32_0;
      UTF_16_0;
    }
    else if (it.code_idx == 1)
    {
      UTF_32_1;
      UTF_16_1;
    }
    else if (it.code_idx == 2)
    {
      UTF_32_2;
      UTF_16_2;
    }
    else if (it.code_idx == 3)
    {
      UTF_32_3;
      UTF_16_3;
    }
    else
    {
      UTF_32_4;
      UTF_16_4;
    }
  }

  TEST_FINISH;

  #undef CODE_0
  #undef CODE_1
  #undef CODE_2
  #undef CODE_3
  #undef CODE_4

  #undef UTF_8_0
  #undef UTF_8_1
  #undef UTF_8_2
  #undef UTF_8_3
  #undef UTF_8_4

  #undef UTF_16_0
  #undef UTF_16_1
  #undef UTF_16_2
  #undef UTF_16_3
  #undef UTF_16_4

  #undef UTF_32_0
  #undef UTF_32_1
  #undef UTF_32_2
  #undef UTF_32_3
  #undef UTF_32_4
}

void Test_String_Recode_Speed()
{
  u8 *c_str = MARY_C_String(u8, "aϑ☱𗷱");
  Mary_String_t str;
  Mary_String_Create_With_C_String(&str, MARY_UTF_8, c_str, 0);
  for (u64 i = 0; i < 0x2000; ++i)
  {
    Mary_String_Append_C_String(&str, c_str, MARY_UTF_8, 11);
  }
  for (u64 i = 0; i < 16; ++i)
  {
    MARY_Benchmark(Mary_String_Recode(&str, 32), 1);
    Mary_String_Recode(&str, 8);
  }
}

void Test_String_Copy_To()
{
  u8 array[11];
  Mary_C_String_t c_str = MARY_C_String(u32, "aϑ☱𗷱");
  Mary_String_t str; Mary_String_Create_With_C_String(&str, MARY_UTF_32, c_str, 0);
  Mary_p array_p = { array, sizeof(array) };
  Mary_String_Copy_To(&str, &array_p, MARY_UTF_8);
  for (I i = 0; ; ++i)
  {
    printf("%u ", array[i]);
    if (array[i] == 0) break;
  }
}

static void String_Macro_Decode(u16 *from, u8 *to)
{
  u16 *f = from; Mary_UTF_16_t utf_16; utf_16.code = 1; Mary_UTF_8_t utf_8;
  for (u8 *t = to; utf_16.code != 0;)
  {
    MARY_String_UTF_16_Decode(f, utf_16, f += 1, f += 2);
    MARY_String_UTF_8_Encode
    (
      utf_16.code, utf_8,
      (*t++ = utf_8.a),
      (*t++ = utf_8.a, *t++ = utf_8.b),
      (*t++ = utf_8.a, *t++ = utf_8.b, *t++ = utf_8.c),
      (*t++ = utf_8.a, *t++ = utf_8.b, *t++ = utf_8.c, *t++ = utf_8.d)
    );
  }
}

static void String_Statement_Decode(u16 *from, u8 *to)
{
  u16 *f = from; u8 *t = to; u32 code = 1;

  while (code != 0)
  {
    if (*f < 0xD800 || *f > 0xDFFF)
    {
      code = *f++;
    }
    else
    {
      code = (*f - 0xD800 << 10) + (*(f + 1) - 0xDC00) + 0x10000, f += 2;
    }

    if (code < 0x000080)
    {
      *t++ = code;
    }
    else if (code < 0x000800)
    {
      *t++ = 0xC0 | code >> 6;
      *t++ = 0x80 | code & 0x3F;
    }
    else if (code < 0x010000)
    {
      *t++ = 0xE0 | code >> 12;
      *t++ = 0x80 | code >> 6 & 0x3F;
      *t++ = 0x80 | code & 0x3F;
    }
    else if (code < 0x110000)
    {
      *t++ = 0xF0 | code >> 18;
      *t++ = 0x80 | code >> 12 & 0x3F;
      *t++ = 0x80 | code >> 6 & 0x3F;
      *t++ = 0x80 | code & 0x3F;
    }
  }
}

static void String_Expression_Decode(u16 *from, u8 *to)
{
  u16 *f = from; u8 *t = to; u32 code = 1;

  while (code != 0)
  {
    *f < 0xD800 || *f > 0xDFFF ?
      (code = *f++) :
      (code = *f++ - 0xD800 << 10, code = *f++ - 0xDC00 + 0x10000);

    code < 0x000080 ?
      (*t++ = code) :
    code < 0x000800 ?
      (*t++ = 0xC0 | code >> 6,
       *t++ = 0x80 | code & 0x3F) :
    code < 0x010000 ?
      (*t++ = 0xE0 | code >> 12,
       *t++ = 0x80 | code >> 6 & 0x3F,
       *t++ = 0x80 | code & 0x3F) :
    code < 0x110000 ?
      (*t++ = 0xF0 | code >> 18,
       *t++ = 0x80 | code >> 12 & 0x3F,
       *t++ = 0x80 | code >> 6 & 0x3F,
       *t++ = 0x80 | code & 0x3F) : 0;
  }
}

void Test_String_Decode_Speed()
{
  #define C_STRING_REPEATS 0x100000
  #define TRIALS 24

  Mary_C_String_16_t c_str_16 = MARY_C_String(u16, "aϑ☱𗷱");
  Mary_Size_t from_bytes = sizeof(u16) * 5 * C_STRING_REPEATS + sizeof(u16) * 1; // 1 for null.
  Mary_Size_t to_bytes = sizeof(u8) * 10 * C_STRING_REPEATS + sizeof(u8) * 1;
  u16 *from = malloc(from_bytes), *from_end = MARY_Add_Bytes(from, from_bytes);
  u8 *to = malloc(to_bytes), *to_end = MARY_Add_Bytes(from, to_bytes);

  for (u16 *f = from; f < from_end - 1; f += 5)
  {
    Mary_Copy(c_str_16, f, sizeof(u16) * 5);
  }
  *(from_end - 1) = 0;

  MARY_Benchmark(String_Macro_Decode(from, to), TRIALS);
  MARY_Benchmark(String_Statement_Decode(from, to), TRIALS);
  MARY_Benchmark(String_Expression_Decode(from, to), TRIALS);

  free(from), free(to);

  #undef C_STRING_REPEATS
  #undef TRIALS
}

////// ideas //////

typedef struct { u64 a, b; }                  Big_Return_t;
typedef struct { u8 a, b, c, d, e, f, g, h; } Middle_Return_t;
typedef uint64_t                              Small_Return_t;
static Big_Return_t    Big_Return()    { return (Big_Return_t) { 10, 12 };                       }
static Middle_Return_t Middle_Return() { return (Middle_Return_t) { 10, 12, 3, 34, 1, 5, 6, 1 }; }
static Small_Return_t  Small_Return()  { return MARY_Random(64);                                 }

void Test_Big_Return()
{
  u64 temp = 0; Big_Return_t a; Small_Return_t c; Middle_Return_t b;
  MARY_Benchmark(for (u64 i = 0; i < 0x100000; ++i) (a = Big_Return(), temp += ((u64 *)&a)[MARY_Random(1)]), 12);
  MARY_Benchmark(for (u64 i = 0; i < 0x100000; ++i) (b = Middle_Return(), temp += ((u8 *)&b)[MARY_Random(7)]), 12);
  //MARY_Benchmark(for (u64 i = 0; i < 0x10000; ++i) (c = Small_Return(), temp += ((u8 *)&c)[MARY_Random(7)]), 12);
  MARY_Benchmark(for (u64 i = 0; i < 0x100000; ++i) (c = Small_Return(), temp += c), 12);
  printf("%llu\n", temp);
}

void Test_Bit_Flags()
{
  TEST_START(Test_Bit_Flags);

  for (U i = 0, val = 1, flags = val; i < 64; ++i, val *= 2, flags = val)
  {
    MARY_Bit_Unset(flags, i); MARY_Assert(flags == 0, 0);
    MARY_Assert(MARY_Bit_Is_Set(flags, i) == MARY_FALSE, 0);
    MARY_Bit_Set(flags, i); MARY_Assert(flags == val, 0);
    MARY_Assert(MARY_Bit_Is_Set(flags, i) == MARY_TRUE, 0);
    //Mary_Print_Bits(&flags, sizeof(flags), 1);
  }

  for (U i = 0, val = 0xAAAAAAAAAAAAAAAA, flags = val; i < 64; ++i)
  {
    if (!MARY_Bit_Is_Set(flags, i))
    {
      MARY_Bit_Set(flags, i); MARY_Assert(flags != val, 0);
      MARY_Assert(MARY_Bit_Is_Set(flags, i) == MARY_TRUE, 0);
      //Mary_Print_Bits(&flags, sizeof(flags), 1);
      MARY_Bit_Unset(flags, i); MARY_Assert(flags == val, 0);
      MARY_Assert(MARY_Bit_Is_Set(flags, i) == MARY_FALSE, 0);
    }
    else
    {
      MARY_Bit_Unset(flags, i); MARY_Assert(flags != val, 0);
      MARY_Assert(MARY_Bit_Is_Set(flags, i) == MARY_FALSE, 0);
      //Mary_Print_Bits(&flags, sizeof(flags), 1);
      MARY_Bit_Set(flags, i); MARY_Assert(flags == val, 0);
      MARY_Assert(MARY_Bit_Is_Set(flags, i) == MARY_TRUE, 0);
    }
  }

  U flags = 0xAAAAAAAAAAAAAAAA;
  for (U i = 0; i < 64; ++i)
  {
    if (MARY_Bit_Is_Set(flags, i))
    {
      MARY_Bit_Unset(flags, i);
      MARY_Assert(MARY_Bit_Is_Set(flags, i) == MARY_FALSE, 0);
    }
    else
    {
      MARY_Bit_Set(flags, i);
      MARY_Assert(MARY_Bit_Is_Set(flags, i) == MARY_TRUE, 0);
    }
    //Mary_Print_Bits(&flags, sizeof(flags), 1);
  }
  MARY_Assert(flags == 0x5555555555555555, 0);
  MARY_Bit_Clear(flags);
  MARY_Assert(flags == 0, 0);

  TEST_FINISH;
}

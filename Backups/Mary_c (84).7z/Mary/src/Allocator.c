#include <stdlib.h>
#include <Mary/Allocator.h>
#include <Mary/Pool.h>
#include <Mary/Arena.h>
#include <Mary/Hashmap.h>

MARY_Primitives;

const Mary_Pool_t *MARY_ALLOCATOR_POOLS;

Mary_Allocator_u Mary_Allocator_Stack()
{
  Mary_Allocator_u allocator;
  allocator.stack.type = MARY_STACK;
  return allocator;
}

Mary_Allocator_u Mary_Allocator_Heap()
{
  Mary_Allocator_u allocator;
  allocator.heap.type = MARY_HEAP;
  return allocator;
}

Mary_Allocator_u Mary_Allocator_Pool(Mary_Pool_t *pool)
{
  Mary_Allocator_u allocator;
  allocator.pool.type = MARY_POOL;
  allocator.pool.idx = (u8)(pool - MARY_ALLOCATOR_POOLS);
  return allocator;
}

Mary_Allocator_u Mary_Allocator_Arena(Mary_Enum_t zone)
{
  Mary_Allocator_u allocator;
  allocator.arena.type = MARY_ARENA;
  allocator.arena.zone = (u8)zone;
  return allocator;
}

void *Mary_Allocator_Alloc(Mary_Allocator_u allocator, Mary_Size_t bytes)
{
  Mary_Enum_t type = allocator.type;

  if (type == MARY_ARENA)
  {
    return Mary_Arena_Alloc(allocator.arena.zone, 0, bytes);
  }
  else if (type == MARY_POOL)
  {
    return Mary_Pool_Alloc(&((Mary_Pool_t *)MARY_ALLOCATOR_POOLS)[allocator.pool.idx], bytes);
  }
  else if (type == MARY_HEAP)
  {
    return Mary_Alloc(bytes);
  }
  else if (type == MARY_STACK)
  {
    MARY_Assert(0, "Cannot alloc on the stack."); return 0;
  }
  else
  {
    MARY_Assert(0, "Invalid alloc."); return 0;
  }
}

void *Mary_Allocator_Calloc(Mary_Allocator_u allocator, Mary_Size_t unit, Mary_Size_t units)
{
  Mary_Enum_t type = allocator.type;

  if (type == MARY_ARENA)
  {
    //return Mary_Arena_Calloc(allocator.arena.zone, 0, unit, units);
    return 0;
  }
  else if (type == MARY_POOL)
  {
    //return Mary_Pool_Calloc(&((Mary_Pool_t *)MARY_ALLOCATOR_POOLS)[allocator.pool.idx], unit, units);
    return 0;
  }
  else if (type == MARY_HEAP)
  {
    return Mary_Calloc(unit, units);
  }
  else if (type == MARY_STACK)
  {
    MARY_Assert(0, "Cannot calloc on the stack."); return 0;
  }
  else
  {
    MARY_Assert(0, "Invalid calloc."); return 0;
  }
}

void *Mary_Allocator_Realloc(Mary_Allocator_u allocator, void *data, Mary_Size_t bytes)
{
  Mary_Enum_t type = allocator.type;

  if (type == MARY_ARENA)
  {
    //return Mary_Arena_Realloc(allocator.arena.zone, 0, data, bytes);
    return 0;
  }
  else if (type == MARY_POOL)
  {
    return Mary_Pool_Realloc(&((Mary_Pool_t *)MARY_ALLOCATOR_POOLS)[allocator.pool.idx], data, bytes);
  }
  else if (type == MARY_HEAP)
  {
    return Mary_Realloc(data, bytes);
  }
  else if (type == MARY_STACK)
  {
    MARY_Assert(0, "Cannot realloc on the stack."); return 0;
  }
  else
  {
    MARY_Assert(0, "Invalid realloc."); return 0;
  }
}

void Mary_Allocator_Dealloc(Mary_Allocator_u allocator, void *data)
{
  Mary_Enum_t type = allocator.type;

  if (type == MARY_ARENA)
  {
    Mary_Arena_Dealloc(allocator.arena.zone, 0, data);
  }
  else if (type == MARY_POOL)
  {
    Mary_Pool_Dealloc(&((Mary_Pool_t *)MARY_ALLOCATOR_POOLS)[allocator.pool.idx], data);
  }
  else if (type == MARY_HEAP)
  {
    Mary_Dealloc(data);
  }
  else if (type == MARY_STACK)
  {
    MARY_Assert(0, "Cannot dealloc on the stack.");
  }
  else
  {
    MARY_Assert(0, "Invalid dealloc.");
  }
}

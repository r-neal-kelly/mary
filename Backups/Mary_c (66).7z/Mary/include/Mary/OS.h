#pragma once

#include <stdint.h>
#include <Mary/Pool.h>
#include <Mary/Vector.h>

#if defined(_WIN32)

#define WIN32_LEAN_AND_MEAN
#define UNICODE
#include <Windows.h>
#define MARY_CALL WINAPI

typedef struct
{
  HWND handle;
  HDC context;
  HBRUSH brush; // maybe not necessary...
}
Mary_OS_Window_t;

#define MARY_Benchmark(STATEMENT, TRIALS)                                                        \
{                                                                                                \
  LARGE_INTEGER freq, start, finish, diff;                                                       \
  size_t us = 0; double s = 0;                                                                   \
  for (size_t i = 0; i < (TRIALS); ++i)                                                          \
  {                                                                                              \
    QueryPerformanceFrequency(&freq);                                                            \
    QueryPerformanceCounter(&start);                                                             \
    (STATEMENT);                                                                                 \
    QueryPerformanceCounter(&finish);                                                            \
    diff.QuadPart = finish.QuadPart - start.QuadPart;                                            \
    us += diff.QuadPart * 1000000 / freq.QuadPart;                                               \
  }                                                                                              \
  if ((TRIALS)) us /= (TRIALS), s = us / 1000000.0;                                              \
  printf("%s\n", #STATEMENT);                                                                    \
  printf("%10i trials %10llu us %10g s\n", (TRIALS), us, s);                                     \
}

#elif defined(__linux__)

#define to_be_done

#endif

typedef struct Mary_Window_t Mary_Window_t;

void Mary_OS_Start();
void Mary_OS_Finish();
void Mary_OS_Sleep(size_t milliseconds);
float Mary_OS_Seconds();
float Mary_OS_Milliseconds();
float Mary_OS_Microseconds();

void Mary_OS_Window_Create(Mary_Window_t *window);
void Mary_OS_Window_Destroy(Mary_Window_t *window);
void Mary_OS_Window_Show(Mary_Window_t *window);
void Mary_OS_Window_Hide(Mary_Window_t *window);
void Mary_OS_Window_Measure(Mary_Window_t *window);
void Mary_OS_Window_Handle_Messages(Mary_Window_t *window);
void Mary_OS_Window_Make_Current(Mary_Window_t *window);
void Mary_OS_Window_Swap_Buffers(Mary_Window_t *window);
void Mary_OS_Window_Back_Color(Mary_Window_t *window);



typedef struct Mary_OS_Textmap_t Mary_OS_Textmap_t;
typedef struct Mary_OS_Textmap_Line_t Mary_OS_Textmap_Line_t;
typedef struct Mary_OS_Textmap_Word_t Mary_OS_Textmap_Word_t;
typedef Mary_Vector_t Mary_OS_Textmap_Line_v;
typedef Mary_Vector_t Mary_OS_Textmap_Word_v;

struct Mary_OS_Textmap_t
{
  Mary_Pool_t cache;
  Mary_Bitmap_t bitmap; // we might make a vector of these, if we need to break up horizontally, and we could put an index on the line objects.
  Mary_OS_Textmap_Line_v lines;
};

struct Mary_OS_Textmap_Line_t
{
  Mary_OS_Textmap_Word_v words;
  float w, h, user_w, user_h; // these might just be ints.
};

struct Mary_OS_Textmap_Word_t
{
  float w, h, x1, x2, y1, y2;
};

void Mary_OS_Textmap_Create(Mary_OS_Textmap_t *textmap, uint16_t *text, int text_units);
void Mary_OS_Textmap_Destroy(Mary_OS_Textmap_t *textmap);


// this should all be in its own file probably, with simpler OS calls to draw and measure text.
// the prob is that it will be very hard I think, because we will not be drawing to a dib all at once
// but it would need to be through multiple calls. it may be too specific to be any good.
enum
{
  MARY_OS_WORDMAP_ALIGN_LEFT,
  MARY_OS_WORDMAP_ALIGN_RIGHT,
  MARY_OS_WORDMAP_LEFT_TO_RIGHT,
  MARY_OS_WORDMAP_RIGHT_TO_LEFT
};

typedef struct Mary_OS_Wordmap_t Mary_OS_Wordmap_t;
typedef struct Mary_OS_Wordmap_Word_t Mary_OS_Wordmap_Word_t;
typedef struct Mary_OS_Wordmap_Run_t Mary_OS_Wordmap_Run_t;
typedef struct Mary_OS_Wordmap_Range_t Mary_OS_Wordmap_Range_t;

// it may be too slow to copy bytes for bitmap each time. we could speed it up by having a dib on the type.
struct Mary_OS_Wordmap_t
{
  Mary_Bitmap_t bitmap;
  Mary_Vector_t words;
};

struct Mary_OS_Wordmap_Word_t
{
  float pix_w, pix_h;
  float norm_x1, norm_x2, norm_y1, norm_y2;
};

struct Mary_OS_Wordmap_Run_t
{
  uint16_t *data;
  size_t units;
  uint8_t direction;
  uint16_t font_size;
  // well want font, font_size, etc.
  // maybe even color? we could pass it to pixel shader, overriding main color in element
};

struct Mary_OS_Wordmap_Range_t
{
  size_t from_word;
  size_t to_exclusive_word;
  float pix_max_h;
};

void Mary_OS_Wordmap_Create(Mary_OS_Wordmap_t *wordmap, Mary_Vector_t *runs, uint64_t total_words, uint8_t alignment);
void Mary_OS_Wordmap_Range(Mary_OS_Wordmap_t *wordmap, int max_pix_w, size_t from_word, Mary_OS_Wordmap_Range_t *out_range);
void Mary_OS_Wordmap_Destroy(Mary_OS_Wordmap_t *wordmap);

#include <Mary/OS.h>
#include <Mary/Hashmap.h>
#include <Mary/Arena.h>

MARY_Primitives;

#define TRY_AVAILABLE_ARENA\
  MARY_Assert(is_started == MARY_TRUE, "Mary_Arena has not been started.");

#define TRY_AVAILABLE_FRAME(ARENA)\
  MARY_Assert(ARENA->frames.units > 0, "No frame available.")

#define TRY_AVAILABLE_CHAIN(ARENA)\
  MARY_Assert(ARENA->frames.units > 1, "No chain available.")

#define TRY_INVALID_FRAME(FRAME)\
  MARY_Assert(FRAME->can_alloc == MARY_TRUE, "Invalid frame. Check for an unpopped frame.");\
  FRAME->can_alloc = MARY_FALSE

#define TRY_OUT_OF_MEMORY(DATA)\
  MARY_Assert(DATA != 0, "Out of memory.")

typedef struct
{
  Mary_Vector_t allocs;
  Mary_Vector_t errors;
#ifdef MARY_Debug
  Mary_C_String_8_p name;
  Mary_Bool_t can_alloc;
#endif
}
Mary_Arena_Frame_t;

static Mary_Bool_t is_started = MARY_FALSE;
static Mary_Hashmap_t global_arenas;

void Mary_Arena_Start()
{
  if (is_started == MARY_TRUE) return;

  is_started = MARY_TRUE;

  Mary_Pool_Start();

  Mary_Hashmap_Create(&global_arenas, sizeof(u64), sizeof(Mary_Arena_t));
  Mary_Arena_Create(MARY_Arena_Thread_Bytes);
}

void Mary_Arena_Stop()
{
  if (is_started == MARY_FALSE) return;

  Mary_Arena_Destroy();
  Mary_Hashmap_Destroy(&global_arenas);

  is_started = MARY_FALSE;
}

void Mary_Arena_Create(Mary_Size_t bytes)
{
#ifdef MARY_Debug
  TRY_AVAILABLE_ARENA;
#endif

  u64 arena_id = Mary_OS_Thread_Current_ID();

#ifdef MARY_Debug
  MARY_Assert(!Mary_Hashmap_Contains_Key(&global_arenas, &arena_id),
              "The arena for this thread is already created.");
#endif
  
  Mary_Arena_t arena;
  arena.pool = Mary_Pool_Create(bytes);
  Mary_Vector_Create(&arena.frames, arena.pool->id, sizeof(Mary_Arena_Frame_t), MARY_Arena_Reserve_Frames);
  Mary_Hashmap_Assign(&global_arenas, &arena_id, &arena);
}

void Mary_Arena_Destroy()
{
#ifdef MARY_Debug
  TRY_AVAILABLE_ARENA;
#endif

  u64 arena_id = Mary_OS_Thread_Current_ID();

#ifdef MARY_Debug
  MARY_Assert(Mary_Hashmap_Contains_Key(&global_arenas, &arena_id),
              "The arena for this thread was never created.");
#endif
  
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

#ifdef MARY_Debug
  MARY_Assert(arena->frames.units == 0, "There are still unpopped frames.");
#endif
  
  Mary_Vector_Destroy(&arena->frames);
  Mary_Pool_Destroy(arena->pool);
  Mary_Hashmap_Erase(&global_arenas, &arena_id);
}

#ifdef MARY_Debug
void Mary_Arena_Register(char *func_name)
{
  TRY_AVAILABLE_ARENA;

  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

  TRY_AVAILABLE_FRAME(arena);

  Mary_Arena_Frame_t *frame = MARY_Vector_Point_Back(&arena->frames);

  frame->name.data = func_name;
  frame->name.bytes = Mary_C_String_Count_Bytes(func_name, 8, 1);
  //frame->name.allocator = MARY_STATIC;
  frame->can_alloc = MARY_FALSE;
}

void Mary_Arena_Validate(Mary_Enum_t zone, char *func_name)
{
  TRY_AVAILABLE_ARENA;

  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

  if (zone == MARY_CHAIN || zone == MARY_ERROR)
  {
    TRY_AVAILABLE_CHAIN(arena);
  }
  TRY_AVAILABLE_FRAME(arena);

  Mary_Arena_Frame_t *frame = MARY_Vector_Point_Back(&arena->frames);

  MARY_Assert(Mary_Is_Same(frame->name.data, func_name, frame->name.bytes),
              "Invalid frame. Check for an unpopped frame.");

  frame->can_alloc = MARY_TRUE;
}
#endif

void Mary_Arena_Push()
{
#ifdef MARY_Debug
  TRY_AVAILABLE_ARENA;
#endif

  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

  Mary_Arena_Frame_t *frame = MARY_Vector_Point_Push(&arena->frames);
  Mary_Vector_Create(&frame->allocs, arena->pool->id, sizeof(void *), MARY_Arena_Reserve_Allocs_Per_Frame);
  Mary_Vector_Create(&frame->errors, arena->pool->id, sizeof(Mary_Error_t *), 1);
}

void Mary_Arena_Pop()
{
#ifdef MARY_Debug
  TRY_AVAILABLE_ARENA;
#endif

  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

#ifdef MARY_Debug
  TRY_AVAILABLE_FRAME(arena);
#endif

  Mary_Arena_Frame_t *frame = MARY_Vector_Point_Pop(&arena->frames);

#ifdef MARY_Debug
  MARY_Assert(frame->errors.units == 0, "Unhandled error in arena!");
#endif

  MARY_Vector_Each(&frame->allocs, void *)
  {
    if (Mary_Pool_Has_Data(arena->pool, it.val))
    {
      Mary_Pool_Dealloc(arena->pool, it.val);
    }
    else
    {
      Mary_Dealloc(it.val);
    }
  }
  Mary_Vector_Destroy(&frame->allocs);

  MARY_Vector_Each(&frame->errors, void *)
  {
    if (Mary_Pool_Has_Data(arena->pool, it.val))
    {
      Mary_Pool_Dealloc(arena->pool, it.val);
    }
    else
    {
      Mary_Dealloc(it.val);
    }
  }
  Mary_Vector_Destroy(&frame->errors);
}

void *Mary_Arena_Alloc_Frame(Mary_Size_t bytes)
{
#ifdef MARY_Debug
  TRY_AVAILABLE_ARENA;
#endif

  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

#ifdef MARY_Debug
  TRY_AVAILABLE_FRAME(arena);
#endif

  Mary_Arena_Frame_t *frame = MARY_Vector_Point_Back(&arena->frames);

#ifdef MARY_Debug
  TRY_INVALID_FRAME(frame);
#endif

  void *data;

  if (Mary_Pool_Has_Free(arena->pool, bytes))
  {
    data = Mary_Pool_Alloc(arena->pool, bytes);
  }
  else
  {
    data = Mary_Alloc(bytes);
  }

#ifdef MARY_Debug
  TRY_OUT_OF_MEMORY(data);
#endif

  MARY_Vector_Push(&frame->allocs, void *, data);

  return data;
}

void *Mary_Arena_Alloc_Chain(Mary_Size_t bytes)
{
#ifdef MARY_Debug
  TRY_AVAILABLE_ARENA;
#endif

  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

#ifdef MARY_Debug
  TRY_AVAILABLE_CHAIN(arena);
  TRY_AVAILABLE_FRAME(arena);
#endif

  Mary_Arena_Frame_t *frame = MARY_Vector_Point_Back(&arena->frames);
  Mary_Arena_Frame_t *chain = MARY_Vector_Point(&arena->frames, arena->frames.units - 2);

#ifdef MARY_Debug
  TRY_INVALID_FRAME(frame);
#endif

  void *data;

  if (Mary_Pool_Has_Free(arena->pool, bytes))
  {
    data = Mary_Pool_Alloc(arena->pool, bytes);
  }
  else
  {
    data = Mary_Alloc(bytes);
  }

#ifdef MARY_Debug
  TRY_OUT_OF_MEMORY(data);
#endif

  MARY_Vector_Push(&chain->allocs, void *, data);

  return data;
}

void *Mary_Arena_Alloc_Error(Mary_Size_t bytes)
{
#ifdef MARY_Debug
  TRY_AVAILABLE_ARENA;
#endif

  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

#ifdef MARY_Debug
  TRY_AVAILABLE_CHAIN(arena);
  TRY_AVAILABLE_FRAME(arena);
#endif

  Mary_Arena_Frame_t *frame = MARY_Vector_Point_Back(&arena->frames);
  Mary_Arena_Frame_t *chain = MARY_Vector_Point(&arena->frames, arena->frames.units - 2);

#ifdef MARY_Debug
  TRY_INVALID_FRAME(frame);
#endif

  void *data;

  if (Mary_Pool_Has_Free(arena->pool, bytes))
  {
    data = Mary_Pool_Alloc(arena->pool, bytes);
  }
  else
  {
    data = Mary_Alloc(bytes);
  }

#ifdef MARY_Debug
  TRY_OUT_OF_MEMORY(data);
#endif

  MARY_Vector_Push(&chain->errors, Mary_Error_t *, data);

  return data;
}

// the reallocs still need to verify the correct frame, because they are blindly looking relative to the current stack frame.
// I need to make allocators accept a pointer to the actual vector that is holding the pointer to make judge correctly which frame is which.
// currently, we can not reallocate like it is.

void *Mary_Arena_Realloc_Frame(void *data, Mary_Size_t bytes)
{
#ifdef MARY_Debug
  TRY_AVAILABLE_ARENA;
#endif

  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

#ifdef MARY_Debug
  TRY_AVAILABLE_FRAME(arena);
#endif

  if (Mary_Pool_Has_Data(arena->pool, data))
  {
    data = Mary_Pool_Realloc(arena->pool, data, bytes);
  }
  else
  {
    data = Mary_Realloc(data, bytes);
  }

#ifdef MARY_Debug
  TRY_OUT_OF_MEMORY(data);
#endif

  return data;
}

void *Mary_Arena_Realloc_Chain(void *data, Mary_Size_t bytes)
{
#ifdef MARY_Debug
  TRY_AVAILABLE_ARENA;
#endif

  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

#ifdef MARY_Debug
  TRY_AVAILABLE_CHAIN(arena);
  TRY_AVAILABLE_FRAME(arena);
#endif

  if (Mary_Pool_Has_Data(arena->pool, data))
  {
    data = Mary_Pool_Realloc(arena->pool, data, bytes);
  }
  else
  {
    data = Mary_Realloc(data, bytes);
  }

#ifdef MARY_Debug
  TRY_OUT_OF_MEMORY(data);
#endif

  return data;
}

void Mary_Arena_Dealloc_Frame(void *data)
{
#ifdef MARY_Debug
  TRY_AVAILABLE_ARENA;
#endif

  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

#ifdef MARY_Debug
  TRY_AVAILABLE_FRAME(arena);
#endif

  Mary_Arena_Frame_t *frame = MARY_Vector_Point_Back(&arena->frames);

#ifdef MARY_Debug
  TRY_INVALID_FRAME(frame);
#endif

  Mary_Bool_t was_found; Mary_Index_t idx =
    Mary_Vector_Index_Of_Reverse(&frame->allocs, &data, &was_found);

#ifdef MARY_Debug
  MARY_Assert(was_found == MARY_TRUE, "Could not find data in frame.");
#endif

  Mary_Vector_Erase_At(&frame->allocs, idx);

  if (Mary_Pool_Has_Data(arena->pool, data))
  {
    Mary_Pool_Dealloc(arena->pool, data);
  }
  else
  {
    Mary_Dealloc(data);
  }
}

void Mary_Arena_Dealloc_Chain(void *data)
{
#ifdef MARY_Debug
  TRY_AVAILABLE_ARENA;
#endif

  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

#ifdef MARY_Debug
  TRY_AVAILABLE_CHAIN(arena);
  TRY_AVAILABLE_FRAME(arena);
#endif

  Mary_Arena_Frame_t *frame = MARY_Vector_Point_Back(&arena->frames);
  Mary_Arena_Frame_t *chain = MARY_Vector_Point(&arena->frames, arena->frames.units - 2);

#ifdef MARY_Debug
  TRY_INVALID_FRAME(frame);
#endif

  Mary_Bool_t was_found; Mary_Index_t idx =
    Mary_Vector_Index_Of_Reverse(&chain->allocs, &data, &was_found);

#ifdef MARY_Debug
  MARY_Assert(was_found == MARY_TRUE, "Could not find data in chain.");
#endif

  Mary_Vector_Erase_At(&chain->allocs, idx);

  if (Mary_Pool_Has_Data(arena->pool, data))
  {
    Mary_Pool_Dealloc(arena->pool, data);
  }
  else
  {
    Mary_Dealloc(data);
  }
}

void *Mary_Arena_Alloc(Mary_Enum_t zone, Mary_Size_t bytes)
{
  if (zone == MARY_ARENA_FRAME)
  {
    return Mary_Arena_Alloc_Frame(bytes);
  }
  else if (zone == MARY_ARENA_CHAIN)
  {
    return Mary_Arena_Alloc_Chain(bytes);
  }
  else if (zone == MARY_ARENA_ERROR)
  {
    return Mary_Arena_Alloc_Error(bytes); // maybe we should force error creation to use the specific call, because we don't really want a vector for example, to create one.
  }
  else
  {
    MARY_Assert(0, "Invalid zone.");
    return 0;
  }
}

void *Mary_Arena_Realloc(Mary_Enum_t zone, void *data, Mary_Size_t bytes)
{
  if (zone == MARY_ARENA_FRAME)
  {
    return Mary_Arena_Realloc_Frame(data, bytes);
  }
  else if (zone == MARY_ARENA_CHAIN)
  {
    return Mary_Arena_Realloc_Chain(data, bytes);
  }
  else
  {
    MARY_Assert(0, "Invalid zone.");
    return 0;
  }
}

void Mary_Arena_Dealloc(Mary_Enum_t zone, void *data)
{
  if (zone == MARY_ARENA_CHAIN)
  {
    Mary_Arena_Dealloc_Chain(data);
  }
  else if (zone == MARY_ARENA_FRAME)
  {
    Mary_Arena_Dealloc_Frame(data);
  }
  else
  {
    MARY_Assert(0, "Invalid zone.");
  }
}

void Mary_Arena_Chain(void *data)
{
#ifdef MARY_Debug
  TRY_AVAILABLE_ARENA;
#endif

  u64 arena_id = Mary_OS_Thread_Current_ID();
  Mary_Arena_t *arena = Mary_Hashmap_Point(&global_arenas, &arena_id);

#ifdef MARY_Debug
  TRY_AVAILABLE_CHAIN(arena);
  TRY_AVAILABLE_FRAME(arena);
#endif

  Mary_Arena_Frame_t *frame = MARY_Vector_Point_Back(&arena->frames);
  Mary_Arena_Frame_t *chain = MARY_Vector_Point(&arena->frames, arena->frames.units - 2);

#ifdef MARY_Debug
  TRY_INVALID_FRAME(frame);
#endif

  Mary_Bool_t was_found; Mary_Index_t idx =
    Mary_Vector_Index_Of_Reverse(&frame->allocs, &data, &was_found);

#ifdef MARY_Debug
  MARY_Assert(was_found == MARY_TRUE, "Could not find data in frame.");
#endif

  Mary_Vector_Erase_At(&frame->allocs, idx);

  MARY_Vector_Push(&chain->allocs, void *, data);
}

void Mary_Arena_Empty(Mary_Arena_t *arena)
{
  // need to check that there are no frames present.
}

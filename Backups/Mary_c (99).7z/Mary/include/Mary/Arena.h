#pragma once

#include <Mary/Utils.h>
#include <Mary/Allocator.h>
#include <Mary/Vector.h>
#include <Mary/Pool.h>

#define MARY_Arena_Thread_Bytes 0x300000
#define MARY_Arena_Reserve_Frames 8
#define MARY_Arena_Reserve_Allocs_Per_Frame 8

enum Mary_Arena_Zone_e
{
  MARY_ARENA_FRAME = MARY_FRAME,
  MARY_ARENA_CHAIN = MARY_CHAIN,
  MARY_ARENA_ERROR = MARY_ERROR
};

typedef struct Mary_Arena_t Mary_Arena_t;

struct Mary_Arena_t
{
  Mary_Pool_t *pool;
  Mary_Vector_t frames;
};

void Mary_Arena_Start();
void Mary_Arena_Stop();
void Mary_Arena_Create();
void Mary_Arena_Destroy();
void Mary_Arena_Push();
void Mary_Arena_Pop();
void *Mary_Arena_Alloc_Frame(Mary_Size_t bytes);
void *Mary_Arena_Alloc_Chain(Mary_Size_t bytes);
void *Mary_Arena_Alloc_Error(Mary_Size_t bytes); // we have bytes on here for the sake of variable error_types
void *Mary_Arena_Realloc_Frame(void *data, Mary_Size_t bytes);
void *Mary_Arena_Realloc_Chain(void *data, Mary_Size_t bytes);
void Mary_Arena_Dealloc_Frame(void *data);
void Mary_Arena_Dealloc_Chain(void *data);
void *Mary_Arena_Alloc(Mary_Enum_t zone, Mary_Size_t bytes);
void *Mary_Arena_Realloc(Mary_Enum_t zone, void *data, Mary_Size_t bytes);
void Mary_Arena_Dealloc(Mary_Enum_t zone, void *data);
void Mary_Arena_Chain(void *data);
void Mary_Arena_Save(); // I think it would be useful to have a way to get data out of pool to user's location. eg if a lib function returns a chain, but the user wants to keep it.
void Mary_Arena_Empty(); // clears the entire allocation both in pool and in heap.

#ifdef MARY_Debug
void Mary_Arena_Register(char *func_name);
void Mary_Arena_Validate(Mary_Enum_t zone, char *func_name);
#endif

#define MARY_Arena_In                                   \
  MARY_Allocators;                                      \
  Mary_Arena_Push();                                    \
  MARY_In_Debug(Mary_Bool_t ARENA_FRAME_ACTIVATED = 1;) \
  MARY_In_Debug(Mary_Arena_Register(__func__);)

#define MARY_Arena_Out                      \
  MARY_In_Debug(ARENA_FRAME_ACTIVATED = 0;) \
  Mary_Arena_Pop();

#define MARY_Arena_Return(RETURN) \
MARY_M                            \
  MARY_Arena_Out; return RETURN;  \
MARY_W

#define MARY_Arena_Chain(DATA)                                       \
(                                                                    \
  MARY_In_Debug(Mary_Arena_Validate(MARY_CHAIN, __func__)MARY_Comma) \
  Mary_Arena_Chain(DATA)                                             \
)

#define MARY_Arena_Chain_Return(DATA) \
MARY_M                                \
  MARY_Arena_Chain(DATA);             \
  MARY_Arena_Return(DATA);            \
MARY_W

#define MARY_Arena_Alloc(ALLOCATOR, BYTES)                          \
(                                                                   \
  MARY_In_Debug(Mary_Arena_Validate(ALLOCATOR, __func__)MARY_Comma) \
  ALLOCATOR == MARY_FRAME ? Mary_Arena_Alloc_Frame(BYTES) :         \
  ALLOCATOR == MARY_CHAIN ? Mary_Arena_Alloc_Chain(BYTES) :         \
  ALLOCATOR == MARY_ERROR ? Mary_Arena_Alloc_Error(BYTES) :         \
  ALLOCATOR == MARY_HEAP ? Mary_Alloc(BYTES) :                      \
  (MARY_Assert(0, "Invalid allocator"), 0)                          \
)

#define MARY_Arena_Dealloc(ALLOCATOR, BYTES)                        \
(                                                                   \
  MARY_In_Debug(Mary_Arena_Validate(ALLOCATOR, __func__)MARY_Comma) \
  ALLOCATOR == MARY_HEAP ? Mary_Dealloc(BYTES) :                    \
  ALLOCATOR == MARY_CHAIN ? Mary_Arena_Dealloc_Chain(BYTES) :       \
  ALLOCATOR == MARY_FRAME ? Mary_Arena_Dealloc_Frame(BYTES) :       \
  (MARY_Assert(0, "Invalid allocator"), 0)                          \
)

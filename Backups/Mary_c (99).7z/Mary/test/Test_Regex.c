#include <Mary/Utils.h>
#include <Mary/Allocator.h>
#include <Mary/Arena.h>
#include <Mary/String.h>
#include <Mary/Regex.h>
#include <Mary/Test/Test.h> // this should prob. be one level up.

MARY_Primitives;
MARY_Allocators;

static void Test_Regex_Create();

void Test_Regex()
{
  Mary_Regex_Start();

  MARY_Arena_In;

  Test_Regex_Create();

  MARY_Arena_Out;

  Mary_Regex_Stop();
}

static void Test_Regex_Create()
{
  TEST_START(Test_Regex_Create);

  MARY_Arena_In;

  Mary_Regex_t regex;
  MARY_String_Static(expression, 8, u8"abc");
  Mary_Regex_Create(&regex, HEAP, &expression, "");
  Mary_Regex_Destroy(&regex);

  MARY_Arena_Out;

  TEST_STOP;
}

#include <stdio.h>
#include <stdlib.h>
#include <Mary/File.h>

MARY_PRIMITIVES;

void Mary_File_Create(Mary_File_t *mary_file, const char *file_path, const char *mode)
{
  FILE *file = fopen(file_path, mode);
  if (file == 0)
  {
    Mary_Exit_Failure("File_Read: could not open.");
  }

  u64 bytes = 0;
  while (feof(file) == 0)
  {
    fgetc(file), ++bytes;
  }
  --bytes;

  u8 *data = malloc(bytes + sizeof(u64));
  if (data == 0)
  {
    Mary_Exit_Failure("File_Read: could not allocate buffer.");
  }

  rewind(file);
  size_t bytes_read = fread(data, sizeof(u8), bytes, file);
  if (ferror(file) || bytes_read != bytes)
  {
    Mary_Exit_Failure("File_Read: could not read into buffer.");
  }
  *(u64 *)(data + bytes) = 0;

  if (fclose(file) == EOF)
  {
    Mary_Exit_Failure("File_Read: could not close.");
  }

  mary_file->data = data;
  mary_file->bytes = bytes + sizeof(u64);
}

void Mary_File_Destroy(Mary_File_t *mary_file)
{
  free(mary_file->data);
}

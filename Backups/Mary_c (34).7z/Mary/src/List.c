#include <string.h>
#include <Mary/List.h>

MARY_PRIMITIVES;

const size_t SIZE_PTR = sizeof(void *);
const u64 ZERO = 0;

void Mary_List_Create(Mary_List_t *mary_list, Mary_Pool_t *mary_pool, size_t unit)
{
  mary_list->front = 0;
  mary_list->back = 0;
  mary_list->pool = mary_pool;
  mary_list->unit = unit;
  mary_list->size = 0;
}

void Mary_List_Delete(Mary_List_t *mary_list)
{
  // nothing to free atm.
}

void Mary_List_Push_Back(Mary_List_t *mary_list, void *in_elem)
{
  u8 *alloc = Mary_Pool_Allocate(mary_list->pool, mary_list->unit + SIZE_PTR);
  if (!mary_list->front)
  {
    mary_list->front = alloc;
  }
  else
  {
    memcpy((u8 *)mary_list->back + mary_list->unit, &alloc, SIZE_PTR);
  }
  mary_list->back = alloc;
  memcpy(alloc, in_elem, mary_list->unit);
  memcpy(alloc + mary_list->unit, &ZERO, SIZE_PTR);
  ++mary_list->size;
}

inline void *Mary_List_Point(Mary_List_t *mary_list, size_t index)
{
  if (index == 0)
  {
    return mary_list->front;
  }
  else if (index == mary_list->size - 1)
  {
    return mary_list->back;
  }
  else
  {
    size_t unit = mary_list->unit;
    u8 *p; memcpy(&p, (u8 *)mary_list->front + unit, SIZE_PTR);
    for (size_t i = 1; i < index; ++i)
    {
      memcpy(&p, p + unit, SIZE_PTR);
    }
    return p;
  }
}

inline void Mary_List_Next(Mary_List_t *mary_list, void *in_out_ptr)
{
  memcpy(&in_out_ptr, (u8 *)in_out_ptr + mary_list->unit, SIZE_PTR);
}

void Mary_List_At(Mary_List_t *mary_list, size_t index, void *out_elem)
{
  if (index == 0)
  {
    memcpy(out_elem, mary_list->front, mary_list->unit);
  }
  else if (index == mary_list->size - 1)
  {
    memcpy(out_elem, mary_list->back, mary_list->unit);
  }
  else
  {
    memcpy(out_elem, Mary_List_Point(mary_list, index), mary_list->unit);
  }
}

void Mary_List_Erase_At(Mary_List_t *mary_list, size_t index)
{
  u8 *front = mary_list->front;
  size_t unit = mary_list->unit;
  if (index == 0)
  {
    u8 *next; memcpy(&next, front + unit, SIZE_PTR);
    Mary_Pool_Deallocate(mary_list->pool, front);
    mary_list->front = next;
  }
  else
  {
    u8 *prev = mary_list->front;
    for (size_t i = 1; i < index; ++i)
    {
      memcpy(&prev, prev + unit, SIZE_PTR);
    }
    u8 *self; memcpy(&self, prev + unit, SIZE_PTR);
    u8 *next; memcpy(&next, self + unit, SIZE_PTR);
    Mary_Pool_Deallocate(mary_list->pool, self);
    memcpy(prev + unit, &next, SIZE_PTR);
    if (index == mary_list->size - 1)
    {
      mary_list->back = prev;
    }
  }
  --mary_list->size;
}

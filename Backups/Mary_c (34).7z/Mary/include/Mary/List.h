#pragma once

#include <Mary/Pool.h>

typedef struct
{
  void *front;
  void *back;
  Mary_Pool_t *pool;
  size_t unit;
  size_t size;
}
Mary_List_t;

void Mary_List_Create(Mary_List_t *mary_list, Mary_Pool_t *mary_pool, size_t unit);
void Mary_List_Delete(Mary_List_t *mary_list);
void Mary_List_Push_Back(Mary_List_t *mary_list, void *in_elem);
void Mary_List_Push_Front(Mary_List_t *mary_list);
void Mary_List_Push_At(Mary_List_t *mary_list); // was Insert
void Mary_List_Pop_Back(Mary_List_t *mary_list);
void Mary_List_Pop_Front(Mary_List_t *mary_list);
void Mary_List_Pop_At(Mary_List_t *mary_list); // was Eject
void Mary_List_Assign(Mary_List_t *mary_list);
void *Mary_List_Point(Mary_List_t *mary_list, size_t index);
void Mary_List_Next(Mary_List_t *mary_list, void *in_out_ptr);
void Mary_List_At(Mary_List_t *mary_list, size_t index, void *out_elem);
void Mary_List_Back(Mary_List_t *mary_list);
void Mary_List_Front(Mary_List_t *mary_list);
void Mary_List_Tail(Mary_List_t *mary_list);
void Mary_List_Erase(Mary_List_t *mary_list);
void Mary_List_Erase_At(Mary_List_t *mary_list, size_t index);

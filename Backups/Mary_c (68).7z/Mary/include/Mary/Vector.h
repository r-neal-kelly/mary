#pragma once

#include <Mary/Utils.h>

#define MARY_Vector_t\
  MARY_Pointer_t;\
  size_t unit;\
  size_t units

typedef struct
{
  MARY_Vector_t;
}
Mary_Vector_t;

void Mary_Vector_Create(Mary_Vector_t *vector, size_t unit, size_t opt_units);
void Mary_Vector_Create_With(Mary_Vector_t *vector, size_t unit, Mary_p ptr); // Mary_Vector_Create_At?
void Mary_Vector_Create_With_Data(Mary_Vector_t *vector, size_t unit, Mary_p ptr); // Mary_Vector_Create_With?
void Mary_Vector_Create_Copy(Mary_Vector_t *vector, size_t unit, Mary_p ptr, size_t units);
void Mary_Vector_Destroy(Mary_Vector_t *vector);
void Mary_Vector_Reserve(Mary_Vector_t *vector, size_t units);
void Mary_Vector_Fit(Mary_Vector_t *vector);
void Mary_Vector_Push_At(Mary_Vector_t *vector, size_t index, void *in_elem);
void Mary_Vector_Pop_At(Mary_Vector_t *vector, size_t index, void *out_elem);
void Mary_Vector_Assign(Mary_Vector_t *vector, size_t index, void *in_elem);
void Mary_Vector_Exchange(Mary_Vector_t *vector, size_t index, void *in_elem, void *out_elem);
void Mary_Vector_Add_Slice(Mary_Vector_t *vector, size_t from, size_t to_exclusive, void *opt_in_elems);
void Mary_Vector_Delete_Slice(Mary_Vector_t *vector, size_t from, size_t to_exclusive);
void Mary_Vector_Copy_Slice(Mary_Vector_t *vector, size_t from, size_t to_exclusive, void *out_elems);
void Mary_Vector_Take_Slice(Mary_Vector_t *vector, size_t from, size_t to_exclusive, void *out_elems);
void Mary_Vector_Put_Slice(Mary_Vector_t *vector, size_t from, size_t to_exclusive, void *in_elems);
void Mary_Vector_Push_Back(Mary_Vector_t *vector, void *in_elem);
void Mary_Vector_Push_Front(Mary_Vector_t *vector, void *in_elem);
void Mary_Vector_Pop_Back(Mary_Vector_t *vector, void *out_elem);
void Mary_Vector_Pop_Front(Mary_Vector_t *vector, void *out_elem);
void Mary_Vector_At(Mary_Vector_t *vector, size_t index, void *out_elem);
char Mary_Vector_Has_At(Mary_Vector_t *vector, size_t index);
void *Mary_Vector_Point(Mary_Vector_t *vector, size_t index);
void Mary_Vector_Back(Mary_Vector_t *vector, void *out_elem);
void Mary_Vector_Front(Mary_Vector_t *vector, void *out_elem);
void Mary_Vector_Empty(Mary_Vector_t *vector);
char Mary_Vector_Is_Empty(Mary_Vector_t *vector);
void Mary_Vector_Resize(Mary_Vector_t *vector, size_t units);
void Mary_Vector_Fill(Mary_Vector_t *vector, void *in_elem);
void Mary_Vector_Rotate(Mary_Vector_t *vector, void *out_elem);
void Mary_Vector_Reverse(Mary_Vector_t *vector);
char Mary_Vector_Contains(Mary_Vector_t *vector, void *elem);
char Mary_Vector_Contains_First_Bytes(Mary_Vector_t *vector, void *elem, size_t bytes);
size_t Mary_Vector_Index_Of(Mary_Vector_t *vector, void *elem, char *out_was_found);
void Mary_Vector_Erase_At(Mary_Vector_t *vector, size_t index);
void Mary_Vector_Erase(Mary_Vector_t *vector, void *elem);
void Mary_Vector_Sort(Mary_Vector_t *vector);

#define MARY_Vector_Create(VECTOR, TYPE, OPT_UNITS)\
  Mary_Vector_Create(&VECTOR, sizeof(TYPE), (OPT_UNITS))

#define MARY_Vector_Create_With(VECTOR, TYPE, MARY_PTR)\
  Mary_Vector_Create_With(&VECTOR, sizeof(TYPE), (Mary_p)(MARY_PTR))

#define MARY_Vector_Create_Copy(VECTOR, TYPE, MARY_PTR, UNITS)\
  Mary_Vector_Create_Copy(&VECTOR, sizeof(TYPE), (Mary_p)(MARY_PTR), (UNITS))

#define MARY_Vector_Create_On_Stack(VECTOR, TYPE, UNITS) TYPE VECTOR##_a[UNITS];\
  Mary_Vector_Create_With(&VECTOR, sizeof(TYPE), (Mary_p) { VECTOR##_a, sizeof(TYPE) * (UNITS) })

#define MARY_Vector_Destroy(VECTOR)\
  Mary_Vector_Destroy(&VECTOR);

#define MARY_Vector_Push_Back(VECTOR, IN_ELEM)\
  Mary_Vector_Push_Back(&VECTOR, &IN_ELEM)

#define MARY_Vector_At(VECTOR, INDEX, OUT_ELEM)\
  Mary_Vector_At(&VECTOR, (INDEX), &OUT_ELEM)

#define MARY_Vector_Assign(VECTOR, INDEX, IN_ELEM)\
  Mary_Vector_Assign(&VECTOR, (INDEX), &IN_ELEM)

#define MARY_Vector_Add_Slice(VECTOR, FROM, TO_EXCLUSIVE)\
  Mary_Vector_Add_Slice(&VECTOR, (FROM), (TO_EXCLUSIVE))

#define MARY_Vector_Delete_Slice(VECTOR, FROM, TO_EXCLUSIVE)\
  Mary_Vector_Delete_Slice(&VECTOR, (FROM), (TO_EXCLUSIVE))

#define MARY_Vector_Copy_Slice(VECTOR, FROM, TO_EXCLUSIVE, OUT_ELEMS)\
  Mary_Vector_Copy_Slice(&VECTOR, (FROM), (TO_EXCLUSIVE), &OUT_ELEMS)

#define MARY_Vector_Take_Slice(VECTOR, FROM, TO_EXCLUSIVE, OUT_ELEMS)\
  Mary_Vector_Take_Slice(&VECTOR, (FROM), (TO_EXCLUSIVE), &OUT_ELEMS)

#define MARY_Vector_Point(VECTOR, INDEX, OUT_POINTER)\
  Mary_Vector_Point(&VECTOR, (INDEX), &OUT_POINTER)

#define MARY_Vector(PTR) ((Mary_Vector_t *)(PTR))

#define MARY_Vector_Each(VECTOR_PTR, TYPE)                                                         \
  for                                                                                              \
  (                                                                                                \
    struct { size_t idx, start, finish, units; TYPE *ptr; TYPE val; }                              \
    it =                                                                                           \
    {                                                                                              \
      0, 0, (VECTOR_PTR)->units - 1, (VECTOR_PTR)->units,                                          \
      (TYPE *)(VECTOR_PTR)->data, *((TYPE *)(VECTOR_PTR)->data)                                    \
    };                                                                                             \
    it.idx < it.units;                                                                             \
    ++it.idx, it.ptr = (void *)((u8 *)it.ptr + (VECTOR_PTR)->unit), it.val = *it.ptr               \
  )

// there is a bug in this macro. need to fix it and get rid of the other reverse.
#define MARY_Vector_Each_Reverse2(VECTOR_PTR, TYPE)                                                \
  for                                                                                              \
  (                                                                                                \
    struct { size_t idx, start, finish; TYPE *ptr; TYPE val; }                                     \
    it =                                                                                           \
    {                                                                                              \
      (VECTOR_PTR)->units - 1, (VECTOR_PTR)->units - 1, 0,                                         \
      (TYPE *)((u8 *)(VECTOR_PTR)->data + (VECTOR_PTR)->units * (VECTOR_PTR)->unit),               \
      *((TYPE *)((u8 *)(VECTOR_PTR)->data + (VECTOR_PTR)->units * (VECTOR_PTR)->unit))             \
    };                                                                                             \
    it.idx + 1 > it.finish;                                                                        \
    --it.idx, it.ptr = (void *)((u8 *)it.ptr - (VECTOR_PTR)->unit), it.val = *it.ptr               \
  )

#define MARY_Vector_Each_Reverse(VECTOR_PTR, TYPE)\
  MARY_Range((VECTOR_PTR)->data, TYPE, (VECTOR_PTR)->units - 1, 0)

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <Mary/Utils.h>
#include <Mary/Hashmap.h>
#include <Mary/Bitbool.h>

MARY_PRIMITIVES;

#define DEFAULT_BUCKETS 16 // this needs to be a power of 2
#define THRESHOLD_PERCENT 84

typedef u64 Used;
typedef struct { u64 idx; Used *used; u8 *key, *value; } Bucket;

static u64 Hash_Key(void *key, size_t unit_key);
static void Hash_Bucket(Mary_Hashmap_t *hashmap, void *key, Bucket *out_bucket);
static void Hash_Value(Mary_Hashmap_t *hashmap, void *key, void *value);
static void Rehash(Mary_Hashmap_t *hashmap, size_t total_buckets);

void Mary_Hashmap_Create(Mary_Hashmap_t *hashmap, size_t unit_key, size_t unit_value)
{
  size_t unit_bucket = MARY_Round_to_64bit(sizeof(Used) + unit_key + unit_value);
  Mary_Vector_Create(&hashmap->buckets, unit_bucket, DEFAULT_BUCKETS);
  hashmap->buckets.units = DEFAULT_BUCKETS;
  hashmap->occupied = 0;
  hashmap->unit_key = unit_key;
  hashmap->unit_value = unit_value;
  Mary_Hashmap_Empty(hashmap);
}

void Mary_Hashmap_Destroy(Mary_Hashmap_t *hashmap)
{
  Mary_Vector_Destroy(&hashmap->buckets);
}

void Mary_Hashmap_Assign(Mary_Hashmap_t *hashmap, void *in_key, void *in_value)
{
  if (hashmap->occupied >= (THRESHOLD_PERCENT * hashmap->buckets.units / 100))
  {
    Rehash(hashmap, hashmap->buckets.units << 1); // * 2
  }
  Hash_Value(hashmap, in_key, in_value);
}

char Mary_Hashmap_At(Mary_Hashmap_t *hashmap, void *in_key, void *out_value)
{
  Bucket bucket; Hash_Bucket(hashmap, in_key, &bucket);
  if (*bucket.used == 1)
  {
    memcpy(out_value, bucket.value, hashmap->unit_value);
    return 1;
  }
  else
  {
    return 0;
  }
}

void *Mary_Hashmap_Point(Mary_Hashmap_t *hashmap, void *in_key)
{
  Bucket bucket; Hash_Bucket(hashmap, in_key, &bucket);
  return bucket.value;
}

char Mary_Hashmap_Contains_Key(Mary_Hashmap_t *hashmap, void *in_key)
{
  Bucket bucket; Hash_Bucket(hashmap, in_key, &bucket);
  return (char)*bucket.used;
}

void Mary_Hashmap_Erase(Mary_Hashmap_t *hashmap, void *in_key)
{
  Bucket bucket; Hash_Bucket(hashmap, in_key, &bucket);
  *bucket.used = 0;
}

void Mary_Hashmap_Empty(Mary_Hashmap_t *hashmap)
{
  MARY_Vector_Each(&hashmap->buckets, Used)
  {
    *it.ptr = 0;
  }
}

static uint64_t Hash_Key(void *key, size_t unit_key)
{
  // FNV-1a https://en.wikipedia.org/wiki/Fowler%E2%80%93Noll%E2%80%93Vo_hash_function
  uint64_t hash =  0xcbf29ce484222325;
  uint64_t prime = 0x00000100000001b3;
  u8 *p = (u8 *)key;
  for (size_t i = 0; i < unit_key; ++i, p += 1)
  {
    hash ^= *p;
    hash *= prime;
  }
  return hash;
}

static void Hash_Bucket(Mary_Hashmap_t *hashmap, void *key, Bucket *bucket)
{
  size_t last_idx = hashmap->buckets.units - 1;
  bucket->idx = Hash_Key(key, hashmap->unit_key) & (last_idx);  // no mod, we & with buckets a ^ of 2
  bucket->used = Mary_Vector_Point(&hashmap->buckets, bucket->idx);
  bucket->key = (u8 *)bucket->used + sizeof(Used);
  bucket->value = bucket->key + hashmap->unit_key;

  while (1)
  {
    if (*bucket->used == 0)
    {
      break;
    }
    else if (memcmp(bucket->key, key, hashmap->unit_key) == 0)
    {
      break;
    }
    else if (bucket->idx == last_idx)
    {
      bucket->idx = 0;
      bucket->used = hashmap->buckets.data;
      bucket->key = (u8 *)bucket->used + sizeof(Used);
      bucket->value = bucket->key + hashmap->unit_key;
    }
    else
    {
      ++bucket->idx;
      bucket->used += hashmap->buckets.unit;
      bucket->key += hashmap->buckets.unit;
      bucket->value += hashmap->buckets.unit;
    }
  }
}

static void Hash_Value(Mary_Hashmap_t *hashmap, void *key, void *value)
{
  Bucket bucket; Hash_Bucket(hashmap, key, &bucket);
  if (*bucket.used == 0)
  {
    memcpy(bucket.key, key, hashmap->unit_key);
    memcpy(bucket.value, value, hashmap->unit_value);
    *bucket.used = 1;
    ++hashmap->occupied;
  }
  else
  {
    memcpy(bucket.value, value, hashmap->unit_value);
  }
}

static void Rehash(Mary_Hashmap_t *hashmap, size_t total_buckets)
{
  Mary_Vector_t old_buckets = hashmap->buckets;
  Mary_Vector_Create(&hashmap->buckets, hashmap->buckets.unit, total_buckets);
  hashmap->buckets.units = total_buckets;
  hashmap->occupied = 0;
  Mary_Hashmap_Empty(hashmap);

  MARY_Vector_Each(&old_buckets, u8)
  {
    if (*(Used *)it.ptr != 0)
    {
      Hash_Value(hashmap,
                 it.ptr + sizeof(Used),
                 it.ptr + sizeof(Used) + hashmap->unit_key);
    }
  }

  Mary_Vector_Destroy(&old_buckets);
}

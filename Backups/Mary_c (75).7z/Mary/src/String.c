#include <stdlib.h>
#include <string.h>
#include <Mary/String.h>

MARY_Primitives;

// these need to be separated into their own funcs.
void Mary_String_Create(Mary_String_t *mary_string, char bit_format, void *string, size_t opt_units)
{
  Mary_Vector_t *mary_vector = (Mary_Vector_t *)mary_string;
  if (bit_format == 8)
  {
    Mary_Vector_Create(mary_vector, 1, opt_units || 64);
    u8 *p = string; u8 code = *p;
    for (; code; ++p, code = *p)
    {
      Mary_Vector_Push_Back(mary_vector, &code);
    }
    code = 0; Mary_Vector_Push_Back(mary_vector, &code);
    if (!opt_units)
    {
      Mary_Vector_Fit(mary_vector);
    }
  }
  else if (bit_format == 16)
  {
    Mary_Vector_Create(mary_vector, 2, opt_units || 64);
    u16 *p = string; u16 code = *p;
    for (; code; ++p, code = *p)
    {
      Mary_Vector_Push_Back(mary_vector, &code);
    }
    code = 0; Mary_Vector_Push_Back(mary_vector, &code);
    if (!opt_units)
    {
      Mary_Vector_Fit(mary_vector);
    }
  }
  else if (bit_format == 32)
  {
    Mary_Vector_Create(mary_vector, 4, opt_units || 64);
    u32 *p = string; u32 code = *p;
    for (; code; ++p, code = *p)
    {
      Mary_Vector_Push_Back(mary_vector, &code);
    }
    code = 0; Mary_Vector_Push_Back(mary_vector, &code);
    if (!opt_units)
    {
      Mary_Vector_Fit(mary_vector);
    }
  }
  mary_string->codes = Mary_String_Count_Codes(mary_string);
}

void Mary_String_Create_At(Mary_String_t *mary_string, char bit_format, Mary_p mary_ptr)
{
  if (bit_format == 8)
  {
    Mary_String_8_Create_At(mary_string, mary_ptr);
  }
  else if (bit_format == 16)
  {
    Mary_String_16_Create_At(mary_string, mary_ptr);
  }
  else if (bit_format == 32)
  {
    Mary_String_32_Create_At(mary_string, mary_ptr);
  }
}

void Mary_String_8_Create_At(Mary_String_t *mary_string, Mary_p mary_ptr)
{
  Mary_Vector_t *mary_vector = MARY_Vector(mary_string);
  Mary_Vector_Create_At(mary_vector, sizeof(u8), mary_ptr);
  mary_string->codes = 0;
}

void Mary_String_16_Create_At(Mary_String_t *mary_string, Mary_p mary_ptr)
{
  Mary_Vector_t *mary_vector = MARY_Vector(mary_string);
  Mary_Vector_Create_At(mary_vector, sizeof(u16), mary_ptr);
  mary_string->codes = 0;
}

void Mary_String_32_Create_At(Mary_String_t *mary_string, Mary_p mary_ptr)
{
  Mary_Vector_t *mary_vector = MARY_Vector(mary_string);
  Mary_Vector_Create_At(mary_vector, sizeof(u32), mary_ptr);
  mary_string->codes = 0;
}

void Mary_String_Create_With(Mary_String_t *mary_string, char bit_format, Mary_p mary_ptr)
{
  if (bit_format == 8)
  {
    Mary_String_8_Create_With(mary_string, mary_ptr);
  }
  else if (bit_format == 16)
  {
    Mary_String_16_Create_With(mary_string, mary_ptr);
  }
  else if (bit_format == 32)
  {
    Mary_String_32_Create_With(mary_string, mary_ptr);
  }
}

void Mary_String_8_Create_With(Mary_String_t *mary_string, Mary_p mary_ptr)
{
  Mary_Vector_t *mary_vector = MARY_Vector(mary_string);
  Mary_Vector_Create_With(mary_vector, sizeof(u8), mary_ptr);
  mary_string->codes = Mary_String_Count_Codes(mary_string);
}

void Mary_String_16_Create_With(Mary_String_t *mary_string, Mary_p mary_ptr)
{
  Mary_Vector_t *mary_vector = MARY_Vector(mary_string);
  Mary_Vector_Create_With(mary_vector, sizeof(u16), mary_ptr);
  mary_string->codes = Mary_String_Count_Codes(mary_string);
}

void Mary_String_32_Create_With(Mary_String_t *mary_string, Mary_p mary_ptr)
{
  Mary_Vector_t *mary_vector = MARY_Vector(mary_string);
  Mary_Vector_Create_With(mary_vector, sizeof(u32), mary_ptr);
  mary_string->codes = Mary_String_Count_Codes(mary_string);
}

void Mary_String_Destroy(Mary_String_t *mary_string)
{
  free(mary_string->data);
}

// we now have a similiar thing in utils. consolidate.
size_t Mary_String_Count_Bytes(char bit_format, void *string, char want_null)
{
  size_t i = 0, inc = bit_format >> 3;
  for (u8 *p = string; *p != 0; i += inc, p += inc);
  return want_null ? i + inc : i;
}

size_t Mary_String_Count_Codes(Mary_String_t *mary_string)
{
  u64 count = 0;
  if (mary_string->unit == sizeof(u8))
  {
    u64 i = 0;
    u8 *p = mary_string->data, v = *p;
    while (i < mary_string->units)
    {
      if (v >> 7 == 0x00)
      {
        i += 1, p += 1, v = *p;
      }
      else if (v >> 5 == 0x06)
      {
        i += 2, p += 2, v = *p;
      }
      else if (v >> 4 == 0x0E)
      {
        i += 3, p += 3, v = *p;
      }
      else if (v >> 3 == 0x1E)
      {
        i += 4, p += 4, v = *p;
      }
      ++count;
    }
  }
  else if (mary_string->unit == sizeof(u16))
  {
    u64 i = 0;
    u16 *p = mary_string->data, v = *p;
    while (i < mary_string->units)
    {
      if (v < 0xD800 || v > 0xDFFF)
      {
        i += 1, p += 1, v = *p;
      }
      else
      {
        i += 2, p += 2, v = *p;
      }
      ++count;
    }
  }
  else if (mary_string->unit == sizeof(u32))
  {
    count = mary_string->units;
  }
  return count;
}

char Mary_String_Get_Format(Mary_String_t *mary_string)
{
  return (char)(mary_string->unit * 8);
}

void Mary_String_Format(Mary_String_t *mary_string, char new_bit_format)
{
  u8 old_bit_format = (u8)mary_string->unit * 8;
  if (old_bit_format == 8 && new_bit_format == 16)
  {
    Mary_String_Format_8_To_16(mary_string);
  }
  else if (old_bit_format == 8 && new_bit_format == 32)
  {
    Mary_String_Format_8_To_32(mary_string);
  }
  else if (old_bit_format == 16 && new_bit_format == 8)
  {
    Mary_String_Format_16_To_8(mary_string);
  }
  else if (old_bit_format == 16 && new_bit_format == 32)
  {
    Mary_String_Format_16_To_32(mary_string);
  }
  else if (old_bit_format == 32 && new_bit_format == 8)
  {
    Mary_String_Format_32_To_8(mary_string);
  }
  else if (old_bit_format == 32 && new_bit_format == 16)
  {
    Mary_String_Format_32_To_16(mary_string);
  }
}

#define Push Mary_Vector_Push_Back
void Mary_String_Format_8_To_16(Mary_String_t *string)
{
  Mary_String_t buffer; buffer.codes = 0;
  Mary_Vector_t *vec = MARY_Vector(&buffer);
  Mary_Vector_Create(vec, sizeof(u16), string->units);
  u8 *p = string->data;
  u32 utf32 = 1;
  u16 a, b;
  while (utf32 != 0)
  {
    MARY_String_8_Decode(p, utf32, p += 1, p += 2, p += 3, p += 4);
    MARY_String_16_Encode
    (
      utf32, a, b,
      (Push(vec, &a)),
      (Push(vec, &a), Push(vec, &b))
    );
    ++buffer.codes;
  }
  string->units = 0;
  string->unit = buffer.unit;
  string->codes = buffer.codes;
  Mary_Vector_Add_Slice(MARY_Vector(string), 0, buffer.units, buffer.data);
  Mary_Vector_Destroy(vec);
}

void Mary_String_Format_8_To_32(Mary_String_t *string)
{
  Mary_String_t buffer; buffer.codes = 0;
  Mary_Vector_t *vec = MARY_Vector(&buffer);
  Mary_Vector_Create(vec, sizeof(u32), string->units);
  u8 *p = string->data;
  u32 utf32 = 1;
  while (utf32 != 0)
  {
    MARY_String_8_Decode(p, utf32, p += 1, p += 2, p += 3, p += 4);
    Mary_Vector_Push_Back(vec, &utf32);
    ++buffer.codes;
  }
  string->units = 0;
  string->unit = buffer.unit;
  string->codes = buffer.codes;
  Mary_Vector_Add_Slice(MARY_Vector(string), 0, buffer.units, buffer.data);
  Mary_Vector_Destroy(vec);
}

void Mary_String_Format_16_To_8(Mary_String_t *string)
{
  Mary_String_t buffer; buffer.codes = 0;
  Mary_Vector_t *vec = MARY_Vector(&buffer);
  Mary_Vector_Create(vec, sizeof(u8), string->units);
  u16 *p = string->data;
  u32 utf32 = 1;
  u8 a, b, c, d;
  while (utf32 != 0)
  {
    MARY_String_16_Decode(p, utf32, p += 1, p += 2);
    MARY_String_8_Encode
    (
      utf32, a, b, c, d,
      (Push(vec, &a)),
      (Push(vec, &a), Push(vec, &b)),
      (Push(vec, &a), Push(vec, &b), Push(vec, &c)),
      (Push(vec, &a), Push(vec, &b), Push(vec, &c), Push(vec, &d))
    );
    ++buffer.codes;
  }
  string->units = 0;
  string->unit = buffer.unit;
  string->codes = buffer.codes;
  Mary_Vector_Add_Slice(MARY_Vector(string), 0, buffer.units, buffer.data);
  Mary_Vector_Destroy(vec);
}

void Mary_String_Format_16_To_32(Mary_String_t *string)
{
  Mary_String_t buffer; buffer.codes = 0;
  Mary_Vector_t *vec = MARY_Vector(&buffer);
  Mary_Vector_Create(vec, sizeof(u32), string->units);
  u16 *p = string->data;
  u32 utf32 = 1;
  while (utf32 != 0)
  {
    MARY_String_16_Decode(p, utf32, p += 1, p += 2);
    Mary_Vector_Push_Back(vec, &utf32);
    ++buffer.codes;
  }
  string->units = 0;
  string->unit = buffer.unit;
  string->codes = buffer.codes;
  Mary_Vector_Add_Slice(MARY_Vector(string), 0, buffer.units, buffer.data);
  Mary_Vector_Destroy(vec);
}

void Mary_String_Format_32_To_8(Mary_String_t *string)
{
  Mary_String_t buffer; buffer.codes = 0;
  Mary_Vector_t *vec = MARY_Vector(&buffer);
  Mary_Vector_Create(vec, sizeof(u8), string->units);
  u32 *p = string->data;
  u32 utf32 = 1;
  u8 a, b, c, d;
  while (utf32 != 0)
  {
    utf32 = *p; ++p;
    MARY_String_8_Encode
    (
      utf32, a, b, c, d,
      (Push(vec, &a)),
      (Push(vec, &a), Push(vec, &b)),
      (Push(vec, &a), Push(vec, &b), Push(vec, &c)),
      (Push(vec, &a), Push(vec, &b), Push(vec, &c), Push(vec, &d))
    );
    ++buffer.codes;
  }
  string->units = 0;
  string->unit = buffer.unit;
  string->codes = buffer.codes;
  Mary_Vector_Add_Slice(MARY_Vector(string), 0, buffer.units, buffer.data);
  Mary_Vector_Destroy(vec);
}

void Mary_String_Format_32_To_16(Mary_String_t *string)
{
  Mary_String_t buffer; buffer.codes = 0;
  Mary_Vector_t *vec = MARY_Vector(&buffer);
  Mary_Vector_Create(vec, sizeof(u16), string->units);
  u32 *p = string->data;
  u32 utf32 = 1;
  u16 a, b;
  while (utf32 != 0)
  {
    utf32 = *p; ++p;
    MARY_String_16_Encode
    (
      utf32, a, b,
      (Push(vec, &a)),
      (Push(vec, &a), Push(vec, &b))
    );
    ++buffer.codes;
  }
  string->units = 0;
  string->unit = buffer.unit;
  string->codes = buffer.codes;
  Mary_Vector_Add_Slice(MARY_Vector(string), 0, buffer.units, buffer.data);
  Mary_Vector_Destroy(vec);
}
#undef Push

void Mary_String_8_Match(Mary_String_t *mary_string, Mary_String_t *regex)
{
  // take the matches from an Regex_Execute and narrow down by flags. Maybe we should do the flags in here, not the compiler.
}

void Mary_String_8_Replace(Mary_String_t *mary_string, u8 *regex, u8 *replacement)
{

}

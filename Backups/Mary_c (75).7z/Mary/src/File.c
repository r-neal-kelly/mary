#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <Mary/File.h>

MARY_Primitives;

const char modes[12][4] =
{
  "rb", "r+b", "wb", "w+b", "ab", "a+b",
  "rb", "r+b", "wb", "w+b", "ab", "a+b"
};

static void File_Error(Mary_File_t *mary_file);

void Mary_File_Create(Mary_File_t *mary_file, const char *file_path, uint32_t enum_mode, uint64_t unit)
{
  mary_file->unit = unit;

  mary_file->flags = 0;
  if (enum_mode < MARY_FILE_READ_BYTES)
  {
    mary_file->flags |= MARY_FILE_TEXT;
  }
  else
  {
    mary_file->flags |= MARY_FILE_BYTES;
  }

  // can fopen still open up a file_path even if it's in utf16?
  mary_file->stream = fopen(file_path, &modes[enum_mode][0]);
  if (mary_file->stream == 0)
  {
    File_Error(mary_file);
  }
  else
  {
    if (enum_mode == MARY_FILE_WRITE_TEXT || enum_mode == MARY_FILE_APPEND_TEXT ||
        enum_mode == MARY_FILE_WRITE_BYTES || enum_mode == MARY_FILE_APPEND_BYTES)
    {
      mary_file->units = 0;
    }
    else
    {
      u64 bytes = 0;
      while (fgetc(mary_file->stream),
             feof(mary_file->stream) == 0)
      {
        ++bytes;
      }
      rewind(mary_file->stream);

      mary_file->units = bytes / unit;
    }
  }
}

void Mary_File_Destroy(Mary_File_t *mary_file)
{
  if (fclose(mary_file->stream) == EOF)
  {
    File_Error(mary_file);
  }
  else
  {
    mary_file->flags |= MARY_FILE_ENDED;
  }
}

static void File_Error(Mary_File_t *mary_file)
{
  mary_file->units = 0;
  mary_file->flags |= MARY_FILE_ERROR;
  MARY_Assert(mary_file->flags & MARY_FILE_ERROR);
}

uint64_t Mary_File_Has_Error(Mary_File_t *mary_file)
{
  return mary_file->flags & MARY_FILE_ERROR ? MARY_TRUE : MARY_FALSE;
}

uint64_t Mary_File_Has_Bytes(Mary_File_t *mary_file)
{
  return mary_file->flags & MARY_FILE_BYTES ? MARY_TRUE : MARY_FALSE;
}

uint64_t Mary_File_Has_Text(Mary_File_t *mary_file)
{
  return mary_file->flags & MARY_FILE_TEXT ? MARY_TRUE : MARY_FALSE;
}

uint64_t Mary_File_Has_Ended(Mary_File_t *mary_file)
{
  if (MARY_Truthy(feof(mary_file->stream)))
  {
    mary_file->flags |= MARY_FILE_ENDED;
    return MARY_TRUE;
  }
  else
  {
    return MARY_FALSE;
  }
}

uint64_t Mary_File_Read_Unit(Mary_File_t *mary_file, void *out_unit)
{
  if (mary_file->flags & MARY_FILE_ENDED)
  {
    return MARY_FALSE;
  }
  else if (mary_file->flags & MARY_FILE_TEXT)
  {
    u64 cr = '\r', lf = '\n';
    fread(out_unit, mary_file->unit, 1, mary_file->stream);
    if (MARY_Truthy(feof(mary_file->stream)))
    {
      mary_file->flags |= MARY_FILE_ENDED;
      return MARY_FALSE;
    }
    else
    {
      if (memcmp(out_unit, &cr, mary_file->unit) == 0)
      {
        fpos_t pos; fgetpos(mary_file->stream, &pos);
        fread(out_unit, mary_file->unit, 1, mary_file->stream);
        if (MARY_Truthy(feof(mary_file->stream)))
        {
          Mary_Copy(&lf, out_unit, mary_file->unit);
          mary_file->flags |= MARY_FILE_ENDED;
        }
        else if (memcmp(out_unit, &lf, mary_file->unit) != 0)
        {
          fsetpos(mary_file->stream, &pos);
          Mary_Copy(&lf, out_unit, mary_file->unit);
        }
      }
    }
  }
  else
  {
    fread(out_unit, mary_file->unit, 1, mary_file->stream);
    if (MARY_Truthy(feof(mary_file->stream)))
    {
      mary_file->flags |= MARY_FILE_ENDED;
      return MARY_FALSE;
    }
  }
  return MARY_TRUE;
}

Mary_Bool_t Mary_File_Read_Line(Mary_File_t *mary_file, Mary_Vector_t *out_buffer, uint64_t is_created)
{
  if ((mary_file->flags & MARY_FILE_BYTES) || (mary_file->flags & MARY_FILE_ENDED))
  {
    return MARY_FALSE;
  }

  if (MARY_Falsey(is_created))
  {
    Mary_Vector_Create(out_buffer, mary_file->unit, 0);
  }

  u64 code = 0, units = 0;
  while (Mary_File_Read_Unit(mary_file, &code) && code == '\n');
  if (code != 0)
  {
    ++units, Mary_Vector_Push_Back(out_buffer, &code);
  }

  while (Mary_File_Read_Unit(mary_file, &code) && code != '\n')
  {
    ++units, Mary_Vector_Push_Back(out_buffer, &code);
  }

  if (units == 0)
  {
    return MARY_FALSE;
  }
  else
  {
    if (code != 0)
    {
      code = 0; Mary_Vector_Push_Back(out_buffer, &code);
    }
    return MARY_TRUE;
  }
}

void Mary_File_Read_All(Mary_File_t *mary_file, Mary_Vector_t *out_buffer, uint64_t is_created)
{
  rewind(mary_file->stream);

  if (MARY_Truthy(is_created))
  {
    MARY_Assert(out_buffer->unit == mary_file->unit);
    Mary_Vector_Reserve(out_buffer, out_buffer->units + mary_file->units + 1); // extra room for null
  }
  else
  {
    Mary_Vector_Create(out_buffer, mary_file->unit, mary_file->units + 1); // extra room for null
  }

  u8 *buffer_ptr = MARY_Vector_Point(out_buffer, out_buffer->units);
  if (mary_file->flags & MARY_FILE_TEXT)
  {
    while (Mary_File_Read_Unit(mary_file, buffer_ptr))
    {
      ++out_buffer->units, buffer_ptr += mary_file->unit;
    }
    u64 null = '\0'; Mary_Vector_Push_Back(out_buffer, &null);
  }
  else
  {
    u64 units_read = fread(buffer_ptr, mary_file->unit, mary_file->units, mary_file->stream);
    if (MARY_Truthy(ferror(mary_file->stream)) || units_read != mary_file->units)
    {
      File_Error(mary_file);
    }
    else
    {
      out_buffer->units += units_read;
    }
  }
}

void Mary_File_Write_All(Mary_File_t *mary_file, Mary_Vector_t *in_buffer)
{
  u64 written_units = fwrite((const void*)in_buffer->data, in_buffer->unit,
                             in_buffer->units, mary_file->stream);
  if (written_units != in_buffer->units)
  {
    File_Error(mary_file);
  }
}

#pragma once

#include <stdio.h>
#include <Mary/Utils.h>
#include <Mary/Vector.h>

enum
{
  MARY_FILE_READ_TEXT,
  MARY_FILE_READ_WRITE_TEXT,
  MARY_FILE_WRITE_TEXT,
  MARY_FILE_WRITE_READ_TEXT,
  MARY_FILE_APPEND_TEXT,
  MARY_FILE_APPEND_READ_TEXT,
  MARY_FILE_READ_BYTES,
  MARY_FILE_READ_WRITE_BYTES,
  MARY_FILE_WRITE_BYTES,
  MARY_FILE_WRITE_READ_BYTES,
  MARY_FILE_APPEND_BYTES,
  MARY_FILE_APPEND_READ_BYTES
};

enum
{
  MARY_FILE_ERROR = 0x01,
  MARY_FILE_BYTES = 0x02, 
  MARY_FILE_TEXT = 0x04,
  MARY_FILE_ENDED = 0x08
};

typedef struct
{
  FILE *stream;
  uint64_t unit;
  uint64_t units;
  uint64_t flags;
}
Mary_File_t;

// maybe we shouldn't always do the create and destroy pattern, but it would be consistent if we did.
// make sure to handle \n properly...?

void Mary_File_Create(Mary_File_t *mary_file, const char *file_path, uint32_t enum_mode, uint64_t unit); // Open()?
void Mary_File_Destroy(Mary_File_t *mary_file); // Close()?
Mary_Bool_t Mary_File_Has_Error(Mary_File_t *mary_file);
Mary_Bool_t Mary_File_Has_Bytes(Mary_File_t *mary_file);
Mary_Bool_t Mary_File_Has_Text(Mary_File_t *mary_file);
Mary_Bool_t Mary_File_Has_Ended(Mary_File_t *mary_file);
Mary_Bool_t Mary_File_Read_Unit(Mary_File_t *mary_file, void *out_unit);
Mary_Bool_t Mary_File_Read_Line(Mary_File_t *mary_file, Mary_Vector_t *out_buffer, uint64_t is_created);
void Mary_File_Read_All(Mary_File_t *mary_file, Mary_Vector_t *out_buffer, uint64_t is_created); // All_Units? and another, All_Lines
void Mary_File_Write_Unit(Mary_File_t *mary_file, void *in_unit);
// rewind func?
// maybe we could have a Write_Line that takes text? maybe. I think we should make it a String_t though?
void Mary_File_Write_All(Mary_File_t *mary_file, Mary_Vector_t *in_buffer);

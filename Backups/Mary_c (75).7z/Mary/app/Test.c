﻿#include <stdio.h>
#include <Mary/Mary.h>

MARY_Primitives;

void test()
{
#if 1
  Mary_String_t string;
  Mary_String_Create(&string, 32, MARY_C_String(u32, "aγፈ𐙖"), 0);
  MARY_String_32_Each(&string) printf("%u\n", it.code);
  Mary_String_Format(&string, 8); printf("\n");
  MARY_String_8_Each(&string) printf("%u\n", it.code);
  Mary_String_Format(&string, 32); printf("\n");
  MARY_String_32_Each(&string) printf("%u\n", it.code);
  Mary_String_Format(&string, 16); printf("\n");
  MARY_String_16_Each(&string) printf("%u\n", it.code);
  Mary_String_Format(&string, 8); printf("\n");
  MARY_String_8_Each(&string) printf("%u\n", it.code);
  Mary_String_Format(&string, 16); printf("\n");
  MARY_String_16_Each(&string) printf("%u\n", it.code);
  Mary_String_Format(&string, 32); printf("\n");
  MARY_String_32_Each(&string) printf("%u\n", it.code);
  Mary_Exit_Success();
#endif
}

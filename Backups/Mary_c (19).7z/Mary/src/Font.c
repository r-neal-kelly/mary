#include <stdint.h>
#include <Mary/Utils.h>
#include <Mary/Vector.h>
#include <Mary/String.h>
#include <Mary/Font.h>

#define RASTER_TRUETYPE     0x74727565
#define RASTER_POSTSCRIPT   0x74797031
#define RASTER_OPENTYPE_TTF 0x00010000
#define RASTER_OPENTYPE_CFF 0x4F54544F

FT_Library g_ft_library;
uint8_t g_little_endian = 0;
#define U16(P) (g_little_endian ? MARY_SWAP_16(*(uint16_t *)(P)) : *(uint16_t *)(P))
#define U32(P) (g_little_endian ? MARY_SWAP_32(*(uint32_t *)(P)) : *(uint32_t *)(P))
#define U64(P) (g_little_endian ? MARY_SWAP_64(*(uint64_t *)(P)) : *(uint64_t *)(P))
#define S16(P) (g_little_endian ? MARY_SWAP_16(*( int16_t *)(P)) : *( int16_t *)(P))
#define S32(P) (g_little_endian ? MARY_SWAP_32(*( int32_t *)(P)) : *( int32_t *)(P))
#define S64(P) (g_little_endian ? MARY_SWAP_64(*( int64_t *)(P)) : *( int64_t *)(P))

void Mary_Font_Start()
{
  if (FT_Init_FreeType(&g_ft_library))
    Mary_Exit_Failure("Mary_Font_Start: Failed to init FreeType.");

  volatile uint16_t i = 0x0001;
  if (*(uint8_t *)&i == 1)
    g_little_endian = 1;
  else
    g_little_endian = 0;
}

void Mary_Font_Finish()
{
  if (FT_Done_FreeType(g_ft_library))
    Mary_Exit_Failure("Mary_Font_Finish: Failed to free FreeType.");
}

void Mary_Font_Create(Mary_Font_t *mary_font, char *file_path)
{
  Mary_File_t file = Mary_File_Read(file_path);
  mary_font->data = file.data;
  uint8_t *data_start = file.data;
  uint8_t *p = data_start;

  { ////// can we handle this type of font?
    uint32_t rasterizer = U32(p); p += 4;
    if (rasterizer != RASTER_OPENTYPE_TTF)
      Mary_Exit_Failure("Mary_Font_Create: Can only handle standard OpenType fonts.");
  }

  { ////// store table lookup in hashmap
    uint16_t num_tables = U16(p); p += 8;
    char table_tag[5]; memset(table_tag + 4, 0, 1);
    Mary_Hashmap_Create(&mary_font->tables, 5, sizeof(void *));
    for (int i = 0; i < num_tables; ++i)
    {
      memcpy(table_tag, p, 4); p += 8;
      uint32_t offset = U32(p); p += 8;
      void *table_start = data_start + offset;
      Mary_Hashmap_Insert(&mary_font->tables, table_tag, &table_start);
      printf("%s: %i\n", table_tag, offset);//
    }
  }

  { ////// create freetype font face
    if (FT_New_Memory_Face(g_ft_library, file.data, (FT_Long)file.size, 0, &mary_font->ft_face))
      Mary_Exit_Failure("Mary_Font_Create: Couldn't creat FreeType font face.");
    FT_Set_Pixel_Sizes(mary_font->ft_face, 0, 16);
    mary_font->pixel_size = 16;

    printf("num_glyphs:%i\n", mary_font->ft_face->num_glyphs);//
    printf("units_per_em:%u\n", mary_font->ft_face->units_per_EM);//
    printf("num_fixed_sizes:%i\n", mary_font->ft_face->num_fixed_sizes);//
    printf("y_ppem:%u\n", mary_font->ft_face->size->metrics.y_ppem);//
  }
}

void Mary_Font_Destroy(Mary_Font_t *mary_font)
{
  FT_Done_Face(mary_font->ft_face);
  Mary_Hashmap_Destroy(&mary_font->tables);
  free(mary_font->data);
}

void Mary_Font_Layout(Mary_Font_t *mary_font, Mary_String_t *string)
{
  char string_format = Mary_String_Get_Format(string);
  if (string_format != 32)
  {
    Mary_String_Format(string, 32);
  }
  uint32_t *unicodes = string->data;
  Mary_Vector_t v_glyph_indices;
  Mary_Vector_Create(&v_glyph_indices, sizeof(FT_UInt), 64);
  for (int i = 0; i < string->size; ++i)
  {
    FT_UInt glyph_index = FT_Get_Char_Index(mary_font->ft_face, unicodes[i]);
    Mary_Vector_Push_Back(&v_glyph_indices, &glyph_index);
    printf("%4u ", glyph_index);//
  }
  puts("");

  // and then we run those through both the GSUB and GPOS tables
  // which I now believe will only work with the indices and pixels (ppem)
  // meaning we can have freetype rasterize our glyphs after GSUB and beforre GPOS
  Mary_Vector_Destroy(&v_glyph_indices);
}

#include <stdio.h>
#include <Mary/Utils.h>
#include <Mary/Vector.h>
#include <Mary/Test/Test.h>
#include <Mary/Test/Test_Vector.h>

MARY_Primitives;

void Test_Vector_Loops()
{
  TEST_START(Test_Vector_Loops);

  MARY_Vector_Stack(nums, u8, 256);

  for (I i = 0; i < 256; ++i)
  {
    MARY_Vector_Push(&nums, u8, (u8)i);
  }

  I independant = 0;

  MARY_Vector_Each(&nums, u8)
  {
    MARY_Assert(it.v = &nums, 0);
    MARY_Assert(it.idx == independant, 0);
    MARY_Assert(it.end == 255, 0);
    MARY_Assert(it.ptr == &nums_array[it.idx], 0);
    MARY_Assert(it.val == nums_array[it.val], 0);
    ++independant;
  }

  MARY_Assert(independant == 256, 0);

  independant = 255;

  MARY_Vector_Each_Reverse(&nums, u8)
  {
    MARY_Assert(it.v = &nums, 0);
    MARY_Assert(it.idx == independant, 0);
    MARY_Assert(it.end == 0, 0);
    MARY_Assert(it.ptr == &nums_array[it.idx], 0);
    MARY_Assert(it.val == nums_array[it.val], 0);
    --independant;
  }

  MARY_Assert(independant + 1 == 0, 0);

  // I think we should be able to handle a it.v.units of ~0llu
  // in Vector_Each, but in Each_Reverse, it won't even start,
  // because of the it.idx + 1 trick. in order to fix it, we would
  // have to store a separate variable for units. It's such an edge case
  // though. About 16,777,216 terrabytes for an array with ~0llu u8's!

  TEST_STOP;
}

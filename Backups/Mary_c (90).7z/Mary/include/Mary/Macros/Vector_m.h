#pragma once

#include <Mary/Vector.h>

#undef MARY_Vector
#undef MARY_Vector_Stack
#undef MARY_Vector_Create
#undef MARY_Vector_Create_At
#undef MARY_Vector_Create_With
#undef MARY_Vector_Create_Stack
#undef MARY_Vector_Has_Index
#undef MARY_Vector_Is_Empty
#undef MARY_Vector_Point
#undef MARY_Vector_Point_Front
#undef MARY_Vector_Point_Back
#undef MARY_Vector_At
#undef MARY_Vector_At_Front
#undef MARY_Vector_At_Back
#undef MARY_Vector_Push
#undef MARY_Vector_Pop
#undef MARY_Vector_Point_Push
#undef MARY_Vector_Point_Pop
#undef MARY_Vector_Empty
#undef MARY_Vector_Cast
#undef MARY_Vector_Each
#undef MARY_Vector_Each_Reverse

////// Constants //////

#define MARY_Vector_Grow_Rate 1.7f

////// Namespace //////

#define MARY_Vector_Namespace\
  <Mary/Namespace/Vector_Begin.h>

#define MARY_Vector_Namespace_Begin\
  <Mary/Namespace/Vector_Begin.h>

#define MARY_Vector_Namespace_Quick\
  <Mary/Namespace/Vector_Quick.h>

#define MARY_Vector_Namespace_End\
  <Mary/Namespace/Vector_End.h>

////// Creation //////

#define MARY_Vector_Create(NAME, ALLOCATOR, TYPE, OPT_RESERVE_UNITS)\
  Mary_Vector_t NAME; Mary_Vector_Create(&NAME, ALLOCATOR, sizeof(TYPE), OPT_RESERVE_UNITS);

#define MARY_Vector_Create_At(NAME, AT_DATA, AT_BYTES, AT_ALLOCATOR, AT_TYPE)\
  MARY_Pointer(NAME##_at_ptr, AT_DATA, AT_BYTES, AT_ALLOCATOR);\
  Mary_Vector_t NAME; Mary_Vector_Create_At(&NAME, &NAME##_at_ptr, sizeof(AT_TYPE))

#define MARY_Vector_Create_With(NAME, WITH_DATA, WITH_BYTES, WITH_ALLOCATOR, WITH_TYPE, WITH_UNITS)\
  MARY_Pointer(NAME##_with_ptr, WITH_DATA, WITH_BYTES, WITH_ALLOCATOR);\
  Mary_Vector_t NAME; Mary_Vector_Create_With(&NAME, &NAME##_with_ptr, sizeof(WITH_TYPE), WITH_UNITS)

#define MARY_Vector_Create_Stack(NAME, TYPE, UNITS)\
  TYPE NAME##_array[UNITS];\
  MARY_Vector_Create_At(NAME, NAME##_array, sizeof(NAME##_array), MARY_STACK, TYPE)

#define MARY_Vector(NAME, ALLOCATOR, TYPE, OPT_RESERVE_UNITS)\
  MARY_Vector_Create(NAME, ALLOCATOR, TYPE, OPT_RESERVE_UNITS)

#define MARY_Vector_Stack(NAME, TYPE, UNITS)\
  MARY_Vector_Create_Stack(NAME, TYPE, UNITS)

////// Booleans //////

#define MARY_Vector_Has_Index(THIS, IDX)\
  ( (IDX) < (THIS)->units )

#define MARY_Vector_Is_Empty(THIS)\
  ( !MARY_Vector_Has_Index(THIS, 0) )

////// Accessing //////

#define MARY_Vector_Point(THIS, IDX)\
  MARY_Cast( (uint8_t *)(THIS)->data + (IDX) * (THIS)->unit, void )

#define MARY_Vector_Point_Front(THIS)\
  MARY_Cast( (THIS)->data, void )

#define MARY_Vector_Point_Back(THIS)\
  MARY_Cast( (uint8_t *)(THIS)->data + ((THIS)->units - 1) * (THIS)->unit, void )

#define MARY_Vector_At(THIS, TYPE, IDX)                                           \
  *MARY_Cast( ( MARY_Assert(MARY_Vector_Has_Index(THIS, IDX), "Invalid index."),  \
                MARY_Assert(sizeof(TYPE) == (THIS)->unit, "Invalid type."),       \
                (uint8_t *)(THIS)->data + (IDX) * (THIS)->unit ), TYPE            )

#define MARY_Vector_At_Front(THIS, TYPE)                                    \
  *MARY_Cast( ( MARY_Assert(!MARY_Vector_Is_Empty(THIS), "Empty Vector."),  \
                MARY_Assert(sizeof(TYPE) == (THIS)->unit, "Invalid type."), \
                (THIS)->data ), TYPE                                        )

#define MARY_Vector_At_Back(THIS, TYPE)                                               \
  *MARY_Cast( ( MARY_Assert(!MARY_Vector_Is_Empty(THIS), "Empty Vector."),            \
                MARY_Assert(sizeof(TYPE) == (THIS)->unit, "Invalid type."),           \
                (uint8_t *)(THIS)->data + ((THIS)->units - 1) * (THIS)->unit ), TYPE  )

////// Altering //////

#define MARY_Vector_Push(THIS, TYPE, ITEM)           \
  ( ++(THIS)->units * (THIS)->unit > (THIS)->bytes ? \
      (Mary_Vector_Grow(THIS), 0) : 0,               \
    MARY_Vector_At_Back(THIS, TYPE) = ITEM           )

#define MARY_Vector_Pop(THIS, TYPE)\
  MARY_Vector_At_Back(THIS, TYPE); --(THIS)->units

#define MARY_Vector_Point_Push(THIS)                 \
  ( ++(THIS)->units * (THIS)->unit > (THIS)->bytes ? \
      (Mary_Vector_Grow(THIS), 0) : 0,               \
    MARY_Vector_Point_Back(THIS)                     )

#define MARY_Vector_Point_Pop(THIS)                            \
  ( MARY_Assert(!MARY_Vector_Is_Empty(THIS), "Empty Vector."), \
    MARY_Vector_Point_Back(THIS) ); --(THIS)->units

#define MARY_Vector_Empty(THIS)\
  ( (THIS)->units = 0 )

#define MARY_Vector_Cast(THIS)\
  MARY_Cast(THIS, Mary_Vector_t)

////// Loops //////

#define MARY_Vector_Each(THIS, TYPE)                                         \
  for                                                                        \
  (                                                                          \
    struct { Mary_Vector_t *v; Mary_Index_t idx, end; TYPE *ptr; TYPE val; } \
    it = { (THIS), 0, it.v->units ? it.v->units - 1 : 0,                     \
            MARY_Vector_Point_Front(it.v), *it.ptr       };                  \
    it.idx < it.v->units;                                                    \
    ++it.idx, it.ptr = MARY_Vector_Point(it.v, it.idx), it.val = *it.ptr     \
  )

#define MARY_Vector_Each_Reverse(THIS, TYPE)                                 \
  for                                                                        \
  (                                                                          \
    struct { Mary_Vector_t *v; Mary_Index_t idx, end; TYPE *ptr; TYPE val; } \
    it = { (THIS), it.v->units - 1, 0,                                       \
           it.v->units ? MARY_Vector_Point_Back(it.v) :                      \
             MARY_Vector_Point_Front(it.v), *it.ptr     };                   \
    it.idx + 1 > 0;                                                          \
    --it.idx, it.ptr = MARY_Vector_Point(it.v, it.idx), it.val = *it.ptr     \
  )

////// To be done //////

// I want to be able to combine these in a func so that it does the right one for the size.
#define MARY_Vector_Bubble_Sort(BOOL_EXPRESSION)

#define MARY_Vector_Quick_Sort(BOOL_EXPRESSION)

#define MARY_Vector_Linear_Search(BOOL_EXPRESSION)

#define MARY_Vector_Binary_Search(BOOL_EXPRESSION)

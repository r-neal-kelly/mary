#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <Mary/Utils.h>
#include <Mary/Hashmap.h>
#include <Mary/Regex.h>

MARY_PRIMITIVES;

#define ESC  '~'        // NOT backslash
#define DOT  0xF0000000 // .
#define BAR  0xF0000001 // |
#define AND  0xF0000002 // & (implicit)
#define QUES 0xF0000003 // ?
#define STAR 0xF0000004 // *
#define PLUS 0xF0000005 // +
#define EXPO 0xF0000006 // ^
#define CASH 0xF0000007 // $
#define LPAR 0xF0000008 // (
#define RPAR 0xF0000009 // )
#define LSQU 0xF000000A // [
#define RSQU 0xF000000B // ]
#define HYPH 0xF000000C // -
#define APOS 0xF000000D // ?>
#define ANEG 0xF000000E // ?>!
#define BPOS 0xF000000F // ?<
#define BNEG 0xF0000010 // ?<!
#define BOUP 0xF0000011 // ~b
#define BOUN 0xF0000012 // ~B

#define FLAG_GLOBAL    0x01 // 'g'
#define FLAG_MULTILINE 0x02 // 'm'

#define SHORT_SPACES       0xF0000000 // ~s ~S
#define SHORT_LATIN        0xF0000001 // ~:Latin: ~:!Latin:
#define SHORT_HEBREW       0xF0000002 // ~:Hebrew: ~:!Hebrew:
#define SHORT_GREEK        0xF0000003 // ~:Greek: ~:!Greek:
#define SHORT_LATIN_CHAR   0xF0000004 // ~:Latin Char: ~:!Latin Char:
#define SHORT_HEBREW_CHAR  0xF0000005 // ~:Hebrew Char: ~:!Hebrew Char:
#define SHORT_GREEK_CHAR   0xF0000006 // ~:Greek Char: ~:!Greek Char:
#define SHORT_UNICODE_CHAR 0XF0000007 // ~:Unicode Char: ~:!Unicode Char:
#define SHORT_LATIN_PUNC   0xF0000008 // ~:Latin Punc: ~:!Latin Punc:
#define SHORT_HEBREW_PUNC  0xF0000009 // ~:Hebrew Punc: ~:!Hebrew Punc:
#define SHORT_GREEK_PUNC   0xF000000A // ~:Greek Punc: ~:!Greek Punc:
#define SHORT_UNICODE_PUNC 0XF000000B // ~:Unicode Punc: ~:!Unicode Punc:
// SHORT_LATIN_NUMB ?

#define STATE_DOT        0xF0000000 // .
#define STATE_XOR        0xF0000001 // []
#define STATE_NOR        0xF0000002 // [^]
#define STATE_SPLIT      0xF0000003 // *, +, ?, |
#define STATE_AHEAD_POS  0xF0000004 // (?>)
#define STATE_AHEAD_NEG  0xF0000005 // (?>!)
#define STATE_BEHIND_POS 0xF0000006 // (?<)
#define STATE_BEHIND_NEG 0xF0000007 // (?<!)
#define STATE_BOUND_EXPO 0xF0000008 // ^
#define STATE_BOUND_CASH 0xF0000009 // $
#define STATE_BOUND_POS  0xF000000A // ~b
#define STATE_BOUND_NEG  0xF000000B // ~B
#define STATE_MATCH      0xF000000C

typedef struct
{
  u32 size;
  u32 str[64];
}
Shortcut;

typedef struct
{
  u32 flag; // 0x0 - 0x10FFFF for unicode
  void *out_a; // State *
  void *out_b; // State *
}
State;

typedef struct
{
  State *in;
  Mary_Pointer_t outs; // [State **...]
}
Fragment;

typedef struct
{
  State *state;
  u64 from;
}
Candidate;

typedef Mary_Slice_t Match;

b64 mary_regex_is_started = 0;
Mary_Hashmap_t hm_shortcuts;

void Mary_Regex_Start()
{
  u32 short_id, *str; Shortcut shortcut;
  Mary_Hashmap_Create(&hm_shortcuts, sizeof(u32), sizeof(Shortcut));

  #define SET_SHORTCUT(ID, STR) str = STR;                                     \
    MARY_Range(str, u32, 0, ~(u32)0)                                           \
    {                                                                          \
      if (range.val == '-') shortcut.str[range.idx] = HYPH;                    \
      else  shortcut.str[range.idx] = range.val;                               \
      if (range.val == 0) { shortcut.size = (u32)range.idx; break; }           \
    }                                                                          \
    short_id = (ID); Mary_Hashmap_Assign(&hm_shortcuts, &short_id, &shortcut);

  SET_SHORTCUT(SHORT_SPACES, U" \n\r\t\f\u00A0\u2002-\u200B");
  SET_SHORTCUT(SHORT_HEBREW, U"\u0590-\u05FF\uFB1D-\uFB4F");
  SET_SHORTCUT(SHORT_GREEK, U"\u0370-\u03FF\u1F00-\u1FFF");
  SET_SHORTCUT(SHORT_HEBREW_CHAR, U"\u05D0-\u05F2\u05C6\uFB1F-\uFB28\uFB2A-\uFB4F\uFB1D");
  SET_SHORTCUT(SHORT_LATIN_PUNC, U"\u0020-\u002F\u003A-\u0040\u005B-\u0060\u007B-\u007E");

  #undef SET_SHORTCUT

  mary_regex_is_started = 1;
}

void Mary_Regex_Finish()
{
  Mary_Hashmap_Destroy(&hm_shortcuts);
  mary_regex_is_started = 0;
}

void Mary_Regex_Create(Mary_Regex_t *mary_regex, char bit_format, void *expression, char *flags)
{
  if (!mary_regex_is_started) Mary_Exit_Failure("Need to run 'Mary_Regex_Start()'.");
  Mary_Pool_Create(&mary_regex->pool, 64 * sizeof(u32) + 64 * sizeof(State));
  void *data_expression = Mary_Pool_Allocate(&mary_regex->pool, 256);
  Mary_Pointer_t ptr_expression = { data_expression, 256 };
  Mary_String_Create_With(&mary_regex->expression, bit_format, expression, 0, ptr_expression);
  Mary_String_Format(&mary_regex->expression, 32);
  Mary_Regex_Compile(mary_regex);
  mary_regex->flags = 0;
  if (flags)
  {
    while (*flags != 0)
    {
      if (*flags == 'g' || *flags == 'G') mary_regex->flags |= FLAG_GLOBAL;
      else if (*flags == 'm' || *flags == 'M') mary_regex->flags |= FLAG_MULTILINE;
      ++flags;
    }
  }
}

void Mary_Regex_Destroy(Mary_Regex_t *mary_regex)
{
  Mary_Pool_Destroy(&mary_regex->pool);
}

void Mary_Regex_Tokenize(Mary_Vector_t *v_tokens, u32 *expression, u64 expression_size)
{
  if (*expression == 0)
  {
    Mary_Exit_Failure("Regex is empty.");
  }

  Mary_Vector_t v_buffer; MARY_Vector_Create_On_Stack(v_buffer, u32, 64);

  // should prob have a stack simulation to take into account all brackets, to make sure they are closed.

  u32 token, next_code, short_id; Shortcut shortcut; u64 from, to_exclusive, negate;

  #define TRY_CONCAT                                                                \
  {                                                                                 \
    next_code = *(range.ptr + 1);                                                   \
    if (next_code != '*' && next_code != '+' &&                                     \
        next_code != '?' && next_code != '{' &&                                     \
        next_code != ')' && next_code != '|' &&                                     \
        next_code != '\0')                                                          \
    {                                                                               \
      token = AND; Mary_Vector_Push_Back(v_tokens, &token);                         \
    }                                                                               \
  }

  #define ADD_SHORTCUT(SHORT_ID, NEGATE)                                            \
  {                                                                                 \
    short_id = SHORT_ID; Mary_Hashmap_At(&hm_shortcuts, &short_id, &shortcut);      \
    token = LSQU; Mary_Vector_Push_Back(v_tokens, &token);                          \
    if (NEGATE) token = EXPO, Mary_Vector_Push_Back(v_tokens, &token);              \
    from = v_tokens->size, to_exclusive = from + shortcut.size;                     \
    Mary_Vector_Add_Slice(v_tokens, from, to_exclusive, shortcut.str);              \
    token = RSQU; Mary_Vector_Push_Back(v_tokens, &token);                          \
  }

  #define ADD_TOKEN(TOKEN)                                                          \
  {                                                                                 \
    token = TOKEN; Mary_Vector_Push_Back(v_tokens, &token);                         \
  }

  MARY_Range(expression, u32, 0, expression_size)
  {
    if (range.val == ESC)
    {
      MARY_Range_Advance(1);
      if (range.val == 's')
      {
        ADD_SHORTCUT(SHORT_SPACES, 0);
      }
      else if (range.val == 'S')
      {
        ADD_SHORTCUT(SHORT_SPACES, 1);
      }
      else if (range.val == 'b' || range.val == 'B')
      {
        if (range.val == 'b') ADD_TOKEN(BOUP) else ADD_TOKEN(BOUN);
        if (*(range.ptr + 1) == ':')
        {
          MARY_Range_Advance(2);
          if (memcmp(range.ptr, U"Hebrew", 6) == 0)
          {
            ADD_TOKEN(SHORT_HEBREW_PUNC); MARY_Range_Advance(6);
          }
          else if (memcmp(range.ptr, U"Greek", 5) == 0)
          {
            ADD_TOKEN(SHORT_GREEK_PUNC); MARY_Range_Advance(5);
          }
          else if (memcmp(range.ptr, U"Unicode", 7) == 0)
          {
            ADD_TOKEN(SHORT_UNICODE_PUNC); MARY_Range_Advance(7);
          }
          else if (memcmp(range.ptr, U"Latin", 5) == 0)
          {
            ADD_TOKEN(SHORT_LATIN_PUNC); MARY_Range_Advance(5);
          }
        }
        else
        {
          ADD_TOKEN(SHORT_LATIN_PUNC);
        }
      }
      else if (range.val == ':')
      {
        MARY_Range_Advance(1); negate = 0;
        if (range.val == '!')
        {
          MARY_Range_Advance(1); negate = 1;
        }
        if (memcmp(range.ptr, U"Hebrew Char", 11) == 0)
        {
          ADD_SHORTCUT(SHORT_HEBREW_CHAR, negate); MARY_Range_Advance(11);
        }
        else if (memcmp(range.ptr, U"Hebrew", 6) == 0)
        {
          ADD_SHORTCUT(SHORT_HEBREW, negate); MARY_Range_Advance(6);
        }
        else if (memcmp(range.ptr, U"Greek", 5) == 0)
        {
          ADD_SHORTCUT(SHORT_GREEK, negate); MARY_Range_Advance(5);
        }
        if (range.val != ':')
        {
          // error.
        }
      }
      else
      {
        ADD_TOKEN(range.val);
      }
      TRY_CONCAT;
    }
    else if (range.val == '?')
    {
      next_code = *(range.ptr + 1);
      if (next_code == '<')
      {
        MARY_Range_Advance(1); next_code = *(range.ptr + 1);
        if (next_code == '!')
        {
          MARY_Range_Advance(1); ADD_TOKEN(BNEG);
        }
        else
        {
          ADD_TOKEN(BPOS);
        }
        u32 *sub_expression = range.ptr + 1, balance = 1;
        while (balance != 0)
        {
          MARY_Range_Advance(1);
          if (range.val == ')') --balance;
          else if (range.val == '(') ++balance;
          Mary_Vector_Push_Back(&v_buffer, range.ptr);
        }
        u32 code = 0; Mary_Vector_Assign(&v_buffer, v_buffer.size - 1, &code);
        Mary_Vector_t v_sub_tokens; MARY_Vector_Create_On_Stack(v_sub_tokens, u32, 64);
        Mary_Regex_Tokenize(&v_sub_tokens, v_buffer.data, v_buffer.size);
        Mary_Vector_Empty(&v_buffer); --v_sub_tokens.size;
        while (v_sub_tokens.size)
        {
          Mary_Vector_Pop_Back(&v_sub_tokens, &code);
          if (code != AND)
          {
            Mary_Vector_Push_Back(&v_buffer, &code);
          }
          else
          {
            while (v_buffer.size)
            {
              Mary_Vector_Pop_Back(&v_buffer, &code);
              Mary_Vector_Push_Back(v_tokens, &code);
            }
            ADD_TOKEN(AND);
          }
        }
        while (v_buffer.size)
        {
          Mary_Vector_Pop_Back(&v_buffer, &code);
          Mary_Vector_Push_Back(v_tokens, &code);
        }
        ADD_TOKEN(RPAR); TRY_CONCAT;
      }
      else if (next_code == '>')
      {
        MARY_Range_Advance(1); next_code = *(range.ptr + 1);
        if (next_code == '!')
        {
          MARY_Range_Advance(1); ADD_TOKEN(ANEG);
        }
        else
        {
          ADD_TOKEN(APOS);
        }
      }
      else
      {
        ADD_TOKEN(QUES); TRY_CONCAT;
      }
    }
    else if (range.val == '.')
    {
      ADD_TOKEN(DOT); TRY_CONCAT;
    }
    else if (range.val == '|')
    {
      ADD_TOKEN(BAR);
    }
    else if (range.val == '*')
    {
      ADD_TOKEN(STAR); TRY_CONCAT;
    }
    else if (range.val == '+')
    {
      ADD_TOKEN(PLUS); TRY_CONCAT;
    }
    else if (range.val == '^')
    {
      ADD_TOKEN(EXPO); TRY_CONCAT;
    }
    else if (range.val == '$')
    {
      ADD_TOKEN(CASH); TRY_CONCAT;
    }
    else if (range.val == '(')
    {
      ADD_TOKEN(LPAR);
    }
    else if (range.val == ')')
    {
      ADD_TOKEN(RPAR); TRY_CONCAT;
    }
    else if (range.val == '[')
    {
      ADD_TOKEN(LSQU); MARY_Range_Advance(1);
      if (range.val == '^')
      {
        ADD_TOKEN(EXPO); MARY_Range_Advance(1);
      }
      while (range.val != ']' && range.val != 0)
      {
        if (range.val == '-')
        {
          ADD_TOKEN(HYPH); MARY_Range_Advance(1);
        }
        else if (range.val == ESC)
        {
          ADD_TOKEN(*(range.ptr + 1)); MARY_Range_Advance(2);
        }
        else
        {
          ADD_TOKEN(range.val); MARY_Range_Advance(1);
        }
      }
      if (range.val == ']')
      {
        ADD_TOKEN(RSQU); TRY_CONCAT;
      }
    }
    else if (range.val == '{')
    {
      // not working with ~:...:
      u64 m = 0, n = 0; u32 code;
      MARY_Range_Advance(1);
      while (range.val != ',' && range.val != '}') // might want string->number conversion in String_t, one for each format
      {
        if (range.val >= '0' && range.val <= '9')
        {
          Mary_Vector_Push_Back(&v_buffer, &range.val);
        }
        MARY_Range_Advance(1);
      }
      for (u64 exp = 1; v_buffer.size; exp *= 10)
      {
        Mary_Vector_Pop_Back(&v_buffer, &code); m += (code - '0') * exp;
      }
      if (range.val != ',')
      {
        n = m;
      }
      else
      {
        MARY_Range_Advance(1);
        while (range.val != '}')
        {
          if (range.val >= '0' && range.val <= '9')
          {
            Mary_Vector_Push_Back(&v_buffer, &range.val);
          }
          MARY_Range_Advance(1);
        }
        for (u64 exp = 1; v_buffer.size; exp *= 10)
        {
          Mary_Vector_Pop_Back(&v_buffer, &code); n += (code - '0') * exp;
        }
      }
      if (m == 0 && n == 1)
      {
        ADD_TOKEN(QUES);
      }
      else if (m == 0 && n == 0)
      {
        ADD_TOKEN(STAR);
      }
      else if (m == 1 && n == 0)
      {
        ADD_TOKEN(PLUS);
      }
      else if (!(m == 1 && n == 1))
      {
        u32 *p_code = v_tokens->size - 1 + (u32 *)v_tokens->data; code = *p_code;
        if (code == RPAR || code == RSQU)
        {
          Mary_Vector_Push_Back(&v_buffer, p_code);
          u64 balance = 1;
          while (balance)
          {
            code = *--p_code; Mary_Vector_Push_Back(&v_buffer, p_code);
            if (code == RPAR || code == RSQU) ++balance;
            else if (code == LPAR || code == LSQU) --balance;
          }
          // this needs to be made like the one below it.
          if (m == 0)
          {
            ADD_TOKEN(QUES);
          }
          for (u64 i_m = m; i_m > 1; --i_m)
          {
            ADD_TOKEN(AND);
            MARY_Range_Reverse(v_buffer.data, u32, v_buffer.size - 1, 0)
            {
              ADD_TOKEN(range.val);
            }
          }
          for (u64 i_n = n - m; i_n > 0; --i_n)
          {
            ADD_TOKEN(AND);
            MARY_Range_Reverse(v_buffer.data, u32, v_buffer.size - 1, 0)
            {
              ADD_TOKEN(range.val);
            }
            ADD_TOKEN(QUES);
          }
          Mary_Vector_Empty(&v_buffer);
        }
        else
        {
          if (m == 0)
          {
            ADD_TOKEN(QUES);
          }
          for (u64 i_m = m; i_m > 1; --i_m)
          {
            ADD_TOKEN(AND); ADD_TOKEN(code);
          }
          if (n == 0)
          {
            ADD_TOKEN(AND); ADD_TOKEN(code); ADD_TOKEN(STAR);
          }
          else
          {
            for (u64 i_n = (n > m) ? n - m : 0; i_n > 0; --i_n)
            {
              ADD_TOKEN(AND); ADD_TOKEN(code); ADD_TOKEN(QUES);
            }
          }
        }
      }
      if (range.val == '}')
      {
        TRY_CONCAT;
      }
    }
    else
    {
      ADD_TOKEN(range.val); if (range.val != '\0') TRY_CONCAT;
    }
  }

  #undef TRY_CONCAT
  #undef ADD_SHORTCUT
  #undef ADD_TOKEN
}

void Mary_Regex_Compile(Mary_Regex_t *mary_regex)
{
  Mary_Pool_t pool_compiler;
  Mary_Pool_Create(&pool_compiler, 256);

  Mary_Vector_t v_input, v_stack, v_output, v_codepoints;
  MARY_Vector_Create_On_Stack(v_input, u32, 64);
  MARY_Vector_Create_On_Stack(v_stack, u32, 64);
  MARY_Vector_Create_On_Stack(v_output, Fragment, 64);
  MARY_Vector_Create_On_Stack(v_codepoints, u32, 64);

  u32 top, *codepoints, flag; Shortcut *shortcut; Fragment frag, frag_a, frag_b; State **ppState;

  #define IN_CREATE(IN, FLAG, OUT_PTR_A, OUT_PTR_B)                                                \
  {                                                                                                \
    (IN) = Mary_Pool_Allocate(&mary_regex->pool, sizeof(State));                                   \
    (IN)->flag = (FLAG);                                                                           \
    (IN)->out_a = (OUT_PTR_A);                                                                     \
    (IN)->out_b = (OUT_PTR_B);                                                                     \
  }

  #define OUTS_CREATE(OUTS, OUT_PTR)                                                               \
  {                                                                                                \
    (OUTS).bytes = sizeof(State **);                                                               \
    (OUTS).data = Mary_Pool_Allocate(&pool_compiler, (OUTS).bytes);                                \
    ppState = &(State *)(OUT_PTR);                                                                 \
    memcpy((OUTS).data, &ppState, (OUTS).bytes);                                                   \
  }

  #define OUTS_CONCAT(OUTS, OUTS_A, OUTS_B)                                                        \
  {                                                                                                \
    (OUTS).bytes = (OUTS_A).bytes + (OUTS_B).bytes;                                                \
    (OUTS).data = Mary_Pool_Allocate(&pool_compiler, (OUTS).bytes);                                \
    memcpy((OUTS).data, (OUTS_A).data, (OUTS_A).bytes);                                            \
    memcpy((u8 *)(OUTS).data + (OUTS_A).bytes, (OUTS_B).data, (OUTS_B).bytes);                     \
  }

  #define OUTS_PATCH(OUTS, IN)                                                                     \
  {                                                                                                \
    MARY_Range((OUTS).data, State **, 0, (OUTS).bytes / sizeof(State **)) *range.val = IN;         \
  }

  #define OUTS_DELETE(OUTS)                                                                        \
  {                                                                                                \
    Mary_Pool_Deallocate(&pool_compiler, (OUTS).data);                                             \
  }

  #define EVAL_WHILE(CONDITION)                                                                    \
  {                                                                                                \
    if (v_stack.size)                                                                              \
    {                                                                                              \
      Mary_Vector_At(&v_stack, v_stack.size - 1, &top);                                            \
      while ((CONDITION))                                                                          \
      {                                                                                            \
        if (top == PLUS)                                                                           \
        {                                                                                          \
          Mary_Vector_Pop_Back(&v_output, &frag_a);                                                \
          IN_CREATE(frag.in, STATE_SPLIT, frag_a.in, 0);                                           \
          OUTS_PATCH(frag_a.outs, frag.in);                                                        \
          OUTS_DELETE(frag_a.outs);                                                                \
          OUTS_CREATE(frag.outs, frag.in->out_b);                                                  \
          frag.in = frag_a.in;                                                                     \
          Mary_Vector_Push_Back(&v_output, &frag);                                                 \
        }                                                                                          \
        else if (top == STAR)                                                                      \
        {                                                                                          \
          Mary_Vector_Pop_Back(&v_output, &frag_a);                                                \
          IN_CREATE(frag.in, STATE_SPLIT, frag_a.in, 0);                                           \
          OUTS_PATCH(frag_a.outs, frag.in);                                                        \
          OUTS_DELETE(frag_a.outs);                                                                \
          OUTS_CREATE(frag.outs, frag.in->out_b);                                                  \
          Mary_Vector_Push_Back(&v_output, &frag);                                                 \
        }                                                                                          \
        else if (top == QUES)                                                                      \
        {                                                                                          \
          Mary_Vector_Pop_Back(&v_output, &frag_a);                                                \
          IN_CREATE(frag.in, STATE_SPLIT, frag_a.in, 0);                                           \
          ppState = &(State *)frag.in->out_b;                                                      \
          frag_b.outs.data = &ppState;                                                             \
          frag_b.outs.bytes = sizeof(State **);                                                    \
          OUTS_CONCAT(frag.outs, frag_a.outs, frag_b.outs);                                        \
          OUTS_DELETE(frag_a.outs);                                                                \
          Mary_Vector_Push_Back(&v_output, &frag);                                                 \
        }                                                                                          \
        else if (top == AND)                                                                       \
        {                                                                                          \
          Mary_Vector_Pop_Back(&v_output, &frag_b);                                                \
          Mary_Vector_Pop_Back(&v_output, &frag_a);                                                \
          frag.in = frag_a.in;                                                                     \
          frag.outs = frag_b.outs;                                                                 \
          OUTS_PATCH(frag_a.outs, frag_b.in);                                                      \
          Mary_Vector_Push_Back(&v_output, &frag);                                                 \
        }                                                                                          \
        else if (top == BAR)                                                                       \
        {                                                                                          \
          Mary_Vector_Pop_Back(&v_output, &frag_b);                                                \
          Mary_Vector_Pop_Back(&v_output, &frag_a);                                                \
          IN_CREATE(frag.in, STATE_SPLIT, frag_a.in, frag_b.in);                                   \
          OUTS_CONCAT(frag.outs, frag_a.outs, frag_b.outs);                                        \
          OUTS_DELETE(frag_a.outs);                                                                \
          OUTS_DELETE(frag_b.outs);                                                                \
          Mary_Vector_Push_Back(&v_output, &frag);                                                 \
        }                                                                                          \
        else if (top == APOS)                                                                      \
        {                                                                                          \
          Mary_Vector_Pop_Back(&v_output, &frag_a);                                                \
          IN_CREATE(frag_b.in, STATE_MATCH, 0, 0);                                                 \
          OUTS_PATCH(frag_a.outs, frag_b.in);                                                      \
          OUTS_DELETE(frag_a.outs);                                                                \
          IN_CREATE(frag.in, STATE_AHEAD_POS, 0, frag_a.in);                                       \
          OUTS_CREATE(frag.outs, frag.in->out_a);                                                  \
          Mary_Vector_Push_Back(&v_output, &frag);                                                 \
        }                                                                                          \
        else if (top == ANEG)                                                                      \
        {                                                                                          \
          Mary_Vector_Pop_Back(&v_output, &frag_a);                                                \
          IN_CREATE(frag_b.in, STATE_MATCH, 0, 0);                                                 \
          OUTS_PATCH(frag_a.outs, frag_b.in);                                                      \
          OUTS_DELETE(frag_a.outs);                                                                \
          IN_CREATE(frag.in, STATE_AHEAD_NEG, 0, frag_a.in);                                       \
          OUTS_CREATE(frag.outs, frag.in->out_a);                                                  \
          Mary_Vector_Push_Back(&v_output, &frag);                                                 \
        }                                                                                          \
        else if (top == BPOS)                                                                      \
        {                                                                                          \
          Mary_Vector_Pop_Back(&v_output, &frag_a);                                                \
          IN_CREATE(frag_b.in, STATE_MATCH, 0, 0);                                                 \
          OUTS_PATCH(frag_a.outs, frag_b.in);                                                      \
          OUTS_DELETE(frag_a.outs);                                                                \
          IN_CREATE(frag.in, STATE_BEHIND_POS, 0, frag_a.in);                                      \
          OUTS_CREATE(frag.outs, frag.in->out_a);                                                  \
          Mary_Vector_Push_Back(&v_output, &frag);                                                 \
        }                                                                                          \
        else if (top == BNEG)                                                                      \
        {                                                                                          \
          Mary_Vector_Pop_Back(&v_output, &frag_a);                                                \
          IN_CREATE(frag_b.in, STATE_MATCH, 0, 0);                                                 \
          OUTS_PATCH(frag_a.outs, frag_b.in);                                                      \
          OUTS_DELETE(frag_a.outs);                                                                \
          IN_CREATE(frag.in, STATE_BEHIND_NEG, 0, frag_a.in);                                      \
          OUTS_CREATE(frag.outs, frag.in->out_a);                                                  \
          Mary_Vector_Push_Back(&v_output, &frag);                                                 \
        }                                                                                          \
        if (--v_stack.size == 0) break;                                                            \
        else Mary_Vector_At(&v_stack, v_stack.size - 1, &top);                                     \
      }                                                                                            \
    }                                                                                              \
  }

  Mary_Regex_Tokenize(&v_input, mary_regex->expression.data, mary_regex->expression.size);

  MARY_Range(v_input.data, u32, 0, v_input.size)
  {
    // precedence 1: +, *, ? 2: () 3: & 4: |
    if (range.val == 0)
    {
      EVAL_WHILE(v_stack.size != 0);
      Mary_Vector_Pop_Back(&v_output, &frag_a);
      IN_CREATE(frag.in, STATE_MATCH, 0, 0);
      OUTS_PATCH(frag_a.outs, frag.in);
      mary_regex->machine = frag_a.in;
      break;
    }
    else if (range.val == PLUS || range.val == STAR || range.val == QUES)
    {
      EVAL_WHILE(top == PLUS || top == STAR || top == QUES);
      Mary_Vector_Push_Back(&v_stack, range.ptr);
    }
    else if (range.val == LPAR)
    {
      EVAL_WHILE(top == PLUS || top == STAR || top == QUES);
      Mary_Vector_Push_Back(&v_stack, range.ptr);
    }
    else if (range.val == RPAR)
    {
      EVAL_WHILE(top != LPAR);
      --v_stack.size;
    }
    else if (range.val == AND)
    {
      EVAL_WHILE(top == PLUS || top == STAR || top == QUES || top == AND);
      Mary_Vector_Push_Back(&v_stack, range.ptr);
    }
    else if (range.val == BAR)
    {
      EVAL_WHILE(top == PLUS || top == STAR || top == QUES || top == AND || top == BAR);
      Mary_Vector_Push_Back(&v_stack, range.ptr);
    }
    else if (range.val == APOS || range.val == ANEG || range.val == BPOS || range.val == BNEG)
    {
      Mary_Vector_Push_Back(&v_stack, range.ptr);
    }
    else if (range.val == LSQU)
    {
      MARY_Range_Advance(1);
      if (range.val == EXPO)
      {
        IN_CREATE(frag.in, STATE_NOR, 0, 0); MARY_Range_Advance(1);
      }
      else
      {
        IN_CREATE(frag.in, STATE_XOR, 0, 0);
      }
      while (range.val != RSQU)
      {
        Mary_Vector_Push_Back(&v_codepoints, &range.val); MARY_Range_Advance(1);
      }
      range.val = 0; Mary_Vector_Push_Back(&v_codepoints, &range.val);
      codepoints = Mary_Pool_Allocate(&mary_regex->pool, sizeof(32) * v_codepoints.size);
      memcpy(codepoints, v_codepoints.data, sizeof(32) * v_codepoints.size);
      Mary_Vector_Empty(&v_codepoints);
      frag.in->out_b = codepoints;
      OUTS_CREATE(frag.outs, frag.in->out_a);
      Mary_Vector_Push_Back(&v_output, &frag);
    }
    else if (range.val == EXPO || range.val == CASH)
    {
      flag = (range.val == EXPO) ? STATE_BOUND_EXPO : STATE_BOUND_CASH;
      IN_CREATE(frag.in, flag, 0, 0);
      OUTS_CREATE(frag.outs, frag.in->out_a);
      Mary_Vector_Push_Back(&v_output, &frag);
    }
    else if (range.val == BOUP || range.val == BOUN)
    {
      flag = (range.val == BOUP) ? STATE_BOUND_POS : STATE_BOUND_NEG; MARY_Range_Advance(1);
      shortcut = Mary_Hashmap_Point(&hm_shortcuts, &range.val);
      IN_CREATE(frag.in, flag, 0, shortcut->str);
      OUTS_CREATE(frag.outs, frag.in->out_a);
      Mary_Vector_Push_Back(&v_output, &frag);
    }
    else if (range.val == DOT)
    {
      IN_CREATE(frag.in, STATE_DOT, 0, 0);
      OUTS_CREATE(frag.outs, frag.in->out_a);
      Mary_Vector_Push_Back(&v_output, &frag);
    }
    else
    {
      IN_CREATE(frag.in, range.val, 0, 0);
      OUTS_CREATE(frag.outs, frag.in->out_a);
      Mary_Vector_Push_Back(&v_output, &frag);
    }
  }

  #undef IN_CREATE
  #undef OUTS_CREATE
  #undef OUTS_CONCAT
  #undef OUTS_PATCH
  #undef OUTS_DELETE
  #undef EVAL_WHILE

  Mary_Pool_Destroy(&pool_compiler);
}

Mary_Vector_t Mary_Regex_Execute(Mary_Regex_t *mary_regex, char bit_format, void *search_string)
{
  if (bit_format == 8)
  {
    return Mary_Regex_8bit_Execute(mary_regex, search_string);
  }
  else if (bit_format == 16)
  {
    return Mary_Regex_16bit_Execute(mary_regex, search_string);
  }
  else
  {
    return Mary_Regex_32bit_Execute(mary_regex, search_string);
  }
}

Mary_Vector_t Mary_Regex_8bit_Execute(Mary_Regex_t *mary_regex, uint8_t *search_string)
{
  return (Mary_Vector_t){0, 0, 0, 0};
}

Mary_Vector_t Mary_Regex_16bit_Execute(Mary_Regex_t *mary_regex, uint16_t *search_string)
{
  return (Mary_Vector_t){ 0, 0, 0, 0 };
}

void Add_Candidates(size_t flags,
                    State *machine,
                    Mary_Vector_t *v_new,
                    Mary_Vector_t *v_states,
                    Mary_Vector_t *v_matches,
                    u64 codepoint_idx,
                    u32 *codepoint_ptr,
                    u32 codepoint_val);

void Update_Candidates(size_t flags,
                       Mary_Vector_t *v_old,
                       Mary_Vector_t *v_new,
                       Mary_Vector_t *v_states,
                       Mary_Vector_t *v_matches,
                       u64 codepoint_idx,
                       u32 *codepoint_ptr,
                       u32 codepoint_val);

char Execute_Behind(size_t flags,
                    State *machine,
                    u64 codepoint_idx,
                    u32 *codepoint_ptr);

char Execute_Ahead(size_t flags,
                   State *machine,
                   u64 codepoint_idx,
                   u32 *codepoint_ptr);

char Execute_Behind(size_t flags,
                    State *machine,
                    u64 codepoint_idx,
                    u32 *codepoint_ptr)
{
  Mary_Vector_t v_candidates_old, *v_old = &v_candidates_old;
  Mary_Vector_t v_candidates_new, *v_new = &v_candidates_new;
  Mary_Vector_t v_states, v_matches, *v_swap;
  MARY_Vector_Create_On_Stack(v_candidates_old, Candidate, 64);
  MARY_Vector_Create_On_Stack(v_candidates_new, Candidate, 64);
  MARY_Vector_Create_On_Stack(v_states, State *, 64);
  MARY_Vector_Create_On_Stack(v_matches, Match, 64);
  u64 idx = codepoint_idx - 1; u32 *ptr = codepoint_ptr - 1;
  Add_Candidates(flags, machine, v_new, &v_states, &v_matches, idx, ptr, *ptr);
  MARY_Range_Reverse(codepoint_ptr - codepoint_idx, u32, idx, 0)
  {
    Update_Candidates(flags, v_old, v_new, &v_states, &v_matches, range.idx, range.ptr, range.val);
    if (v_matches.size) return 1;
    else if (!v_new->size) return 0;
    v_swap = v_old; v_old = v_new; v_new = v_swap;
  }
  return 0;
}

char Execute_Ahead(size_t flags,
                   State *machine,
                   u64 codepoint_idx,
                   u32 *codepoint_ptr)
{
  Mary_Vector_t v_candidates_old, *v_old = &v_candidates_old;
  Mary_Vector_t v_candidates_new, *v_new = &v_candidates_new;
  Mary_Vector_t v_states, v_matches, *v_swap;
  MARY_Vector_Create_On_Stack(v_candidates_old, Candidate, 64);
  MARY_Vector_Create_On_Stack(v_candidates_new, Candidate, 64);
  MARY_Vector_Create_On_Stack(v_states, State *, 64);
  MARY_Vector_Create_On_Stack(v_matches, Match, 64);
  u64 idx = codepoint_idx; u32 *ptr = codepoint_ptr, last_codepoint = 1;
  Add_Candidates(flags, machine, v_new, &v_states, &v_matches, idx, ptr, *ptr);
  MARY_Range(ptr, u32, 0, ~(u64)0)
  {
    if (last_codepoint == 0) break;
    else last_codepoint = range.val;
    Update_Candidates(flags, v_old, v_new, &v_states, &v_matches, range.idx, range.ptr, range.val);
    if (v_matches.size) return 1;
    else if (!v_new->size) return 0;
    v_swap = v_old; v_old = v_new; v_new = v_swap;
  }
  return 0;
}

char Class_Contains(u32 *class_codepoints, u32 codepoint)
{
  for (; *class_codepoints != 0; ++class_codepoints)
  {
    if (*(class_codepoints + 1) == HYPH)
    {
      if (codepoint >= *class_codepoints && codepoint <= *(class_codepoints += 2)) return 1;
    }
    else if (codepoint == *class_codepoints) return 1;
  }
  return 0;
}

void Add_Candidates(size_t flags,
                    State *machine,
                    Mary_Vector_t *v_new,
                    Mary_Vector_t *v_states,
                    Mary_Vector_t *v_matches,
                    u64 codepoint_idx,
                    u32 *codepoint_ptr,
                    u32 codepoint_val)
{
  Candidate candidate; State *p_state; Match match; u32 *p_codepoints;
  if (v_matches->size == 0 || flags & FLAG_GLOBAL) // can add this check into main execute loop instead.
  {
    Mary_Vector_Push_Back(v_states, &machine);
    for (u64 j = 0; j < v_states->size; ++j)
    {
      Mary_Vector_At(v_states, j, &p_state);
      if (p_state->flag == STATE_MATCH)
      {
        match.from = codepoint_idx;
        match.to_exclusive = codepoint_idx + 1;
        Mary_Vector_Push_Back(v_matches, &match);
      }
      else if (p_state->flag == STATE_SPLIT)
      {
        Mary_Vector_Push_Back(v_states, &p_state->out_a);
        Mary_Vector_Push_Back(v_states, &p_state->out_b);
      }
      else if (p_state->flag == STATE_BEHIND_POS)
      {
        if (codepoint_idx)
        {
          if (Execute_Behind(flags, p_state->out_b, codepoint_idx, codepoint_ptr))
          {
            Mary_Vector_Push_Back(v_states, &p_state->out_a);
          }
        }
      }
      else if (p_state->flag == STATE_BEHIND_NEG)
      {
        if (codepoint_idx)
        {
          if (!Execute_Behind(flags, p_state->out_b, codepoint_idx, codepoint_ptr))
          {
            Mary_Vector_Push_Back(v_states, &p_state->out_a);
          }
        }
        else
        {
          Mary_Vector_Push_Back(v_states, &p_state->out_a);
        }
      }
      else if (p_state->flag == STATE_AHEAD_POS)
      {
        if (codepoint_val)
        {
          if (Execute_Ahead(flags, p_state->out_b, codepoint_idx, codepoint_ptr))
          {
            Mary_Vector_Push_Back(v_states, &p_state->out_a);
          }
        }
      }
      else if (p_state->flag == STATE_AHEAD_NEG)
      {
        if (codepoint_val)
        {
          if (!Execute_Ahead(flags, p_state->out_b, codepoint_idx, codepoint_ptr))
          {
            Mary_Vector_Push_Back(v_states, &p_state->out_a);
          }
        }
        else
        {
          Mary_Vector_Push_Back(v_states, &p_state->out_a);
        }
      }
      else if (p_state->flag == STATE_BOUND_EXPO)
      {
        if (codepoint_idx == 0)
        {
          Mary_Vector_Push_Back(v_states, &p_state->out_a);
        }
        else if (flags & FLAG_MULTILINE)
        {
          u32 prev = *(codepoint_ptr - 1);
          if (prev == '\n' || prev == '\r')
          {
            Mary_Vector_Push_Back(v_states, &p_state->out_a);
          }
        }
      }
      else if (p_state->flag == STATE_BOUND_CASH)
      {
        if (codepoint_val == 0)
        {
          Mary_Vector_Push_Back(v_states, &p_state->out_a);
        }
        else if (flags & FLAG_MULTILINE)
        {
          if (codepoint_val == '\n' || codepoint_val == '\r')
          {
            Mary_Vector_Push_Back(v_states, &p_state->out_a);
          }
        }
      }
      else if (p_state->flag == STATE_BOUND_POS)
      {
        u64 prev_exists = codepoint_idx != 0; u64 curr_exists = codepoint_val != 0;
        u64 prev_is_bound = (prev_exists) ? Class_Contains(p_state->out_b, *(codepoint_ptr - 1)) : 0;
        u64 curr_is_bound = (curr_exists) ? Class_Contains(p_state->out_b, codepoint_val) : 0;
        if (!prev_exists && curr_exists && !curr_is_bound)
        {
          Mary_Vector_Push_Back(v_states, &p_state->out_a);
        }
        else if (!curr_exists && prev_exists && !prev_is_bound)
        {
          Mary_Vector_Push_Back(v_states, &p_state->out_a);
        }
        else if (prev_exists && curr_exists && prev_is_bound && !curr_is_bound)
        {
          Mary_Vector_Push_Back(v_states, &p_state->out_a);
        }
        else if (prev_exists && curr_exists && !prev_is_bound && curr_is_bound)
        {
          Mary_Vector_Push_Back(v_states, &p_state->out_a);
        }
      }
      else if (p_state->flag == STATE_BOUND_NEG)
      {
        u64 prev_exists = codepoint_idx != 0; u64 curr_exists = codepoint_val != 0;
        u64 prev_is_bound = (prev_exists) ? Class_Contains(p_state->out_b, *(codepoint_ptr - 1)) : 0;
        u64 curr_is_bound = (curr_exists) ? Class_Contains(p_state->out_b, codepoint_val) : 0;
        if (!prev_exists && curr_exists && curr_is_bound)
        {
          Mary_Vector_Push_Back(v_states, &p_state->out_a);
        }
        else if (!curr_exists && prev_exists && prev_is_bound)
        {
          Mary_Vector_Push_Back(v_states, &p_state->out_a);
        }
        else if (prev_exists && curr_exists && prev_is_bound && curr_is_bound)
        {
          Mary_Vector_Push_Back(v_states, &p_state->out_a);
        }
        else if (prev_exists && curr_exists && !prev_is_bound && !curr_is_bound)
        {
          Mary_Vector_Push_Back(v_states, &p_state->out_a);
        }
      }
      else if (p_state->flag == STATE_XOR)
      {
        p_codepoints = p_state->out_b;
        for (; *p_codepoints != 0; ++p_codepoints)
        {
          if (*(p_codepoints + 1) == HYPH)
          {
            if (codepoint_val >= *p_codepoints && codepoint_val <= *(p_codepoints += 2))
            {
              candidate = (Candidate) { p_state, codepoint_idx };
              Mary_Vector_Push_Back(v_new, &candidate); break;
            }
          }
          else if (codepoint_val == *p_codepoints)
          {
            candidate = (Candidate) { p_state, codepoint_idx };
            Mary_Vector_Push_Back(v_new, &candidate); break;
          }
        }
      }
      else if (p_state->flag == STATE_NOR)
      {
        p_codepoints = p_state->out_b;
        for (; *p_codepoints != 0; ++p_codepoints)
        {
          if (*(p_codepoints + 1) == HYPH)
          {
            if (codepoint_val >= *p_codepoints && codepoint_val <= *(p_codepoints += 2)) break;
          }
          else if (codepoint_val == *p_codepoints) break;
        }
        if (*p_codepoints == 0)
        {
          candidate = (Candidate) { p_state, codepoint_idx };
          Mary_Vector_Push_Back(v_new, &candidate);
        }
      }
      else if (p_state->flag == STATE_DOT)
      {
        if (codepoint_val != '\n')
        {
          candidate = (Candidate) { p_state, codepoint_idx };
          Mary_Vector_Push_Back(v_new, &candidate);
        }
      }
      else if (p_state->flag == codepoint_val)
      {
        candidate = (Candidate) { p_state, codepoint_idx };
        Mary_Vector_Push_Back(v_new, &candidate);
      }
    }
    Mary_Vector_Empty(v_states);
  }
}

void Update_Candidates(size_t flags,
                       Mary_Vector_t *v_old,
                       Mary_Vector_t *v_new,
                       Mary_Vector_t *v_states,
                       Mary_Vector_t *v_matches,
                       u64 codepoint_idx,
                       u32 *codepoint_ptr,
                       u32 codepoint_val)
{
  Candidate candidate, *p_candidate; State *p_state; Match match; u32 *p_codepoints;
  for (u64 i = 0; i < v_old->size; ++i)
  {
    p_candidate = Mary_Vector_Point(v_old, i);
    Mary_Vector_Push_Back(v_states, &p_candidate->state->out_a);
    for (u64 j = 0; j < v_states->size; ++j)
    {
      Mary_Vector_At(v_states, j, &p_state);
      if (p_state->flag == STATE_MATCH)
      {
        match.from = p_candidate->from;
        match.to_exclusive = codepoint_idx;
        Mary_Vector_Push_Back(v_matches, &match);
      }
      else if (p_state->flag == STATE_SPLIT)
      {
        Mary_Vector_Push_Back(v_states, &p_state->out_a);
        Mary_Vector_Push_Back(v_states, &p_state->out_b);
      }
      else if (p_state->flag == STATE_BEHIND_POS)
      {
        if (codepoint_idx)
        {
          if (Execute_Behind(flags, p_state->out_b, codepoint_idx, codepoint_ptr))
          {
            Mary_Vector_Push_Back(v_states, &p_state->out_a);
          }
        }
      }
      else if (p_state->flag == STATE_BEHIND_NEG)
      {
        if (codepoint_idx)
        {
          if (!Execute_Behind(flags, p_state->out_b, codepoint_idx, codepoint_ptr))
          {
            Mary_Vector_Push_Back(v_states, &p_state->out_a);
          }
        }
        else
        {
          Mary_Vector_Push_Back(v_states, &p_state->out_a);
        }
      }
      else if (p_state->flag == STATE_AHEAD_POS)
      {
        if (codepoint_val)
        {
          if (Execute_Ahead(flags, p_state->out_b, codepoint_idx, codepoint_ptr))
          {
            Mary_Vector_Push_Back(v_states, &p_state->out_a);
          }
        }
      }
      else if (p_state->flag == STATE_AHEAD_NEG)
      {
        if (codepoint_val)
        {
          if (!Execute_Ahead(flags, p_state->out_b, codepoint_idx, codepoint_ptr))
          {
            Mary_Vector_Push_Back(v_states, &p_state->out_a);
          }
        }
        else
        {
          Mary_Vector_Push_Back(v_states, &p_state->out_a);
        }
      }
      else if (p_state->flag == STATE_BOUND_EXPO)
      {
        if (codepoint_idx == 0)
        {
          Mary_Vector_Push_Back(v_states, &p_state->out_a);
        }
        else if (flags & FLAG_MULTILINE)
        {
          u32 prev = *(codepoint_ptr - 1);
          if (prev == '\n' || prev == '\r')
          {
            Mary_Vector_Push_Back(v_states, &p_state->out_a);
          }
        }
      }
      else if (p_state->flag == STATE_BOUND_CASH)
      {
        if (codepoint_val == 0)
        {
          Mary_Vector_Push_Back(v_states, &p_state->out_a);
        }
        else if (flags & FLAG_MULTILINE)
        {
          if (codepoint_val == '\n' || codepoint_val == '\r')
          {
            Mary_Vector_Push_Back(v_states, &p_state->out_a);
          }
        }
      }
      else if (p_state->flag == STATE_BOUND_POS)
      {
        u64 prev_exists = codepoint_idx != 0; u64 curr_exists = codepoint_val != 0;
        u64 prev_is_bound = (prev_exists) ? Class_Contains(p_state->out_b, *(codepoint_ptr - 1)) : 0;
        u64 curr_is_bound = (curr_exists) ? Class_Contains(p_state->out_b, codepoint_val) : 0;
        if (!prev_exists && curr_exists && !curr_is_bound)
        {
          Mary_Vector_Push_Back(v_states, &p_state->out_a);
        }
        else if (!curr_exists && prev_exists && !prev_is_bound)
        {
          Mary_Vector_Push_Back(v_states, &p_state->out_a);
        }
        else if (prev_exists && curr_exists && prev_is_bound && !curr_is_bound)
        {
          Mary_Vector_Push_Back(v_states, &p_state->out_a);
        }
        else if (prev_exists && curr_exists && !prev_is_bound && curr_is_bound)
        {
          Mary_Vector_Push_Back(v_states, &p_state->out_a);
        }
      }
      else if (p_state->flag == STATE_BOUND_NEG)
      {
        u64 prev_exists = codepoint_idx != 0; u64 curr_exists = codepoint_val != 0;
        u64 prev_is_bound = (prev_exists) ? Class_Contains(p_state->out_b, *(codepoint_ptr - 1)) : 0;
        u64 curr_is_bound = (curr_exists) ? Class_Contains(p_state->out_b, codepoint_val) : 0;
        if (!prev_exists && curr_exists && curr_is_bound)
        {
          Mary_Vector_Push_Back(v_states, &p_state->out_a);
        }
        else if (!curr_exists && prev_exists && prev_is_bound)
        {
          Mary_Vector_Push_Back(v_states, &p_state->out_a);
        }
        else if (prev_exists && curr_exists && prev_is_bound && curr_is_bound)
        {
          Mary_Vector_Push_Back(v_states, &p_state->out_a);
        }
        else if (prev_exists && curr_exists && !prev_is_bound && !curr_is_bound)
        {
          Mary_Vector_Push_Back(v_states, &p_state->out_a);
        }
      }
      else if (p_state->flag == STATE_XOR)
      {
        p_codepoints = p_state->out_b;
        for (; *p_codepoints != 0; ++p_codepoints)
        {
          if (*(p_codepoints + 1) == HYPH)
          {
            if (codepoint_val >= *p_codepoints && codepoint_val <= *(p_codepoints += 2))
            {
              candidate = (Candidate) { p_state, p_candidate->from };
              Mary_Vector_Push_Back(v_new, &candidate); break;
            }
          }
          else if (codepoint_val == *p_codepoints)
          {
            candidate = (Candidate) { p_state, p_candidate->from };
            Mary_Vector_Push_Back(v_new, &candidate); break;
          }
        }
      }
      else if (p_state->flag == STATE_NOR)
      {
        p_codepoints = p_state->out_b;
        for (; *p_codepoints != 0; ++p_codepoints)
        {
          if (*(p_codepoints + 1) == HYPH)
          {
            if (codepoint_val >= *p_codepoints && codepoint_val <= *(p_codepoints += 2)) break;
          }
          else if (codepoint_val == *p_codepoints) break;
        }
        if (*p_codepoints == 0)
        {
          candidate = (Candidate) { p_state, p_candidate->from };
          Mary_Vector_Push_Back(v_new, &candidate);
        }
      }
      else if (p_state->flag == STATE_DOT)
      {
        if (codepoint_val != '\n')
        {
          candidate = (Candidate) { p_state, p_candidate->from };
          Mary_Vector_Push_Back(v_new, &candidate);
        }
      }
      else if (p_state->flag == codepoint_val)
      {
        candidate = (Candidate) { p_state, p_candidate->from };
        Mary_Vector_Push_Back(v_new, &candidate);
      }
    }
    Mary_Vector_Empty(v_states);
  }
  Mary_Vector_Empty(v_old);
}

Mary_Vector_t Mary_Regex_32bit_Execute(Mary_Regex_t *mary_regex, uint32_t *search_string)
{
  Mary_String_t str;
  Mary_String_Create(&str, 32, search_string, 0);

  Mary_Vector_t v_candidates_old, *v_old = &v_candidates_old;
  Mary_Vector_t v_candidates_new, *v_new = &v_candidates_new;
  Mary_Vector_t v_states, v_matches, *v_swap;
  MARY_Vector_Create_On_Stack(v_candidates_old, Candidate, 64);
  MARY_Vector_Create_On_Stack(v_candidates_new, Candidate, 64);
  MARY_Vector_Create_On_Stack(v_states, State *, 64);
  MARY_Vector_Create(v_matches, Match, 64 * sizeof(Match));

  MARY_Range(str.data, u32, 0, str.size)
  {
    Add_Candidates(mary_regex->flags, mary_regex->machine, v_new, &v_states, &v_matches, range.idx, range.ptr, range.val);
    Update_Candidates(mary_regex->flags, v_old, v_new, &v_states, &v_matches, range.idx, range.ptr, range.val);
    v_swap = v_old; v_old = v_new; v_new = v_swap;
  }
  Mary_String_Destroy(&str);

  return v_matches;
}

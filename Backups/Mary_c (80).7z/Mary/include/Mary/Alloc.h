#pragma once

#include <Mary/Utils.h>
#include <Mary/Arena.h>

enum Mary_Alloc_e
{
  MARY_ALLOC_STACK,
  MARY_ALLOC_HEAP
};

void Mary_Alloc_Start();
void Mary_Alloc_Finish();

void *Mary_Alloc_Heap(Mary_Size_t bytes);
void *Mary_Calloc_Heap(Mary_Size_t unit, Mary_Size_t units); // use Mary_Zero
void *Mary_Realloc_Heap(void *data, Mary_Size_t bytes);
void Mary_Dealloc_Heap(void *data);

Mary_Arena_Frame_ID_t Mary_Alloc_Push();
void Mary_Alloc_Pop(Mary_Arena_Frame_ID_t frame_id);
void *Mary_Alloc_Frame(Mary_Arena_Frame_ID_t frame_id, Mary_Size_t bytes);
void *Mary_Alloc_Chain(Mary_Arena_Frame_ID_t frame_id, Mary_Size_t bytes);
void *Mary_Alloc_Error(Mary_Arena_Frame_ID_t frame_id, Mary_Size_t bytes);
void *Mary_Alloc_Vault(Mary_Size_t bytes);
void Mary_Dealloc_Frame(Mary_Arena_Frame_ID_t frame_id, void *data);
void Mary_Dealloc_Chain(Mary_Arena_Frame_ID_t frame_id, void *data);
void Mary_Dealloc_Vault(void *data);
void Mary_Alloc_Keep(Mary_Arena_Frame_ID_t frame_id, void *data);
void *Mary_Alloc_Cut(void *frame, void *data);

#define MARY_Alloc_In\
  enum Mary_Alloc_e { STACK, HEAP, FRAME, CHAIN, ERROR, VAULT };\
  const Mary_Arena_Frame_ID_t MARY_ALLOC_FRAME_ID = Mary_Alloc_Push()

#define MARY_Alloc_Out\
  Mary_Alloc_Pop(MARY_ALLOC_FRAME_ID)

#define MARY_Alloc_Return\
  Mary_Alloc_Pop(MARY_ALLOC_FRAME_ID); return

#define MARY_Alloc_Keep(DATA)\
  Mary_Alloc_Keep(MARY_ALLOC_FRAME_ID, DATA)

#define MARY_Alloc_Keep_Return(DATA)\
  MARY_Alloc_Keep(DATA); MARY_Alloc_Return DATA

#define MARY_Alloc(ENUM, BYTES)                                  \
(                                                                \
  ENUM == FRAME ? Mary_Alloc_Frame(MARY_ALLOC_FRAME_ID, BYTES) : \
  ENUM == CHAIN ? Mary_Alloc_Chain(MARY_ALLOC_FRAME_ID, BYTES) : \
  ENUM == ERROR ? Mary_Alloc_Error(MARY_ALLOC_FRAME_ID, BYTES) : \
  ENUM == VAULT ? Mary_Alloc_Vault(BYTES) :                      \
  ENUM == HEAP ? Mary_Alloc_Heap(BYTES) :                        \
  (MARY_Assert(0, "Invalid allocator"), 0)                       \
)

#define MARY_Dealloc(ENUM, BYTES)                                    \
(                                                                    \
  ENUM == VAULT ? Mary_Dealloc_Vault(BYTES) :                        \
  ENUM == HEAP ? Mary_Dealloc_Heap(BYTES) :                          \
  ENUM == CHAIN ? Mary_Dealloc_Chain(MARY_ALLOC_FRAME_ID, BYTES) :   \
  ENUM == FRAME ? Mary_Dealloc_Frame(MARY_ALLOC_FRAME_ID, BYTES) :   \
  (MARY_Assert(0, "Invalid allocator"), 0)                           \
)

#pragma once

#include <Mary/Vector.h>

typedef struct
{
  MARY_Pointer_t;
  size_t free;
  Mary_Vector_t index;
}
Mary_Pool_t;

void Mary_Pool_Create(Mary_Pool_t *pool, size_t bytes);
void Mary_Pool_Create_At(Mary_Pool_t *pool, Mary_p with_ptr, Mary_p with_idx);
void Mary_Pool_Destroy(Mary_Pool_t *pool);
void *Mary_Pool_Allocate(Mary_Pool_t *pool, size_t bytes);
void Mary_Pool_Deallocate(Mary_Pool_t *pool, void *ptr); // we could call Has_Ptr in here to check, and soft fail, but not sure I like that idea.
void Mary_Pool_Empty(Mary_Pool_t *pool);
Mary_Bool_t Mary_Pool_Has_Data(Mary_Pool_t *pool, void *data);
Mary_Bool_t Mary_Pool_Has_Free(Mary_Pool_t *pool, Mary_Size_t bytes);
// prob. need a func to see if there is enough space so I don't forget to round.
// might be cool to have a func that returns a vector of ptrs to each value in pool.

#define MARY_Pool_Create_At_Stack(POOL, BYTES, BYTES_IDX)\
  u8 POOL##_ary[(BYTES) + 7 & -8], POOL##_idx[(BYTES_IDX) + 7 & -8];\
  Mary_Pool_Create_At(&POOL, (Mary_p) { POOL##_ary, (BYTES) + 7 & -8 },\
                             (Mary_p) { POOL##_idx, (BYTES_IDX) + 7 & -8 })

#define MARY_Pool_Round(BYTES) MARY_Round_to_64bit(BYTES)

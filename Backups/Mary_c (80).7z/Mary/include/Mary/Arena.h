#pragma once

#include <Mary/Utils.h>
#include <Mary/Pool.h>
#include <Mary/Vector.h>

typedef struct
{
  Mary_Pool_t pool;
  Mary_Vector_t vault;
  Mary_Vector_t frames;
}
Mary_Arena_t;

typedef void *Mary_Arena_Frame_ID_t;

void Mary_Arena_Create(Mary_Arena_t *arena, Mary_Size_t bytes);
void Mary_Arena_Destroy(Mary_Arena_t *arena);
Mary_Arena_Frame_ID_t Mary_Arena_Push(Mary_Arena_t *arena);
void Mary_Arena_Pop(Mary_Arena_t *arena, Mary_Arena_Frame_ID_t frame_id);
void *Mary_Arena_Alloc_Frame(Mary_Arena_t *arena, Mary_Arena_Frame_ID_t frame_id, Mary_Size_t bytes);
void *Mary_Arena_Alloc_Chain(Mary_Arena_t *arena, Mary_Arena_Frame_ID_t frame_id, Mary_Size_t bytes);
void *Mary_Arena_Alloc_Error(Mary_Arena_t *arena, Mary_Arena_Frame_ID_t frame_id, Mary_Size_t bytes);
void *Mary_Arena_Alloc_Vault(Mary_Arena_t *arena, Mary_Size_t bytes);
void Mary_Arena_Dealloc_Frame(Mary_Arena_t *arena, Mary_Arena_Frame_ID_t frame_id, void *data);
void Mary_Arena_Dealloc_Chain(Mary_Arena_t *arena, Mary_Arena_Frame_ID_t frame_id, void *data);
void Mary_Arena_Dealloc_Vault(Mary_Arena_t *arena, void *data);
void Mary_Arena_Keep(Mary_Arena_t *arena, Mary_Arena_Frame_ID_t frame_id, void *data); // Backup? Reserve? Defer? Delay? Preserve might be best, even though it's long.
void *Mary_Arena_Cut(Mary_Arena_t *arena, void *data); // maybe one for Frame and one for Store?
void Mary_Arena_Empty(Mary_Arena_t *arena); // clears the entire allocation both in pool and in heap.

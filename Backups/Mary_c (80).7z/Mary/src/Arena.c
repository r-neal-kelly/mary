#include <Mary/Alloc.h>
#include <Mary/Arena.h>

MARY_Primitives;

typedef struct
{
  Mary_Vector_t allocs;
  Mary_Vector_t errors;
}
Mary_Arena_Frame_t;

void Mary_Arena_Create(Mary_Arena_t *arena, Mary_Size_t bytes)
{
  Mary_Pool_Create(&arena->pool, bytes);
  Mary_Vector_Create(&arena->vault, sizeof(void *), 8);
  Mary_Vector_Create(&arena->frames, sizeof(Mary_Arena_Frame_t), 8);
}

void Mary_Arena_Destroy(Mary_Arena_t *arena)
{
  MARY_Assert(arena->frames.units == 0, "There are still unpopped frames.");

  Mary_Vector_Destroy(&arena->frames);

  MARY_Vector_Each(&arena->vault, void *)
  {
    if (Mary_Pool_Has_Data(&arena->pool, it.val))
    {
      Mary_Pool_Deallocate(&arena->pool, it.val);
    }
    else
    {
      Mary_Dealloc_Heap(it.val);
    }
  }
  Mary_Vector_Destroy(&arena->vault);

  Mary_Pool_Destroy(&arena->pool);
}

Mary_Arena_Frame_ID_t Mary_Arena_Push(Mary_Arena_t *arena)
{
  // if we work some more on pool, add a realloc to it, and some on vector, add a realloc func ptr, then we can prob. put
  // these vectos on the pool as well, which is better by far than allocing heap each function.
  // there is also the potential of using the stack to store the vectors, through a macro
  Mary_Arena_Frame_t *frame = Mary_Vector_Point_Push_Back(&arena->frames);
  Mary_Vector_Create(&frame->allocs, sizeof(void *), 8);
  Mary_Vector_Create(&frame->errors, sizeof(Mary_Error_t *), 1);
  return MARY_Vector_Point_Back(&arena->frames);
}

void Mary_Arena_Pop(Mary_Arena_t *arena, Mary_Arena_Frame_ID_t frame_id)
{
  Mary_Arena_Frame_t *frame = Mary_Vector_Point_Pop_Back(&arena->frames);

  MARY_Assert(frame != 0, "No frames available.");
  MARY_Assert(frame == frame_id, "Invalid frame_id. Check for an unpopped frame.");
  MARY_Assert(frame->errors.units == 0, "Unhandled error in arena!");

  MARY_Vector_Each(&frame->allocs, void *)
  {
    if (Mary_Pool_Has_Data(&arena->pool, it.val))
    {
      Mary_Pool_Deallocate(&arena->pool, it.val);
    }
    else
    {
      Mary_Dealloc_Heap(it.val);
    }
  }
  Mary_Vector_Destroy(&frame->allocs);

  MARY_Vector_Each(&frame->errors, void *)
  {
    if (Mary_Pool_Has_Data(&arena->pool, it.val))
    {
      Mary_Pool_Deallocate(&arena->pool, it.val);
    }
    else
    {
      Mary_Dealloc_Heap(it.val);
    }
  }
  Mary_Vector_Destroy(&frame->errors);
}

// should we assert in these when the data ptr is null?
void *Mary_Arena_Alloc_Frame(Mary_Arena_t *arena, Mary_Arena_Frame_ID_t frame_id, Mary_Size_t bytes)
{
  Mary_Arena_Frame_t *frame = MARY_Vector_Point_Back(&arena->frames);

  MARY_Assert(frame != 0, "No frames available.");
  MARY_Assert(frame == frame_id, "Invalid frame_id. Check for an unpopped frame.");

  void *data;

  if (Mary_Pool_Has_Free(&arena->pool, bytes))
  {
    data = Mary_Pool_Allocate(&arena->pool, bytes);
  }
  else
  {
    data = Mary_Alloc_Heap(bytes);
  }

  MARY_Assert(data != 0, "Out of memory.");

  Mary_Vector_Push_Back(&frame->allocs, &data);

  return data;
}

void *Mary_Arena_Alloc_Chain(Mary_Arena_t *arena, Mary_Arena_Frame_ID_t frame_id, Mary_Size_t bytes)
{
  Mary_Arena_Frame_t *frame = MARY_Vector_Point_Back(&arena->frames);
  Mary_Arena_Frame_t *chain = MARY_Vector_Point(&arena->frames, arena->frames.units - 2);

  MARY_Assert(frame != 0, "No frames available.");
  MARY_Assert(chain != 0, "No chain available.");
  MARY_Assert(frame == frame_id, "Invalid frame_id. Check for an unpopped frame.");

  void *data;

  if (Mary_Pool_Has_Free(&arena->pool, bytes))
  {
    data = Mary_Pool_Allocate(&arena->pool, bytes);
  }
  else
  {
    data = Mary_Alloc_Heap(bytes);
  }

  MARY_Assert(data != 0, "Out of memory.");

  Mary_Vector_Push_Back(&chain->allocs, &data);

  return data;
}

void *Mary_Arena_Alloc_Error(Mary_Arena_t *arena, Mary_Arena_Frame_ID_t frame_id, Mary_Size_t bytes)
{
  Mary_Arena_Frame_t *frame = MARY_Vector_Point_Back(&arena->frames);
  Mary_Arena_Frame_t *chain = MARY_Vector_Point(&arena->frames, arena->frames.units - 2);

  MARY_Assert(frame != 0, "No frames available.");
  MARY_Assert(chain != 0, "No chain available.");
  MARY_Assert(frame == frame_id, "Invalid frame_id. Check for an unpopped frame.");

  void *data;

  if (Mary_Pool_Has_Free(&arena->pool, bytes))
  {
    data = Mary_Pool_Allocate(&arena->pool, bytes);
  }
  else
  {
    data = Mary_Alloc_Heap(bytes);
  }

  MARY_Assert(data != 0, "Out of memory.");

  Mary_Vector_Push_Back(&chain->errors, &data);

  return data;
}

void *Mary_Arena_Alloc_Vault(Mary_Arena_t *arena, Mary_Size_t bytes)
{
  void *data;

  if (Mary_Pool_Has_Free(&arena->pool, bytes))
  {
    data = Mary_Pool_Allocate(&arena->pool, bytes);
  }
  else
  {
    data = Mary_Alloc_Heap(bytes);
  }

  MARY_Assert(data != 0, "Out of memory.");

  Mary_Vector_Push_Back(&arena->vault, &data);

  return data;
}

void Mary_Arena_Dealloc_Frame(Mary_Arena_t *arena, Mary_Arena_Frame_ID_t frame_id, void *data)
{
  Mary_Arena_Frame_t *frame = MARY_Vector_Point_Back(&arena->frames);

  MARY_Assert(frame != 0, "No frames available.");
  MARY_Assert(frame == frame_id, "Invalid frame_id. Check for an unpopped frame.");

  Mary_Bool_t was_found; Mary_Index_t idx =
    Mary_Vector_Index_Of_Reverse(&frame->allocs, data, &was_found);

  MARY_Assert(was_found == MARY_TRUE, "Couldn't find pointer.");

  Mary_Vector_Erase_At(&frame->allocs, idx);

  if (Mary_Pool_Has_Data(&arena->pool, data))
  {
    Mary_Pool_Deallocate(&arena->pool, data);
  }
  else
  {
    Mary_Dealloc_Heap(data);
  }
}

void Mary_Arena_Dealloc_Chain(Mary_Arena_t *arena, Mary_Arena_Frame_ID_t frame_id, void *data)
{
  Mary_Arena_Frame_t *frame = MARY_Vector_Point_Back(&arena->frames);
  Mary_Arena_Frame_t *chain = MARY_Vector_Point(&arena->frames, arena->frames.units - 2);

  MARY_Assert(frame != 0, "No frames available.");
  MARY_Assert(chain != 0, "No chain available.");
  MARY_Assert(frame == frame_id, "Invalid frame_id. Check for an unpopped frame.");

  Mary_Bool_t was_found; Mary_Index_t idx =
    Mary_Vector_Index_Of_Reverse(&chain->allocs, data, &was_found);

  MARY_Assert(was_found == MARY_TRUE, "Couldn't find pointer.");

  Mary_Vector_Erase_At(&chain->allocs, idx);

  if (Mary_Pool_Has_Data(&arena->pool, data))
  {
    Mary_Pool_Deallocate(&arena->pool, data);
  }
  else
  {
    Mary_Dealloc_Heap(data);
  }
}

void Mary_Arena_Dealloc_Vault(Mary_Arena_t *arena, void *data)
{
  Mary_Bool_t was_found; Mary_Index_t idx =
    Mary_Vector_Index_Of_Reverse(&arena->vault, data, &was_found);

  MARY_Assert(was_found == MARY_TRUE, "Couldn't find pointer.");

  Mary_Vector_Erase_At(&arena->vault, idx);

  if (Mary_Pool_Has_Data(&arena->pool, data))
  {
    Mary_Pool_Deallocate(&arena->pool, data);
  }
  else
  {
    Mary_Dealloc_Heap(data);
  }
}

void Mary_Arena_Keep(Mary_Arena_t *arena, Mary_Arena_Frame_ID_t frame_id, void *data)
{
  Mary_Arena_Frame_t *frame = MARY_Vector_Point_Back(&arena->frames);
  Mary_Arena_Frame_t *chain = MARY_Vector_Point(&arena->frames, arena->frames.units - 2);

  MARY_Assert(frame != 0, "No frames available.");
  MARY_Assert(chain != 0, "No chain available.");
  MARY_Assert(frame == frame_id, "Invalid frame_id. Check for an unpopped frame.");

  Mary_Bool_t was_found; Mary_Index_t idx =
    Mary_Vector_Index_Of_Reverse(&frame->allocs, data, &was_found);

  MARY_Assert(was_found == MARY_TRUE, "Couldn't find pointer.");

  Mary_Vector_Erase_At(&frame->allocs, idx);

  Mary_Vector_Push_Back(&chain->allocs, &data);
}

void *Mary_Arena_Cut(Mary_Arena_t *arena, void *data)
{
  // this will go through the most recent frame (perhaps the store too),
  // to find the data ptr, and it will remove it from the arena's vectors
  // and pool if necessary, and if it was in pool, malloc in on the heap
  // again and return to user. if it was already on the heap, then just
  // remove it from the vector.

  return 0;
}

void Mary_Arena_Empty(Mary_Arena_t *arena)
{
  // need to check that there are no frames present.
}

#include <stdlib.h>
#include <Mary/Alloc.h>
#include <Mary/Arena.h>

MARY_Primitives;

#define G_ARENA_BYTES 0x300000

static Mary_Arena_t g_arena; // if we do threading, we will have to make a global arena for each thread. a thread id to arena table would work

void Mary_Alloc_Start()
{
  Mary_Arena_Create(&g_arena, G_ARENA_BYTES);
}

void Mary_Alloc_Finish()
{
  Mary_Arena_Destroy(&g_arena);
}

void *Mary_Alloc_Heap(Mary_Size_t bytes)
{
  void *data = malloc(bytes);
  MARY_Assert(data != 0, "Out of memory.");
  return data;
}

void Mary_Dealloc_Heap(void *data)
{
  free(data);
}

Mary_Arena_Frame_ID_t Mary_Alloc_Push()
{
  return Mary_Arena_Push(&g_arena);
}

void Mary_Alloc_Pop(Mary_Arena_Frame_ID_t frame_id)
{
  Mary_Arena_Pop(&g_arena, frame_id);
}

void *Mary_Alloc_Frame(Mary_Arena_Frame_ID_t frame_id, Mary_Size_t bytes)
{
  return Mary_Arena_Alloc_Frame(&g_arena, frame_id, bytes);
}

void *Mary_Alloc_Chain(Mary_Arena_Frame_ID_t frame_id, Mary_Size_t bytes)
{
  return Mary_Arena_Alloc_Chain(&g_arena, frame_id, bytes);
}

void *Mary_Alloc_Error(Mary_Arena_Frame_ID_t frame_id, Mary_Size_t bytes)
{
  return Mary_Arena_Alloc_Error(&g_arena, frame_id, bytes);
}

void *Mary_Alloc_Vault(Mary_Size_t bytes)
{
  return Mary_Arena_Alloc_Vault(&g_arena, bytes);
}

void Mary_Dealloc_Frame(Mary_Arena_Frame_ID_t frame_id, void *data)
{
  Mary_Arena_Dealloc_Frame(&g_arena, frame_id, data);
}

void Mary_Dealloc_Chain(Mary_Arena_Frame_ID_t frame_id, void *data)
{
  Mary_Arena_Dealloc_Chain(&g_arena, frame_id, data);
}

void Mary_Dealloc_Vault(void *data)
{
  Mary_Arena_Dealloc_Vault(&g_arena, data);
}

void Mary_Alloc_Keep(Mary_Arena_Frame_ID_t frame_id, void *data)
{
  Mary_Arena_Keep(&g_arena, frame_id, data);
}

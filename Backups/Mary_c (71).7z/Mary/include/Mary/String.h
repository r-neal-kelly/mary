#pragma once

#include <Mary/Vector.h>

enum
{
  MARY_STRING_UTF8 = 8,
  MARY_STRING_UTF16 = 16,
  MARY_STRING_UTF32 = 32
};

typedef struct
{
  MARY_Vector_t;
  size_t codes;
}
Mary_String_t;

void Mary_String_Create(Mary_String_t *mary_string, char bit_format, void *string, size_t opt_units);
void Mary_String_Create_At(Mary_String_t *mary_string, char bit_format, Mary_p mary_ptr);
void Mary_String_8bit_Create_At(Mary_String_t *mary_string, Mary_p mary_ptr);
void Mary_String_16bit_Create_At(Mary_String_t *mary_string, Mary_p mary_ptr);
void Mary_String_32bit_Create_At(Mary_String_t *mary_string, Mary_p mary_ptr);
void Mary_String_Create_With(Mary_String_t *mary_string, char bit_format, Mary_p mary_ptr);
void Mary_String_8bit_Create_With(Mary_String_t *mary_string, Mary_p mary_ptr);
void Mary_String_16bit_Create_With(Mary_String_t *mary_string, Mary_p mary_ptr);
void Mary_String_32bit_Create_With(Mary_String_t *mary_string, Mary_p mary_ptr);
void Mary_String_Destroy(Mary_String_t *mary_string);
size_t Mary_String_Count_Bytes(char bit_format, void *string, char want_null);
size_t Mary_String_Count_Codes(Mary_String_t *mary_string);
void Mary_String_Edit(Mary_String_t *mary_string, void *string);
char Mary_String_Get_Format(Mary_String_t *mary_string);
void Mary_String_Format(Mary_String_t *mary_string, char bit_format);
void Mary_String_8bit_to_16bit(Mary_String_t *s_8bit);
void Mary_String_8bit_to_32bit(Mary_String_t *s_8bit);
void Mary_String_16bit_to_8bit(Mary_String_t *s_16bit);
void Mary_String_16bit_to_32bit(Mary_String_t *s_16bit);
void Mary_String_32bit_to_8bit(Mary_String_t *s_32bit);
void Mary_String_32bit_to_16bit(Mary_String_t *s_32bit);
// Cluster() should group the clusters in the string together
// Alphabet() should return the whatever lang it is, see Lang.h

void Mary_String_UTF8_To_UTF16(Mary_String_t *string);
void Mary_String_UTF8_To_UTF16_2(Mary_String_t *string);

typedef struct
{
  uint8_t a, b, c, d;
  uint32_t units;
}
Mary_String_UTF8_Code;

#define MARY_String_UTF8_Encode(CODE)                            \
(                                                                \
  (CODE) < 0x000080 ? (Mary_String_UTF8_Code)                    \
                      {                                          \
                        (uint8_t)(CODE),                         \
                        0, 0, 0, 1                               \
                      } :                                        \
  (CODE) < 0x000800 ? (Mary_String_UTF8_Code)                    \
                      {                                          \
                        (uint8_t)( 0xC0 | (CODE) >> 6         ), \
                        (uint8_t)( 0x80 | (CODE)       & 0x3F ), \
                        0, 0, 2                                  \
                      } :                                        \
  (CODE) < 0x010000 ? (Mary_String_UTF8_Code)                    \
                      {                                          \
                        (uint8_t)( 0xE0 | (CODE) >> 12        ), \
                        (uint8_t)( 0x80 | (CODE) >> 6  & 0x3F ), \
                        (uint8_t)( 0x80 | (CODE)       & 0x3F ), \
                        0, 3                                     \
                      } :                                        \
  (CODE) < 0x110000 ? (Mary_String_UTF8_Code)                    \
                      {                                          \
                        (uint8_t)( 0xF0 | (CODE) >> 18        ), \
                        (uint8_t)( 0x80 | (CODE) >> 12 & 0x3F ), \
                        (uint8_t)( 0x80 | (CODE) >> 6  & 0x3F ), \
                        (uint8_t)( 0x80 | (CODE)       & 0x3F ), \
                        4                                        \
                      } :                                        \
  (Mary_String_UTF8_Code) { 0, 0, 0, 0, 0 }                      \
)

#define MARY_String_UTF8_Decode(PTR)                      \
(                                                         \
  *(PTR) >> 7 == 0x00 ? ( * (PTR)             )       :   \
  *(PTR) >> 5 == 0x06 ? ( * (PTR)      ^ 0xC0 ) << 6  |   \
                        ( *((PTR) + 1) ^ 0x80 )       :   \
  *(PTR) >> 4 == 0x0E ? ( * (PTR)      ^ 0xE0 ) << 12 |   \
                        ( *((PTR) + 1) ^ 0x80 ) << 6  |   \
                        ( *((PTR) + 2) ^ 0x80 )       :   \
  *(PTR) >> 3 == 0x1E ? ( * (PTR)      ^ 0xF0 ) << 18 |   \
                        ( *((PTR) + 1) ^ 0x80 ) << 12 |   \
                        ( *((PTR) + 2) ^ 0x80 ) << 6  |   \
                        ( *((PTR) + 3) ^ 0x80 )       : 0 \
)

#define MARY_String_UTF8_Code_Units(CODE) \
(                                         \
  (CODE) < 0x000080 ? 1 :                 \
  (CODE) < 0x000800 ? 2 :                 \
  (CODE) < 0x010000 ? 3 :                 \
  (CODE) < 0x110000 ? 4 : 0               \
)

#define MARY_String_UTF8_Ptr_Units(PTR) \
(                                       \
  *(PTR) >> 7 == 0x00 ? 1 :             \
  *(PTR) >> 5 == 0x06 ? 2 :             \
  *(PTR) >> 4 == 0x0E ? 3 :             \
  *(PTR) >> 3 == 0x1E ? 4 : 0           \
)

typedef struct
{
  uint16_t a, b;
  uint32_t units;
}
Mary_String_UTF16_Code;

// this may be whats slow. try a union?
#define MARY_String_UTF16_Encode(CODE)                      \
(                                                           \
  (CODE) < 0x10000 ?                                        \
    (Mary_String_UTF16_Code)                                \
    {                                                       \
      (uint16_t)(CODE),                                     \
      0, 1                                                  \
    } :                                                     \
    (Mary_String_UTF16_Code)                                \
    {                                                       \
      (uint16_t)( ( (CODE) - 0x10000 >> 10    ) + 0xD800 ), \
      (uint16_t)( ( (CODE) - 0x10000 &  0x3FF ) + 0xDC00 ), \
      2                                                     \
    }                                                       \
)

#define MARY_String_UTF16_Decode(PTR)   \
(                                       \
  *(PTR) < 0xD800 || *(PTR) > 0xDFFF ?  \
    *(PTR) : (*(PTR) - 0xD800 << 10) +  \
             (*((PTR) + 1) - 0xDC00) +  \
             0x10000                    \
)

#define MARY_String_UTF16_Code_Units(CODE) \
(                                          \
  (CODE) < 0x10000 ? 1 : 2                 \
)

#define MARY_String_UTF16_Ptr_Units(PTR)     \
(                                            \
  *(PTR) < 0xD800 || *(PTR) > 0xDFFF ? 2 : 1 \
)

#define MARY_String_UTF8_Each(S)\
  for\
  (\
    struct { u64 idx_codes, idx_units, finish_exclusive, finish; u8 *ptr; u32 code; }\
    it =\
    {\
      (MARY_Assert(Mary_String_Get_Format(S) == MARY_STRING_UTF8), 0),\
      0, (S)->codes, (S)->codes - 1, (S)->data,\
      MARY_String_UTF8_Decode((u8 *)(S)->data)\
    };\
    it.idx_codes < it.finish_exclusive;\
    ++it.idx_codes,\
    it.idx_units += MARY_String_UTF8_Code_Units(it.code),\
    it.ptr = (u8 *)(S)->data + it.idx_units,\
    it.code = MARY_String_UTF8_Decode(it.ptr)\
  )

#define MARY_String_UTF16_Each(S)\
  for\
  (\
    struct { u64 idx_codes, idx_units, finish_exclusive, finish; u16 *ptr; u32 code; }\
    it =\
    {\
      (MARY_Assert(Mary_String_Get_Format(S) == MARY_STRING_UTF16), 0),\
      0, (S)->codes, (S)->codes - 1, (S)->data,\
      MARY_String_UTF16_Decode((u16 *)(S)->data)\
    };\
    it.idx_codes < it.finish_exclusive;\
    ++it.idx_codes,\
    it.idx_units += MARY_String_UTF16_Code_Units(it.code),\
    it.ptr = (u16 *)(S)->data + it.idx_units,\
    it.code = MARY_String_UTF16_Decode(it.ptr)\
  )

#define MARY_String_UTF32_Each(S)\
  for\
  (\
    struct { u64 idx_codes, idx_units, finish_exclusive, finish; u32 *ptr; u32 code; }\
    it =\
    {\
      (MARY_Assert(Mary_String_Get_Format(S) == MARY_STRING_UTF32), 0),\
      0, (S)->codes, (S)->codes - 1, (S)->data, *(u32 *)(S)->data\
    };\
    it.idx_codes < it.finish_exclusive;\
    ++it.idx_codes, ++it.idx_units, ++it.ptr, it.code = *it.ptr\
  )

#include <Mary/Wordmap.h>

MARY_PRIMITIVES;

void Mary_Wordmap_Create(Mary_Wordmap_t *wordmap, Mary_Wordmap_Info_t *info)
{
  // the opt_lines decides the size and number of pages at startup.
  // else the default is the size of the font for one line.

  // the font_face may not be zeroed out correctly, so we'll just
  // copy until we hit a zero.
}

void Mary_Wordmap_Destroy(Mary_Wordmap_t *wordmap)
{

}

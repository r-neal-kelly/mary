#pragma once

#include <Mary/Utils.h>
#include <Mary/Allocator.h>
#include <Mary/Vector.h>

typedef struct { MARY_Vector_t; Mary_Size_t codes; } Mary_String_t;

void Mary_String_Create(Mary_String_t *this, Mary_Allocator_t allocator, Mary_UTF_t utf, Mary_Size_t opt_reserve_units);
void Mary_String_Create_At(Mary_String_t *this, void *at_data, Mary_Size_t at_bytes, Mary_Allocator_t at_allocator, Mary_UTF_t at_utf);
void Mary_String_Create_With(Mary_String_t *this, void *with_data, Mary_Size_t opt_with_bytes, Mary_Allocator_t with_allocator, Mary_UTF_t with_utf);
void Mary_String_Create_From(Mary_String_t *this, Mary_Allocator_t allocator, Mary_UTF_t utf, void *from_data, Mary_UTF_t from_utf);
void Mary_String_Destroy(Mary_String_t *this);
void Mary_String_Copy(Mary_String_t *from, Mary_String_t *to);
void Mary_String_Recode(Mary_String_t *this, Mary_UTF_t to_utf);
void Mary_String_Assign(Mary_String_t *this, Mary_String_t *str);
void Mary_String_Append_Front(Mary_String_t *this, Mary_String_t *front);
void Mary_String_Append_Back(Mary_String_t *this, Mary_String_t *back);
void Mary_String_Trim(Mary_String_t *this);

// might be worth having "Heap_At, Pool_At", etc. for names that have already been declared. think about having to manually validate a frame in debug mode otherwise.
#define MARY_String_Static(NAME, UTF, C_STR)
#define MARY_String_Stack(NAME, UTF, C_STR)
#define MARY_String_Heap(NAME, UTF, C_STR)
#define MARY_String_Pool(NAME, POOL, UTF, C_STR)
#define MARY_String_Frame(NAME, UTF, C_STR)
#define MARY_String_Chain(NAME, UTF, C_STR)
#define MARY_String_Point_Front(THIS)
#define MARY_String_Point_Back(THIS)
#define MARY_String_Point_End(THIS)
#define MARY_String_Assign(THIS, UTF, C_STR)
#define MARY_String_Append_Front(THIS, UTF, C_STR)
#define MARY_String_Append_Back(THIS, UTF, C_STR)
#define MARY_String_Get_UTF(THIS)
#define MARY_String_Code_32_To_Units_8(CODE)
#define MARY_String_Data_8_To_Units_8(DATA)
#define MARY_String_Code_32_To_Units_16(CODE)
#define MARY_String_Data_16_To_Units_16(DATA)
#define MARY_String_Encode_8(CODE, OUT, CASE_A, CASE_B, CASE_C, CASE_D)
#define MARY_String_Decode_8(PTR, OUT)
#define MARY_String_Decode_8_Reverse(PTR, OUT)
#define MARY_String_Encode_16(CODE, OUT, CASE_A, CASE_B)
#define MARY_String_Decode_16(PTR, OUT)
#define MARY_String_Decode_16_Reverse(PTR, OUT)
#define MARY_String_Encode_32(CODE, OUT, CASE_A)
#define MARY_String_Decode_32(PTR, OUT)
#define MARY_String_Decode_32_Reverse(PTR, OUT)
#define MARY_String_Each(THIS, UTF)
#define MARY_String_Each_To(THIS, UTF, TO_UTF)
#define MARY_String_Each_8(THIS)
#define MARY_String_Each_8_To_16(THIS)
#define MARY_String_Each_8_To_32(THIS)
#define MARY_String_Each_16(THIS)
#define MARY_String_Each_16_To_8(THIS)
#define MARY_String_Each_16_To_32(THIS)
#define MARY_String_Each_32(THIS)
#define MARY_String_Each_32_To_8(THIS)
#define MARY_String_Each_32_To_16(THIS)

#include <Mary/Macros/String_m.h>

//////////////////////////////////////////////////////////

// Cluster() should group the clusters in the string together (clusters are letters along with combining marks, it's lang specific)
// Alphabet() should return whatever lang it is, see Lang.h

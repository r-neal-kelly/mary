#pragma once

#include <stdint.h>
#include <Mary/Utils.h>
#include <Mary/Pool.h>
#include <Mary/Vector.h>
#include <Mary/String.h>

typedef struct
{
  Mary_Pool_t *pool;
  Mary_String_t expression;
  size_t flags;
  void *machine;
}
Mary_Regex_t;

void Mary_Regex_Start();
void Mary_Regex_Finish();
void Mary_Regex_Create(Mary_Regex_t *mary_regex, Mary_UTF_t utf, void *expression, char *flags);
void Mary_Regex_Destroy(Mary_Regex_t *mary_regex);
void Mary_Regex_Compile(Mary_Regex_t *mary_regex);
Mary_Vector_t Mary_Regex_Execute(Mary_Regex_t *mary_regex, char bit_format, void *search_string);
Mary_Vector_t Mary_Regex_8bit_Execute(Mary_Regex_t *mary_regex, uint8_t *search_string);
Mary_Vector_t Mary_Regex_16bit_Execute(Mary_Regex_t *mary_regex, uint16_t *search_string);
Mary_Vector_t Mary_Regex_32bit_Execute(Mary_Regex_t *mary_regex, uint32_t *search_string);

#define MARY_Regex_Class_Space       U" \n\r\t\f\x00A0\x2002-\x200B"
#define MARY_Regex_Class_Latin       U"\x0021-\x007E\x00A1-\x00AC\x00AE-\x024F"
//#define MARY_Regex_Class_Latin_Char
#define MARY_Regex_Class_Latin_Punc  U"\x0020-\x002F\x003A-\x0040\x005B-\x0060\x007B-\x007E"
//#define MARY_Regex_Class_Latin_Numb
#define MARY_Regex_Class_Hebrew      U"\x0590-\x05FF\xFB1D-\xFB4F"
#define MARY_Regex_Class_Hebrew_Char U"\x05D0-\x05F2\x05C6\xFB1F-\xFB28\xFB2A-\xFB4F\xFB1D"
#define MARY_Regex_Class_Greek       U"\x0370-\x03FF\x1F00-\x1FFF"

// should we have the strings on stack or static? since we can define classes like above,
// we could just use the stack, and I think this will seriously cut down on binary size,
// if this function were to be used a LOT. Also, the fact that you can combine classes
// together this way is awesome. "" "" == ""
// I am think about making the strings static though, and just having the Classes in const globals.
// because I will have to store them for Regex type anyway, and it would be more generic.
#define MARY_Regex_Class_Has(CLASS_32, CODE_32, OUT_BOOL) \
MARY_M                                                    \
  u32 class_32[] = CLASS_32, code_32 = CODE_32;           \
  OUT_BOOL = MARY_FALSE;                                  \
  for (I i = 0; class_32[i] != 0; ++i)                    \
  {                                                       \
    if (class_32[i + 1] == '-' &&                         \
        class_32[i] <= code_32 &&                         \
        code_32 <= class_32[i += 2])                      \
    {                                                     \
      OUT_BOOL = MARY_TRUE; break;                        \
    }                                                     \
    else if (class_32[i] == code_32)                      \
    {                                                     \
      OUT_BOOL = MARY_TRUE; break;                        \
    }                                                     \
  }                                                       \
MARY_W

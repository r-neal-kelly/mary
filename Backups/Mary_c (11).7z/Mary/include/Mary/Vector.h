#pragma once

#include <stddef.h>

typedef struct
{
  void *data;
  size_t capacity;
  size_t unit;
  size_t size;
}
Mary_Vector_t;

void   Mary_Vector_Create    (Mary_Vector_t *vector, size_t unit);
void   Mary_Vector_Destroy   (Mary_Vector_t *vector);
void   Mary_Vector_Reserve   (Mary_Vector_t *vector, size_t size);
void   Mary_Vector_Fit       (Mary_Vector_t *vector);
void   Mary_Vector_Insert    (Mary_Vector_t *vector, size_t index, void *elem_in);
void   Mary_Vector_Eject     (Mary_Vector_t *vector, size_t index, void *elem_out);
void   Mary_Vector_Assign    (Mary_Vector_t *vector, size_t index, void *elem_in);
void   Mary_Vector_Exchange  (Mary_Vector_t *vector, size_t index, void *elem_in, void *elem_out);
void   Mary_Vector_Push_Back (Mary_Vector_t *vector, void *elem_in);
void   Mary_Vector_Push_Front(Mary_Vector_t *vector, void *elem_in);
void   Mary_Vector_Pop_Back  (Mary_Vector_t *vector, void *elem_out);
void   Mary_Vector_Pop_Front (Mary_Vector_t *vector, void *elem_out);
void   Mary_Vector_At        (Mary_Vector_t *vector, size_t index, void *elem_out);
char   Mary_Vector_Has_At    (Mary_Vector_t *vector, size_t index);
void   Mary_Vector_Back      (Mary_Vector_t *vector, void *elem_out);
void   Mary_Vector_Front     (Mary_Vector_t *vector, void *elem_out);
void   Mary_Vector_Empty     (Mary_Vector_t *vector);
char   Mary_Vector_Is_Empty  (Mary_Vector_t *vector);
void   Mary_Vector_Resize    (Mary_Vector_t *vector, size_t size);
void   Mary_Vector_Fill      (Mary_Vector_t *vector, void *elem_in);
void   Mary_Vector_Rotate    (Mary_Vector_t *vector, void *elem_out);
void   Mary_Vector_Reverse   (Mary_Vector_t *vector);
char   Mary_Vector_Contains  (Mary_Vector_t *vector, void *elem);
size_t Mary_Vector_Index_Of  (Mary_Vector_t *vector, void *elem, char *out_was_found);
void   Mary_Vector_Erase_At  (Mary_Vector_t *vector, size_t index);
void   Mary_Vector_Erase     (Mary_Vector_t *vector, void *elem);

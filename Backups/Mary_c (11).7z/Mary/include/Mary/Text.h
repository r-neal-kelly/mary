#pragma once

#include <stdint.h>
#include <Mary/Vector.h>

typedef struct
{
  float x, y;
  float w, h;
  float r, g, b, a;
  Mary_Vector_t v_text; // Mary_String_t?
  uint8_t *pixel_buffer;
}
Mary_Text_t;

void Mary_Text_Create(Mary_Text_t *elem);
void Mary_Text_Destroy(Mary_Text_t *elem);
void Mary_Text_Text(Mary_Text_t *elem, uint16_t *text);
void Mary_Text_Render(Mary_Text_t *elem, Mary_Matrix_4x4f *projection);

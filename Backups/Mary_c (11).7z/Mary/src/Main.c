#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <Mary/Mary.h>

int main()
{
#if 0
  //////
  Mary_Hashmap_t hashmap;
  const Mary_Hashmap_i *hashmap_i = Mary_Hashmap();
  int key, val, out_val = 0;
  srand((uint32_t)time(0));

  hashmap_i->Create(&hashmap, sizeof(key), sizeof(val));
  for (int i = 0; i < 144000; ++i)
  {
    key = i, val = rand(); hashmap_i->Insert(&hashmap, &key, &val);
    hashmap_i->At(&hashmap, &key, &out_val);
    //printf("%i: %i\n", key, out_val);
  }
  hashmap_i->Destroy(&hashmap);
  
  Mary_Exit_Success();
  //////
#endif

  Mary_Start();

  const Mary_Window_i *window_i = Mary_Window();
  Mary_Window_t window;
  //Mary_Window_t window2;
  window_i->Create(&window);
  //window_i->Create(&window2);
  while (Mary_Window_Can_Render())
  {
    Mary_Window_Render();
  }
  window_i->Destroy(&window);
  //window_i->Destroy(&window2);

  Mary_Finish();

  puts("\nThank you for using the C programming language!");
  Mary_Exit_Success();
}

#define intern static
#include <stdlib.h>
#include <Mary/OS.h>
#include <Mary/OpenGL.h>
#include <Mary/Text.h>

void Mary_Text_Create(Mary_Text_t *elem);
void Mary_Text_Destroy(Mary_Text_t *elem);
void Mary_Text_Text(Mary_Text_t *elem, uint16_t *text);
intern void Mary_Text_Buffer(Mary_Text_t *elem);
void Mary_Text_Render(Mary_Text_t *elem, Mary_Matrix_4x4f *projection);

// do global font stuff in here

void Mary_Text_Create(Mary_Text_t *elem)
{
  elem->x = 0;
  elem->y = 0;
  elem->w = 100;
  elem->h = 100;
  Mary_Vector_Create(&elem->v_text, sizeof(uint16_t));
}

void Mary_Text_Destroy(Mary_Text_t *elem)
{
  Mary_Vector_Destroy(&elem->v_text);
  free(elem->pixel_buffer);
}

void Mary_Text_Text(Mary_Text_t *elem, uint16_t *text)
{
  Mary_Vector_t *v_text = &elem->v_text;

  if (!Mary_Vector_Is_Empty(v_text))
  {
    Mary_Vector_Empty(v_text);
  }

  uint16_t *c = text;
  while (1)
  {
    Mary_Vector_Push_Back(v_text, c);
    c += 2;
    if (&c == '\0')
    {
      break;
    }
  }
}

intern void Mary_Text_Buffer(Mary_Text_t *elem)
{
  Mary_OpenGL_g g_opengl = Mary_OpenGL();
  Mary_Vector_t *v_text = &elem->v_text;
  uint8_t *pixel_buffer = elem->pixel_buffer;
  int width = (int)elem->w;
  int height = (int)elem->h;
  unsigned int total_bytes = width * height * 4;

  BITMAPINFO bmi;
  memset(&bmi, 0, sizeof(bmi));
  bmi.bmiHeader.biSize = sizeof(bmi.bmiHeader);
  bmi.bmiHeader.biWidth = width;
  bmi.bmiHeader.biHeight = -height;
  bmi.bmiHeader.biPlanes = 1;
  bmi.bmiHeader.biBitCount = 32;
  bmi.bmiHeader.biCompression = BI_RGB;
  bmi.bmiHeader.biSizeImage = total_bytes;

  void *buffer;
  HDC memDC = CreateCompatibleDC(g_opengl.win32_context);
  HBITMAP memBM = CreateDIBSection(memDC, &bmi, DIB_RGB_COLORS, &buffer, 0, 0);
  SelectObject(memDC, memBM);

  RECT rect;
  rect.left = 0;
  rect.top = 0;
  rect.right = width + 1;
  rect.bottom = height + 1;

  SetBkColor(memDC, RGB(0, 0, 0)); // can invert these two for highlight!
  SetTextColor(memDC, RGB(255, 255, 255));
  //HGDIOBJ old_font = SelectObject(memDC, Win32FontHandle());

  GdiFlush();
  DrawTextExW
    ( memDC
    , (wchar_t *)v_text
    , (int)v_text->size
    , &rect
    , DT_LEFT | DT_WORDBREAK // temp
    , 0
    );

  free(pixel_buffer);
  pixel_buffer = (uint8_t *)malloc(total_bytes);
  GdiFlush();
  memcpy(pixel_buffer, buffer, total_bytes);

  //SelectObject(memDC, old_font);
  DeleteObject(memBM);
  DeleteDC(memDC);
}

void Mary_Text_Render(Mary_Text_t *elem, Mary_Matrix_4x4f *projection)
{
  static float vertices[] =
  {
    0.0f, 0.0f, 
    1.0f, 0.0f,
    1.0f, 1.0f,
    0.0f, 1.0f
  };
  static unsigned int indices[] =
  {
    0, 1, 2,
    2, 3, 0
  };

  static GLuint program = 0;
  if (!program)
  {
    program = Mary_OpenGL_Program("Mary/shaders/text_v.shader", "Mary/shaders/text_f.shader");
    glUseProgram(program);
  }
  static GLuint VAO = 0;
  if (!VAO)
  {
    glGenVertexArrays(1, &VAO);
    glBindVertexArray(VAO);
  }
  static GLuint VBO = 0;
  if (!VBO)
  {
    glGenBuffers(1, &VBO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, sizeof(float) * 2, (void *)0);
    glEnableVertexAttribArray(0);
  }
  static GLuint EBO = 0;
  if (!EBO)
  {
    glGenBuffers(1, &EBO);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
  }
  static GLuint texture = 0;
  if (!texture)
  {

  }

  // see if all variables are current

  GLint u_model = glGetUniformLocation(program, "model");
  Mary_Matrix_4x4f model = Mary_OpenGL_Identity();
  Mary_OpenGL_Scale(&model, elem->w, elem->h, 1.0f);
  Mary_OpenGL_Translate(&model, elem->x, elem->y, 0.0f);
  glUniformMatrix4fv(u_model, 1, GL_TRUE, model.matrix);

  GLint u_projection = glGetUniformLocation(program, "projection");
  glUniformMatrix4fv(u_projection, 1, GL_TRUE, projection->matrix);

  glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
}

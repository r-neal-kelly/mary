#pragma once

#include <stdint.h>
#include <Mary/Vector.h>

enum
{
  MARY_ELEMENT_WINDOW,
  MARY_ELEMENT_TEXT
};

enum
{
  MARY_EVENT_KEYBOARD,
  MARY_EVENT_MOUSE
};

typedef struct
{
  char type;
  void *window;
  void *parent;
  Mary_Vector_t children;
  Mary_Vector_t events;
}
Mary_Element_t;

typedef Mary_Vector_t Mary_Element_v;

typedef struct
{
  int type;
  void *event;
}
Mary_Event_t;

typedef struct
{
  const uint32_t key;
}
Mary_Event_Keyboard;

typedef struct
{
  const uint8_t button;
}
Mary_Event_Mouse;

// when we have events, we make these global objects and put them on a pool.
// then we send out Mary_Event_t's in each elem's event queue, but then point
// to the real events in the pool. this way everyone is getting the same information.
// it may be a little slower this way though. but once the pool is in the cache, every other
// even it easy to access locally.

void Mary_Element_Create(Mary_Element_t *element, char type);
void Mary_Element_Destroy(Mary_Element_t *element);
void Mary_Element_Window(Mary_Element_t *element, void *mary_window);
void Mary_Element_Parent(Mary_Element_t *element, Mary_Element_t *parent);

#define MARY_Element_Each(ELEMENT)\
  MARY_Vector_Each(ELEMENT.children, Mary_Element_t)

#include <stdio.h>
#include <stdlib.h>
#include <Mary/OS.h>
#include <Mary/OpenGL.h>
#include <Mary/Text.h>

MARY_PRIMITIVES;

static HDC g_win32_context = 0;
static GLuint g_VAO = 0;
static GLuint g_VBO = 0;
static GLuint g_EBO = 0;
static GLuint g_program = 0;
static GLint g_u_model = -1;
static GLint g_u_projection = -1;
static GLint g_u_color = -1;
static GLint g_u_texture = -1;

void Mary_Text_Start()
{
  ////// OpenGL Globals
  Mary_OpenGL_g g_opengl = Mary_OpenGL();
  g_win32_context = g_opengl.win32_context;
  ////// Vertex Array Object
  glGenVertexArrays(1, &g_VAO);
  glBindVertexArray(g_VAO);
  ////// Vertex Buffer Object
  float vertices[] =
  {
    0.0f, 0.0f, 0.0f, 0.0f,
    1.0f, 0.0f, 1.0f, 0.0f,
    1.0f, 1.0f, 1.0f, 1.0f,
    0.0f, 1.0f, 0.0f, 1.0f
  };
  glGenBuffers(1, &g_VBO);
  glBindBuffer(GL_ARRAY_BUFFER, g_VBO);
  glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_DYNAMIC_DRAW);
  glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, sizeof(float) * 4, (void *)0);
  glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(float) * 4, (void *)(sizeof(float) * 2));
  glEnableVertexAttribArray(0);
  glEnableVertexAttribArray(1);
  ////// Element Buffer Object
  unsigned int indices[] =
  {
    0, 1, 2,
    2, 3, 0
  };
  glGenBuffers(1, &g_EBO);
  glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, g_EBO);
  glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
  ////// Program
  g_program = Mary_OpenGL_Program("Mary/shaders/text_v.shader", "Mary/shaders/text_f.shader");
  ////// Uniforms
  g_u_model = glGetUniformLocation(g_program, "u_model");
  g_u_projection = glGetUniformLocation(g_program, "u_projection");
  g_u_color = glGetUniformLocation(g_program, "u_color");
  g_u_texture = glGetUniformLocation(g_program, "u_texture");
}

void Mary_Text_Finish()
{

}

void Mary_Text_Create(Mary_Text_t *elem, char bit_format, void *string, size_t opt_size, float width, float height)
{
  ////// Style
  elem->x = 0;
  elem->y = 0;
  elem->w = width;
  elem->h = height;
  elem->r = 0;
  elem->g = 0;
  elem->b = 0;
  elem->a = 1;
  ////// String, Lines, Cache
  Mary_String_Create(&elem->string, bit_format, string, opt_size);
  Mary_String_Format(&elem->string, 16);
  Mary_Wordmap_t line; Mary_Vector_Create(&elem->lines, sizeof(Mary_Wordmap_t), 64);
  Mary_Slice_t slice = { 0, 0 }; u16 *line_data; int line_units;
  MARY_Range(elem->string.data, u16, 0, elem->string.units)
  {
    if (range.val == '\n' || range.val == '\0')
    {
      slice.to_exclusive = range.idx + 1;
      line_data = (u16 *)(elem->string.data) + slice.from;
      line_units = (int)(slice.to_exclusive - slice.from);
      slice.from = range.idx + 1;
      line = Mary_OS_Text_To_Bitmap(line_data, line_units);
      Mary_Vector_Push_Back(&elem->lines, &line);
    }
  }
  
  ////// Texture
  glGenTextures(1, &elem->texture);
  glActiveTexture(GL_TEXTURE0); // maybe should have a vector that keeps a stack for all slots?
  glBindTexture(GL_TEXTURE_2D, elem->texture);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); // do these stick on texture object?
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
}

void Mary_Text_Destroy(Mary_Text_t *elem)
{
  // need to destroy everything in lines vector. needs to be made simpler.
  Mary_String_Destroy(&elem->string);
  //Mary_Vector_Destroy(&elem->words.widths);
  //free(&elem->words.line.data);
  glDeleteTextures(1, &elem->texture);
}

void Mary_Text_Render(Mary_Text_t *elem, Mary_Matrix_4x4f *projection)
{
  ////// Set VBO
  GLuint current_VBO; glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &current_VBO);
  if (current_VBO != g_VBO)
  {
    glBindVertexArray(g_VAO);
  }
  ////// Set Program
  GLuint current_program; glGetIntegerv(GL_CURRENT_PROGRAM, &current_program);
  if (current_program != g_program)
  {
    glUseProgram(g_program);
  }
  ////// Set Texture
  glActiveTexture(GL_TEXTURE0);
  GLuint current_texture; glGetIntegerv(GL_TEXTURE_BINDING_2D, &current_texture);
  if (current_texture != elem->texture)
  {
    glBindTexture(GL_TEXTURE_2D, elem->texture);
  }
  ////// Set Uniforms
  Mary_Matrix_4x4f model;
  glUniformMatrix4fv(g_u_projection, 1, GL_TRUE, projection->matrix);
  glUniform4f(g_u_color, elem->r, elem->g, elem->b, elem->a);
  glUniform1i(g_u_texture, 0);
  ////// Draw
  Mary_Wordmap_t words; float y = 0.0f;
  MARY_Range(elem->lines.data, Mary_Wordmap_t, 0, elem->lines.units)
  {
    words = range.val;
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, words.line.width, words.line.height, 0,
                 GL_BGRA, GL_UNSIGNED_BYTE, words.line.data);
    float x1 = 0.0f, x2 = 0.0f, x = 0.0f, w = 0.0f, h = (float)words.line.height;
    MARY_Range(words.widths.data, int, 0, words.widths.units)
    {
      w = (float)range.val;
      if (x + w > elem->w)
      {
        x = 0.0f, y += words.line.height;
        if (y > elem->h) return;
      }
      x2 = x1 + (w / words.line.width);
      float vertices[] =
      {
        0.0f, 0.0f, x1, 0.0f,
        1.0f, 0.0f, x2, 0.0f,
        1.0f, 1.0f, x2, 1.0f,
        0.0f, 1.0f, x1, 1.0f
      };
      glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_DYNAMIC_DRAW);
      model = Mary_OpenGL_Identity();
      Mary_OpenGL_Scale(&model, w, h, 1.0f);
      Mary_OpenGL_Translate(&model, x, y, 0.0f);
      glUniformMatrix4fv(g_u_model, 1, GL_TRUE, model.matrix);
      glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
      x1 = x2;
      x += w;
    }
    y += words.line.height;
    if (y > elem->h) return;
  }
}

void Mary_Text_Position(Mary_Text_t *elem, float x, float y)
{
  elem->x = x;
  elem->y = y;
}

void Mary_Text_Size(Mary_Text_t *elem, float w, float h)
{
  elem->w = w;
  elem->h = h;
}

void Mary_Text_Color(Mary_Text_t *elem, float r, float g, float b, float a)
{
  elem->r = r;
  elem->g = g;
  elem->b = b;
  elem->a = a;
}

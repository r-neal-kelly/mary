#include <stdlib.h>
#include <stdio.h>
#include <Mary/OS.h>
#include <Mary/OpenGL.h>

MARY_PRIMITIVES;

#if defined(_WIN32)
HDC dib_context;
BITMAPINFO dib_bmi;

void Mary_OS_Start()
{
  Mary_OpenGL_g g_opengl = Mary_OpenGL();
  HDC g_win32_context = g_opengl.win32_context;
  dib_context = CreateCompatibleDC(g_win32_context);
  SetBkColor(dib_context, RGB(0, 0, 0));
  SetTextColor(dib_context, RGB(255, 255, 255));

  memset(&dib_bmi, 0, sizeof(dib_bmi));
  dib_bmi.bmiHeader.biSize = sizeof(dib_bmi.bmiHeader);
  dib_bmi.bmiHeader.biWidth = 0;
  dib_bmi.bmiHeader.biHeight = 0;
  dib_bmi.bmiHeader.biPlanes = 1;
  dib_bmi.bmiHeader.biBitCount = 32;
  dib_bmi.bmiHeader.biCompression = BI_RGB;
  dib_bmi.bmiHeader.biSizeImage = 0;
}

void Mary_OS_Finish()
{
  DeleteDC(dib_context);
}

Mary_Wordmap_t Mary_OS_Text_To_Bitmap(uint16_t *text, int units)
{
  RECT rect = { 0, 0, ~0, 0 }; unsigned int flags = DT_LEFT | DT_NOCLIP | DT_SINGLELINE;
  DrawTextEx(dib_context, text, units, &rect, flags | DT_CALCRECT, 0);
  void *dib_buffer; HBITMAP dib_bitmap; int dib_bytes = rect.right * rect.bottom << 2;
  dib_bmi.bmiHeader.biWidth = rect.right;
  dib_bmi.bmiHeader.biHeight = -rect.bottom;
  dib_bmi.bmiHeader.biSizeImage = dib_bytes;
  dib_bitmap = CreateDIBSection(dib_context, &dib_bmi, DIB_RGB_COLORS, &dib_buffer, 0, 0);
  SelectObject(dib_context, dib_bitmap);

  DrawTextEx(dib_context, text, units, &rect, flags, 0);
  Mary_Wordmap_t wordmap;
  wordmap.line = (Mary_Bitmap_t) { malloc(dib_bytes), dib_bytes, (short)rect.right, (short)rect.bottom, 32 };
  memcpy(wordmap.line.data, dib_buffer, dib_bytes);
  Mary_Vector_Create(&wordmap.widths, sizeof(int), 64);

  Mary_Slice_t slice = { 0, 0 }; u16 *word_data; int word_units;
  MARY_Range(text, u16, 0, units)
  {
    if (range.val == ' ' || range.val == '\n' || range.val == '\0')
    {
      slice.to_exclusive = range.idx + 1;
      word_data = (u16 *)(text) + slice.from;
      word_units = (int)(slice.to_exclusive - slice.from);
      slice.from = range.idx + 1;
      DrawTextEx(dib_context, word_data, word_units, &rect, flags | DT_CALCRECT, 0);
      Mary_Vector_Push_Back(&wordmap.widths, &rect.right);
    }
  }

  DeleteObject(dib_bitmap);

  return wordmap;
}

// need a change font
#endif

#include <Mary/Element.h>
#include <Mary/Window.h>

MARY_PRIMITIVES;

void Mary_Element_Create(Mary_Element_t *element, char type)
{
  element->type = type; element->window = 0; element->parent = 0;
  Mary_Vector_Create(&element->children, sizeof(Mary_Element_t *), 0);
  Mary_Vector_Create(&element->events, sizeof(Mary_Event_t), 0);
}

void Mary_Element_Destroy(Mary_Element_t *element)
{
  element->window = 0; element->parent = 0;
  Mary_Vector_Destroy(&element->children);
}

void Mary_Element_Window(Mary_Element_t *element, void *mary_window)
{
  if (element->window)
  {
    // need to remove this elements 'events' from old window.
    element->window = mary_window;
  }
  MARY_Range(element->children.data, Mary_Element_t, 0, element->children.units)
  {
    Mary_Element_Window(range.ptr, mary_window);
  }
}

void Mary_Element_Parent(Mary_Element_t *element, Mary_Element_t *parent)
{
  // maybe we should not allow windows to be parented. but it is a cool idea to have them that way.
  // it's just that windows do not resemble other elements as much as the others do.
}

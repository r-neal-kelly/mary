#pragma once

#include <Mary/Utils.h>

typedef struct
{
  void *data;
  size_t bytes;
  size_t unit;
  size_t size; // units? it would be less ambiguous
}
Mary_Vector_t;

void Mary_Vector_Create(Mary_Vector_t *vector, size_t unit, size_t opt_reserve);
void Mary_Vector_Create_With(Mary_Vector_t *v, size_t unit, Mary_Pointer_t mary_ptr);
void Mary_Vector_Create_Copy(Mary_Vector_t *v, size_t unit, Mary_Pointer_t mary_ptr, size_t size);
void Mary_Vector_Destroy(Mary_Vector_t *vector);
void Mary_Vector_Reserve(Mary_Vector_t *vector, size_t size);
void Mary_Vector_Fit(Mary_Vector_t *vector);
void Mary_Vector_Insert(Mary_Vector_t *vector, size_t index, void *in_elem); // Push_At?
void Mary_Vector_Eject(Mary_Vector_t *vector, size_t index, void *out_elem); // Pop_At?
void Mary_Vector_Assign(Mary_Vector_t *vector, size_t index, void *in_elem);
void Mary_Vector_Exchange(Mary_Vector_t *vector, size_t index, void *in_elem, void *out_elem);
void Mary_Vector_Add_Slice(Mary_Vector_t *vector, size_t from, size_t to_exclusive, void *opt_in_elems);
void Mary_Vector_Delete_Slice(Mary_Vector_t *vector, size_t from, size_t to_exclusive);
void Mary_Vector_Copy_Slice(Mary_Vector_t *vector, size_t from, size_t to_exclusive, void *out_elems);
void Mary_Vector_Take_Slice(Mary_Vector_t *vector, size_t from, size_t to_exclusive, void *out_elems);
void Mary_Vector_Put_Slice(Mary_Vector_t *vector, size_t from, size_t to_exclusive, void *in_elems);
void Mary_Vector_Push_Back(Mary_Vector_t *vector, void *in_elem);
void Mary_Vector_Push_Front(Mary_Vector_t *vector, void *in_elem);
void Mary_Vector_Pop_Back(Mary_Vector_t *vector, void *out_elem);
void Mary_Vector_Pop_Front(Mary_Vector_t *vector, void *out_elem);
void Mary_Vector_At(Mary_Vector_t *vector, size_t index, void *out_elem);
char Mary_Vector_Has_At(Mary_Vector_t *vector, size_t index);
void *Mary_Vector_Point(Mary_Vector_t *vector, size_t index);
void Mary_Vector_Back(Mary_Vector_t *vector, void *out_elem);
void Mary_Vector_Front(Mary_Vector_t *vector, void *out_elem);
void Mary_Vector_Empty(Mary_Vector_t *vector);
char Mary_Vector_Is_Empty(Mary_Vector_t *vector);
void Mary_Vector_Resize(Mary_Vector_t *vector, size_t size);
void Mary_Vector_Fill(Mary_Vector_t *vector, void *in_elem);
void Mary_Vector_Rotate(Mary_Vector_t *vector, void *out_elem);
void Mary_Vector_Reverse(Mary_Vector_t *vector);
char Mary_Vector_Contains(Mary_Vector_t *vector, void *elem);
size_t Mary_Vector_Index_Of(Mary_Vector_t *vector, void *elem, char *out_was_found);
void Mary_Vector_Erase_At(Mary_Vector_t *vector, size_t index);
void Mary_Vector_Erase(Mary_Vector_t *vector, void *elem);
void Mary_Vector_Sort(Mary_Vector_t *vector);

#define MARY_Vector_Create(VECTOR, TYPE, OPT_RESERVE)\
  Mary_Vector_Create(&VECTOR, sizeof(TYPE), (OPT_RESERVE))
#define MARY_Vector_Create_With(VECTOR, TYPE, MARY_PTR)\
  Mary_Vector_Create_With(&VECTOR, sizeof(TYPE), (Mary_p)(MARY_PTR))
#define MARY_Vector_Create_Copy(VECTOR, TYPE, MARY_PTR, SIZE)\
  Mary_Vector_Create_Copy(&VECTOR, sizeof(TYPE), (Mary_p)(MARY_PTR), (SIZE))
#define MARY_Vector_Create_On_Stack(VECTOR, TYPE, SIZE) TYPE VECTOR##_a[SIZE];\
  Mary_Vector_Create_With(&VECTOR, sizeof(TYPE), (Mary_p) { VECTOR##_a, sizeof(TYPE) * (SIZE) })
#define MARY_Vector_Destroy(VECTOR)\
  Mary_Vector_Destroy(&VECTOR);
#define MARY_Vector_Push_Back(VECTOR, IN_ELEM)\
  Mary_Vector_Push_Back(&VECTOR, &IN_ELEM)
#define MARY_Vector_At(VECTOR, INDEX, OUT_ELEM)\
  Mary_Vector_At(&VECTOR, (INDEX), &OUT_ELEM)
#define MARY_Vector_Assign(VECTOR, INDEX, IN_ELEM)\
  Mary_Vector_Assign(&VECTOR, (INDEX), &IN_ELEM)
#define MARY_Vector_Add_Slice(VECTOR, FROM, TO_EXCLUSIVE)\
  Mary_Vector_Add_Slice(&VECTOR, (FROM), (TO_EXCLUSIVE))
#define MARY_Vector_Delete_Slice(VECTOR, FROM, TO_EXCLUSIVE)\
  Mary_Vector_Delete_Slice(&VECTOR, (FROM), (TO_EXCLUSIVE))
#define MARY_Vector_Copy_Slice(VECTOR, FROM, TO_EXCLUSIVE, OUT_ELEMS)\
  Mary_Vector_Copy_Slice(&VECTOR, (FROM), (TO_EXCLUSIVE), &OUT_ELEMS)
#define MARY_Vector_Take_Slice(VECTOR, FROM, TO_EXCLUSIVE, OUT_ELEMS)\
  Mary_Vector_Take_Slice(&VECTOR, (FROM), (TO_EXCLUSIVE), &OUT_ELEMS)
#define MARY_Vector_Point(VECTOR, INDEX, OUT_POINTER)\
  Mary_Vector_Point(&VECTOR, (INDEX), &OUT_POINTER)
